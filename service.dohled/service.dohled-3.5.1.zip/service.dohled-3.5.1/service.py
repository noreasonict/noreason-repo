import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import socket
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
import uuid
import subprocess
import ssl
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta
from ftplib import FTP
import shutil
import random
import sqlite3
import re

# Přidat cestu k bundlované websocket knihovně
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
sys.path.insert(0, ADDON_PATH)

# Import websocket knihovny (bundlovaná s addonem)
try:
    import websocket
    WEBSOCKET_AVAILABLE = True
    xbmc.log("[Dohled] WebSocket knihovna načtena", xbmc.LOGINFO)
except ImportError:
    WEBSOCKET_AVAILABLE = False
    xbmc.log("[Dohled] WebSocket knihovna není dostupná, použije se HTTP fallback", xbmc.LOGWARNING)

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')
DEVICE_ID_FILE = os.path.join(PROFILE_DIR, 'device_id.txt')
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
TIME_SYNC_FILE = "/storage/.kodi/userdata/time_synced.flag"
STOP_SMYCKY_FLAG = "/storage/.kodi/userdata/stop_smycky_playlist.flag"  # Signal pro zastavení playlistu v service.smycky
CURRENT_PLAYING_FILE = "/storage/.kodi/userdata/current_playing.txt"  # Sdílení aktuálně přehrávaného souboru z service.smycky
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"  # Heartbeat pro externí watchdog
WATCHDOG_SCRIPT = "/storage/.kodi/temp/dohled_watchdog.py"  # Self-spawned watchdog daemon
WATCHDOG_PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"  # PID watchdogu
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# SSL kontext pro HTTPS requesty - ověřuje certifikáty (bezpečné)
# Fallback na neověřené spojení pokud certifikát selže (zpětná kompatibilita)
_ssl_context = None
def get_ssl_context():
    global _ssl_context
    if _ssl_context is None:
        try:
            _ssl_context = ssl.create_default_context()
            xbmc.log("[Dohled] SSL: Používám ověřené certifikáty", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] SSL: Fallback na neověřené ({e})", xbmc.LOGWARNING)
            _ssl_context = ssl.create_default_context()
            _ssl_context.check_hostname = False
            _ssl_context.verify_mode = ssl.CERT_NONE
    return _ssl_context

def api_request(url, data=None, method=None, timeout=10):
    """HTTP request s Authorization headerem a SSL ověřením.
    Při SSL chybě automaticky zkusí bez ověření certifikátu (zpětná kompatibilita)."""
    headers = {
        'Authorization': f'Bearer {API_KEY}'
    }
    if data is not None:
        headers['Content-Type'] = 'application/json'
        encoded = json.dumps(data).encode('utf-8') if isinstance(data, dict) else data
    else:
        encoded = None

    def _make_request(ctx):
        if encoded is not None:
            req = urllib.request.Request(url, data=encoded, headers=headers, method=method or 'POST')
        else:
            req = urllib.request.Request(url, headers=headers, method=method or 'GET')
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as response:
            return json.loads(response.read().decode())

    ctx = get_ssl_context()
    try:
        return _make_request(ctx)
    except ssl.SSLError as e:
        xbmc.log(f"[Dohled] SSL chyba, zkouším bez ověření: {e}", xbmc.LOGWARNING)
    except urllib.error.URLError as e:
        if 'SSL' in str(e) or 'CERTIFICATE' in str(e).upper():
            xbmc.log(f"[Dohled] SSL chyba (URLError), zkouším bez ověření: {e}", xbmc.LOGWARNING)
        else:
            raise
    # Fallback bez ověření certifikátu
    fallback_ctx = ssl.create_default_context()
    fallback_ctx.check_hostname = False
    fallback_ctx.verify_mode = ssl.CERT_NONE
    return _make_request(fallback_ctx)

# WebSocket konfigurace
WS_URL = "wss://apidohled.noreason.eu/ws/"
WS_RECONNECT_INTERVAL = 5  # Sekund mezi pokusy o reconnect
WS_PING_INTERVAL = 30  # Sekund mezi ping zprávami

# Monotonic čas startu addonu - nezávislý na změnách systémového času (NTP sync)
# time.monotonic() je nezávislé na NTP/čase, takže můžeme později vypočítat správný boot_time
# Toto se změní při každém restartu Kodi (i bez rebootu celého systému)
ADDON_START_MONOTONIC = time.monotonic()
WS_MONITORING_INTERVAL = 30  # Sekund mezi plnými monitoring zprávami přes WebSocket
WS_STATE_CHECK_INTERVAL = 2  # Sekund mezi kontrolami stavu (rychlá detekce změn)
WS_STATE_HEARTBEAT_INTERVAL = 10  # Sekund - max interval pro heartbeat i bez změny stavu
LOG_UPLOAD_INTERVAL = 60  # Sekund mezi odesilanim logu na server
LOG_UPLOAD_MAX_SIZE = 500 * 1024  # Max 500 KB per upload

# Správa úložiště
VIDEO_DIR = "/storage/videos/"
IMAGE_DIR = "/storage/pictures/"  # Obrázky patří do /storage/pictures/, ne videos!
# Staging složka pro stahování. MUSÍ být na stejném filesystému jako VIDEO_DIR/IMAGE_DIR.
# NESMÍ být /tmp - to je na Kodi boxu tmpfs v RAM (~512 MB), velké soubory se tam nevejdou
# (1GB video -> [Errno 28] No space left on device). /storage má desítky GB volných.
DOWNLOAD_STAGING_DIR = "/storage/"

# Zámky stahování PER SOUBOR. Dvě vlákna (download_only z nastavení souboru lokality
# + download_and_play od technika) stahovala TÝŽ soubor do TÉHOŽ staging souboru
# .downloading_<název>, vzájemně si ho přepsala/odstranila -> přehrání selhalo a auto-play
# zůstal zablokovaný (nalezeno 2.9.2026 testem V23). Druhé vlákno teď počká a když už je
# soubor stažený ve správné velikosti, stahování přeskočí.
_zamky_stahovani = {}
_zamky_stahovani_guard = threading.Lock()


def nazev_pro_hlaseni(f):
    """Název souboru pro monitoring: lokální soubory VŽDY jen basename (zařízení je ukládá
    bez cesty), stream URL a playlist string beze změny. Dřív se hlásil jednou s podsložkou
    ('Oresi/x.jpg' z položky playlistu) a jindy bez ní - server to musel normalizovat na
    devíti místech (2.9.2026); od teď je hlášení jednotné už u zdroje."""
    if not f:
        return f
    if '://' in f or f.startswith('playlist:'):
        return f
    return os.path.basename(f)


def stream_dostupny(url, timeout=6.0):
    """Rychlá kontrola dostupnosti streamu PŘED předáním Kodi.

    PROČ: neúspěšný OpenFile v Kodi zavře naše krycí okno a ukáže HOME + chybový dialog
    (změřeno 2.9.2026 v E4: ~170 ms menu při každém pokusu, pořadí zavírání dialogů
    nepomůže). Mrtvou URL proto Kodi vůbec nedostane - krycí černá zůstane a watchdog
    zkouší znovu bez přehrávání. http/https: GET s krátkým čtením; rtsp/rtmp: TCP connect;
    udp/rtp (multicast) ověřit nelze -> True.
    """
    try:
        u = urllib.parse.urlparse(url)
        scheme = (u.scheme or "").lower()
        if scheme in ("http", "https"):
            ctx = ssl._create_unverified_context() if scheme == "https" else None
            req = urllib.request.Request(url, headers={"User-Agent": "Kodi-dohled"})
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                    r.read(1024)
            except urllib.error.HTTPError:
                # Server odpovedel (401/403/404...): ZIJE - autentizaci v URL, Range apod.
                # zvlada Kodi; tady se chytaji jen MRTVE cile (odmitnute spojeni, timeout, DNS).
                return True
            return True
        if scheme in ("rtsp", "rtmp", "rtmps"):
            port = u.port or {"rtsp": 554, "rtmp": 1935, "rtmps": 443}[scheme]
            with socket.create_connection((u.hostname, port), timeout=timeout):
                pass
            return True
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Stream nedostupný ({e}): {url}", xbmc.LOGWARNING)
        return False


def zamek_stahovani(local_filename):
    with _zamky_stahovani_guard:
        z = _zamky_stahovani.get(local_filename)
        if z is None:
            z = threading.Lock()
            _zamky_stahovani[local_filename] = z
        return z
MIN_FREE_SPACE_MB = 1000  # Minimální volné místo v MB - jediné kritérium pro mazání souborů

# Soubor pro sledování restartů
REBOOT_TRACK_FILE = "/storage/.kodi/userdata/reboot_log.txt"


def get_local_media_path(filename):
    """
    Vrátí správnou lokální cestu pro mediální soubor.
    Obrázky jdou do IMAGE_DIR, videa do VIDEO_DIR.

    Args:
        filename: Název souboru (může obsahovat cestu, použije se jen basename)

    Returns:
        Úplná cesta k souboru nebo None pokud filename je prázdný
    """
    if not filename:
        return None
    base_filename = os.path.basename(filename)
    if is_image_file(base_filename):
        return os.path.join(IMAGE_DIR, base_filename)
    else:
        return os.path.join(VIDEO_DIR, base_filename)


def mark_reboot(source="manual"):
    """
    Zaznamená restart do REBOOT_TRACK_FILE před provedením restartu.
    Volat VŽDY před os.system("reboot") nebo xbmc.executebuiltin("Reboot").

    Args:
        source: Zdroj restartu (manual, scheduled, update_video, refresh_config, setup)
    """
    try:
        from datetime import datetime
        now = datetime.now()
        date_str = now.strftime('%Y-%m-%d')
        time_str = now.strftime('%Y-%m-%d %H:%M:%S')

        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {date_str}\n")
            f.write(f"Čas restartu: {time_str}\n")
            f.write(f"Zdroj: {source}\n")
            f.flush()
            os.fsync(f.fileno())

        xbmc.log(f"[Dohled] Zaznamenán restart: {time_str} (zdroj: {source})", xbmc.LOGINFO)
        time.sleep(0.5)  # Krátká pauza pro jistotu zápisu na disk
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při záznamu restartu: {e}", xbmc.LOGERROR)


# ======= OCHRANA PROTI SMYČCE AUTOMATICKÝCH RESTARTŮ =======
# Zabraňuje boot-loopu: pokud addon provede příliš mnoho automatických restartů
# za sebou (bez toho, aby zařízení bylo delší dobu stabilní), další automatické
# restarty se potlačí. Chrání proti VŠEM automatickým reboot cestám (scheduled
# reboot, RestartApp po instalaci inputstream / self-update), i kdyby jejich vlastní
# logika selhala (např. skok systémového času). Manuální / backend příkazy tím
# záměrně neprocházejí - ty jsou vždy vyžádané.
AUTO_REBOOT_COUNTER_FILE = "/storage/.kodi/userdata/dohled_auto_reboot_count.txt"
AUTO_REBOOT_MAX = 3               # max po sobě jdoucích automatických restartů
AUTO_REBOOT_STABLE_UPTIME = 1800  # sekund běhu (monotonic), po kterých se počítadlo vynuluje


def _read_auto_reboot_count():
    try:
        with open(AUTO_REBOOT_COUNTER_FILE, "r", encoding="utf-8") as f:
            return int((f.read().strip() or "0"))
    except Exception:
        return 0


def _write_auto_reboot_count(value):
    try:
        with open(AUTO_REBOOT_COUNTER_FILE, "w", encoding="utf-8") as f:
            f.write(str(int(value)))
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zápisu auto-reboot počítadla: {e}", xbmc.LOGWARNING)


def can_auto_reboot(source="scheduled"):
    """
    Vrátí True pokud je bezpečné provést AUTOMATICKÝ restart, a zvýší počítadlo.
    Pokud proběhlo už příliš mnoho rychlých automatických restartů za sebou
    (bez stabilního uptime), vrátí False -> restart se NEPROVEDE (rozbije boot-loop).
    Fail-open: při chybě FS vrátí True, aby se neblokovaly legitimní restarty.
    """
    try:
        count = _read_auto_reboot_count()
        if count >= AUTO_REBOOT_MAX:
            xbmc.log(f"[Dohled] SMYČKA RESTARTŮ detekována ({count}x, zdroj: {source}) - automatický restart POTLAČEN", xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification("Dohled", "Detekována smyčka restartů - restart potlačen", xbmcgui.NOTIFICATION_WARNING, 8000)
            except Exception:
                pass
            return False
        _write_auto_reboot_count(count + 1)
        xbmc.log(f"[Dohled] Automatický restart povolen (počítadlo {count + 1}/{AUTO_REBOOT_MAX}, zdroj: {source})", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba v can_auto_reboot ({e}), povoluji restart (fail-open)", xbmc.LOGWARNING)
        return True


def reset_auto_reboot_counter_when_stable():
    """
    Vynuluje počítadlo automatických restartů, jakmile zařízení běží stabilně.
    Uptime se měří přes time.monotonic() (nezávislé na skoku systémového času).
    Když se zařízení restartuje ve smyčce (< AUTO_REBOOT_STABLE_UPTIME mezi resty),
    počítadlo se nikdy nevynuluje a can_auto_reboot() smyčku po AUTO_REBOOT_MAX zastaví.
    """
    monitor = xbmc.Monitor()
    while (time.monotonic() - ADDON_START_MONOTONIC) < AUTO_REBOOT_STABLE_UPTIME:
        remaining = AUTO_REBOOT_STABLE_UPTIME - (time.monotonic() - ADDON_START_MONOTONIC)
        if monitor.waitForAbort(min(60, max(1, remaining))):
            return
    _write_auto_reboot_count(0)
    xbmc.log("[Dohled] Zařízení běží stabilně, počítadlo automatických restartů vynulováno", xbmc.LOGINFO)
    while not monitor.abortRequested():
        if monitor.waitForAbort(3600):
            return
        _write_auto_reboot_count(0)


def write_heartbeat():
    """
    Zapíše aktuální timestamp do heartbeat souboru.
    Externí watchdog kontroluje tento soubor a restartuje Kodi pokud je příliš starý.
    """
    try:
        with open(HEARTBEAT_FILE, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass  # Tiché selhání - nechceme crashovat kvůli heartbeatu


def spawn_watchdog_daemon():
    """
    Vytvoří a spustí watchdog jako oddělený daemon proces.
    Watchdog běží NEZÁVISLE na Kodi a přežije i když Kodi addon zabije.
    Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi.
    """
    # Watchdog script - self-contained Python (bez xbmc importů)
    watchdog_code = '''#!/usr/bin/env python3
"""
Dohled Watchdog Daemon - automaticky restartuje Kodi pokud service.dohled přestane fungovat.
Tento script běží jako ODDĚLENÝ PROCES, nezávisle na Kodi.
"""
import os
import sys
import time
import signal

# Konfigurace
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"
PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"
LOG_FILE = "/storage/.kodi/temp/dohled_watchdog.log"
CHECK_INTERVAL = 60  # Kontrolovat každých 60 sekund
MAX_HEARTBEAT_AGE = 600  # Max stáří heartbeatu (10 minut)
STARTUP_GRACE_PERIOD = 300  # 5 minut po startu čekat na service.dohled

def log(message):
    """Zapíše zprávu do logu."""
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, 'a') as f:
            f.write(f"[{timestamp}] {message}\\n")
    except:
        pass

def get_heartbeat_age():
    """Vrátí stáří heartbeat souboru v sekundách, nebo None pokud neexistuje."""
    try:
        if not os.path.exists(HEARTBEAT_FILE):
            return None
        with open(HEARTBEAT_FILE, 'r') as f:
            last_beat = float(f.read().strip())
        return time.time() - last_beat
    except:
        return None

def restart_kodi():
    """Restartuje Kodi přes systemctl (přežije pád Kodi)."""
    log("RESTARTUJI KODI - service.dohled neodpovídá!")
    try:
        os.remove(HEARTBEAT_FILE)
    except:
        pass
    # Restart přes systemctl - funguje i když Kodi neodpovídá
    os.system("systemctl restart kodi")
    sys.exit(0)  # Watchdog se ukončí, nový se spustí s novým Kodi

def check_existing_watchdog():
    """Zkontroluje a ukončí existující watchdog pokud běží."""
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, 'r') as f:
                old_pid = int(f.read().strip())
            # Zkontrolovat jestli proces běží
            os.kill(old_pid, 0)  # Pokud neběží, vyhodí výjimku
            # Proces běží - ukončit ho
            os.kill(old_pid, signal.SIGTERM)
            time.sleep(1)
            try:
                os.kill(old_pid, signal.SIGKILL)
            except:
                pass
            log(f"Ukončen starý watchdog PID {old_pid}")
        except (ProcessLookupError, ValueError, FileNotFoundError):
            pass  # Proces neběží nebo špatný PID
        try:
            os.remove(PID_FILE)
        except:
            pass

def write_pid():
    """Zapíše PID do souboru."""
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

def main():
    # Ukončit starý watchdog
    check_existing_watchdog()

    # Zapsat náš PID
    write_pid()

    log(f"Watchdog daemon spuštěn (PID {os.getpid()})")
    log(f"Grace period: {STARTUP_GRACE_PERIOD}s, Max heartbeat age: {MAX_HEARTBEAT_AGE}s")

    # Startup grace period
    log(f"Čekám {STARTUP_GRACE_PERIOD}s na spuštění service.dohled...")
    time.sleep(STARTUP_GRACE_PERIOD)
    log("Grace period dokončena, začínám monitorovat heartbeat")

    # Hlavní smyčka
    while True:
        age = get_heartbeat_age()

        if age is None:
            log("Heartbeat soubor neexistuje, čekám...")
        elif age > 86400:
            # Nereálně velké stáří = skok systémového času dopředu (ne mrtvý addon).
            # NErestartovat kvůli skoku hodin - jen počkat na další heartbeat.
            log(f"Heartbeat stáří {int(age)}s je nereálné (skok hodin?), restart NEProveden")
        elif age < 0:
            # Záporné stáří = hodiny se posunuly zpět; heartbeat je fakticky čerstvý.
            log(f"Heartbeat stáří {int(age)}s záporné (skok hodin zpět), ignoruji")
        elif age > MAX_HEARTBEAT_AGE:
            log(f"Heartbeat je starý {int(age)}s (max {MAX_HEARTBEAT_AGE}s)")
            restart_kodi()
            return

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    # Double-fork pro plnou daemonizaci
    if os.fork() > 0:
        sys.exit(0)  # Parent exits

    os.setsid()  # Nová session

    if os.fork() > 0:
        sys.exit(0)  # First child exits

    # Druhé dítě je daemon
    # Uzavřít file descriptory
    sys.stdin.close()
    sys.stdout.close()
    sys.stderr.close()

    # Redirect to /dev/null
    fd = os.open('/dev/null', os.O_RDWR)
    os.dup2(fd, 0)
    os.dup2(fd, 1)
    os.dup2(fd, 2)

    main()
'''

    try:
        # Zapsat watchdog script
        with open(WATCHDOG_SCRIPT, 'w') as f:
            f.write(watchdog_code)
        os.chmod(WATCHDOG_SCRIPT, 0o755)

        # Spustit watchdog jako samostatný proces
        # Použijeme os.system s nohup aby proces přežil ukončení rodiče
        subprocess.Popen(
            ['python3', WATCHDOG_SCRIPT],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        xbmc.log("[Dohled] Watchdog daemon spuštěn", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při spouštění watchdog daemonu: {e}", xbmc.LOGERROR)


# Podporované formáty souborů
VIDEO_EXTENSIONS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

# Výchozí doba zobrazení obrázku (v sekundách)
DEFAULT_IMAGE_DISPLAY_TIME = 10

# Texture cache - pro detekci a opravu černé obrazovky
TEXTURE_DB_PATH = "/storage/.kodi/userdata/Database/Textures13.db"
THUMBNAILS_PATH = "/storage/.kodi/userdata/Thumbnails"
BLACK_SCREEN_MAX_RETRIES = 2
BLACK_SCREEN_VERIFY_DELAY = 0.5  # sekundy čekání na zobrazení
KODI_LOG_PATH = "/storage/.kodi/temp/kodi.log"
BLACK_SCREEN_LOG_MONITOR_INTERVAL = 0.5  # sekundy mezi kontrolami logu

# Sledování aktuálně zobrazeného obrázku (pro monitoring)
# Nastavuje se při play_file/play_playlist, None když hraje video nebo nic
current_displayed_image = None

# Sledování uživatelem ručně puštěného souboru
# Monitoring loop nebude přepisovat soubor dokud je toto nastaveno
user_initiated_file = None

# Flag pro manuální zastavení - monitoring loop nebude auto-startovat
# Nastavuje se při stop příkazu, resetuje se při play/play_file/play_playlist
user_stopped = False

# PAUZA PLAYLISTU. Nestaci pauznout prehravac: obrazek se zobrazuje pres ShowPicture,
# takze player.isPlaying() je False a puvodni pause() nad obrazkem NIC NEUDELAL
# (zmereno 1.9.2026: prikaz dorazil, ale playlist se do 8 s posunul na dalsi polozku).
# Playlistove smycky proto tenhle priznak respektuji a nepokracuji dal, dokud trva.
playlist_paused = False


def is_playlist_paused():
    return playlist_paused


# Per-device trvalé ztlumení (příznak Muted z API) - vynucuje monitoring loop
device_muted = False

# Uložení posledního stopnutého obsahu pro možnost obnovení přehrávání
# Formát: {'type': 'single'/'playlist', 'file': 'filename', 'files': ['file1', 'file2']}
last_stopped_content = None

# Flag pro nový obsah čekající na restart - zabrání auto-play nového obsahu
# Nastavuje se při download_only/download_only_playlist, resetuje se při restartu
pending_new_content = False

# Tracking čerstvě stažených souborů pro správné přehrávání obrázků
# {filename: timestamp} - soubory stažené v posledních 60 sekundách
# play_file handler kontroluje tuto dict a volá show_picture_safe s freshly_downloaded=True
recently_downloaded_files = {}
RECENTLY_DOWNLOADED_TTL = 60  # sekund - jak dlouho považovat soubor za "čerstvě stažený"


# === ODSTRANĚNO: BLACK OVERLAY - způsobovalo problémy ===
# Veškeré překrývání a skrývání Kodi UI bylo odstraněno pro stabilitu


def silent_install_addon(addon_id, zip_url, origin='repository.libreelec.tv'):
    """Tichá instalace addonu - stáhne ZIP, rozbalí do addons, zaregistruje v DB. Bez GUI."""
    import zipfile
    import sqlite3
    addons_dir = "/storage/.kodi/addons"
    addon_path = os.path.join(addons_dir, addon_id)
    tmp_zip = f"/tmp/{addon_id}.zip"

    try:
        # Stáhnout ZIP
        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: stahuji z {zip_url}", xbmc.LOGINFO)
        urllib.request.urlretrieve(zip_url, tmp_zip)

        # Rozbalit
        with zipfile.ZipFile(tmp_zip, 'r') as z:
            z.extractall(addons_dir)
        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: rozbaleno do {addon_path}", xbmc.LOGINFO)

        # Zaregistrovat v DB
        db_path = None
        db_dir = "/storage/.kodi/userdata/Database"
        for f in sorted(os.listdir(db_dir), reverse=True):
            if f.startswith("Addons") and f.endswith(".db"):
                db_path = os.path.join(db_dir, f)
                break

        if db_path:
            conn = sqlite3.connect(db_path)
            c = conn.cursor()
            c.execute(
                "INSERT OR REPLACE INTO installed (addonID, enabled, installDate, origin, lastUpdated, lastUsed) "
                "VALUES (?, 1, datetime('now'), ?, datetime('now'), datetime('now'))",
                (addon_id, origin)
            )
            conn.commit()
            conn.close()
            xbmc.log(f"[Dohled] Tichá instalace {addon_id}: zaregistrováno v DB ({db_path})", xbmc.LOGINFO)

        # Uklidit
        os.remove(tmp_zip)

        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: HOTOVO (vyžaduje restart Kodi)", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Tichá instalace {addon_id} selhala: {e}", xbmc.LOGERROR)
        if os.path.exists(tmp_zip):
            try:
                os.remove(tmp_zip)
            except:
                pass
        return False


def ensure_inputstream_addons():
    """Zajistí tichou instalaci inputstream addonů potřebných pro streamy."""
    import platform
    arch = platform.machine()
    if arch == 'aarch64':
        base = 'https://addons.libreelec.tv/12.2.0/ARMv8/aarch64'
    else:
        base = 'https://addons.libreelec.tv/12.2.0/ARMv7/arm'
    xbmc.log(f"[Dohled] Architektura: {arch}, repo: {base}", xbmc.LOGINFO)
    addons = {
        'inputstream.ffmpegdirect': f'{base}/inputstream.ffmpegdirect/inputstream.ffmpegdirect-21.3.8.3.zip',
        'inputstream.adaptive': f'{base}/inputstream.adaptive/inputstream.adaptive-21.5.18.1.zip',
    }
    needs_restart = False
    for addon_id, zip_url in addons.items():
        if not xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
            xbmc.log(f"[Dohled] Addon {addon_id} chybí, spouštím tichou instalaci", xbmc.LOGINFO)
            if silent_install_addon(addon_id, zip_url):
                needs_restart = True
        else:
            xbmc.log(f"[Dohled] Addon {addon_id} již nainstalován", xbmc.LOGINFO)

    if needs_restart:
        # Pojistka proti smyčce: kdyby se addon po instalaci nikdy nezaregistroval
        # jako System.HasAddon, RestartApp by se opakoval na každém bootu.
        if not can_auto_reboot("inputstream"):
            xbmc.log("[Dohled] Inputstream vyžaduje restart, ale detekována smyčka - restart přeskočen", xbmc.LOGWARNING)
            return
        xbmc.log("[Dohled] Inputstream addony nainstalovány, plánuji restart Kodi za 10s", xbmc.LOGINFO)
        xbmc.sleep(10000)
        xbmc.executebuiltin('RestartApp')


def ensure_low_latency_cache():
    """Zajistí optimální nastavení cache pro low-latency streaming.
    Vytvoří/aktualizuje advancedsettings.xml s malým bufferem pro streamy."""
    adv_settings_path = "/storage/.kodi/userdata/advancedsettings.xml"
    desired_content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>20971520</memorysize>
        <readfactor>4</readfactor>
    </cache>
    <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>10</curllowspeedtime>
    </network>
</advancedsettings>
'''
    try:
        needs_update = True
        if os.path.exists(adv_settings_path):
            with open(adv_settings_path, 'r') as f:
                current = f.read()
            # Zkontrolovat jestli cache nastavení už existuje
            if '<buffermode>1</buffermode>' in current and '<memorysize>20971520</memorysize>' in current:
                needs_update = False

        if needs_update:
            with open(adv_settings_path, 'w') as f:
                f.write(desired_content)
            xbmc.log("[Dohled] advancedsettings.xml aktualizován pro low-latency streaming", xbmc.LOGINFO)
            return True  # Vyžaduje restart Kodi
        return False
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zápisu advancedsettings.xml: {e}", xbmc.LOGERROR)
        return False


def get_smycky_current_playing():
    """Přečte aktuálně přehrávaný soubor z service.smycky."""
    try:
        if os.path.exists(CURRENT_PLAYING_FILE):
            with open(CURRENT_PLAYING_FILE, 'r') as f:
                return f.read().strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení current_playing: {e}", xbmc.LOGERROR)
    return None


def is_video_file(filename):
    """Zjistí, zda je soubor video podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(VIDEO_EXTENSIONS)


def is_image_file(filename):
    """Zjistí, zda je soubor obrázek podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(IMAGE_EXTENSIONS)


def is_supported_file(filename):
    """Zjistí, zda je soubor podporovaný (video nebo obrázek)."""
    if not filename:
        return False
    return filename.lower().endswith(SUPPORTED_EXTENSIONS)


def get_media_type(filename):
    """Vrátí typ média: 'video', 'image' nebo None."""
    if not filename:
        return None
    lower_name = filename.lower()
    if lower_name.endswith(VIDEO_EXTENSIONS):
        return 'video'
    elif lower_name.endswith(IMAGE_EXTENSIONS):
        return 'image'
    return None


# ======= FUNKCE PRO TEXTURE CACHE (černá obrazovka) =======

def clear_image_from_texture_cache(image_path):
    """
    Vyčistí konkrétní obrázek z Kodi texture cache.
    Smaže záznam z Textures13.db a odpovídající soubor z Thumbnails.

    Args:
        image_path: Cesta k obrázku (např. /storage/videos/image.jpg)

    Returns:
        bool: True pokud byla cache vyčištěna, False při chybě
    """
    if not os.path.exists(TEXTURE_DB_PATH):
        xbmc.log(f"[Dohled] Texture DB nenalezena: {TEXTURE_DB_PATH}", xbmc.LOGWARNING)
        return False

    try:
        conn = sqlite3.connect(TEXTURE_DB_PATH)
        cursor = conn.cursor()

        # Najít záznamy pro tento obrázek (hledáme podle cesty)
        cursor.execute(
            "SELECT id, cachedurl FROM texture WHERE url LIKE ?",
            (f"%{os.path.basename(image_path)}%",)
        )
        rows = cursor.fetchall()

        if not rows:
            xbmc.log(f"[Dohled] Obrázek není v texture cache: {image_path}", xbmc.LOGINFO)
            conn.close()
            return True  # Není v cache = OK

        for row in rows:
            texture_id, cached_url = row

            # Smazat thumbnail soubor pokud existuje
            if cached_url:
                thumbnail_path = os.path.join(THUMBNAILS_PATH, cached_url)
                if os.path.exists(thumbnail_path):
                    try:
                        os.remove(thumbnail_path)
                        xbmc.log(f"[Dohled] Smazán thumbnail: {thumbnail_path}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Nelze smazat thumbnail: {e}", xbmc.LOGWARNING)

            # Smazat záznam z DB
            cursor.execute("DELETE FROM texture WHERE id = ?", (texture_id,))
            xbmc.log(f"[Dohled] Smazán texture cache záznam ID={texture_id} pro {image_path}", xbmc.LOGINFO)

        conn.commit()
        conn.close()
        return True

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění texture cache: {e}", xbmc.LOGERROR)
        return False


def verify_image_displayed():
    """
    Ověří, zda je obrázek skutečně zobrazen.
    Kontroluje různé Kodi conditions pro picture viewer/slideshow.

    Returns:
        bool: True pokud je obrázek zobrazen, False pokud černá obrazovka
    """
    # Kodi conditions pro zobrazený obrázek
    conditions = [
        "Window.IsActive(slideshow)",
        "Window.IsVisible(slideshow)",
        "Slideshow.IsActive",
        "Window.IsActive(pictures)",
        "Window.IsVisible(pictures)",
    ]

    for condition in conditions:
        if xbmc.getCondVisibility(condition):
            return True

    # Žádná z podmínek není splněna = pravděpodobně černá obrazovka
    return False


def wait_for_player_stop(timeout=3.0, poll_interval=0.1):
    """
    Čeká, dokud Kodi player skutečně nezastaví přehrávání.
    KRITICKÉ: Kodi potřebuje čas na uvolnění video rendereru před zobrazením obrázku.

    Args:
        timeout: Maximální čas čekání v sekundách
        poll_interval: Interval mezi kontrolami

    Returns:
        bool: True pokud player zastaven, False při timeoutu
    """
    player = xbmc.Player()
    start_time = time.time()
    checks = 0

    while time.time() - start_time < timeout:
        checks += 1
        # Kontrola zda video skutečně neběží
        if not player.isPlayingVideo() and not player.isPlaying():
            elapsed = time.time() - start_time
            xbmc.log(f"[Dohled] Player zastaven po {elapsed:.2f}s ({checks} kontrol)", xbmc.LOGINFO)
            # Extra čekání pro uvolnění GPU/renderer resources
            time.sleep(0.5)
            return True
        time.sleep(poll_interval)

    elapsed = time.time() - start_time
    xbmc.log(f"[Dohled] VAROVÁNÍ: Timeout čekání na zastavení playeru ({elapsed:.2f}s, {checks} kontrol)", xbmc.LOGWARNING)
    return False


# ======= BLACK TRANSITION =======
# Plynule prechody mezi medii bez probliknuti Kodi GUI.
#
# Strategie pro kazdy typ prechodu:
# - Obrazek→Video: Spustit cerne video (nahradi slideshow), pak spustit skutecne video
# - Video→Obrazek: ShowPicture PRED player.stop() (obrazek prekryje video)
# - Obrazek→Obrazek: ShowPicture(novy) primo nahradi stary
#
# Cerne video ma na Amlogic HW nejvyssi z-order (HW overlay),
# takze zaruceně prekryje vse vcetne slideshow.

BLACK_VIDEO_PATH = os.path.join(ADDON_PATH, 'black_transition.mp4')


def _detect_amlogic():
    """True jen na Amlogic boxech (tam ma video HW overlay nad GUI).

    Krycí černé VIDEO se pouziva vyhradne tam. Na ostatnim HW (Raspberry/vc4, x86)
    je GUI nad videem, takze krytí zajisti cerny OBRAZEK ve slideshow okne - a to je
    lepsi, protoze:
      - nepotrebuje dekoder (mereno na Pi: ze 41 spusteni krycího videa 40x
        "OutputPicture - timeout waiting for buffer" a 6x uplne selhani otevreni
        = 15 % prechodu bez krytí -> prosvitlo HOME),
      - ubira jedno spusteni/zastaveni dekoderu na kazdy cyklus playlistu, coz je
        dulezite na slabych RPi3.
    """
    try:
        if os.path.exists('/sys/class/amhdmitx'):
            return True
        with open('/proc/device-tree/compatible', 'rb') as f:
            return b'amlogic' in f.read().lower()
    except Exception:
        pass
    return False


USE_BLACK_TRANSITION_VIDEO = _detect_amlogic()
# Krycí černý obrázek - drží slideshow okno (12007) v popředí s černým obsahem.
# Používá se všude, kde by jinak na obrazovce nezůstalo NIC a Kodi by ukázalo HOME menu.
BLACK_IMAGE_PATH = os.path.join(ADDON_PATH, 'black.png')


def show_black_filler(reason=""):
    """Okamžitě zobrazí černý obrázek jako krytí.

    PRAVIDLO PROJEKTU: menu Kodi se NIKDY nesmí ukázat. Když není připravený žádný
    obsah (start, chybějící soubor, selhání zobrazení, úplné zastavení), musí být
    obrazovka ČERNÁ - nikdy home menu. ShowPicture drží slideshow okno v popředí,
    takže černý obrázek spolehlivě přebije home.
    """
    try:
        if os.path.exists(BLACK_IMAGE_PATH):
            xbmc.executebuiltin(f'ShowPicture("{BLACK_IMAGE_PATH}")')
            if reason:
                xbmc.log(f"[Dohled] Krycí černá obrazovka ({reason})", xbmc.LOGINFO)
            return True
    except Exception as e:
        xbmc.log(f"[Dohled] Nepodařilo se zobrazit krycí černou: {e}", xbmc.LOGWARNING)
    return False


# Okna, která znamenají "náš obsah je na obrazovce" (obrázek / video / vizualizace).
_CONTENT_WINDOWS = (
    "Window.IsVisible(slideshow) | Window.IsVisible(pictures) | Slideshow.IsActive | "
    "Window.IsVisible(fullscreenvideo) | VideoPlayer.IsFullscreen | Window.IsVisible(visualisation)"
)


def is_content_on_screen():
    """True, pokud je v popředí náš obsah (obrázek přes slideshow nebo fullscreen video)."""
    try:
        return bool(xbmc.getCondVisibility(_CONTENT_WINDOWS))
    except Exception:
        return True  # při chybě raději předpokládat, že obsah běží (nezasahovat)


def is_menu_visible():
    """True JEN pokud je vidět Kodi menu a ZÁROVEŇ na obrazovce není žádný náš obsah.

    KRITICKÉ: slideshow (obrázky) je v Kodi DIALOG nad základním oknem 'home', takže
    Window.IsVisible(home) je True i když je obrázek přes celou obrazovku. Kontrolovat
    samotné home proto NELZE - pojistka by hlásila menu pořád a znovu spouštěla obsah
    (obrazovka by problikávala). Menu je problém jen tehdy, když nad ním NIC našeho není.
    """
    try:
        if is_content_on_screen():
            return False
        return bool(xbmc.getCondVisibility("Window.IsVisible(home) | Window.IsActive(home)"))
    except Exception:
        return False


# Značka běžícího přechodu. Uvnitř přechodu je stav "video hraje pod slideshow oknem"
# NORMÁLNÍ a pojistka do něj nesmí zasahovat (Action(FullScreen) nad otevřeným
# slideshow video neodkryje a ukáže HOME - změřeno ~1,9 s).
# Je to ČASOVÁ značka, ne počítadlo: sama vyprší, takže ani přechod ukončený výjimkou
# nemůže pojistku zablokovat natrvalo.
_transition_until = 0.0


def _transition_begin(max_seconds=8.0):
    global _transition_until
    _transition_until = time.monotonic() + max_seconds


def _transition_end():
    global _transition_until
    _transition_until = 0.0


def _transition_running():
    return time.monotonic() < _transition_until


def wait_slideshow_shows(filename, timeout=5.0):
    """Čeká, dokud slideshow neohlásí KONKRÉTNÍ soubor (infolabel Slideshow.Filename).

    verify_image_displayed() umí jen "slideshow okno je vidět" - jakmile se ale jako
    krytí nasadí černý obrázek, je tahle podmínka splněná okamžitě a čekání by
    negarantovalo nic. Proto se čeká na jméno cílového souboru; když infolabel není
    k dispozici (starší Kodi), použije se původní kontrola.
    """
    target = os.path.basename(filename)
    start = time.time()
    while time.time() - start < timeout:
        try:
            cur = xbmc.getInfoLabel('Slideshow.Filename') or ''
        except Exception:
            cur = ''
        if cur:
            if os.path.basename(cur) == target:
                return True
        elif verify_image_displayed():
            return True
        xbmc.sleep(50)
    return verify_image_displayed()


def uncover_video_from_image(player, timeout=3.0):
    """Odkryje UŽ SPUŠTĚNÉ video zpod slideshow okna, bez odhalení menu.

    Video na Amlogic HW běží pod slideshow oknem. Slideshow proto zavřeme TEPRVE až
    video skutečně hraje - tím pádem se pod ním hned objeví video, nikdy prázdno/menu.
    Používá se tam, kde se video spustilo jinde (např. video playlist) a je nad ním
    ještě zobrazený obrázek.
    """
    _transition_begin()
    try:
        start = time.time()
        while time.time() - start < timeout:
            if player.isPlayingVideo():
                break
            xbmc.executebuiltin('Dialog.Close(busydialog)')   # spinner nad obrázkem
            xbmc.sleep(50)
        xbmc.sleep(200)  # nechat vykreslit první frame
        # ATOMICKÉ ODKRYTÍ - vysvětlení a měření viz transition_to_video_from_image()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace
        ensure_fullscreen_video()
        xbmc.sleep(50)
        # Když video z nějakého důvodu nehraje, nesmí zůstat prázdná obrazovka
        if not player.isPlayingVideo() and not is_content_on_screen():
            show_black_filler("video se nespustilo")
        elif is_menu_visible():
            show_black_filler("menu po odkrytí videa")
        xbmc.log("[Dohled] Video odkryto zpod obrázku", xbmc.LOGINFO)
    finally:
        _transition_end()


def ensure_fullscreen_video():
    """Prepne video do fullscreenu ZPUSOBEM, KTERY NEMUZE PREPNOUT SPATNE.

    Action(FullScreen) je PREPINAC: kdyz uz Kodi po zavreni dialogu ve fullscreenu je,
    slepe zavolany prikaz ho z fullscreenu VYHODI na HOME. Na RPi3 to bylo videt jako
        obrazek -> video (2 ms) -> HOME MENU (78 ms) -> video
    (menu vratila teprve pojistka). GUI.SetFullscreen je naopak IDEMPOTENTNI.

    Zachrana: na nekterem HW (merene driv na aarch64) samotne GUI.SetFullscreen video
    neodkrylo, proto se po chvili overi vysledek a teprve pak se pouzije prepinac.

    MERENO na RPi3 (harness script.transtest, vzorkovani 500 Hz = 2 ms):
      Close(true) + Action(FullScreen)      -> 1 z 6 prechodu blik 162 ms
      Close(true) + GUI.SetFullscreen       -> 0 z 6
      GUI.SetFullscreen PRED zavrenim       -> 4 z 6 SELHALO (video zustalo pod menu)
    """
    try:
        xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1,
                                        "method": "GUI.SetFullscreen",
                                        "params": {"fullscreen": True}}))
    except Exception:
        pass
    for _ in range(6):          # max ~60 ms
        if xbmc.getCondVisibility('VideoPlayer.IsFullscreen'):
            return True
        xbmc.sleep(10)
    xbmc.executebuiltin('Action(FullScreen)')
    return False


def uncover_if_covered(player, reason=""):
    """Když je nad hrajícím videem otevřené krycí okno, odkryje video.

    PROČ: video se v Kodi vykresluje POD GUI. Když nad ním zůstane slideshow okno
    (typicky krycí ČERNÁ z show_black_filler - po startu "příprava obsahu", po selhání
    zobrazení, po zastavení obsahu), divák vidí ČERNOU OBRAZOVKU, přesto že video hraje.
    Krytí se NEUKLÁDÁ do current_displayed_image (není to obsah), takže se podle té
    proměnné poznat nedá - rozhoduje jedině skutečná viditelnost slideshow okna.

    Tuhle chybu měly obě playlistové smyčky i RepeatVideo (nalezeno testy výměny obsahu
    2026-08-10: u jednoho videa i u playlistu jen z videí zůstala černá obrazovka natrvalo).
    """
    if xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
        xbmc.log(f"[Dohled] Nad videem je krycí okno{' (' + reason + ')' if reason else ''}"
                 " - odkrývám video", xbmc.LOGINFO)
        uncover_video_from_image(player)
        return True
    return False


def play_video_uncovered(player, file_path, wait_stop=0.0, builtin=False):
    """Spustí video a ZARUČENĚ ho odkryje zpod případného krycího okna."""
    if wait_stop:
        wait_for_player_stop(timeout=wait_stop)
    if builtin:
        xbmc.executebuiltin(f'PlayMedia("{file_path}")')
    else:
        player.play(file_path)
    uncover_if_covered(player, os.path.basename(file_path))


def transition_to_video_from_image(player, video_path):
    """Prechod obrazek→video:
    1. Spusti video (bezi pod slideshow)
    2. Pocka az video nabehne
    3. Zavre slideshow okno (ID 10134) - video je uz pod nim pripravene
    """
    xbmc.log(f"[Dohled] Transition obrazek→video: {os.path.basename(video_path)}", xbmc.LOGINFO)
    _transition_begin()
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    # Spustit video - bezi pod slideshow oknem
    player.play(video_path)
    # Cekat az video zacne hrat (max 3s)
    start = time.time()
    while time.time() - start < 3.0:
        if player.isPlayingVideo():
            break
        # Kodi si pri otevirani souboru samo pusti busy spinner NAD obrazkem
        # (zmereno 94-185 ms) - hned ho zavirat, obsah ma byt cisty.
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.sleep(50)
    xbmc.sleep(200)  # Extra pauza pro jistotu ze je frame vykreslen
    # ATOMICKÉ ODKRYTÍ: zavření slideshow a přepnutí videa do fullscreenu musí jít
    # do Kodi BEZ JAKÉKOLI PAUZY MEZI TÍM - Kodi je pak vyřídí ve stejném frame
    # a divák nikdy neuvidí, co je pod slideshow.
    #
    # MĚŘENO (harness script.transtest + vzorkování okna na 200 Hz, tj. pod 1 frame):
    #   ActivateWindow(fullscreenvideo) + 150 ms + Dialog.Close + 80 ms + FullScreen
    #                                          -> HOME MENU 64-81 ms (3/3 pokusů)
    #   Dialog.Close(12007) + Action(FullScreen) bez pauzy   -> 0 ms (8/8 pokusů)
    #
    # POZOR - RASPBERRY PI 3 (změřeno 28.8.2026): tohle pořadí samo o sobě NESTAČÍ,
    # protože Action(FullScreen) je PŘEPÍNAČ - když Kodi po zavření dialogu do
    # fullscreenu přejde samo, druhý příkaz ho zase VYHODÍ na HOME. Proto se přepíná
    # přes ensure_fullscreen_video() (idempotentní GUI.SetFullscreen + záchrana).
    #
    # NAMĚŘENO NA RPi3 za reálného provozu (vzorkování 500 Hz, počítají se jen bliky
    # delší než jeden frame 16,7 ms):
    #   Close(12007) + Action(FullScreen)                -> 5 bliků / 240 s (21-266 ms)
    #   Close(12007,true) + Action(FullScreen)           -> 10 bliků / 600 s
    #   ... + čekací smyčka na IsFullscreen (ZHORŠENÍ!)  -> 38 bliků / 900 s
    #   Close(12007,true) + ensure_fullscreen_video()    -> 0 bliků / 1200 s
    # Zavírání BEZ animace (true) se v harnessu neprojevilo jako rozhodující, ale
    # škodit nemůže a zůstává. Rozhodující je NEPŘEPÍNACÍ přepnutí do fullscreenu.
    # ActivateWindow(fullscreenvideo) se pod modálním slideshow VŮBEC neuplatní
    # (base okno zůstane 'home'), takže po zavření dialogu prosvitlo menu přesně
    # na dobu následující pauzy. Proto je pauza pryč a ActivateWindow taky.
    # Varianty GUI.SetFullscreen / ReplaceWindow / Action(FullScreen) před zavřením
    # slideshow video vůbec neodkryly (HOME ~2 s) - nepoužívat.
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace
    ensure_fullscreen_video()
    xbmc.sleep(50)
    # Fallback pokud slideshow stale bezi
    if xbmc.getCondVisibility('Window.IsActive(slideshow)'):
        xbmc.executebuiltin('Action(Back)')
        xbmc.sleep(100)
        xbmc.executebuiltin('Action(FullScreen)')
    # Pojistka: kdyby přesto prosvitlo menu, okamžitě zakryt černou (nikdy menu)
    if is_menu_visible():
        xbmc.log("[Dohled] Transition obrázek→video: menu po zavření slideshow - kryji černou", xbmc.LOGWARNING)
        xbmc.executebuiltin('Action(FullScreen)')
        xbmc.sleep(50)
        if is_menu_visible():
            show_black_filler("menu po přechodu obrázek→video")
    _transition_end()
    xbmc.log("[Dohled] Transition obrazek→video: dokonceno", xbmc.LOGINFO)

def transition_to_image_from_video(player, image_path):
    """Prechod video→obrazek:
    1. KRYTÍ: cerny obrazek do slideshow okna (GUI vrstva, bez dekoderu - nemuze selhat)
    2. Jen na Amlogic navic krycí cerne video (HW overlay nad GUI)
    3. ShowPicture pripravi cilovy obrazek
    4. Slideshow do popredi a TEPRVE POTOM stop videa
    """
    xbmc.log(f"[Dohled] Transition video→obrazek: {os.path.basename(image_path)}", xbmc.LOGINFO)
    _transition_begin()
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    # KRYTÍ BEZ DEKODÉRU jako první krok. Kdyby cokoli dál selhalo (nepodařilo se
    # otevřít krycí video, Kodi zaneprázdněné, chyba souboru), je pod videem
    # připravená ČERNÁ - nikdy ne HOME menu.
    # MĚŘENO harnessem: se současným postupem prosvitlo HOME 5 ms při 3 ze 3 přechodů;
    # s tímto krytím 0 ms při 3 ze 3 - a to i ve variantě, kde krycí video záměrně
    # NEEXISTOVALO (simulace reálného selhání dekodéru).
    xbmc.executebuiltin(f'ShowPicture("{BLACK_IMAGE_PATH}")')
    if USE_BLACK_TRANSITION_VIDEO:
        # Spustit cerne video PRIMO (ne pres playlist - RepeatOne v playlistu nefunguje)
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        player.play(BLACK_VIDEO_PATH)
        # Cekat az cerne video zacne hrat (max 1,5 s - kdyz se nerozjede, kryje obrazek)
        start = time.time()
        black_ok = False
        while time.time() - start < 1.5:
            if player.isPlayingVideo():
                black_ok = True
                break
            xbmc.sleep(50)
        if not black_ok:
            xbmc.log("[Dohled] Transition: krycí video se nerozjelo - kryje černý obrázek",
                     xbmc.LOGWARNING)
        xbmc.sleep(150)
    # Zobrazit obrazek - slideshow okno se pripravi POD video vrstvou
    xbmc.executebuiltin(f'ShowPicture("{image_path}")')
    # Cekat, az slideshow ohlasi PRAVE TENTO soubor (max 5s)
    if wait_slideshow_shows(image_path, 5.0):
        xbmc.log("[Dohled] Transition: slideshow okno ready", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] Transition: slideshow neohlásil {os.path.basename(image_path)} "
                 f"- pokračuji (kryje černá)", xbmc.LOGWARNING)
    xbmc.sleep(50)
    # KRITICKÉ POŘADÍ: slideshow dát do popředí JEŠTĚ PŘED zastavením videa.
    # Když se video zastavilo první, Kodi na ~0,3 s spadlo na základní okno (HOME menu)
    # a teprve pak vykreslilo slideshow - měřením zachyceno 5x za 110 s.
    xbmc.executebuiltin('ActivateWindow(slideshow)')
    xbmc.sleep(120)
    # Teprve teď zastavit černé video - slideshow už je navrchu
    player.stop()
    xbmc.sleep(50)
    # Pojistka: kdyby stop přesto odhalil menu, okamžitě obrázek vrátit
    if is_menu_visible():
        xbmc.log("[Dohled] Transition video→obrázek: menu po stopu - vracím obrázek", xbmc.LOGWARNING)
        xbmc.executebuiltin(f'ShowPicture("{image_path}")')
    _transition_end()
    xbmc.log("[Dohled] Transition video→obrazek: dokonceno", xbmc.LOGINFO)

# Zpetna kompatibilita - tyto funkce se volaji z ruznych mist
# transition_show/hide/wait_and_hide jiz nejsou potreba s novym pristupem,
# ale necham je jako no-op aby nepadaly stare volani
def transition_show():
    pass

def transition_hide():
    pass

def transition_wait_and_hide(condition_func=None, timeout=5.0, poll_interval=0.1):
    return True


def verify_image_file_ready(image_path, expected_size=None, timeout=5.0):
    """
    Ověří, že obrazový soubor je plně zapsán na disk a je čitelný.
    Kritické pro soubory právě stažené z FTP - Kodi je nemůže načíst okamžitě.

    Args:
        image_path: Cesta k souboru
        expected_size: Očekávaná velikost souboru (volitelné)
        timeout: Maximální čas čekání v sekundách

    Returns:
        bool: True pokud je soubor připraven, False pokud timeout
    """
    start_time = time.time()
    attempt = 0

    while time.time() - start_time < timeout:
        attempt += 1
        try:
            # 1. Ověřit že soubor existuje a má velikost
            if not os.path.exists(image_path):
                xbmc.log(f"[Dohled] verify_image: Soubor neexistuje (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            file_size = os.path.getsize(image_path)
            if file_size == 0:
                xbmc.log(f"[Dohled] verify_image: Soubor má nulovou velikost (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 2. Ověřit očekávanou velikost (pokud je známá)
            if expected_size and file_size != expected_size:
                xbmc.log(f"[Dohled] verify_image: Neúplný soubor {file_size}/{expected_size} (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 3. Pokusit se otevřít a přečíst celý soubor - klíčové pro ověření
            with open(image_path, 'rb') as f:
                data = f.read()

            if len(data) != file_size:
                xbmc.log(f"[Dohled] verify_image: Přečteno {len(data)}, očekáváno {file_size} (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 4. Pro JPEG ověřit strukturu (SOI marker na začátku, EOI na konci)
            is_jpeg = image_path.lower().endswith(('.jpg', '.jpeg'))
            if is_jpeg:
                # JPEG musí začínat FF D8 a končit FF D9
                if len(data) < 4:
                    xbmc.log(f"[Dohled] verify_image: Soubor příliš malý pro JPEG (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[0:2] != b'\xff\xd8':
                    xbmc.log(f"[Dohled] verify_image: Chybí JPEG SOI marker (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[-2:] != b'\xff\xd9':
                    xbmc.log(f"[Dohled] verify_image: Chybí JPEG EOI marker - soubor neúplný (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

            # 5. Pro PNG ověřit signaturu
            is_png = image_path.lower().endswith('.png')
            if is_png:
                # PNG musí začínat specifickou 8-byte signaturou
                if len(data) < 8:
                    xbmc.log(f"[Dohled] verify_image: Soubor příliš malý pro PNG (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[0:8] != b'\x89PNG\r\n\x1a\n':
                    xbmc.log(f"[Dohled] verify_image: Chybí PNG signatura (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

            # Všechny kontroly prošly
            elapsed = time.time() - start_time
            xbmc.log(f"[Dohled] verify_image: Soubor připraven po {attempt} pokusech ({elapsed:.2f}s): {image_path}", xbmc.LOGINFO)
            return True

        except IOError as e:
            xbmc.log(f"[Dohled] verify_image: IO chyba (pokus {attempt}): {e}", xbmc.LOGDEBUG)
            time.sleep(0.1)
            continue
        except Exception as e:
            xbmc.log(f"[Dohled] verify_image: Chyba (pokus {attempt}): {e}", xbmc.LOGWARNING)
            time.sleep(0.1)
            continue

    elapsed = time.time() - start_time
    xbmc.log(f"[Dohled] verify_image: TIMEOUT po {elapsed:.2f}s a {attempt} pokusech: {image_path}", xbmc.LOGERROR)
    return False


def show_picture_safe(image_path, _retry_count=0, freshly_downloaded=False):
    """
    Zobrazí obrázek s detekcí černé obrazovky a auto-opravou.
    Pro čerstvě stažené soubory používá speciální přístup.

    Args:
        image_path: Cesta k obrázku
        _retry_count: Interní počítadlo pokusů
        freshly_downloaded: True pokud byl soubor právě stažen (vyžaduje extra opatrnost)

    Returns:
        bool: True pokud se obrázek zobrazil, False při selhání
    """
    filename = os.path.basename(image_path)

    # PRO ČERSTVĚ STAŽENÉ SOUBORY: Speciální příprava
    if freshly_downloaded and _retry_count == 0:
        xbmc.log(f"[Dohled] show_picture_safe: Čerstvě stažený soubor - speciální příprava", xbmc.LOGINFO)

        # 1. KRITICKÉ: Kompletně zastavit video player a uvolnit GPU/decoder resources!
        # Použít xbmc.Player().stop() s kontrolou isPlaying() - spolehlivější než PlayerControl(Stop)
        player = xbmc.Player()
        if player.isPlaying():
            xbmc.log(f"[Dohled] show_picture_safe: Player běží - zastavuji", xbmc.LOGINFO)
            player.stop()

            # Čekat až se player skutečně zastaví (max 5 sekund)
            max_wait = 50  # 50 x 100ms = 5 sekund
            wait_count = 0
            while player.isPlaying() and wait_count < max_wait:
                xbmc.sleep(100)
                wait_count += 1

            if wait_count >= max_wait:
                xbmc.log(f"[Dohled] show_picture_safe: VAROVÁNÍ - player se nezastavil po 5s!", xbmc.LOGWARNING)
            else:
                xbmc.log(f"[Dohled] show_picture_safe: Player zastaven po {wait_count * 100}ms", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Dohled] show_picture_safe: Player neběží", xbmc.LOGINFO)

        # Krátká pauza po zastavení playeru (problém byl ve složce, ne v GPU)
        xbmc.sleep(300)

        # 2. Container.Refresh pro jistotu
        xbmc.executebuiltin("Container.Refresh")
        xbmc.sleep(200)

        # 4. PREVENTIVNĚ vyčistit texture cache
        clear_image_from_texture_cache(image_path)

        # 5. Ověřit že soubor je čitelný (otevřít a přečíst hlavičku)
        try:
            with open(image_path, 'rb') as f:
                header = f.read(16)
                xbmc.log(f"[Dohled] show_picture_safe: Soubor čitelný, header {len(header)} bytes", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] show_picture_safe: CHYBA - soubor není čitelný: {e}", xbmc.LOGERROR)
            return False

        # 6. Krátká pauza před zobrazením (sníženo z 500ms, problém byl ve složce)
        xbmc.sleep(100)

    # Zobrazit obrázek pomocí SlideShow (může být spolehlivější než ShowPicture pro single image)
    # SlideShow s jedním souborem = zobrazí jen ten jeden obrázek
    parent_dir = os.path.dirname(image_path)
    xbmc.log(f"[Dohled] show_picture_safe: Zobrazuji {filename}", xbmc.LOGINFO)
    xbmc.executebuiltin(f'ShowPicture("{image_path}")')

    # Počkat a ověřit zobrazení (použít xbmc.sleep pro lepší integraci s Kodi)
    xbmc.sleep(int(BLACK_SCREEN_VERIFY_DELAY * 1000))

    if not verify_image_displayed():
        # ČERNÁ OBRAZOVKA DETEKOVÁNA!
        xbmc.log(f"[Dohled] ČERNÁ OBRAZOVKA detekována: {filename} (pokus {_retry_count + 1})", xbmc.LOGERROR)

        if _retry_count < BLACK_SCREEN_MAX_RETRIES:
            # Pokus o opravu - vyčistit cache a zkusit znovu
            xbmc.log(f"[Dohled] Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)
            xbmc.sleep(500)
            return show_picture_safe(image_path, _retry_count + 1, freshly_downloaded=False)
        else:
            # Všechny pokusy selhaly - zkusit JSON-RPC jako poslední možnost
            xbmc.log(f"[Dohled] Zkouším JSON-RPC Player.Open jako fallback", xbmc.LOGINFO)
            try:
                import json
                request = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "Player.Open",
                    "params": {"item": {"file": image_path}},
                    "id": 1
                })
                response = xbmc.executeJSONRPC(request)
                xbmc.log(f"[Dohled] JSON-RPC response: {response}", xbmc.LOGINFO)
                xbmc.sleep(1000)
                if verify_image_displayed():
                    xbmc.log(f"[Dohled] JSON-RPC úspěšné pro: {filename}", xbmc.LOGINFO)
                    return True
            except Exception as e:
                xbmc.log(f"[Dohled] JSON-RPC selhalo: {e}", xbmc.LOGERROR)

            xbmc.log(f"[Dohled] Všechny pokusy selhaly pro: {filename}", xbmc.LOGERROR)
            transition_hide()
            return False

    # Úspěch - skrýt overlay pokud je zobrazen
    transition_hide()
    if _retry_count > 0:
        xbmc.log(f"[Dohled] Obrázek zobrazen po {_retry_count + 1} pokusech: {filename}", xbmc.LOGINFO)
    return True


# ======= KODI LOG MONITOR PRO DETEKCI ČERNÉ OBRAZOVKY =======

class KodiLogMonitor(threading.Thread):
    """
    Monitoruje Kodi log pro detekci chyby 'Error loading the current image'.
    Když je chyba detekována, automaticky vyčistí texture cache a pokusí se
    obrázek znovu zobrazit.
    """

    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._last_position = 0
        self._last_error_time = 0  # Pro debouncing - nechceme reagovat na každý řádek
        self._processed_images = {}  # {image_path: timestamp} - pro tracking již zpracovaných
        self._fix_attempts = {}  # {image_path: count} - počet pokusů o opravu
        self._max_fix_attempts = 2  # Maximální počet pokusů o auto-fix
        # Pattern pro detekci chyby: Error loading the current image 0: /storage/videos/filename.jpg
        self._error_pattern = re.compile(r'Error loading the current image \d+: (.+)$')

    def stop(self):
        self._stop_event.set()

    def run(self):
        xbmc.log("[Dohled] KodiLogMonitor spuštěn", xbmc.LOGINFO)

        # Přeskočit existující obsah logu
        if os.path.exists(KODI_LOG_PATH):
            try:
                with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                    f.seek(0, 2)  # Seek to end
                    self._last_position = f.tell()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při inicializaci pozice: {e}", xbmc.LOGWARNING)

        while not self._stop_event.is_set():
            try:
                self._check_log()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor chyba: {e}", xbmc.LOGWARNING)

            self._stop_event.wait(BLACK_SCREEN_LOG_MONITOR_INTERVAL)

        xbmc.log("[Dohled] KodiLogMonitor ukončen", xbmc.LOGINFO)

    def _check_log(self):
        """Kontroluje nové řádky v Kodi logu."""
        if not os.path.exists(KODI_LOG_PATH):
            return

        try:
            with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                # Zkontrolovat zda soubor nebyl rotován (pozice větší než velikost)
                f.seek(0, 2)
                current_size = f.tell()
                if self._last_position > current_size:
                    self._last_position = 0

                # Číst od poslední pozice
                f.seek(self._last_position)
                new_lines = f.readlines()
                self._last_position = f.tell()

                for line in new_lines:
                    self._process_line(line)
        except Exception as e:
            xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při čtení logu: {e}", xbmc.LOGWARNING)

    def _process_line(self, line):
        """Zpracuje jeden řádek logu."""
        # Hledáme "error <general>: Error loading the current image"
        if 'Error loading the current image' not in line:
            return

        match = self._error_pattern.search(line)
        if not match:
            return

        image_path = match.group(1).strip()
        current_time = time.time()

        # Debouncing - Kodi loguje tuto chybu opakovaně, zpracuj jen jednou za 5 sekund pro daný obrázek
        if image_path in self._processed_images:
            if current_time - self._processed_images[image_path] < 5:
                return

        self._processed_images[image_path] = current_time

        # Vyčistit staré záznamy (processed a fix_attempts)
        self._processed_images = {k: v for k, v in self._processed_images.items()
                                   if current_time - v < 60}
        # Reset fix_attempts po 2 minutách
        self._fix_attempts = {k: v for k, v in self._fix_attempts.items()
                              if k in self._processed_images}

        # Kontrola počtu pokusů - po vyčerpání přestat zkoušet
        attempts = self._fix_attempts.get(image_path, 0)
        if attempts >= self._max_fix_attempts:
            xbmc.log(f"[Dohled] KodiLogMonitor: Černá obrazovka pro {image_path} - max pokusů ({self._max_fix_attempts}) vyčerpáno", xbmc.LOGWARNING)
            # Opakovaně černý obrázek = pravděpodobně POŠKOZENÝ SOUBOR.
            # Smazat, znovu stáhnout z FTP a zobrazit (jinak jen svítí černá).
            def _repair_and_show():
                try:
                    fn = os.path.basename(image_path)
                    if ensure_media_playable(fn):
                        self._fix_attempts[image_path] = 0
                        xbmc.executebuiltin(f'ShowPicture("{get_local_media_path(fn)}")')
                        xbmc.log(f"[Dohled] KodiLogMonitor: {fn} znovu stažen a zobrazen", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] KodiLogMonitor: oprava souboru selhala: {e}", xbmc.LOGERROR)
            threading.Thread(target=_repair_and_show, daemon=True).start()
            return

        self._fix_attempts[image_path] = attempts + 1
        xbmc.log(f"[Dohled] KodiLogMonitor: Detekována černá obrazovka pro: {image_path} (pokus {attempts + 1}/{self._max_fix_attempts})", xbmc.LOGERROR)

        # Spustit opravu v separátním vlákně aby neblokoval monitor
        threading.Thread(target=self._fix_black_screen, args=(image_path,), daemon=True).start()

    def _fix_black_screen(self, image_path):
        """Pokusí se opravit černou obrazovku vyčištěním cache a znovuzobrazením."""
        filename = os.path.basename(image_path)

        try:
            # 1. Vyčistit texture cache
            xbmc.log(f"[Dohled] Auto-fix: Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)

            # 2. Krátká pauza
            time.sleep(0.3)

            # 3. NEZAVÍRAT slideshow! Action(Stop) ho zavřel a odhalil HOME menu.
            #    ShowPicture níže obrázek nahradí atomicky.

            # 4. Znovu zobrazit obrázek
            xbmc.log(f"[Dohled] Auto-fix: Znovu zobrazuji: {filename}", xbmc.LOGINFO)
            xbmc.executebuiltin(f'ShowPicture("{image_path}")')

            # 5. Počkat a zkontrolovat
            time.sleep(1)

            # Pokud se opět objeví chyba, bude zachycena dalším průchodem
            xbmc.log(f"[Dohled] Auto-fix: Oprava dokončena pro: {filename}", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[Dohled] Auto-fix: Chyba při opravě {filename}: {e}", xbmc.LOGERROR)


# Instance log monitoru (globální)
kodi_log_monitor = None


# ======= FUNKCE PRO SPRÁVU DISKU =======

def get_disk_space_mb(path):
    """Vrátí volné místo na disku v MB."""
    try:
        statvfs = os.statvfs(path)
        free_bytes = statvfs.f_frsize * statvfs.f_bavail
        return free_bytes / (1024 * 1024)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa na disku: {e}", xbmc.LOGERROR)
        return 0


def get_file_size_mb(filepath):
    """Vrátí velikost souboru v MB."""
    try:
        if os.path.exists(filepath):
            return os.path.getsize(filepath) / (1024 * 1024)
        return 0
    except:
        return 0


def cleanup_old_media(current_filename, needed_space_mb=0):
    """
    Vyčistí staré mediální soubory pouze pokud je nedostatek volného místa.
    Maže nejstarší soubory dokud není dostatek místa (MIN_FREE_SPACE_MB + needed_space_mb).
    """
    try:
        free_space = get_disk_space_mb(VIDEO_DIR)
        total_needed = MIN_FREE_SPACE_MB + needed_space_mb

        if free_space >= total_needed:
            xbmc.log(f"[Dohled] Dostatek místa ({free_space:.0f} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0, 0

        space_to_free = total_needed - free_space
        xbmc.log(f"[Dohled] Nedostatek místa ({free_space:.0f} MB), potřeba uvolnit {space_to_free:.0f} MB", xbmc.LOGWARNING)

        media_files = []
        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                mtime = os.path.getmtime(filepath)
                size_mb = get_file_size_mb(filepath)
                media_files.append({
                    'filename': filename,
                    'filepath': filepath,
                    'mtime': mtime,
                    'size_mb': size_mb
                })

        # Seřadit od nejstaršího (nejstarší budou smazány první)
        media_files.sort(key=lambda x: x['mtime'])
        xbmc.log(f"[Dohled] Nalezeno {len(media_files)} mediálních souborů", xbmc.LOGINFO)

        deleted_count = 0
        freed_space_mb = 0

        for file_info in media_files:
            if freed_space_mb >= space_to_free:
                break

            # Chránit aktuálně přehrávaný soubor
            if file_info['filename'] == current_filename:
                xbmc.log(f"[Dohled] Chráním aktuální soubor: {file_info['filename']}", xbmc.LOGINFO)
                continue

            try:
                os.remove(file_info['filepath'])
                deleted_count += 1
                freed_space_mb += file_info['size_mb']
                xbmc.log(f"[Dohled] Smazán starý soubor: {file_info['filename']} ({file_info['size_mb']:.1f} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při mazání {file_info['filename']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            pass  # Notifikace odstraněna - info je v logu

        return deleted_count, freed_space_mb

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění starých souborů: {e}", xbmc.LOGERROR)
        return 0, 0


def analyze_disk_usage():
    """Analyzuje využití disku a vrátí statistiky."""
    try:
        media_files = []
        total_size_mb = 0

        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                size_mb = get_file_size_mb(filepath)
                mtime = os.path.getmtime(filepath)
                media_files.append({
                    'filename': filename,
                    'size_mb': size_mb,
                    'mtime': mtime,
                    'type': get_media_type(filename)
                })
                total_size_mb += size_mb

        media_files.sort(key=lambda x: x['size_mb'], reverse=True)
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        video_count = sum(1 for f in media_files if f['type'] == 'video')
        image_count = sum(1 for f in media_files if f['type'] == 'image')

        return {
            'media_count': len(media_files),
            'video_count': video_count,
            'image_count': image_count,
            'total_size_mb': total_size_mb,
            'free_space_mb': free_space_mb,
            'largest_files': media_files[:3]
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při analýze disku: {e}", xbmc.LOGERROR)
        return None


# ======= FTP FUNKCE =======

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
    try:
        return api_request(api_url, timeout=10)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def fetch_expected_file(device_id):
    """Získá očekávaný soubor z API - nejprve zkontroluje device override, pak locality."""
    if not device_id:
        return None, None

    # Přidat boot_time pro detekci restartu - API vymaže UserInitiatedPlayback při změně boot_time
    boot_time = get_boot_time()
    boot_param = f"?boot_time={urllib.parse.quote(boot_time)}" if boot_time else ""
    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file{boot_param}"
    try:
        data = api_request(api_url, timeout=10)
        filename = data.get("filename")
        source = data.get("source")

        # Per-device trvalé ztlumení - vynucuje se v monitoring loopu
        global device_muted
        device_muted = bool(data.get("muted", False))

        if filename:
            xbmc.log(f"[Dohled] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
            return filename, source
        return None, None
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání očekávaného souboru: {e}", xbmc.LOGWARNING)
        return None, None


def get_remote_file_info(host, user, password, path, filename):
    """Získá datum poslední úpravy a velikost souboru na FTP serveru."""
    try:
        xbmc.log(f"[Dohled] Připojuji se k FTP serveru {host}...", xbmc.LOGINFO)

        ftp = FTP(host, timeout=30)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")

        try:
            size = ftp.size(path + filename)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání velikosti souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        try:
            modified_time = ftp.sendcmd("MDTM " + path + filename)[4:].strip()
            remote_timestamp = time.mktime(datetime.strptime(modified_time, "%Y%m%d%H%M%S").timetuple())
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání data úpravy souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        ftp.quit()
        xbmc.log(f"[Dohled] FTP info: velikost {size/1024/1024:.1f}MB", xbmc.LOGINFO)
        return remote_timestamp, size

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba FTP při připojení k {host}: {e}", xbmc.LOGERROR)
        return None, None


def get_local_file_info(path):
    """Získá datum poslední úpravy a velikost lokálního souboru."""
    if os.path.exists(path):
        return os.path.getmtime(path), os.path.getsize(path)
    return 0, 0


def download_file_ftp(host, user, password, path, filename, local_path):
    """Stáhne soubor z FTP s kontrolou místa na disku."""
    try:
        ftp = FTP(host, timeout=30)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        remote_size = ftp.size(path + filename)
        ftp.quit()

        remote_size_mb = remote_size / (1024 * 1024)
        free_space_mb = get_disk_space_mb(VIDEO_DIR)

        if free_space_mb < remote_size_mb + MIN_FREE_SPACE_MB:
            xbmc.log(f"[Dohled] Nedostatek místa, spouštím cleanup", xbmc.LOGWARNING)
            cleanup_old_media(os.path.basename(local_path), remote_size_mb)

        temp_path = local_path + "_tmp"
        xbmc.log(f"[Dohled] Stahuji {filename}...", xbmc.LOGINFO)

        with open(temp_path, "wb") as out_file:
            ftp = FTP(host, timeout=30)
            ftp.login(user, password)
            ftp.voidcmd("TYPE I")

            downloaded = 0

            def write_block(block):
                nonlocal downloaded
                out_file.write(block)
                downloaded += len(block)

            ftp.retrbinary("RETR " + path + filename, write_block, blocksize=1024*1024)
            ftp.quit()

        if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
            shutil.move(temp_path, local_path)
            xbmc.log(f"[Dohled] Soubor {filename} úspěšně stažen ({remote_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Aktualizovat last_filename
            try:
                with open(LAST_FILENAME_FILE, "w", encoding="utf-8") as f:
                    f.write(filename)
            except:
                pass

            return True
        else:
            raise ValueError("Stažený soubor je prázdný!")

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při stahování z FTP: {e}", xbmc.LOGERROR)
        temp_path = local_path + "_tmp"
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass
        return False


# ======= OVĚŘOVÁNÍ INTEGRITY SOUBORŮ + SAMOOPRAVA =======
# Občas se lokální soubor poškodí (přerušené stahování, vadná SD karta, plný disk).
# Kodi ho pak nedokáže přehrát a vzniká smyčka, kdy se přehrávání pořád znovu spouští.
# Tady se poškozený soubor DETEKUJE, SMAŽE a znovu STÁHNE z FTP.

MEDIA_REPAIR_MAX_ATTEMPTS = 2      # kolikrát zkusit opravu téhož souboru
MEDIA_REPAIR_COOLDOWN = 900        # s - po tomto čase se počítadlo pokusů resetuje
_media_repair_state = {}           # filename -> {"attempts": int, "last": monotonic}

# Lokálně se soubory ukládají pod basename, ale na FTP mohou být v PODSLOŽCE
# (např. 'Oresi/foto.jpg'). Pro opětovné stažení je nutná plná relativní cesta,
# jinak stahování skončí 550 (soubor nenalezen) - proto si ji tady pamatujeme.
_remote_name_by_basename = {}


def register_remote_name(name):
    """Zapamatuje plnou relativní FTP cestu k souboru (kvůli podsložkám)."""
    try:
        if not name or name.startswith('playlist:') or '://' in name:
            return
        base = os.path.basename(name)
        if not base:
            return
        if base != name:
            _remote_name_by_basename[base] = name      # má podsložku - to je ta cenná informace
        else:
            _remote_name_by_basename.setdefault(base, name)
    except Exception:
        pass


def resolve_remote_name(name):
    """Vrátí plnou relativní cestu pro FTP podle basename (nebo vstup, když není známá)."""
    try:
        return _remote_name_by_basename.get(os.path.basename(name), name)
    except Exception:
        return name

# Očekávané hlavičky (magic bytes) pro rychlou detekci rozbitého/nedostaženého souboru
_MEDIA_MAGIC = {
    '.png': [b'\x89PNG\r\n\x1a\n'],
    '.jpg': [b'\xff\xd8\xff'],
    '.jpeg': [b'\xff\xd8\xff'],
    '.gif': [b'GIF87a', b'GIF89a'],
    '.bmp': [b'BM'],
    '.mkv': [b'\x1a\x45\xdf\xa3'],
    '.webm': [b'\x1a\x45\xdf\xa3'],
}


def validate_media_file(local_path, expected_size=None):
    """Rychlá kontrola, že mediální soubor není poškozený.

    Vrací (ok: bool, reason: str). Kontroluje se:
    - existence a nenulová velikost,
    - shoda s očekávanou velikostí z API (nedostažený/odseknutý soubor),
    - magic bytes hlavičky podle přípony (mp4/mov mají 'ftyp' na offsetu 4),
    - čitelnost souboru.
    """
    try:
        if not local_path or not os.path.exists(local_path):
            return False, "soubor neexistuje"
        size = os.path.getsize(local_path)
        if size == 0:
            return False, "nulová velikost"
        if expected_size and size != expected_size:
            return False, f"velikost {size} != očekávaná {expected_size}"

        ext = os.path.splitext(local_path)[1].lower()
        with open(local_path, 'rb') as f:
            head = f.read(16)
        if len(head) < 8:
            return False, "soubor je kratší než hlavička"

        if ext in _MEDIA_MAGIC:
            if not any(head.startswith(m) for m in _MEDIA_MAGIC[ext]):
                return False, f"poškozená hlavička {ext}"
        elif ext in ('.mp4', '.m4v', '.mov'):
            # ISO BMFF: box type na offsetu 4 bývá 'ftyp' (případně 'moov'/'mdat'/'free'/'skip')
            if head[4:8] not in (b'ftyp', b'moov', b'mdat', b'free', b'skip', b'wide'):
                return False, "poškozená hlavička mp4"
        elif ext == '.avi':
            if not (head.startswith(b'RIFF') and head[8:12] == b'AVI '):
                return False, "poškozená hlavička avi"
        return True, ""
    except Exception as e:
        return False, f"nelze přečíst: {e}"


def repair_media_file(filename, reason="", locality=None):
    """Smaže poškozený soubor a znovu ho stáhne z FTP.

    Chrání se počítadlem pokusů (MEDIA_REPAIR_MAX_ATTEMPTS) a cooldownem, aby z opravy
    nevznikla nová nekonečná smyčka. Vrací True, když je soubor po opravě v pořádku.
    """
    global _media_repair_state

    base = os.path.basename(filename)
    now = time.monotonic()
    st = _media_repair_state.get(base, {"attempts": 0, "last": 0.0})
    if now - st["last"] > MEDIA_REPAIR_COOLDOWN:
        st = {"attempts": 0, "last": now}   # dávno předtím -> nový začátek

    if st["attempts"] >= MEDIA_REPAIR_MAX_ATTEMPTS:
        xbmc.log(f"[Dohled] Oprava {base}: vyčerpány pokusy ({st['attempts']}) - nezkouším dál", xbmc.LOGWARNING)
        return False

    st["attempts"] += 1
    st["last"] = now
    _media_repair_state[base] = st

    # Plná relativní cesta pro FTP (soubor může být v podsložce, lokálně je pod basename)
    remote_name = resolve_remote_name(filename)
    xbmc.log(f"[Dohled] POŠKOZENÝ SOUBOR {base} ({reason}) - stahuji znovu z '{remote_name}' "
             f"(pokus {st['attempts']}/{MEDIA_REPAIR_MAX_ATTEMPTS})", xbmc.LOGERROR)

    if locality is None:
        locality = load_config().get("locality")
    ftp_config = fetch_ftp_config(locality) if locality else None
    if not ftp_config or not ftp_config.get("ftp_host"):
        xbmc.log("[Dohled] Oprava: FTP konfigurace není dostupná - vadný soubor RADĚJI NECHÁVÁM", xbmc.LOGERROR)
        return False

    local_path = get_local_media_path(base)
    backup_path = (local_path + ".corrupt") if local_path else None

    # KRITICKÉ: vadný soubor NESMAZAT dřív, než je ověřená náhrada. Dřív se mazal hned
    # a když stahování selhalo (např. špatná FTP cesta), zařízení zůstalo BEZ souboru
    # a Kodi hlásilo "Přehrávání selhalo". Proto ho jen odložíme stranou a při
    # neúspěchu vrátíme zpět.
    moved_aside = False
    try:
        if local_path and os.path.exists(local_path):
            if backup_path and os.path.exists(backup_path):
                os.remove(backup_path)
            os.rename(local_path, backup_path)
            moved_aside = True
    except Exception as e:
        xbmc.log(f"[Dohled] Oprava: nelze odložit vadný soubor: {e}", xbmc.LOGWARNING)

    try:
        clear_image_from_texture_cache(local_path)
    except Exception:
        pass

    # Zkusit plnou cestu, a když selže, ještě samotný basename (kdyby byl registr špatný)
    ok = download_file_ftp(
        ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"),
        ftp_config.get("ftp_path"), remote_name, local_path
    )
    if not ok and remote_name != base:
        xbmc.log(f"[Dohled] Oprava: zkouším ještě bez podsložky ({base})", xbmc.LOGINFO)
        ok = download_file_ftp(
            ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"),
            ftp_config.get("ftp_path"), base, local_path
        )

    expected = ftp_config.get("expected_file_size") if os.path.basename(ftp_config.get("file_name") or "") == base else None
    valid, why = validate_media_file(local_path, expected) if ok else (False, "stažení selhalo")

    if ok and valid:
        try:
            if moved_aside and backup_path and os.path.exists(backup_path):
                os.remove(backup_path)
        except Exception:
            pass
        xbmc.log(f"[Dohled] Oprava {base}: soubor znovu stažen a je v pořádku", xbmc.LOGINFO)
        return True

    # Neúspěch - vrátit původní soubor, ať zařízení neskončí úplně bez obsahu
    xbmc.log(f"[Dohled] Oprava {base} SELHALA ({why}) - vracím původní soubor", xbmc.LOGERROR)
    try:
        if moved_aside and backup_path and os.path.exists(backup_path) and not os.path.exists(local_path):
            os.rename(backup_path, local_path)
            xbmc.log(f"[Dohled] Oprava: původní soubor vrácen na místo", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Oprava: nelze vrátit původní soubor: {e}", xbmc.LOGERROR)
    return False


def ensure_media_playable(filename, expected_size=None, locality=None):
    """Ověří soubor a při poškození ho zkusí opravit. Vrací True, když je použitelný."""
    local_path = get_local_media_path(filename)
    ok, why = validate_media_file(local_path, expected_size)
    if ok:
        return True
    xbmc.log(f"[Dohled] Kontrola integrity {os.path.basename(filename)}: VADNÝ ({why})", xbmc.LOGWARNING)
    return repair_media_file(filename, why, locality)


# ======= PLAYLIST PARSING =======

def parse_playlist_item(item, default_duration=10):
    """Parsuje položku playlistu ve formátu 'soubor' nebo 'soubor:sekundy'.

    Zároveň si zapamatuje plnou relativní FTP cestu (kvůli podsložkám), aby šel
    soubor při poškození znovu stáhnout - lokálně se totiž ukládá jen pod basename.
    """
    item = item.strip()
    if not item:
        return None

    if ':' in item:
        parts = item.rsplit(':', 1)
        if len(parts) == 2 and parts[1].isdigit():
            register_remote_name(parts[0])
            return {'filename': parts[0], 'duration': int(parts[1])}

    register_remote_name(item)
    return {'filename': item, 'duration': None}


def parse_playlist_string(playlist_str, default_duration=10):
    """Parsuje celý playlist string."""
    items = []
    for item in playlist_str.split(','):
        parsed = parse_playlist_item(item, default_duration)
        if parsed:
            items.append(parsed)
    return items


# ======= PŘEHRÁVÁNÍ MÉDIÍ =======

def dismiss_image():
    """NIC NEZAVÍRÁ - přechod obrázek→obrázek se dělá výhradně novým ShowPicture.

    HISTORIE BUGU: dřív tato funkce volala Dialog.Close(all,true) + sleep(0.15).
    Slideshow okno (12007) je v Kodi modální dialog, takže Dialog.Close ho ZAVŘELO,
    obrazovka zůstala bez obsahu a Kodi ukázalo HOME MENU. Přitom ShowPicture nový
    obrázek nahradí ATOMICKY (GUI_MSG_SHOW_PICTURE: Reset+Add+Run), zavírat není třeba.
    Ponecháno jako no-op kvůli zpětné kompatibilitě volajících.
    """
    if current_displayed_image is None:
        return False
    xbmc.log(f"[Dohled] Přechod z obrázku {current_displayed_image} (bez zavírání - ShowPicture nahradí)", xbmc.LOGINFO)
    return True


def close_image_viewer():
    """Ukončí zobrazení obrázku BEZ odhalení menu - obrazovka zůstane ČERNÁ.

    HISTORIE BUGU: dřív dělala Dialog.Close(all) + Action(Stop) + ActivateWindow(home),
    tedy EXPLICITNĚ zapnula Kodi menu. Nyní se místo menu zobrazí krycí černý obrázek,
    který drží slideshow okno v popředí.
    Pro přechod obrázek→VIDEO tuto funkci není potřeba volat - video slideshow přebije
    samo (viz transition_to_video_from_image).
    """
    global current_displayed_image

    if current_displayed_image is None:
        return False

    xbmc.log(f"[Dohled] Ukončuji obrázek (krytí černou): {current_displayed_image}", xbmc.LOGINFO)

    # Krytí černou PŘED jakýmkoli zavíráním - na obrazovce tak nikdy není prázdno/menu
    show_black_filler("ukončení obrázku")
    time.sleep(0.1)

    current_displayed_image = None
    return True


def RepeatVideo(local_file):
    """Spustí přehrávání videa ve smyčce."""
    global current_displayed_image

    filename = os.path.basename(local_file)
    player = xbmc.Player()

    if current_displayed_image:
        # Obrázek → Video: černé video jako bridge
        xbmc.log(f"[Dohled] Přechod obrázek→video: {current_displayed_image} → {filename}", xbmc.LOGINFO)
        transition_to_video_from_image(player, local_file)
        current_displayed_image = None
    else:
        # Spustit video přímo
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.add(local_file)
        player.play(playlist)
        # KRITICKÉ: nad videem může být KRYCÍ ČERNÁ (show_black_filler) - viz uncover_if_covered
        uncover_if_covered(player, filename)

    xbmc.executebuiltin("PlayerControl(RepeatOne)")
    xbmc.log(f"[Dohled] Přehrávám video ve smyčce: {filename}", xbmc.LOGINFO)
    send_immediate_state_update(filename, playing=True, paused=False)


def ShowImage(image_path, display_time=None, _retry_count=0):
    """
    Zobrazí jeden obrázek s detekcí černé obrazovky a auto-opravou.

    Args:
        image_path: Cesta k obrázku
        display_time: Nepoužito (pro kompatibilitu)
        _retry_count: Interní počítadlo pokusů (nepoužívat přímo)

    Returns:
        bool: True pokud se obrázek zobrazil, False při selhání
    """
    global current_displayed_image

    if not os.path.exists(image_path):
        xbmc.log(f"[Dohled] Obrázek nenalezen: {image_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(image_path)
    player = xbmc.Player()
    was_playing_video = player.isPlayingVideo()

    # Zobrazit obrázek
    if was_playing_video:
        # Video → Obrázek: ShowPicture PRED stop
        xbmc.log(f"[Dohled] Přechod video→obrázek: → {filename}", xbmc.LOGINFO)
        transition_to_image_from_video(player, image_path)
        current_displayed_image = filename
    else:
        xbmc.log(f"[Dohled] Zobrazuji obrázek: {filename}", xbmc.LOGINFO)
        # Uvozovky jsou POVINNÉ - bez nich se obrázek s mezerou/čárkou v názvu nezobrazí vůbec
        xbmc.executebuiltin(f'ShowPicture("{image_path}")')
        current_displayed_image = filename

    # Počkat a ověřit zobrazení
    time.sleep(BLACK_SCREEN_VERIFY_DELAY)

    if not verify_image_displayed():
        # ČERNÁ OBRAZOVKA DETEKOVÁNA!
        xbmc.log(f"[Dohled] ČERNÁ OBRAZOVKA detekována: {filename} (pokus {_retry_count + 1})", xbmc.LOGERROR)

        if _retry_count < BLACK_SCREEN_MAX_RETRIES:
            # Pokus o opravu - vyčistit cache a zkusit znovu
            xbmc.log(f"[Dohled] Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)

            # Krátká pauza před dalším pokusem
            time.sleep(0.3)

            # Rekurzivní pokus
            return ShowImage(image_path, display_time, _retry_count + 1)
        else:
            # Všechny pokusy selhaly
            xbmc.log(f"[Dohled] Všechny pokusy selhaly pro: {filename}", xbmc.LOGERROR)
            current_displayed_image = None
            return False

    # Úspěch - obrázek se zobrazil
    if _retry_count > 0:
        xbmc.log(f"[Dohled] Obrázek zobrazen po {_retry_count + 1} pokusech: {filename}", xbmc.LOGINFO)

    # Okamžité odeslání stavu na dashboard
    time.sleep(0.2)
    send_immediate_state_update(filename, playing=True, paused=False)
    return True


def play_media_file(file_path, image_display_time=DEFAULT_IMAGE_DISPLAY_TIME):
    """Přehraje soubor podle jeho typu - video nebo obrázek."""
    if not os.path.exists(file_path):
        xbmc.log(f"[Dohled] Soubor neexistuje: {file_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(file_path)
    media_type = get_media_type(filename)

    if media_type == 'video':
        RepeatVideo(file_path)
        return True
    elif media_type == 'image':
        return ShowImage(file_path, display_time=None)
    else:
        xbmc.log(f"[Dohled] Nepodporovaný typ souboru: {filename}", xbmc.LOGERROR)
        return False


# ======= RESTART SCHEDULING =======

def get_last_reboot_date():
    """Přečte datum posledního restartu z REBOOT_TRACK_FILE."""
    if os.path.exists(REBOOT_TRACK_FILE):
        try:
            with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if lines:
                    first_line = lines[0].strip()
                    if first_line.startswith("Poslední restart:"):
                        return first_line.replace("Poslední restart:", "").strip()
        except:
            pass
    return "Žádný"


def save_planned_reboot(last_reboot_date, planned_time_str):
    """Uloží naplánovaný restart do souboru."""
    try:
        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {last_reboot_date}\n")
            f.write(f"Naplánovaný restart: {planned_time_str}\n")
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při ukládání plánovaného restartu: {e}", xbmc.LOGERROR)


# Generace plánovače restartu - inkrementuje se při každém (pře)plánování.
# reboot_task se ukončí bez restartu, pokud mezitím vznikla novější generace (reschedule_restart).
_reboot_generation = 0


def _parse_hm(value, default_h, default_m):
    """Parsuje 'HH:MM' -> (hodina, minuta); při chybě vrátí default."""
    try:
        if value:
            parts = str(value).split(':')
            return int(parts[0]), int(parts[1])
    except Exception:
        pass
    return default_h, default_m


def schedule_random_reboot(locality=None):
    """Naplánuje náhodný noční restart v samostatném vlákně.

    Feature B: okno a zapnutí/vypnutí se čtou z konfigurace lokality (/api/locality_config).
    - auto_restart=False -> žádný naplánovaný restart.
    - reboot_window_start/end (HH:MM) -> okno (výchozí 21:00-05:00), smí přes půlnoc.
    Podporuje přeplánování za běhu (reschedule_restart) přes _reboot_generation.
    """
    global stop_monitoring, _reboot_generation
    _reboot_generation += 1
    my_gen = _reboot_generation

    def reboot_task():
        monitor = xbmc.Monitor()

        # KRITICKÉ: Počkat (max ~180s), až bude systémový čas věrohodný (viz boot-loop fix).
        waited_for_time = 0
        while not is_time_valid() and waited_for_time < 180 and not monitor.abortRequested():
            if monitor.waitForAbort(5):
                return
            waited_for_time += 5
        if stop_monitoring or monitor.abortRequested() or _reboot_generation != my_gen:
            return

        # Feature B: načíst restart konfiguraci lokality
        auto_restart = True
        win_start, win_end = None, None
        if locality:
            try:
                cfg = fetch_ftp_config(locality)
                if cfg:
                    auto_restart = cfg.get('auto_restart', True)
                    win_start = cfg.get('reboot_window_start')
                    win_end = cfg.get('reboot_window_end')
            except Exception as e:
                xbmc.log(f"[Dohled] Nepodařilo se načíst restart config lokality: {e}", xbmc.LOGWARNING)

        if not auto_restart:
            xbmc.log("[Dohled] Automatický restart je pro tuto lokalitu VYPNUTÝ - neplánuji", xbmc.LOGINFO)
            return

        now = datetime.now()
        last_reboot_date = get_last_reboot_date()

        # Okno restartu (default 21:00-05:00); smí přesahovat půlnoc
        start_h, start_m = _parse_hm(win_start, 21, 0)
        end_h, end_m = _parse_hm(win_end, 5, 0)
        start_time = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
        end_time = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
        if (end_h, end_m) <= (start_h, start_m):
            end_time = end_time + timedelta(days=1)  # přes půlnoc
        # Pokud už celé okno proběhlo, posunout na další den
        if now >= end_time:
            start_time = start_time + timedelta(days=1)
            end_time = end_time + timedelta(days=1)
        xbmc.log(f"[Dohled] Restart okno {start_h:02d}:{start_m:02d}-{end_h:02d}:{end_m:02d}, plánuji na {start_time.date()}", xbmc.LOGINFO)

        # Vygenerovat náhodný čas restartu (musí být v budoucnosti)
        window_min = max(0, int((end_time - start_time).total_seconds() / 60))
        random_reboot_time = None
        for _ in range(100):
            cand = start_time + timedelta(minutes=random.randint(0, window_min))
            if cand > now:
                random_reboot_time = cand
                break
        if random_reboot_time is None:
            xbmc.log("[Dohled] CHYBA: Nepodařilo se najít platný čas restartu", xbmc.LOGERROR)
            return

        restart_date_time = random_reboot_time.strftime('%Y-%m-%d %H:%M:%S')
        save_planned_reboot(last_reboot_date, restart_date_time)
        xbmc.log(f"[Dohled] Naplánovaný restart: {restart_date_time}", xbmc.LOGINFO)

        # Čekání ukotveno na time.monotonic() (imunní vůči skoku hodin -> boot-loop fix)
        wait_seconds = (random_reboot_time - now).total_seconds()
        if wait_seconds <= 0:
            wait_seconds = 60
        deadline_monotonic = time.monotonic() + wait_seconds

        while (time.monotonic() < deadline_monotonic and not stop_monitoring
               and not monitor.abortRequested() and _reboot_generation == my_gen):
            remaining = deadline_monotonic - time.monotonic()
            if monitor.waitForAbort(min(60, max(1, remaining))):
                xbmc.log("[Dohled] Plánovaný restart zrušen (Kodi se vypíná)", xbmc.LOGINFO)
                return

        if stop_monitoring or monitor.abortRequested():
            xbmc.log("[Dohled] Plánovaný restart zrušen (addon se vypíná)", xbmc.LOGINFO)
            return
        if _reboot_generation != my_gen:
            xbmc.log("[Dohled] Plánovaný restart zrušen (přeplánováno)", xbmc.LOGINFO)
            return

        # Pojistka proti smyčce restartů (belt-and-suspenders)
        if not can_auto_reboot("scheduled"):
            return

        xbmc.log("[Dohled] Provádím naplánovaný restart zařízení...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Restart", "Zařízení se nyní restartuje", xbmcgui.NOTIFICATION_WARNING)
        mark_reboot("scheduled")
        xbmc.executebuiltin("Reboot")

    threading.Thread(target=reboot_task, daemon=True).start()


# ======= FALLBACK FUNKCE =======

def find_best_fallback_file():
    """Najde nejlepší fallback soubor."""
    try:
        if os.path.exists(LAST_FILENAME_FILE):
            with open(LAST_FILENAME_FILE, encoding="utf-8") as f:
                last_file = f.read().strip()
                possible = get_local_media_path(last_file)
                if possible and os.path.exists(possible):
                    xbmc.log(f"[Dohled] Fallback z last_filename: {possible}", xbmc.LOGINFO)
                    return possible

        # Hledat v obou adresářích (VIDEO_DIR a IMAGE_DIR)
        media_files = []
        for media_dir in [VIDEO_DIR, IMAGE_DIR]:
            if os.path.exists(media_dir):
                for filename in os.listdir(media_dir):
                    if is_supported_file(filename):
                        filepath = os.path.join(media_dir, filename)
                        mtime = os.path.getmtime(filepath)
                        media_files.append((filepath, mtime, get_media_type(filename)))

        if media_files:
            media_files.sort(key=lambda x: (x[2] != 'video', -x[1]))
            xbmc.log(f"[Dohled] Fallback nejnovější: {media_files[0][0]}", xbmc.LOGINFO)
            return media_files[0][0]

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání fallback souboru: {e}", xbmc.LOGERROR)

    return None


def get_best_available_file(preferred_file):
    """Najde nejlepší dostupný soubor pro přehrání."""
    if preferred_file and os.path.exists(preferred_file) and os.path.getsize(preferred_file) > 0:
        return preferred_file

    fallback_file = find_best_fallback_file()
    if fallback_file and os.path.exists(fallback_file) and os.path.getsize(fallback_file) > 0:
        return fallback_file

    try:
        if os.path.exists("/storage/videos/"):
            for filename in os.listdir("/storage/videos/"):
                if is_supported_file(filename):
                    filepath = os.path.join("/storage/videos/", filename)
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        xbmc.log(f"[Dohled] Nouzový soubor: {filepath}", xbmc.LOGWARNING)
                        return filepath
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání nouzového souboru: {e}", xbmc.LOGERROR)

    return None


# Globální stav WebSocket spojení
ws_connected = False
ws_app = None
ws_thread = None
last_ws_ack_time = 0  # Cas posledniho ACK od serveru
WS_STALE_TIMEOUT = 90  # Pokud zadny ACK za 90s, WS je mrtve

# Globální stav pro detekci změn (rychlé aktualizace)
last_playing_state = None
last_playing_true_time = None  # Čas kdy bylo naposledy playing=True (pro debouncing)
last_paused_state = None
last_filename = None

# Globální stav pro mixed playlist playback
# Používáme playlist_id místo stop_flag pro spolehlivé zastavení předchozího playlistu
current_playlist_id = 0
mixed_playlist_thread = None
# Globální proměnné pro sledování celého playlistu (včetně obrázků)
current_mixed_playlist = []  # Seznam názvů souborů v aktuálním playlistu
current_mixed_playlist_position = -1  # Aktuální pozice v mixed playlistu


class WebSocketClient:
    """WebSocket klient pro real-time komunikaci s API serverem."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.ws = None
        self.connected = False
        self.should_reconnect = True
        self.last_monitoring_time = 0

    def on_message(self, ws, message):
        """Zpracování příchozí zprávy ze serveru."""
        try:
            data = json.loads(message)
            msg_type = data.get("type")

            xbmc.log(f"[Dohled WS] Přijata zpráva typu: {msg_type}", xbmc.LOGINFO)

            if msg_type == "command":
                # Okamžité zpracování příkazu!
                command = data.get("command")
                params = data.get("params", {})
                if command:
                    xbmc.log(f"[Dohled WS] Příkaz: {command}, params: {params}", xbmc.LOGINFO)
                    execute_command(command, params, data.get("command_id"))

            elif msg_type == "ping":
                # Odpovědět na ping
                self.send_pong()

            elif msg_type == "welcome":
                # KRITICKÉ: Teprve zde nastavujeme ws_connected = True
                # Toto je potvrzení že server nás skutečně přijal a zařadil do active_connections
                global ws_connected
                ws_connected = True
                xbmc.log(f"[Dohled WS] Server potvrdil spojení! device_id={data.get('device_id')}", xbmc.LOGINFO)

            elif msg_type == "ack":
                global last_ws_ack_time
                last_ws_ack_time = time.time()
                xbmc.log(f"[Dohled WS] Server potvrdil monitoring data", xbmc.LOGINFO)

        except json.JSONDecodeError:
            xbmc.log(f"[Dohled WS] Neplatná JSON zpráva: {message[:100]}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba zpracování zprávy: {e}", xbmc.LOGERROR)

    def on_error(self, ws, error):
        """Zpracování chyby WebSocket."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Chyba: {error}", xbmc.LOGERROR)
        self.connected = False
        ws_connected = False  # Povolit HTTP fallback

    def on_close(self, ws, close_status_code, close_msg):
        """Zpracování uzavření spojení."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Spojení uzavřeno: {close_status_code} - {close_msg}", xbmc.LOGWARNING)
        self.connected = False
        ws_connected = False

        if self.should_reconnect:
            xbmc.log(f"[Dohled WS] Pokus o reconnect za {WS_RECONNECT_INTERVAL}s...", xbmc.LOGINFO)

    def on_open(self, ws):
        """Zpracování navázání spojení - čekáme na welcome zprávu ze serveru."""
        # DŮLEŽITÉ: Nenastavujeme ws_connected = True zde!
        # Čekáme na welcome zprávu ze serveru jako potvrzení že je spojení skutečně funkční
        xbmc.log("[Dohled WS] TCP spojení navázáno, čekám na welcome zprávu ze serveru...", xbmc.LOGINFO)
        self.connected = True  # Lokální flag pro send_json
        # ws_connected = True se nastaví až po přijetí welcome zprávy

        # Odeslat identifikaci s autorizačním tokenem
        self.send_json({
            "type": "identify",
            "device_id": self.device_id,
            "auth_token": API_KEY
        })

    def send_json(self, data):
        """Odeslání JSON zprávy přes WebSocket."""
        if self.ws and self.connected:
            try:
                self.ws.send(json.dumps(data))
                return True
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba při odesílání: {e}", xbmc.LOGERROR)
                self.connected = False
        return False

    def send_pong(self):
        """Odpověď na ping."""
        self.send_json({"type": "pong"})

    def send_monitoring(self, payload):
        """Odeslání monitoring dat přes WebSocket."""
        return self.send_json({
            "type": "monitoring",
            "payload": payload
        })

    def send_log_upload(self, lines):
        """Odeslani Kodi logu na server pres WebSocket."""
        return self.send_json({
            "type": "log_upload",
            "lines": lines,
            "timestamp": datetime.now().isoformat()
        })

    def connect(self):
        """Navázání WebSocket spojení."""
        global ws_app, ws_connected

        url = f"{WS_URL}{self.device_id}"
        xbmc.log(f"[Dohled WS] Připojuji se k: {url}", xbmc.LOGINFO)

        try:
            # SSL kontext - ověřuje certifikáty (s fallbackem pro zpětnou kompatibilitu)
            ctx = get_ssl_context()

            self.ws = websocket.WebSocketApp(
                url,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close,
                on_open=self.on_open
            )
            ws_app = self.ws

            # Spustit WebSocket v blokovacím režimu (v samostatném vlákně)
            self.ws.run_forever(
                sslopt={"context": ctx},
                ping_interval=WS_PING_INTERVAL,
                ping_timeout=10
            )

        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba při připojování: {e}", xbmc.LOGERROR)
            self.connected = False
            ws_connected = False  # Povolit reconnect

    def disconnect(self):
        """Ukončení WebSocket spojení."""
        self.should_reconnect = False
        if self.ws:
            try:
                self.ws.close()
            except:
                pass


def ws_connection_loop(device_id):
    """Smyčka pro udržování WebSocket spojení."""
    global stop_monitoring, ws_connected

    if not WEBSOCKET_AVAILABLE:
        xbmc.log("[Dohled WS] WebSocket knihovna není dostupná, použije se HTTP", xbmc.LOGWARNING)
        return

    xbmc.log("[Dohled WS] Spouštím WebSocket connection loop", xbmc.LOGINFO)

    ws_client = WebSocketClient(device_id)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        if not ws_connected:
            try:
                ws_client.connect()
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba v connection loop: {e}", xbmc.LOGERROR)

        # Čekat před dalším pokusem o reconnect - použít waitForAbort místo time.sleep!
        # waitForAbort se okamžitě vrátí pokud Kodi požaduje ukončení
        if monitor.waitForAbort(WS_RECONNECT_INTERVAL):
            break
        if stop_monitoring:
            break

    ws_client.disconnect()
    xbmc.log("[Dohled WS] Connection loop ukončen", xbmc.LOGINFO)


# České NTP servery (seřazené podle priority)
CZ_NTP_SERVERS = [
    "antispam.oresi.cz",  # ORESI interní server
    "tik.cesnet.cz",      # CESNET stratum 1
    "tak.cesnet.cz",      # CESNET stratum 1
    "ntp.nic.cz",         # CZ.NIC stratum 1
    "ntp.cesnet.cz",      # CESNET
    "0.cz.pool.ntp.org",  # Czech NTP pool
    "1.cz.pool.ntp.org",
]

# České HTTP servery pro fallback (bez HTTPS - aby fungoval i při špatném čase)
CZ_HTTP_SERVERS = [
    "http://www.seznam.cz",
    "http://www.novinky.cz",
    "http://www.idnes.cz",
    "http://www.centrum.cz",
]

# Minimální platný rok pro kontrolu času
MIN_VALID_YEAR = 2024
# Spodní hranice platného času ("build floor"): časy PŘED tímto datem jsou zaručeně
# špatné (zaseknutý fake-hwclock / RTC bez baterie). Bez tohoto by is_time_valid()
# přijalo starý "platný" čas (rok >= 2024, např. 2025-06) a addon by nesynchronizoval
# -> špatný čas by pak otrávil plánování restartu (viz schedule_random_reboot).
MIN_VALID_DATE = datetime(2026, 7, 1)

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Maximální doba čekání na síť (v sekundách)
NETWORK_WAIT_TIMEOUT = 30

# KRITICKÉ: Okamžitě smazat starý sync flag při načtení modulu
# Toto musí proběhnout PŘED spuštěním doplňku Smycky
try:
    if os.path.exists(TIME_SYNC_FILE):
        os.remove(TIME_SYNC_FILE)
        xbmc.log("[Dohled] Okamžitě odstraněn starý sync flag při startu", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)

# ======= SYNCHRONIZACE ČASU =======

def wait_for_network(timeout=NETWORK_WAIT_TIMEOUT):
    """Čeká na dostupnost sítě (WiFi může trvat déle)."""
    xbmc.log("[Dohled] Čekám na dostupnost sítě...", xbmc.LOGINFO)

    waited = 0
    while waited < timeout:
        try:
            # Zkusit připojení na Google DNS (IP bez DNS resolvingu)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            xbmc.log(f"[Dohled] Síť dostupná po {waited}s", xbmc.LOGINFO)
            return True
        except:
            pass

        time.sleep(1)
        waited += 1

        # Informovat každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Dohled] Stále čekám na síť... ({waited}s)", xbmc.LOGINFO)

    xbmc.log(f"[Dohled] Timeout čekání na síť ({timeout}s)", xbmc.LOGWARNING)
    return False



def is_time_valid():
    """Zkontroluje, zda je systémový čas platný.
    Platný = rok >= MIN_VALID_YEAR A ZÁROVEŇ není před build floor (MIN_VALID_DATE).
    Odmítnutí zaseknutého starého času (např. 2025-06 z fake-hwclock) vynutí NTP sync,
    aby se špatný čas nedostal do plánování restartu."""
    now = datetime.now()
    is_valid = now.year >= MIN_VALID_YEAR and now >= MIN_VALID_DATE
    xbmc.log(f"[Dohled] Kontrola času: {now.strftime('%Y-%m-%d %H:%M:%S')}, platný: {is_valid}", xbmc.LOGINFO)
    return is_valid


def sync_time_ntp(timeout=5):
    """Pokusí se synchronizovat čas přes NTP pomocí ntpd."""
    for server in CZ_NTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o NTP sync: {server}", xbmc.LOGINFO)
            # ntpd -n -q = nedaemonizovat, ukončit po sync
            result = subprocess.run(
                ["ntpd", "-n", "-q", "-p", server],
                timeout=timeout,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                xbmc.log(f"[Dohled] NTP synchronizace úspěšná: {server}", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"[Dohled] NTP {server} selhalo: {result.stderr}", xbmc.LOGWARNING)
        except subprocess.TimeoutExpired:
            xbmc.log(f"[Dohled] NTP {server} timeout po {timeout}s", xbmc.LOGWARNING)
        except FileNotFoundError:
            xbmc.log("[Dohled] ntpd není dostupný, přeskakuji NTP", xbmc.LOGWARNING)
            return False
        except Exception as e:
            xbmc.log(f"[Dohled] NTP {server} chyba: {e}", xbmc.LOGERROR)
    return False


def sync_time_http(timeout=5):
    """Fallback: získá čas z HTTP Date hlavičky (když NTP nedosáhne, např. firewall lokality).

    DŮLEŽITÉ opravy oproti dřívějšku:
    - http:// dnes většinou přesměruje na https://. Při ŠPATNÉM systémovém čase by ověření
      certifikátu selhalo (cert 'not yet valid') -> celý fallback padal. Proto použijeme
      SSL kontext BEZ ověření certifikátu (čteme jen Date hlavičku, ne obsah = bezpečné).
    - Date hlavička je v UTC (GMT). Dřív se nastavovala rovnou -> čas byl posunutý o offset
      časového pásma. Nyní převádíme na LOKÁLNÍ čas (astimezone) před `date --set`.
    """
    import ssl as _ssl
    ctx = _ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = _ssl.CERT_NONE
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
    for url in CZ_HTTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o HTTP time sync: {url}", xbmc.LOGINFO)
            req = urllib.request.Request(url, method='GET')
            req.add_header('User-Agent', 'Mozilla/5.0')

            with opener.open(req, timeout=timeout) as response:
                date_header = response.headers.get('Date')
                if date_header:
                    # RFC 2822 -> tz-aware UTC -> LOKÁLNÍ čas systému
                    server_time = parsedate_to_datetime(date_header)
                    try:
                        local_time = server_time.astimezone()
                    except Exception:
                        local_time = server_time
                    time_str = local_time.strftime("%Y-%m-%d %H:%M:%S")

                    xbmc.log(f"[Dohled] HTTP čas ze serveru: {time_str} (Date: {date_header})", xbmc.LOGINFO)

                    result = subprocess.run(
                        ["date", "--set", time_str],
                        capture_output=True,
                        text=True
                    )

                    if result.returncode == 0:
                        xbmc.log(f"[Dohled] Systémový čas nastaven na: {time_str}", xbmc.LOGINFO)
                        return True
                    else:
                        xbmc.log(f"[Dohled] Chyba nastavení času: {result.stderr}", xbmc.LOGERROR)
                else:
                    xbmc.log(f"[Dohled] {url} nevrátil Date hlavičku", xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log(f"[Dohled] HTTP sync {url} chyba: {e}", xbmc.LOGERROR)

    return False


def create_time_sync_flag():
    """Vytvoří signalizační soubor o úspěšné synchronizaci času."""
    try:
        sync_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(TIME_SYNC_FILE, "w") as f:
            f.write(sync_time_str)
        xbmc.log(f"[Dohled] Vytvořen sync flag: {TIME_SYNC_FILE}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vytváření sync flagu: {e}", xbmc.LOGERROR)


def remove_time_sync_flag():
    """Odstraní signalizační soubor (volá se při startu)."""
    try:
        if os.path.exists(TIME_SYNC_FILE):
            os.remove(TIME_SYNC_FILE)
            xbmc.log(f"[Dohled] Odstraněn starý sync flag", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)


def ensure_time_synchronized():
    """Zajistí synchronizaci času - hlavní funkce volaná při startu."""
    xbmc.log("[Dohled] === Zahajuji kontrolu a synchronizaci času ===", xbmc.LOGINFO)

    # Vždy odstranit starý flag při startu
    remove_time_sync_flag()

    # PRVNÍ: Počkat na síť (WiFi může trvat déle)
    if not wait_for_network():
        xbmc.log("[Dohled] Síť nedostupná, pokračuji bez synchronizace", xbmc.LOGWARNING)
        create_time_sync_flag()
        return False

    # Kontrola, zda je čas již platný
    if is_time_valid():
        xbmc.log("[Dohled] Systémový čas je již platný, sync není potřeba", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    xbmc.log("[Dohled] Systémový čas je neplatný, spouštím synchronizaci", xbmc.LOGWARNING)

    # Pokus 1: NTP (nejpřesnější)
    if sync_time_ntp(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes NTP", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    # Pokus 2: HTTP fallback
    xbmc.log("[Dohled] NTP selhalo, zkouším HTTP fallback", xbmc.LOGWARNING)
    if sync_time_http(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes HTTP", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    # Synchronizace selhala
    xbmc.log("[Dohled] KRITICKÉ: Synchronizace času selhala!", xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        "Chyba synchronizace",
        "Nepodařilo se synchronizovat čas!",
        xbmcgui.NOTIFICATION_ERROR,
        5000
    )

    # I při selhání vytvoříme flag, aby smyčky mohly pokračovat (s rizikem)
    # Lepší než aby se smyčky vůbec nespustily
    create_time_sync_flag()
    return False

# Oprava tabulky installed v Kodi databázi
def fix_installed_table():
    """
    Opravuje záznamy v tabulce 'installed' pro service.dohled a repository.noreason.

    Problémy které řeší:
    1. enabled=0 - addon/repo je vypnutý, Kodi ho ignoruje
    2. origin='' (prázdný) - addon nemá vazbu na repozitář, nemůže se aktualizovat

    Tato funkce:
    - Nastaví enabled=1 pro oba addony
    - Nastaví origin='repository.noreason' pro service.dohled

    DŮLEŽITÉ: Po změnách v databázi je nutný restart Kodi, aby se změny projevily.
    """
    try:
        import glob
        import sqlite3

        # Najít Addons databázi
        db_pattern = "/storage/.kodi/userdata/Database/Addons*.db"
        db_files = glob.glob(db_pattern)

        if not db_files:
            xbmc.log("[Dohled] Addons databáze nenalezena pro fix_installed_table", xbmc.LOGWARNING)
            return False

        db_path = sorted(db_files)[-1]  # Použít nejnovější verzi
        xbmc.log(f"[Dohled] Kontroluji installed tabulku v {db_path}", xbmc.LOGINFO)

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        changes_made = False
        targets = ['service.dohled', 'repository.noreason', 'service.smycky']
        correct_origin = 'repository.noreason'

        for target_id in targets:
            # Zkontrolovat aktuální stav
            cursor.execute("SELECT enabled, origin FROM installed WHERE addonID=?", (target_id,))
            row = cursor.fetchone()

            if row:
                current_enabled, current_origin = row

                # Opravit enabled pokud je 0
                if current_enabled == 0:
                    xbmc.log(f"[Dohled] OPRAVA: Povoluji addon {target_id} (enabled=0 -> 1)", xbmc.LOGWARNING)
                    cursor.execute("UPDATE installed SET enabled=1 WHERE addonID=?", (target_id,))
                    changes_made = True

                # Opravit origin pokud je prázdný (pouze pro addony, ne pro repo samotný)
                if target_id != 'repository.noreason':
                    if current_origin is None or current_origin == '':
                        xbmc.log(f"[Dohled] OPRAVA: Nastavuji origin pro {target_id} na {correct_origin}", xbmc.LOGWARNING)
                        cursor.execute("UPDATE installed SET origin=? WHERE addonID=?", (correct_origin, target_id))
                        changes_made = True
            else:
                xbmc.log(f"[Dohled] Addon {target_id} nenalezen v tabulce installed", xbmc.LOGINFO)

        if changes_made:
            conn.commit()
            xbmc.log("[Dohled] Změny v tabulce installed byly uloženy", xbmc.LOGINFO)
        else:
            xbmc.log("[Dohled] Žádné opravy v tabulce installed nebyly potřeba", xbmc.LOGINFO)

        conn.close()
        return changes_made

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při opravě installed tabulky: {e}", xbmc.LOGERROR)
        return False


# Odstranění blokujících update_rules z Kodi databáze
def fix_addon_update_rules():
    """
    Odstraní záznamy z tabulky update_rules v Kodi Addons databázi,
    které blokují aktualizace service.dohled a repository.noreason.

    Kodi update_rules hodnoty:
    - 0 = Auto-update (podle globálního nastavení)
    - 1 = Pouze notifikovat
    - 2 = Připnuto na aktuální verzi (NIKDY neaktualizovat)

    Pokud je addon "připnutý" (hodnota 2), aktualizace se nikdy neprovede.
    Tato funkce smaže tyto blokující záznamy.
    """
    try:
        import glob
        import sqlite3

        # Najít Addons databázi
        db_pattern = "/storage/.kodi/userdata/Database/Addons*.db"
        db_files = glob.glob(db_pattern)

        if not db_files:
            xbmc.log("[Dohled] Addons databáze nenalezena", xbmc.LOGWARNING)
            return False

        db_path = db_files[0]  # Použít první nalezenou
        xbmc.log(f"[Dohled] Kontroluji update_rules v {db_path}", xbmc.LOGINFO)

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Zkontrolovat existující pravidla
        cursor.execute("SELECT addonID, updateRule FROM update_rules WHERE addonID IN ('service.dohled', 'repository.noreason', 'service.smycky')")
        blocking_rules = cursor.fetchall()

        if blocking_rules:
            for addon_id, rule in blocking_rules:
                if rule == 2:  # Připnuto = blokuje aktualizace
                    xbmc.log(f"[Dohled] Addon {addon_id} má update_rule=2 (připnuto), odstraňuji", xbmc.LOGWARNING)

            # Smazat blokující pravidla
            cursor.execute("DELETE FROM update_rules WHERE addonID IN ('service.dohled', 'repository.noreason', 'service.smycky')")
            conn.commit()
            xbmc.log(f"[Dohled] Odstraněno {len(blocking_rules)} blokujících update pravidel", xbmc.LOGINFO)
            conn.close()
            return True
        else:
            xbmc.log("[Dohled] Žádná blokující update pravidla nenalezena", xbmc.LOGINFO)
            conn.close()
            return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při opravě update_rules: {e}", xbmc.LOGERROR)
        return False


def fix_addons_updatemode_setting():
    """
    Opraví nastavení addons.updatemode v guisettings.xml.

    Toto nastavení může blokovat aktualizace pokud má default="true".
    Hodnoty:
    - 0 = Automaticky instalovat aktualizace
    - 1 = Pouze notifikovat
    - 2 = Nikdy nekontrolovat
    """
    try:
        guisettings_path = "/storage/.kodi/userdata/guisettings.xml"

        if not os.path.exists(guisettings_path):
            return False

        with open(guisettings_path, 'r', encoding='utf-8') as f:
            content = f.read()

        needs_update = False
        new_content = content

        # Opravit default="true" na default="false" pro addons.updatemode
        if 'id="addons.updatemode"' in content and 'default="true"' in content:
            match = re.search(r'<setting id="addons\.updatemode"[^>]*default="true"', content)
            if match:
                new_content = re.sub(
                    r'(<setting id="addons\.updatemode"[^>]*) default="true"',
                    r'\1 default="false"',
                    new_content
                )
                needs_update = True
                xbmc.log('[Dohled] Opravuji addons.updatemode default="true" -> default="false"', xbmc.LOGWARNING)

        if needs_update:
            with open(guisettings_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            return True

        return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při opravě addons.updatemode: {e}", xbmc.LOGERROR)
        return False


def force_self_update_if_needed():
    """
    Zkontroluje jestli je dostupná novější verze service.dohled v repozitáři
    a pokud ano, provede manuální aktualizaci (obejde Kodi update systém).

    Toto řeší situace kdy:
    - Kodi update systém nefunguje správně
    - Addon má špatný origin v databázi
    - Jsou blokující update_rules
    - general.addonupdates nebo addons.updatemode mají špatné nastavení

    DŮLEŽITÉ: Zachovává origin v databázi pro budoucí automatické aktualizace.
    """
    try:
        import glob
        import zipfile
        import tempfile

        xbmc.log("[Dohled] Kontroluji dostupnost novější verze...", xbmc.LOGINFO)

        # 1. Získat aktuální nainstalovanou verzi
        addon = xbmcaddon.Addon()
        current_version = addon.getAddonInfo('version')
        xbmc.log(f"[Dohled] Aktuální verze: {current_version}", xbmc.LOGINFO)

        # 2. Zjistit dostupnou verzi z Kodi databáze
        db_pattern = "/storage/.kodi/userdata/Database/Addons*.db"
        db_files = glob.glob(db_pattern)

        if not db_files:
            xbmc.log("[Dohled] Addons databáze nenalezena", xbmc.LOGWARNING)
            return False

        db_path = db_files[0]
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Získat dostupnou verzi a URL pro stažení
        cursor.execute("""
            SELECT version, json_extract(metadata, '$.path') as download_url
            FROM addons
            WHERE addonID = 'service.dohled'
            ORDER BY version DESC
            LIMIT 1
        """)
        result = cursor.fetchone()

        if not result:
            xbmc.log("[Dohled] Informace o service.dohled nenalezeny v databázi", xbmc.LOGWARNING)
            conn.close()
            return False

        available_version, download_url = result
        xbmc.log(f"[Dohled] Dostupná verze: {available_version}, URL: {download_url}", xbmc.LOGINFO)

        # 3. Porovnat verze
        def parse_version(v):
            return tuple(map(int, v.split('.')))

        if parse_version(available_version) <= parse_version(current_version):
            xbmc.log(f"[Dohled] Již máme aktuální nebo novější verzi ({current_version} >= {available_version})", xbmc.LOGINFO)
            conn.close()
            return False

        xbmc.log(f"[Dohled] NALEZENA NOVĚJŠÍ VERZE: {available_version} > {current_version}", xbmc.LOGWARNING)

        # 4. Stáhnout ZIP
        xbmc.log(f"[Dohled] Stahuji aktualizaci z: {download_url}", xbmc.LOGINFO)

        temp_zip = "/storage/.kodi/temp/service.dohled_update.zip"
        try:
            # Timeout 60s pro pomalé sítě
            ctx = get_ssl_context()

            req = urllib.request.Request(download_url)
            req.add_header('User-Agent', 'Kodi-Addon-Updater/1.0')

            with urllib.request.urlopen(req, timeout=60, context=ctx) as response:
                with open(temp_zip, 'wb') as f:
                    f.write(response.read())

            xbmc.log(f"[Dohled] ZIP stažen: {os.path.getsize(temp_zip)} bajtů", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při stahování ZIP: {e}", xbmc.LOGERROR)
            conn.close()
            return False

        # 5. Extrahovat ZIP
        addons_dir = "/storage/.kodi/addons"
        addon_dir = os.path.join(addons_dir, "service.dohled")
        backup_dir = addon_dir + ".backup"

        try:
            # Vytvořit zálohu
            if os.path.exists(addon_dir):
                if os.path.exists(backup_dir):
                    shutil.rmtree(backup_dir)
                shutil.move(addon_dir, backup_dir)
                xbmc.log("[Dohled] Vytvořena záloha starého addonu", xbmc.LOGINFO)

            # Extrahovat
            with zipfile.ZipFile(temp_zip, 'r') as zf:
                zf.extractall(addons_dir)

            # ZIP vytváří složku s názvem service.dohled-X.X.X, přejmenovat
            extracted_dirs = glob.glob(os.path.join(addons_dir, "service.dohled-*"))
            if extracted_dirs:
                extracted_dir = extracted_dirs[0]
                if os.path.exists(addon_dir):
                    shutil.rmtree(addon_dir)
                shutil.move(extracted_dir, addon_dir)
                xbmc.log(f"[Dohled] Addon extrahován a přejmenován: {extracted_dir} -> {addon_dir}", xbmc.LOGINFO)

            # Smazat zálohu a temp soubory
            if os.path.exists(backup_dir):
                shutil.rmtree(backup_dir)
            if os.path.exists(temp_zip):
                os.remove(temp_zip)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při extrakci: {e}", xbmc.LOGERROR)
            # Obnovit zálohu
            if os.path.exists(backup_dir) and not os.path.exists(addon_dir):
                shutil.move(backup_dir, addon_dir)
            conn.close()
            return False

        # 6. Aktualizovat databázi - timestamp
        try:
            cursor.execute("""
                UPDATE installed
                SET lastUpdated = datetime('now')
                WHERE addonID = 'service.dohled'
            """)
            conn.commit()
            xbmc.log("[Dohled] Databáze aktualizována", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při aktualizaci databáze: {e}", xbmc.LOGWARNING)

        conn.close()

        # 7. Notifikovat uživatele a restartovat Kodi
        xbmc.log(f"[Dohled] AKTUALIZACE DOKONČENA: {current_version} -> {available_version}", xbmc.LOGWARNING)
        xbmc.executebuiltin('Notification(Dohled,Aktualizace na verzi ' + available_version + ' dokončena. Restartuje se...,5000)')

        # Počkat na zobrazení notifikace a restartovat Kodi
        # Pojistka proti smyčce (kdyby repo trvale hlásilo vyšší verzi než reálně nasazený ZIP)
        if not can_auto_reboot("self_update"):
            xbmc.log("[Dohled] Self-update dokončen, ale detekována smyčka - restart přeskočen", xbmc.LOGWARNING)
            return True
        time.sleep(3)
        xbmc.executebuiltin('RestartApp')

        return True

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při self-update: {e}", xbmc.LOGERROR)
        return False


# Zajištění že auto-update je zapnutý
def ensure_addon_autoupdate_enabled():
    """
    Zkontroluje a případně opraví nastavení automatických aktualizací doplňků.

    Kodi nastavení general.addonupdates:
    - 0 = Automaticky stahovat a instalovat (SPRÁVNÁ HODNOTA)
    - 1 = Upozornit, ale neinstalovat
    - 2 = Nikdy nekontrolovat aktualizace

    DŮLEŽITÉ: Pokud je v XML atribut default="true", Kodi ignoruje hodnotu
    a používá systémový default. Musíme změnit na default="false".

    Tato funkce zajistí, že hodnota je vždy 0 (automatické aktualizace).
    """
    try:
        guisettings_path = "/storage/.kodi/userdata/guisettings.xml"

        if not os.path.exists(guisettings_path):
            xbmc.log("[Dohled] guisettings.xml neexistuje, přeskakuji kontrolu auto-update", xbmc.LOGWARNING)
            return False

        # Načíst soubor
        with open(guisettings_path, 'r', encoding='utf-8') as f:
            content = f.read()

        import re
        needs_update = False
        new_content = content

        # Kontrola 1: Najít nastavení a zkontrolovat default atribut a hodnotu
        # Pattern pro celý element včetně atributů
        match = re.search(r'<setting id="general\.addonupdates"([^>]*)>(\d+)</setting>', new_content)

        if match:
            attributes = match.group(1)
            current_value = match.group(2)

            # Zkontrolovat jestli je default="true" - to způsobuje ignorování hodnoty
            if 'default="true"' in attributes:
                xbmc.log('[Dohled] Auto-update má default="true", měním na default="false"', xbmc.LOGWARNING)
                new_content = re.sub(
                    r'(<setting id="general\.addonupdates"[^>]*) default="true"([^>]*>)',
                    r'\1 default="false"\2',
                    new_content
                )
                needs_update = True

            # Zkontrolovat hodnotu - musí být 0 pro automatické aktualizace
            if current_value != '0':
                xbmc.log(f"[Dohled] Auto-update nastavení je {current_value}, měním na 0 (auto-update)", xbmc.LOGWARNING)
                new_content = re.sub(
                    r'(<setting id="general\.addonupdates"[^>]*>)\d+(</setting>)',
                    r'\g<1>0\g<2>',
                    new_content
                )
                needs_update = True

            if needs_update:
                # Zapsat změny
                with open(guisettings_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                xbmc.log("[Dohled] Auto-update nastavení opraveno (hodnota=0, default=false)", xbmc.LOGINFO)
                return True
            else:
                xbmc.log("[Dohled] Auto-update nastavení je správně (0, default=false)", xbmc.LOGINFO)
                return False
        else:
            xbmc.log("[Dohled] Nastavení general.addonupdates nenalezeno v guisettings.xml", xbmc.LOGWARNING)
            return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole auto-update nastavení: {e}", xbmc.LOGERROR)
        return False


# Vynucení kontroly aktualizací doplňků
def force_update_addons(retry_count=3, retry_delay=10):
    """
    Vynutí aktualizaci doplňků s retry mechanismem pro pomalá připojení.

    Kroky:
    1. Opravit tabulku installed v databázi (enabled, origin)
    2. Opravit nastavení auto-update (guisettings.xml) - hodnota 0
    3. Opravit addons.updatemode (guisettings.xml)
    4. Odstranit blokující update pravidla z databáze (update_rules)
    5. Aktualizovat repozitáře a lokální addony
    6. Pokud se addon neaktualizoval automaticky, provést manuální update

    Args:
        retry_count: Počet pokusů o aktualizaci
        retry_delay: Čekání mezi pokusy v sekundách
    """
    # 1. Opravit tabulku installed (enabled=1, origin nastavit)
    fix_installed_table()

    # 2. Zajistit že auto-update je zapnutý (hodnota 0)
    ensure_addon_autoupdate_enabled()

    # 3. Opravit addons.updatemode nastavení
    fix_addons_updatemode_setting()

    # 4. Odstranit blokující update pravidla z databáze
    fix_addon_update_rules()

    # 5. Optimalizace cache pro low-latency streaming
    ensure_low_latency_cache()

    # 6. Tichá instalace inputstream addonů pro streamy
    ensure_inputstream_addons()

    # 7. Standardní Kodi update
    for attempt in range(retry_count):
        try:
            # Test připojení k internetu před pokusem o aktualizaci
            if not test_internet_connection():
                xbmc.log(f"[Dohled] Aktualizace addonů - pokus {attempt + 1}/{retry_count}: Síť nedostupná, čekám...", xbmc.LOGWARNING)
                time.sleep(retry_delay)
                continue

            xbmc.log(f"[Dohled] Aktualizace addonů - pokus {attempt + 1}/{retry_count}", xbmc.LOGINFO)

            # Aktualizovat repozitáře
            xbmc.executebuiltin('UpdateAddonRepos()')

            # Počkat na dokončení aktualizace repozitářů (neblokující příkaz)
            # Na pomalých připojeních může trvat déle
            wait_time = 15 + (attempt * 10)  # Prodloužit čekání s každým pokusem
            xbmc.log(f"[Dohled] Čekám {wait_time}s na aktualizaci repozitářů...", xbmc.LOGINFO)
            time.sleep(wait_time)

            # Aktualizovat lokální doplňky
            xbmc.executebuiltin('UpdateLocalAddons()')
            time.sleep(5)  # Krátké čekání na UpdateLocalAddons

            xbmc.log("[Dohled] Vynucená kontrola aktualizací addonů dokončena", xbmc.LOGINFO)
            break  # Dokončeno, pokračovat na kontrolu self-update

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při aktualizaci addonů (pokus {attempt + 1}): {e}", xbmc.LOGERROR)
            if attempt < retry_count - 1:
                time.sleep(retry_delay)

    # 5. Pokud Kodi auto-update nefunguje, provést manuální self-update
    # Toto zkontroluje jestli je dostupná novější verze a pokud ano, stáhne ji
    xbmc.log("[Dohled] Kontrola self-update (záložní mechanismus)...", xbmc.LOGINFO)
    force_self_update_if_needed()

    return True


def test_internet_connection(timeout=5):
    """Testuje připojení k internetu pomocí HTTP požadavku."""
    try:
        # Použít HTTP (ne HTTPS) pro rychlejší test bez SSL handshake
        req = urllib.request.Request("http://www.google.com", method='HEAD')
        req.add_header('User-Agent', 'Mozilla/5.0')
        urllib.request.urlopen(req, timeout=timeout)
        return True
    except:
        return False


def addon_update_loop():
    """
    Periodická smyčka pro kontrolu aktualizací doplňků.
    Běží na pozadí a kontroluje aktualizace každou hodinu.
    """
    global stop_monitoring
    monitor = xbmc.Monitor()

    # Počkat 5 minut po startu před první kontrolou (dát čas na stabilizaci)
    initial_delay = 300
    xbmc.log(f"[Dohled] Addon update loop: Čekám {initial_delay}s před první kontrolou", xbmc.LOGINFO)

    # Použít waitForAbort místo time.sleep - okamžitě se vrátí při abort
    if monitor.waitForAbort(initial_delay):
        return  # Kodi požaduje ukončení

    while not stop_monitoring and not monitor.abortRequested():
        try:
            xbmc.log("[Dohled] Periodická kontrola aktualizací addonů", xbmc.LOGINFO)
            force_update_addons(retry_count=2, retry_delay=30)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v addon update loop: {e}", xbmc.LOGERROR)

        # Čekat 1 hodinu před další kontrolou - použít waitForAbort
        if monitor.waitForAbort(3600):
            return  # Kodi požaduje ukončení

# Získá čas startu addonu (Kodi) - použít pro detekci restartu Kodi
# DŮLEŽITÉ: Používáme monotonic time pro výpočet správného boot_time,
# protože čas při startu addonu může být špatný (před NTP sync).
# time.monotonic() je nezávislé na změnách systémového času.
def get_boot_time():
    """
    Vypočítá skutečný čas startu addonu dynamicky.

    Princip:
    1. ADDON_START_MONOTONIC obsahuje monotonic čas při startu (nezávislý na NTP)
    2. Spočítáme kolik sekund addon běží: time.monotonic() - ADDON_START_MONOTONIC
    3. Odečteme tuto dobu od AKTUÁLNÍHO času (který je už správný po NTP sync)
    4. Výsledek = skutečný čas kdy addon nastartoval (se správným rokem)
    """
    uptime_seconds = time.monotonic() - ADDON_START_MONOTONIC
    real_start_timestamp = time.time() - uptime_seconds
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(real_start_timestamp))

# Načtení verze doplňku service.smycky přímo z addonu
def get_smycky_version():
    # service.smycky je v proxy módu a na většině zařízení NENÍ nainstalován.
    # Nejdřív ověřit existenci - jinak xbmcaddon.Addon('service.smycky') zaloguje
    # "EXCEPTION: Unknown addon id 'service.smycky'" na C++ úrovni Kodi (i přes try/except).
    if not xbmc.getCondVisibility("System.HasAddon(service.smycky)"):
        return None
    try:
        smycky_addon = xbmcaddon.Addon('service.smycky')
        return smycky_addon.getAddonInfo('version')
    except Exception:
        return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení reboot_log.txt: {e}", xbmc.LOGERROR)
        return None
        
# Načíst nebo vytvořit DeviceID
def get_device_id():
    if xbmcvfs.exists(DEVICE_ID_FILE):
        with xbmcvfs.File(DEVICE_ID_FILE) as f:
            return f.read().strip()
    else:
        new_id = str(uuid.uuid4())
        with xbmcvfs.File(DEVICE_ID_FILE, 'w') as f:
            f.write(new_id)
        xbmc.log(f"[Dohled] Generuji nové DeviceID: {new_id}", xbmc.LOGINFO)
        return new_id

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        response_data = api_request(url, data=payload, timeout=10)
        xbmc.log(f"[Dohled] Odesláno na API, odpověď: {response_data}", xbmc.LOGINFO)
        return response_data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)
        return None

def check_for_commands(device_id):
    """Zkontroluje a vrátí příkaz z API: (command, params, command_id).

    command_id slouzi k potvrzeni SKUTECNEHO provedeni (send_command_ack). Starsi server
    ho neposila - pak je None a potvrzeni se paruje podle jmena prikazu.
    """
    try:
        url = f"https://apidohled.noreason.eu/api/commands/{device_id}"
        data = api_request(url, timeout=5)
        return data.get("command"), data.get("params"), data.get("command_id")
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole příkazů: {e}", xbmc.LOGERROR)
        return None, None, None


def send_download_progress(filename, percent, downloaded_mb, total_mb, status="downloading"):
    """Odešle průběh stahování přes WebSocket."""
    global ws_connected, ws_app
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "download_progress",
                "payload": {
                    "filename": filename,
                    "percent": percent,
                    "downloaded_mb": round(downloaded_mb, 1),
                    "total_mb": round(total_mb, 1),
                    "status": status  # "starting", "downloading", "completed", "error"
                }
            }))
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při odesílání progress: {e}", xbmc.LOGWARNING)


def download_and_play_file(filename):
    """Stáhne soubor z FTP a pak ho přehraje."""
    from ftplib import FTP
    _zamek = None
    _zamek_drzim = False
    global current_displayed_image, user_initiated_file, current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, mixed_playlist_thread

    try:
        # Nechat aktualni prehravani bezet behem stahovani (bez vypadku)
        xbmc.log(f"[Dohled] Download: Stahuji na pozadi {filename} (aktualni prehravani pokracuje)", xbmc.LOGINFO)

        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně uložit jen basename
        # remote_path musí zachovat celou cestu (ftp_path + filename včetně podsložky)
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        _zamek = zamek_stahovani(local_filename)
        _zamek.acquire()   # viz zamek_stahovani
        _zamek_drzim = True

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)
        # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
        _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
        if _uz_stazeno:
            xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

        if not _uz_stazeno:
            # Kontrola místa před stahováním
            ensure_space_for_download(int(file_size_mb) + 50)  # +50 MB rezerva

            xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Odeslat počáteční progress
            send_download_progress(filename, 0, 0, file_size_mb, "starting")

            downloaded = 0
            last_percent = 0
            last_progress_time = time.time()

            with open(temp_path, 'wb') as f:
                def callback(data):
                    nonlocal downloaded, last_percent, last_progress_time
                    f.write(data)
                    downloaded += len(data)
                    percent = int(downloaded * 100 / file_size)
                    current_time = time.time()

                    # Odeslat progress každých 500ms nebo při změně o 5%
                    if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                        downloaded_mb = downloaded / (1024 * 1024)
                        send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                        last_progress_time = current_time

                    if percent >= last_percent + 10:
                        last_percent = percent
                        xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

                ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

        ftp.quit()

        # 4. Přesunout dokončený soubor do cílové složky.
        # Staging i cíl jsou na /storage (stejný filesystém) -> os.rename je atomický a okamžitý.
        if not _uz_stazeno:
            if os.path.exists(local_path):
                os.remove(local_path)
            xbmc.log(f"[Dohled] Download: Přesouvám do {target_dir}", xbmc.LOGINFO)
            os.rename(temp_path, local_path)
        _zamek.release()
        _zamek_drzim = False

        # DŮLEŽITÉ: Vynutit zápis na disk - Kodi potřebuje vidět soubor
        os.sync()
        xbmc.log(f"[Dohled] Download: Filesystem sync dokončen", xbmc.LOGINFO)

        # KRITICKÉ: Informovat Kodi o novém souboru (invaliduje VFS cache)
        xbmc.executebuiltin(f'UpdateLibrary(video, "{target_dir}")')
        xbmc.log(f"[Dohled] Download: UpdateLibrary zavolán pro {target_dir}", xbmc.LOGINFO)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení
        send_download_progress(filename, 100, file_size_mb, file_size_mb, "completed")

        # 5. Zastavit playlist a prepnout na novy soubor (plynuly prechod)
        current_playlist_id += 1
        current_mixed_playlist = []
        current_mixed_playlist_position = -1
        xbmc.log(f"[Dohled] Download: Zastavuji playlist a prehravani noveho souboru", xbmc.LOGINFO)
        try:
            with open(STOP_SMYCKY_FLAG, "w") as f:
                f.write(str(time.time()))
        except:
            pass
        if mixed_playlist_thread and mixed_playlist_thread.is_alive():
            mixed_playlist_thread.join(timeout=2)

        player = xbmc.Player()
        if is_image_file(local_filename):
            if not verify_image_file_ready(local_path, expected_size=file_size, timeout=5.0):
                xbmc.log(f"[Dohled] Download: CHYBA - stažený soubor není čitelný!", xbmc.LOGERROR)
                return
            user_initiated_file = local_filename
            if player.isPlayingVideo():
                transition_to_image_from_video(player, local_path)
            else:
                if current_displayed_image:
                    dismiss_image()
                show_picture_safe(local_path, freshly_downloaded=True)
            current_displayed_image = local_filename
            xbmc.log(f"[Dohled] Download: Obrázek zobrazen: {local_filename}", xbmc.LOGINFO)
        else:
            if current_displayed_image:
                transition_to_video_from_image(player, local_path)
                current_displayed_image = None
            else:
                # Video se pousti PRIMO - ale nad nim muze viset KRYCI CERNA (po stopu,
                # po startu, po selhani zobrazeni), ktera se do current_displayed_image
                # neuklada. Bez odkryti hralo video POD cernou. Nalezeno 2.9.2026 nezavislou
                # kontrolou kodu; test V13 predtim prosel jen proto, ze pred nim bezelo video.
                play_video_uncovered(player, local_path)
            time.sleep(0.5)
            xbmc.executebuiltin("PlayerControl(RepeatOne)")
            xbmc.log(f"[Dohled] Download: Přehrávám video {local_filename}", xbmc.LOGINFO)
            send_immediate_state_update(local_filename, playing=True, paused=False)

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        if _zamek_drzim:
            _zamek.release()
            _zamek_drzim = False
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_fname}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def download_only_file(filename):
    """Stáhne soubor z FTP bez přehrání."""
    from ftplib import FTP
    _zamek = None
    _zamek_drzim = False

    try:
        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně uložit jen basename
        # remote_path musí zachovat celou cestu (ftp_path + filename včetně podsložky)
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        _zamek = zamek_stahovani(local_filename)
        _zamek.acquire()   # viz zamek_stahovani
        _zamek_drzim = True

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)
        # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
        _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
        if _uz_stazeno:
            xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

        if not _uz_stazeno:
            # Kontrola místa před stahováním
            ensure_space_for_download(int(file_size_mb) + 50)

            xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Odeslat počáteční progress
            send_download_progress(filename, 0, 0, file_size_mb, "starting")

            downloaded = 0
            last_percent = 0
            last_progress_time = time.time()

            with open(temp_path, 'wb') as f:
                def callback(data):
                    nonlocal downloaded, last_percent, last_progress_time
                    f.write(data)
                    downloaded += len(data)
                    percent = int(downloaded * 100 / file_size)
                    current_time = time.time()

                    # Odeslat progress každých 500ms nebo při změně o 5%
                    if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                        downloaded_mb = downloaded / (1024 * 1024)
                        send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                        last_progress_time = current_time

                    if percent >= last_percent + 10:
                        last_percent = percent
                        xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

                ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

                # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
                f.flush()
                os.fsync(f.fileno())
                xbmc.log(f"[Dohled] Download: File flush + fsync dokončen", xbmc.LOGINFO)

        ftp.quit()

        # 4. Přesunout dokončený soubor do cílové složky.
        # Staging i cíl jsou na /storage (stejný filesystém) -> os.rename je atomický a okamžitý.
        if not _uz_stazeno:
            if os.path.exists(local_path):
                os.remove(local_path)
            xbmc.log(f"[Dohled] Download: Přesouvám do {target_dir}", xbmc.LOGINFO)
            os.rename(temp_path, local_path)
        _zamek.release()
        _zamek_drzim = False

        # KRITICKÉ: Globální filesystem sync
        os.sync()
        xbmc.log(f"[Dohled] Download: Filesystem sync dokončen", xbmc.LOGINFO)

        # KRITICKÉ: Informovat Kodi o novém souboru (invaliduje VFS cache)
        xbmc.executebuiltin(f'UpdateLibrary(video, "{target_dir}")')
        xbmc.log(f"[Dohled] Download: UpdateLibrary zavolán pro {target_dir}", xbmc.LOGINFO)

        # KRITICKÉ: Ověřit velikost souboru před odesláním "completed"
        actual_size = os.path.getsize(local_path)
        if actual_size != file_size:
            xbmc.log(f"[Dohled] Download: CHYBA - velikost souboru neodpovídá! Očekáváno {file_size}, skutečná {actual_size}", xbmc.LOGERROR)
            send_download_progress(filename, 0, 0, 0, "error")
            return
        xbmc.log(f"[Dohled] Download: Velikost souboru ověřena OK ({actual_size} bytes)", xbmc.LOGINFO)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení - POUZE po úspěšné verifikaci
        send_download_progress(local_filename, 100, file_size_mb, file_size_mb, "completed")

        # DŮLEŽITÉ: Přidat do tracking čerstvě stažených souborů
        # play_file handler pak ví, že má použít freshly_downloaded=True
        recently_downloaded_files[local_filename] = time.time()
        xbmc.log(f"[Dohled] Download: Přidán do recently_downloaded_files: {local_filename}", xbmc.LOGINFO)

        # Nepřehrávat - pouze staženo

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        if _zamek_drzim:
            _zamek.release()
            _zamek_drzim = False
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_fname}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def strip_playlist_duration(item):
    """'Oresi/foto.jpg:15' -> 'Oresi/foto.jpg'. Bez dvojtecky vrati vstup beze zmeny.

    Doba zobrazeni se pripojuje za dvojtecku az v playlistu; pro praci se souborem
    (FTP cesta, lokalni jmeno) se musi odriznout.
    """
    try:
        if ':' in item:
            base, last = item.rsplit(':', 1)
            if last.isdigit():
                return base
    except Exception:
        pass
    return item


def download_files_from_cloud(filenames, ftp_config):
    """Stáhne více souborů z FTP. Vrací seznam úspěšně stažených lokálních souborů."""
    from ftplib import FTP

    ftp_host = ftp_config.get("ftp_host")
    ftp_user = ftp_config.get("ftp_user")
    ftp_pass = ftp_config.get("ftp_pass")
    ftp_path = ftp_config.get("ftp_path")

    downloaded_files = []

    try:
        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        for idx, filename in enumerate(filenames):
            _zamek = None
            _zamek_drzim = False
            try:
                # ODSTRANIT DOBU ZOBRAZENÍ z položky playlistu ("Oresi/foto.jpg:15" -> "Oresi/foto.jpg").
                # Administrace posílá do download_only_playlist položky VČETNĚ ":sekundy"
                # (LocalityPlaylistView to dělá záměrně, kvůli dobám zobrazení). Bez tohohle
                # oříznutí se skládala neexistující cesta "/smycky/Oresi/foto.jpg:15", FTP RETR
                # selhal, chyba se spolkla v per-file try/except a obrázek se PŘED restartem
                # nikdy nestáhl (zařízení ho pak dotáhlo až při startu).
                filename = strip_playlist_duration(filename)
                # ftp_path už obsahuje cestu ke složce (např. /smycky/Oresi/), takže stačí basename
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
                _zamek = zamek_stahovani(local_filename)
                _zamek.acquire()   # viz zamek_stahovani
                _zamek_drzim = True

                remote_path = ftp_path + filename
                file_size = ftp.size(remote_path)
                file_size_mb = file_size / (1024 * 1024)
                # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
                _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
                if _uz_stazeno:
                    xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

                if not _uz_stazeno:
                    # Kontrola místa
                    ensure_space_for_download(int(file_size_mb) + 50)

                    xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

                    # Odeslat progress (filename je aktuální soubor)
                    send_download_progress(f"playlist:{idx+1}/{len(filenames)}", 0, 0, file_size_mb, "downloading")

                    downloaded = 0
                    with open(temp_path, 'wb') as f:
                        def callback(data):
                            nonlocal downloaded
                            f.write(data)
                            downloaded += len(data)
                        ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

                        # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
                        f.flush()
                        os.fsync(f.fileno())

                # Přesunout dokončený soubor do cílové složky.
                # Staging i cíl jsou na /storage (stejný filesystém) -> os.rename je atomický.
                if not _uz_stazeno:
                    if os.path.exists(local_path):
                        os.remove(local_path)
                    os.rename(temp_path, local_path)
                _zamek.release()
                _zamek_drzim = False

                # KRITICKÉ: Globální filesystem sync
                os.sync()

                # KRITICKÉ: Ověřit velikost souboru
                actual_size = os.path.getsize(local_path)
                if actual_size != file_size:
                    xbmc.log(f"[Dohled] Playlist download: CHYBA - velikost {local_filename} neodpovídá! Očekáváno {file_size}, skutečná {actual_size}", xbmc.LOGERROR)
                    continue  # Přeskočit tento soubor, pokračovat s dalšími

                downloaded_files.append(local_filename)
                xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Hotovo: {local_filename} (ověřeno {actual_size} bytes)", xbmc.LOGINFO)

            except Exception as e:
                xbmc.log(f"[Dohled] Playlist download: Chyba při stahování {filename}: {e}", xbmc.LOGERROR)
                if _zamek_drzim:
                    _zamek.release()
                    _zamek_drzim = False
                # Uklidit nedokončený staging soubor (na /storage nezmizí sám jako kdysi v /tmp)
                try:
                    os.remove(f"{DOWNLOAD_STAGING_DIR}.downloading_{os.path.basename(filename)}")
                except OSError:
                    pass
                # Pokračovat s dalšími soubory
                continue

        ftp.quit()

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba FTP připojení: {e}", xbmc.LOGERROR)

    return downloaded_files


def download_and_play_playlist(filenames):
    """Stáhne více souborů z FTP a přehraje je jako playlist."""
    global current_displayed_image, current_playlist_id, mixed_playlist_thread, current_mixed_playlist, current_mixed_playlist_position

    try:
        # 0. Parsovat filenames - extrahovat skutečný název a duration
        # Formát může být "filename.jpg" nebo "filename.jpg:10" (s duration)
        parsed_files = []
        filenames_to_download = []
        for item in filenames:
            if ':' in item:
                parts = item.rsplit(':', 1)
                if len(parts) == 2 and parts[1].isdigit():
                    parsed_files.append({'filename': parts[0], 'duration': int(parts[1])})
                    filenames_to_download.append(parts[0])
                else:
                    parsed_files.append({'filename': item, 'duration': None})
                    filenames_to_download.append(item)
            else:
                parsed_files.append({'filename': item, 'duration': None})
                filenames_to_download.append(item)

        xbmc.log(f"[Dohled] Playlist download: Parsováno {len(parsed_files)} souborů", xbmc.LOGINFO)

        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory (pouze skutečné názvy bez :duration)
        xbmc.log(f"[Dohled] Playlist download: Stahuji {len(filenames_to_download)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames_to_download)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames_to_download, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download: Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # 5. Přehrát jako playlist (použít stejnou logiku jako play_playlist)
        xbmc.log(f"[Dohled] Playlist download: Hotovo, přehrávám {len(downloaded_files)} souborů", xbmc.LOGINFO)

        # NEZAVÍRAT tady obrázek! Aktuální obsah musí zůstat na obrazovce až do chvíle,
        # kdy je připravený nový (jinak by tu byla černá/menu po celou dobu příprav).
        # Zavření/překrytí řeší až konkrétní přehrání níže (transition funkce / ShowPicture).

        # Kategorizovat soubory - použít duration z parsed_files
        video_files = []
        image_files = []

        # Vytvořit lookup dict pro duration
        # Klice pres BASENAME: polozky prichazeji s podslozkou ('Oresi/foto.jpg:10'),
        # stazene soubory jsou bez cesty - jinak se doba nikdy nenasla a obrazky
        # dostaly vychozich 15 s misto nastavene doby (nalezeno 2.9.2026).
        duration_lookup = {os.path.basename(pf['filename']): pf['duration'] for pf in parsed_files}

        for filename in downloaded_files:
            local_path = get_local_media_path(filename)
            if os.path.exists(local_path):
                if is_video_file(filename):
                    video_files.append({"filename": filename})
                elif is_image_file(filename):
                    # Použít parsovanou duration nebo DEFAULT_IMAGE_DISPLAY_TIME
                    duration = duration_lookup.get(os.path.basename(filename)) or DEFAULT_IMAGE_DISPLAY_TIME
                    image_files.append({"filename": filename, "duration": duration})

        # Přehrát podle typu souborů
        if len(video_files) > 0 and len(image_files) == 0:
            # Pouze videa - klasický playlist
            current_playlist_id += 1
            current_mixed_playlist = []
            current_mixed_playlist_position = -1

            player = xbmc.Player()
            # NEVOLAT stop() ani nezavírat obrázek - video playlist se spustí POD slideshow
            # a slideshow se odkryje až když video hraje.
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            for vf in video_files:
                playlist.add(get_local_media_path(vf['filename']))

            player.play(playlist)
            # Odkryt VZDY podle skutecne viditelnosti slideshow okna, ne podle
            # current_displayed_image: kryci cerna se do te promenne neuklada, takze by
            # video po stopu / po startu hralo POD cernou (stejna trida chyby jako driv
            # v RepeatVideo; nalezeno 2.9.2026 nezavislou kontrolou kodu).
            uncover_if_covered(player, "video playlist (download)")
            current_displayed_image = None
            xbmc.executebuiltin("PlayerControl(RepeatAll)")
            xbmc.log(f"[Dohled] Playlist download: Spuštěn video playlist ({len(video_files)} videí)", xbmc.LOGINFO)
            # Okamžité odeslání stavu - první soubor v playlistu
            if video_files:
                send_immediate_state_update(video_files[0]['filename'], playing=True, paused=False)

        else:
            # Mix videí a obrázků nebo pouze obrázky - použít mixed playlist logiku
            # Vytvořit seznam všech souborů v původním pořadí
            all_files = []
            for filename in downloaded_files:
                local_path = get_local_media_path(filename)
                if os.path.exists(local_path):
                    if is_video_file(filename):
                        all_files.append({"filename": filename, "type": "video"})
                    elif is_image_file(filename):
                        all_files.append({"filename": filename, "type": "image",
                                          "duration": duration_lookup.get(os.path.basename(filename))
                                          or DEFAULT_IMAGE_DISPLAY_TIME})

            if not all_files:
                xbmc.log("[Dohled] Playlist download: Žádné platné soubory", xbmc.LOGERROR)
                return

            current_playlist_id += 1
            my_playlist_id = current_playlist_id

            if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                mixed_playlist_thread.join(timeout=3)

            def play_mixed_playlist():
                global current_displayed_image, current_mixed_playlist, current_mixed_playlist_position

                current_mixed_playlist = [f['filename'] for f in all_files]
                current_mixed_playlist_position = 0

                player = xbmc.Player()
                # NEVOLAT stop() - Kodi sám nahradí obsah. A NEVOLAT close_image_viewer():
                # ta nasadi KRYCI CERNOU a prvni video by pak hralo pod ni (was_image je
                # po ni False, takze se slo cestou PlayMedia bez odkryti). Obrazek zustane
                # na obrazovce, dokud ho prvni polozka nenahradi (transition / ShowPicture).
                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()

                while not xbmc.Monitor().abortRequested() and current_playlist_id == my_playlist_id:
                    for idx, file_info in enumerate(all_files):
                        current_mixed_playlist_position = idx

                        if current_playlist_id != my_playlist_id:
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            transition_hide()  # Safety: skryt overlay pri ukonceni
                            return

                        local_path = get_local_media_path(file_info['filename'])

                        was_image = current_displayed_image is not None
                        was_video = player.isPlayingVideo()

                        if file_info['type'] == 'video':
                            if was_image:
                                # Obrazek → Video: cerne video jako bridge
                                xbmc.log("[Dohled] Playlist: obrazek→video", xbmc.LOGINFO)
                                transition_to_video_from_image(player, local_path)
                                current_displayed_image = None
                            else:
                                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                                xbmc.executebuiltin("PlayerControl(RepeatOff)")
                                # PlayMedia + odkryti zpod pripadne kryci cerne
                                play_video_uncovered(player, local_path, builtin=True)

                            time.sleep(2)
                            while not xbmc.Monitor().abortRequested() and current_playlist_id == my_playlist_id:
                                if not player.isPlaying():
                                    break
                                time.sleep(1)
                        else:
                            # Obrazek
                            if was_video:
                                # Video → Obrazek: ShowPicture PRED stop
                                xbmc.log("[Dohled] Playlist: video→obrazek", xbmc.LOGINFO)
                                transition_to_image_from_video(player, local_path)
                                current_displayed_image = file_info['filename']
                            else:
                                # Obrazek → Obrazek nebo nic → obrazek
                                if was_image:
                                    xbmc.log("[Dohled] Playlist: obrazek→obrazek", xbmc.LOGINFO)
                                if show_picture_safe(local_path):
                                    current_displayed_image = file_info['filename']
                                else:
                                    current_displayed_image = None

                            duration = file_info.get('duration', 15)
                            elapsed = 0
                            while elapsed < duration and current_playlist_id == my_playlist_id:
                                time.sleep(1)
                                elapsed += 1

                        if current_playlist_id != my_playlist_id:
                            current_displayed_image = None
                            transition_hide()
                            return

                current_mixed_playlist = []
                current_mixed_playlist_position = -1
                transition_hide()

            mixed_playlist_thread = threading.Thread(target=play_mixed_playlist, daemon=True)
            mixed_playlist_thread.start()
            xbmc.log(f"[Dohled] Playlist download: Spuštěn mix playlist ({len(all_files)} souborů)", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def download_only_playlist(filenames):
    """Stáhne více souborů z FTP BEZ přehrání - pouze stažení."""
    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory
        xbmc.log(f"[Dohled] Playlist download (only): Stahuji {len(filenames)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download (only): Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # BEZ přehrávání - pouze staženo
        xbmc.log(f"[Dohled] Playlist download (only): Hotovo, staženo {len(downloaded_files)} souborů", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Staženo {len(downloaded_files)} souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download (only): Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def get_current_playlist():
    """Získá seznam souborů v aktuálním playlistu (včetně obrázků z mixed playlistu)."""
    global current_mixed_playlist, user_stopped

    # Pokud uživatel zastavil přehrávání, vrátit prázdný playlist
    if user_stopped:
        return []

    # Pokud běží mixed playlist (videa + obrázky), vrátit jeho seznam
    if current_mixed_playlist:
        return current_mixed_playlist

    # Fallback na Kodi video playlist - pouze pokud něco hraje
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return []  # Nic nehraje = prázdný playlist
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        items = []
        for i in range(playlist.size()):
            item = playlist[i]
            path = item.getPath() if hasattr(item, 'getPath') else str(item)
            filename = path.split('/')[-1] if path else f"Item {i}"
            items.append(filename)
        return items
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení playlistu: {e}", xbmc.LOGERROR)
        return []


def get_playlist_position():
    """Vrátí aktuální pozici v playlistu (včetně mixed playlistu)."""
    global current_mixed_playlist, current_mixed_playlist_position, user_stopped

    # Pokud uživatel zastavil přehrávání, vrátit -1
    if user_stopped:
        return -1

    # Pokud běží mixed playlist, vrátit jeho pozici
    if current_mixed_playlist and current_mixed_playlist_position >= 0:
        return current_mixed_playlist_position

    # Fallback na Kodi video playlist pozici - pouze pokud něco hraje
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return -1  # Nic nehraje
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        return playlist.getposition()
    except:
        return -1


def set_kodi_mute(muted):
    """Nastaví mute stav Kodi (Application.SetMute) - jen když se aktuální stav liší.
    Tím se vyhne zbytečnému OSD popupu při opakovaném vynucování v monitoring loopu.
    """
    desired = bool(muted)
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Application.GetProperties",
            "params": {"properties": ["muted"]}
        }))
        current = json.loads(resp).get("result", {}).get("muted")
        if current == desired:
            return
        xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Application.SetMute",
            "params": {"mute": desired}
        }))
        xbmc.log(f"[Dohled] Mute nastaven na: {desired}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při nastavení mute: {e}", xbmc.LOGERROR)


def send_command_ack(command, command_id=None, ok=True, error="", result=None):
    """Potvrdi serveru, ze prikaz byl OPRAVDU proveden (ne jen dorucen).

    Server do te doby vi jen to, ze prikaz PREDAL - Executed=1 se nastavuje uz pri
    vyzvednuti z fronty. Bez tohohle hlasi administrace "Odeslano" i u prikazu,
    ktery se na zarizeni nikdy nevykonal.

    Posila se pres WebSocket; kdyz neni, pres HTTP. Selhani se ignoruje - potvrzeni
    je doplnkova informace a nesmi shodit vykonavani prikazu.
    """
    global ws_connected, ws_app
    zprava = {"type": "command_ack", "command": command, "command_id": command_id,
              "ok": bool(ok), "error": str(error)[:180]}
    if result:
        zprava["result"] = result
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps(zprava))
            return True
        except Exception:
            pass   # spadne se na HTTP nize
    try:
        payload = dict(zprava)
        payload["device_id"] = get_device_id()
        api_request("https://apidohled.noreason.eu/api/commands/ack", data=payload,
                    method="POST", timeout=5)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Potvrzení příkazu se nepodařilo odeslat: {e}", xbmc.LOGDEBUG)
    return False


def execute_command(command, params=None, command_id=None):
    """Vykoná přijatý příkaz a potvrdí serveru jeho SKUTEČNÉ provedení."""
    global current_playlist_id, mixed_playlist_thread, current_displayed_image, current_mixed_playlist, current_mixed_playlist_position, user_initiated_file, user_stopped, pending_new_content, last_playing_true_time, last_stopped_content, playlist_paused
    xbmc.log(f"[Dohled] Vykonávám příkaz: {command}, params: {params}", xbmc.LOGINFO)

    # Jakykoli prikaz, ktery NASAZUJE NOVY OBSAH, rusi pauzu playlistu.
    # Jinak by novy obsah nabehl rovnou pozastaveny (pauza je globalni priznak, ktery
    # playlistove smycky respektuji) a vypadalo by to jako zamrznute zarizeni.
    if command in ("play_file", "play_playlist", "play_stream", "download_and_play",
                   "download_and_play_playlist", "update_video"):
        playlist_paused = False

    # Prikazy, ktere zarizeni RESTARTUJI, musi potvrdit HNED - po os.system("reboot")
    # se uz funkce nevrati, takze potvrzeni na konci by nikdy neodeslo a restart
    # (nejcastejsi prikaz vubec) by vypadal jako nikdy neprovedeny.
    if command in ("restart", "update_video", "refresh_config"):
        # "accepted" = prikaz prijat a zarizeni se restartuje; "ok" by tvrdilo,
        # ze prikaz dobehl, coz u restartu nedava smysl.
        send_command_ack(command, command_id, ok=True, result="accepted")

    try:
        if command == "restart":
            xbmc.log("[Dohled] Příkaz: RESTART zařízení", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Přijat příkaz k restartu...", xbmcgui.NOTIFICATION_WARNING, 3000)
            time.sleep(2)
            mark_reboot("manual")
            os.system("reboot")

        elif command == "update_video":
            xbmc.log("[Dohled] Příkaz: Vynucená aktualizace videa", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Vynucená aktualizace videa - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            mark_reboot("update_video")
            os.system("reboot")  # Restart způsobí stažení nového videa

        elif command == "play":
            xbmc.log("[Dohled] Příkaz: Spustit přehrávání", xbmc.LOGINFO)
            user_stopped = False  # Reset stop flagu
            playlist_paused = False  # Play vzdy rusi pauzu playlistu
            player = xbmc.Player()
            if player.isPlaying():
                # Pokud je pausnuto, spustit
                if xbmc.getCondVisibility("Player.Paused"):
                    player.pause()  # Toggle pause off
                    xbmc.log("[Dohled] Přehrávání obnoveno z pauzy", xbmc.LOGINFO)
            elif last_stopped_content:
                # RESUME: Obnovit naposledy stopnutý obsah
                xbmc.log(f"[Dohled] Obnovuji naposledy zastavený obsah: {last_stopped_content}", xbmc.LOGINFO)
                if last_stopped_content.get('type') == 'playlist':
                    # Obnovit playlist
                    files = last_stopped_content.get('files', [])
                    if files:
                        xbmc.log(f"[Dohled] Resume: spouštím playlist s {len(files)} soubory", xbmc.LOGINFO)
                        execute_command("play_playlist", {"files": files})
                    else:
                        xbmc.log("[Dohled] Resume: playlist je prázdný", xbmc.LOGWARNING)
                elif last_stopped_content.get('type') == 'single':
                    # Obnovit single file
                    filename = last_stopped_content.get('file')
                    if filename:
                        xbmc.log(f"[Dohled] Resume: spouštím soubor {filename}", xbmc.LOGINFO)
                        execute_command("play_file", {"filename": filename})
                    else:
                        xbmc.log("[Dohled] Resume: filename chybí", xbmc.LOGWARNING)
            else:
                # Není nic přehráváno a nemáme co obnovit - zkusit Kodi builtin
                xbmc.executebuiltin("PlayerControl(Play)")
                xbmc.log("[Dohled] Pokus o spuštění přehrávání (Kodi builtin)", xbmc.LOGINFO)

        elif command == "stop":
            playlist_paused = False  # Stop rusi pauzu, at nezustane viset pri dalsim obsahu
            xbmc.log("[Dohled] Příkaz: Zastavit přehrávání", xbmc.LOGINFO)

            # ULOŽIT AKTUÁLNÍ OBSAH PŘED ZASTAVENÍM (pro možnost obnovení přehrávání)
            if current_mixed_playlist and len(current_mixed_playlist) > 0:
                # Byl spuštěn playlist
                last_stopped_content = {
                    'type': 'playlist',
                    'files': list(current_mixed_playlist)  # Kopie seznamu
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: playlist s {len(current_mixed_playlist)} soubory", xbmc.LOGINFO)
            elif user_initiated_file:
                # Byl spuštěn jednotlivý soubor
                last_stopped_content = {
                    'type': 'single',
                    'file': user_initiated_file
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: single file {user_initiated_file}", xbmc.LOGINFO)
            else:
                # Zkusit získat aktuální soubor z přehrávače
                try:
                    player = xbmc.Player()
                    if player.isPlaying():
                        current_file = os.path.basename(player.getPlayingFile())
                        if current_file:
                            last_stopped_content = {
                                'type': 'single',
                                'file': current_file
                            }
                            xbmc.log(f"[Dohled] Uložen obsah pro resume: player file {current_file}", xbmc.LOGINFO)
                except:
                    pass

            # DŮLEŽITÉ: Zastavit běžící playlist
            current_playlist_id += 1
            current_mixed_playlist = []
            current_mixed_playlist_position = -1
            xbmc.log(f"[Dohled] stop: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

            # Nastavit flag že uživatel zastavil - monitoring nebude auto-startovat
            user_stopped = True
            xbmc.log("[Dohled] User stopped flag nastaven - auto-play deaktivován", xbmc.LOGINFO)

            # Vymazat user_initiated_file
            user_initiated_file = None

            # Zavřít zobrazený obrázek
            if current_displayed_image is not None:
                close_image_viewer()

            # Zastavit video
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
                # Po zastaveni VIDEA by zustalo HOME MENU (u obrazku to resi close_image_viewer
                # vyse). Pravidlo projektu: misto menu vzdy cerna. Pojistka to sama neudela,
                # protoze po stopu zamerne mlci (user_stopped).
                wait_for_player_stop(timeout=2.0)
                if not xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
                    show_black_filler("zastaveni videa")
            xbmc.log("[Dohled] Přehrávání zastaveno", xbmc.LOGINFO)

            # DŮLEŽITÉ: Resetovat last_playing_true_time aby state detection
            # okamžitě reportoval playing=False (bez 5s tolerance debouncing)
            last_playing_true_time = None

            # Okamžité odeslání stavu - nic se nepřehrává
            send_immediate_state_update("", playing=False, paused=False)

        elif command == "pause":
            xbmc.log("[Dohled] Příkaz: Pozastavit/pokračovat přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            # Pauza je PREPINAC a musi fungovat i nad OBRAZKEM: ten se zobrazuje pres
            # ShowPicture, takze player.isPlaying() je False. Driv se v takovem pripade
            # jen zalogovalo "nic se neprehrava" a playlist bezel dal - tlacitko bylo mrtve.
            playlist_paused = not playlist_paused
            if player.isPlaying():
                # Video: pauznout i samotny prehravac, at zamrzne obraz
                if xbmc.getCondVisibility("Player.Paused") != playlist_paused:
                    player.pause()  # Toggle
            is_paused = playlist_paused
            status = "pozastaveno" if is_paused else "pokračuje"
            xbmc.log(f"[Dohled] Přehrávání {status} (playlist_paused={playlist_paused})", xbmc.LOGINFO)
            try:
                current_file = os.path.basename(player.getPlayingFile())
            except Exception:
                current_file = current_displayed_image or user_initiated_file or ""
            send_immediate_state_update(current_file, playing=True, paused=is_paused)

        elif command == "play_file":
            # Přehrát konkrétní lokální soubor (video nebo obrázek)
            user_stopped = False  # Reset stop flagu
            if params and params.get("filename"):
                filename = params.get("filename")
                # Pro soubory ze složek použít basename (soubor je uložen bez cesty)
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                if os.path.exists(local_path):
                    xbmc.log(f"[Dohled] Příkaz: Přehrát soubor {local_path}", xbmc.LOGINFO)

                    # Nastavit že uživatel ručně pustil soubor - monitoring loop ho nepřepíše
                    # Při resetu na lokalitu (source=locality) NENASTAVOVAT - ať monitoring běží normálně
                    source = params.get("source", "")
                    if source == "locality":
                        user_initiated_file = None
                        xbmc.log(f"[Dohled] Reset na lokalitu: {local_filename}", xbmc.LOGINFO)
                    else:
                        user_initiated_file = local_filename
                        xbmc.log(f"[Dohled] User initiated file: {local_filename}", xbmc.LOGINFO)

                    # Zapamatovat stav PRED zastavenim playlistu
                    # (po zastaveni playlist vycisti current_displayed_image)
                    had_image_before = current_displayed_image is not None
                    had_video_before = xbmc.Player().isPlayingVideo()

                    # DŮLEŽITÉ: Zastavit běžící playlist před přehráním nového souboru
                    current_playlist_id += 1
                    current_mixed_playlist = []
                    current_mixed_playlist_position = -1
                    xbmc.log(f"[Dohled] play_file: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                    # Signál pro service.smycky aby zastavilo svůj playlist
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na ukončení předchozího playlistu
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        mixed_playlist_thread.join(timeout=2)

                    # Zjistit co aktuálně běží (po zastaveni playlistu)
                    player = xbmc.Player()
                    is_video_playing = player.isPlayingVideo()
                    is_image_displayed = current_displayed_image is not None
                    # Slideshow okno muze byt stale otevrene i kdyz playlist vycistil promennou
                    if not is_image_displayed and had_image_before:
                        is_image_displayed = verify_image_displayed()

                    if is_image_file(local_filename):
                        # CÍLEM JE OBRÁZEK
                        if is_video_playing:
                            # Video → Obrázek: ShowPicture PRED stop (obrazek prekryje video)
                            xbmc.log("[Dohled] Přepínám z videa na obrázek", xbmc.LOGINFO)
                            transition_to_image_from_video(player, local_path)
                            current_displayed_image = local_filename
                            send_immediate_state_update(local_filename, playing=True, paused=False)
                        else:
                            if is_image_displayed:
                                # Obrázek → Obrázek: ShowPicture primo nahradi stary
                                xbmc.log("[Dohled] Přepínám z obrázku na obrázek", xbmc.LOGINFO)
                            else:
                                xbmc.log(f"[Dohled] Zobrazuji obrázek: {local_filename}", xbmc.LOGINFO)

                            # KONTROLA: Byl soubor čerstvě stažen?
                            is_freshly_downloaded = False
                            if local_filename in recently_downloaded_files:
                                download_time = recently_downloaded_files[local_filename]
                                if time.time() - download_time < RECENTLY_DOWNLOADED_TTL:
                                    is_freshly_downloaded = True
                                    xbmc.log(f"[Dohled] play_file: Detekován čerstvě stažený soubor: {local_filename}", xbmc.LOGINFO)
                                    del recently_downloaded_files[local_filename]
                                else:
                                    del recently_downloaded_files[local_filename]

                            if show_picture_safe(local_path, freshly_downloaded=is_freshly_downloaded):
                                current_displayed_image = local_filename
                                xbmc.log(f"[Dohled] Obrázek zobrazen: {local_filename}", xbmc.LOGINFO)
                                send_immediate_state_update(local_filename, playing=True, paused=False)
                            else:
                                current_displayed_image = None

                    elif is_video_file(local_filename):
                        # CÍLEM JE VIDEO
                        if is_image_displayed:
                            # Obrázek → Video: cerne video jako bridge
                            xbmc.log("[Dohled] Přepínám z obrázku na video", xbmc.LOGINFO)
                            transition_to_video_from_image(player, local_path)
                        elif is_video_playing:
                            # Video → Video: Kodi sám nahradí video
                            xbmc.log("[Dohled] Přepínám z videa na video (bez stop)", xbmc.LOGINFO)
                            player.play(local_path)
                        else:
                            # Nic neběží (ale pred zastavenim playlistu mohlo neco byt)
                            if had_image_before or had_video_before:
                                xbmc.log("[Dohled] Spouštím video (po zastaveni playlistu)", xbmc.LOGINFO)
                                if had_image_before:
                                    transition_to_video_from_image(player, local_path)
                                else:
                                    player.play(local_path)
                            else:
                                # Přechod přes transition: video se spustí POD slideshow
                                # a slideshow se zavře teprve když video běží (bez mezery s menu).
                                xbmc.log("[Dohled] Spouštím video (přes transition, bez odhalení menu)", xbmc.LOGINFO)
                                transition_to_video_from_image(player, local_path)

                        current_displayed_image = None
                        time.sleep(0.5)
                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                        send_immediate_state_update(local_filename, playing=True, paused=False)
                    else:
                        # Zkusit přehrát jako video (fallback)
                        xbmc.log(f"[Dohled] Neznámý typ souboru, zkouším jako video", xbmc.LOGWARNING)
                        # NEVOLAT close_image_viewer() - nasadi KRYCI CERNOU a video by hralo POD ni
                        # (cerna obrazovka). Video slideshow prebije samo; odkryva se az PO spusteni.
                        player = xbmc.Player()
                        player.play(local_path)
                        time.sleep(1)
                        uncover_if_covered(player, 'video')
                        current_displayed_image = None
                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                        # Okamžité odeslání stavu
                        send_immediate_state_update(local_filename, playing=True, paused=False)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {local_filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz play_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "play_stream":
            # Přehrát stream URL přímo (IPTV, HTTP, HLS/m3u8, RTMP atd.)
            user_stopped = False
            url = params.get('url', '') if params else ''
            if url:
                xbmc.log(f"[Dohled] Příkaz: Přehrát stream {url}", xbmc.LOGINFO)
                # Oznacit, ze nabiha obsah - pojistka nesmi mezitim spustit fallback
                # (viz ensure_content_visible, bod 2a-0: zpusobilo to pad Kodi)
                _transition_begin(20.0)

                # Zastavit běžící playlist
                current_playlist_id += 1
                current_mixed_playlist = []
                current_mixed_playlist_position = -1
                xbmc.log(f"[Dohled] play_stream: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                # Signál pro service.smycky aby zastavilo svůj playlist
                try:
                    with open(STOP_SMYCKY_FLAG, "w") as f:
                        f.write(str(time.time()))
                    xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                # Počkat na ukončení předchozího playlistu
                if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                    mixed_playlist_thread.join(timeout=2)

                # Zavřít případný obrázek
                if current_displayed_image is not None:
                    close_image_viewer()

                # Zastavit aktuální přehrávání - ale NEJDŘÍV krytí: player.stop() u videa
                # bez slideshow okna ukáže HOME MENU, dokud stream nenaběhne (u internetového
                # HLS klidně sekundy; změřeno 2.9.2026 v E4: menu 170 ms). Černá se odkryje
                # až když stream hraje (smyčka níže + uncover_if_covered).
                player = xbmc.Player()
                if player.isPlaying():
                    if not xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
                        show_black_filler("příprava streamu")
                    player.stop()
                    wait_for_player_stop(timeout=3.0)

                # Připravit ListItem pro stream
                url_lower = url.lower()

                # Mrtvou URL Kodi NEPŘEDÁVAT (viz stream_dostupny) - krycí černá zůstane,
                # user_initiated_file se nastaví a watchdog zkouší znovu (bez přehrávání).
                _dostupny = stream_dostupny(url)
                if not _dostupny:
                    xbmc.log(f"[Dohled] play_stream: stream nedostupný, nepouštím: {url}", xbmc.LOGWARNING)
                # Pro RTSP/RTP/UDP/RTMP - přehrát čistě bez ListItem properties
                if not _dostupny:
                    pass
                elif url_lower.startswith(('rtsp://', 'rtp://', 'udp://', 'rtmp://')):
                    player.play(item=url)
                else:
                    play_item = xbmcgui.ListItem(path=url)
                    play_item.setProperty('IsPlayable', 'true')

                    # Zjistit zda jsou dostupné inputstream addony
                    has_adaptive = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')

                    # Pro HLS/m3u8 streamy: NECHAT NA KODI (nativni ffmpeg cesta).
                    # Driv se tu vynucoval inputstream.adaptive vcetne zastarale vlastnosti
                    # manifest_type (Kodi na ni hlasi deprecation warning). Na RPi3 to
                    # spolehlive shazovalo Kodi ~15 s po startu streamu (SIGSEGV, 2 pady
                    # za sebou 1.9.2026). Tataz URL prehravana PRIMO pres Kodi JSON-RPC,
                    # tedy bez techto vlastnosti, bezela 60 s bez problemu - rozdil je
                    # prave ve vynuceni adaptivniho vstupu.
                    if '.m3u8' in url_lower or 'hls' in url_lower:
                        play_item.setContentLookup(False)
                    # Pro DASH streamy
                    elif '.mpd' in url_lower:
                        if has_adaptive:
                            play_item.setMimeType('application/dash+xml')
                            play_item.setContentLookup(False)
                            play_item.setProperty('inputstream', 'inputstream.adaptive')
                            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')

                    player.play(item=url, listitem=play_item)
                xbmc.sleep(500)
                xbmc.executebuiltin('PlayerControl(RepeatOne)')

                # Nastavit user_initiated_file aby monitoring nepřepínal zpět
                user_initiated_file = url
                # Internetovy HLS/RTSP na RPi3 nabiha klidne 5-15 s. uncover_if_covered ceka
                # jen 3 s: kdyby odkryl driv, ukaze se menu, pojistka ho zakryje cernou a ta
                # pak nad uz hrajicim streamem visi az do dalsiho monitoring cyklu (~35 s).
                # Proto se na start streamu ceka az 20 s (znacka prechodu po tu dobu bezi).
                _t0 = time.time()
                while _dostupny and time.time() - _t0 < 20.0 and not player.isPlayingVideo():
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    xbmc.sleep(250)
                if _dostupny:
                    uncover_if_covered(player, "stream")
                _transition_end()
                current_displayed_image = None

                if not _dostupny:
                    # Stav je nastaven (user_initiated_file), obnovu resi stream watchdog;
                    # technik dostane potvrzeni s chybou misto "ok".
                    raise RuntimeError(f"stream nedostupný: {url}")
                xbmc.log(f"[Dohled] Přehrávám stream: {url}", xbmc.LOGINFO)
                # Okamžité odeslání stavu
                send_immediate_state_update(url, playing=True, paused=False)
            else:
                xbmc.log("[Dohled] Příkaz play_stream bez parametru url", xbmc.LOGWARNING)

        elif command == "download_and_play":
            # Stáhnout soubor z FTP a pak přehrát
            # DULEZITE: Nezastavovat aktualni prehravani - nechame bezet co bezi
            # az po stazeni se prepne na novy soubor (bez vypadku)
            user_stopped = False
            if params and params.get("filename"):
                filename = params.get("filename")
                local_filename = os.path.basename(filename)
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát {filename} (bez zastaveni)", xbmc.LOGINFO)

                # Nastavit user_initiated_file
                source = params.get("source", "")
                if source == "locality":
                    user_initiated_file = None
                    xbmc.log(f"[Dohled] Reset na lokalitu (download): {local_filename}", xbmc.LOGINFO)
                else:
                    user_initiated_file = local_filename
                    xbmc.log(f"[Dohled] User initiated file: {local_filename}", xbmc.LOGINFO)

                # Spustit stahování v samostatném vlákně
                # Aktualni prehravani bezi dal - prepne se az po stazeni
                threading.Thread(target=download_and_play_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_only":
            # Pouze stáhnout soubor z FTP bez přehrání
            # Nastavit pending_new_content flag - zabrání auto-play do restartu
            if params and params.get("filename"):
                filename = params.get("filename")
                xbmc.log(f"[Dohled] Příkaz: Pouze stáhnout {filename}", xbmc.LOGINFO)
                pending_new_content = True
                xbmc.log("[Dohled] pending_new_content nastaven - auto-play zablokován do restartu", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně (bez přehrání)
                threading.Thread(target=download_only_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_and_play_playlist":
            # Stáhnout více souborů z FTP a přehrát jako playlist
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát playlist ({len(files)} souborů)", xbmc.LOGINFO)

                # DŮLEŽITÉ: Zastavit běžící playlist před stahováním
                current_playlist_id += 1
                current_mixed_playlist = []
                current_mixed_playlist_position = -1
                xbmc.log(f"[Dohled] download_and_play_playlist: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                # Signál pro service.smycky aby zastavilo svůj playlist
                try:
                    with open(STOP_SMYCKY_FLAG, "w") as f:
                        f.write(str(time.time()))
                    xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                # Počkat na ukončení předchozího playlistu
                if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                    mixed_playlist_thread.join(timeout=2)

                # Nastavit user_initiated_file - kromě lokalitního zdroje.
                # Locality playlist NENÍ user-initiated (jinak dashboard potlačí varování).
                playlist_str = "playlist:" + ",".join(files)
                source = params.get("source", "")
                if source == "locality":
                    user_initiated_file = None
                    xbmc.log(f"[Dohled] Reset na lokalitu (playlist): {len(files)} souborů", xbmc.LOGINFO)
                else:
                    user_initiated_file = playlist_str
                    xbmc.log(f"[Dohled] User initiated playlist: {len(files)} souborů", xbmc.LOGINFO)

                # Spustit stahování a přehrávání v samostatném vlákně
                threading.Thread(target=download_and_play_playlist, args=(files,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "download_only_playlist":
            # Stáhnout více souborů z FTP BEZ přehrání
            # Nastavit pending_new_content flag - zabrání auto-play do restartu
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout {len(files)} souborů (bez přehrání)", xbmc.LOGINFO)
                pending_new_content = True
                xbmc.log("[Dohled] pending_new_content nastaven - auto-play zablokován do restartu", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně
                threading.Thread(target=download_only_playlist, args=(files,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "delete_file":
            # Smazat lokální soubor
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)

                # Kontrola že soubor není právě přehráván
                player = xbmc.Player()
                if player.isPlayingVideo():
                    playing_file = player.getPlayingFile()
                    if playing_file and playing_file.endswith(filename):
                        xbmc.log(f"[Dohled] Nelze smazat přehrávaný soubor: {filename}", xbmc.LOGWARNING)
                        xbmcgui.Dialog().notification("Dohled", f"Nelze smazat - soubor se přehrává", xbmcgui.NOTIFICATION_ERROR, 3000)
                        return

                if os.path.exists(local_path):
                    try:
                        os.remove(local_path)
                        xbmc.log(f"[Dohled] Soubor smazán: {local_path}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při mazání souboru: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().notification("Dohled", f"Chyba mazání: {str(e)[:20]}", xbmcgui.NOTIFICATION_ERROR, 3000)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor neexistuje", xbmcgui.NOTIFICATION_WARNING, 2000)
            else:
                xbmc.log("[Dohled] Příkaz delete_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "notification":
            title = params.get("title", "Dohled") if params else "Dohled"
            message = params.get("message", "") if params else ""
            duration = params.get("duration", 5000) if params else 5000
            xbmc.log(f"[Dohled] Příkaz: Notifikace - {title}: {message}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, duration)

        elif command == "set_mute":
            # Trvalé ztlumení/odtlumení zařízení
            if params is not None and "muted" in params:
                xbmc.log(f"[Dohled] Příkaz: set_mute ({params.get('muted')})", xbmc.LOGINFO)
                set_kodi_mute(params.get("muted"))
            else:
                xbmc.log("[Dohled] Příkaz set_mute bez parametru muted", xbmc.LOGWARNING)

        elif command == "update_addons":
            xbmc.log("[Dohled] Příkaz: Aktualizace doplňků", xbmc.LOGINFO)
            force_update_addons()

        elif command == "refresh_config":
            xbmc.log("[Dohled] Příkaz: Obnovení konfigurace", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Obnovuji konfiguraci - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            mark_reboot("refresh_config")
            os.system("reboot")

        elif command == "reschedule_restart":
            # Feature B: přeplánovat noční restart podle nové konfigurace lokality (BEZ rebootu).
            # Posílá Django admin po změně restart nastavení lokality.
            xbmc.log("[Dohled] Příkaz: Přeplánování restartu (nová konfigurace lokality)", xbmc.LOGINFO)
            try:
                schedule_random_reboot(load_config().get("locality"))
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při přeplánování restartu: {e}", xbmc.LOGERROR)

        elif command == "shell":
            # ODSTRANENO 1.9.2026 (bezpecnost). Drive: os.system(params["cmd"]) jako root.
            # Endpoint /api/websocket/send-command byl pritom verejne dostupny bez
            # autorizace, takze kdokoli se znalosti UUID zarizeni mohl spustit cokoli.
            # Zadne UI ani Django tenhle prikaz nikdy nevolalo (overeno grepem).
            # Server ho nyni navic odmita uz ve whitelistu (POVOLENE_PRIKAZY v main.py).
            xbmc.log("[Dohled] Příkaz shell je z bezpečnostních důvodů zakázán", xbmc.LOGWARNING)

        elif command == "play_playlist":
            # Přehrát více souborů za sebou (playlist) - podpora videí i obrázků
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                current_displayed_image = None  # Playlist spravuje zobrazení sám
                files = params.get("files")  # Seznam názvů souborů (může obsahovat filename:duration)
                xbmc.log(f"[Dohled] Příkaz: Přehrát playlist s {len(files)} soubory", xbmc.LOGINFO)

                # Nastavit user_initiated_file jako playlist string - kromě lokalitního zdroje.
                # Locality playlist NENÍ user-initiated (jinak dashboard potlačí varování).
                # user_initiated_file zajišťuje, že monitoring loop nepřepíše playlist;
                # u lokalitního zdroje to není třeba - playlist = lokalitní obsah.
                playlist_filenames = []
                for item in files:
                    if ':' in item:
                        parts = item.rsplit(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            playlist_filenames.append(item)  # Zachovat duration
                        else:
                            playlist_filenames.append(item)
                    else:
                        playlist_filenames.append(item)
                source = params.get("source", "")
                if source == "locality":
                    user_initiated_file = None
                    xbmc.log(f"[Dohled] Reset na lokalitu (play_playlist): {len(files)} souborů", xbmc.LOGINFO)
                else:
                    user_initiated_file = "playlist:" + ",".join(playlist_filenames)
                    xbmc.log(f"[Dohled] user_initiated_file nastaven: {user_initiated_file}", xbmc.LOGINFO)

                # Parsovat soubory - může být "filename" nebo "filename:duration"
                parsed_files = []
                for item in files:
                    if ':' in item:
                        parts = item.rsplit(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            parsed_files.append({'filename': parts[0], 'duration': int(parts[1])})
                        else:
                            parsed_files.append({'filename': item, 'duration': None})
                    else:
                        parsed_files.append({'filename': item, 'duration': None})

                # Rozdělit na videa a obrázky
                video_files = []
                image_files = []
                for pf in parsed_files:
                    local_path = get_local_media_path(pf['filename'])
                    if os.path.exists(local_path):
                        if is_video_file(pf['filename']):
                            video_files.append(pf)
                            xbmc.log(f"[Dohled] Playlist: video {pf['filename']}", xbmc.LOGINFO)
                        elif is_image_file(pf['filename']):
                            image_files.append(pf)
                            duration = pf['duration'] or DEFAULT_IMAGE_DISPLAY_TIME
                            xbmc.log(f"[Dohled] Playlist: obrázek {pf['filename']} ({duration}s)", xbmc.LOGINFO)
                        else:
                            xbmc.log(f"[Dohled] Playlist: nepodporovaný typ {pf['filename']}", xbmc.LOGWARNING)
                    else:
                        xbmc.log(f"[Dohled] Playlist: soubor neexistuje {pf['filename']}", xbmc.LOGWARNING)

                has_videos = len(video_files) > 0
                has_images = len(image_files) > 0
                total_count = len(video_files) + len(image_files)

                if total_count == 0:
                    xbmcgui.Dialog().notification("Dohled", "Žádné soubory nenalezeny", xbmcgui.NOTIFICATION_ERROR, 3000)
                elif has_videos and not has_images:
                    # Pouze videa - klasický video playlist

                    # DŮLEŽITÉ: Zastavit service.smycky playlist
                    current_playlist_id += 1
                    current_mixed_playlist = []
                    current_mixed_playlist_position = -1
                    xbmc.log(f"[Dohled] play_playlist (video): Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky (video playlist)", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na ukončení předchozího playlistu
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        mixed_playlist_thread.join(timeout=2)

                    # Spustit video playlist
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.clear()
                    for vf in video_files:
                        playlist.add(get_local_media_path(vf['filename']))

                    player = xbmc.Player()
                    # Spustit CELY playlist a teprve pak odkryt podle SKUTECNE viditelnosti
                    # slideshow okna. play_playlist nahore nuluje current_displayed_image, takze
                    # stara vetev "if current_displayed_image: transition..." byla mrtva a
                    # player.play(playlist) se volal BEZ odkryti: kdyz nad tim viselo slideshow
                    # okno (obrazek predchoziho obsahu nebo kryci cerna), divak videl porad
                    # puvodni obrazek, zatimco video hralo pod nim (zmereno 2.9.2026: 362 s).
                    player.play(playlist)
                    time.sleep(1)
                    uncover_if_covered(player, "video playlist")
                    current_displayed_image = None
                    xbmc.executebuiltin("PlayerControl(RepeatAll)")
                    # Okamžité odeslání stavu - první soubor v playlistu
                    if video_files:
                        send_immediate_state_update(video_files[0]['filename'], playing=True, paused=False)
                else:
                    # Mix videí a obrázků NEBO jeden soubor - custom playback loop

                    # Inkrementovat playlist ID - tím se automaticky zastaví předchozí playlist
                    current_playlist_id += 1
                    my_playlist_id = current_playlist_id
                    xbmc.log(f"[Dohled] Nový playlist ID: {my_playlist_id}", xbmc.LOGINFO)

                    # Signál pro service.smycky aby zastavilo svůj playlist
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na zastavení předchozího playbacku
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        xbmc.log("[Dohled] Čekám na zastavení předchozího playlistu...", xbmc.LOGINFO)
                        # Počkat max 2 sekundy na zastavení vlákna (nový obsah nahradí starý)
                        mixed_playlist_thread.join(timeout=2)

                    xbmc.log(f"[Dohled] Spouštím mix playlist: {len(video_files)} videí + {len(image_files)} obrázků", xbmc.LOGINFO)

                    # Pomocná funkce pro kontrolu zda je tento playlist stále aktivní
                    def is_my_playlist_active():
                        return current_playlist_id == my_playlist_id

                    # Spustit playback loop ve vlákně
                    def mixed_playback_loop():
                        global current_displayed_image, current_mixed_playlist, current_mixed_playlist_position
                        player = xbmc.Player()
                        current_index = 0
                        all_files = parsed_files  # Zachovat původní pořadí

                        # Chybějící soubory DOTÁHNOUT, ne je potichu zahodit z playlistu.
                        # Dřív se tady jen filtrovalo podle existence, takže soubor, který
                        # na zařízení chyběl (smazaný, nedostažený), z playlistu navždy vypadl
                        # a nikdo ho nedoplnil - zařízení hrálo zkrácenou smyčku.
                        # ensure_media_playable má vlastní strop pokusů i cooldown (MEDIA_REPAIR_*).
                        valid_files = []
                        for pf in all_files:
                            if not is_supported_file(pf['filename']):
                                continue
                            local_path = get_local_media_path(pf['filename'])
                            if not os.path.exists(local_path):
                                xbmc.log(f"[Dohled] Mix playlist: {pf['filename']} chybí"
                                         " - zkouším dotáhnout z FTP", xbmc.LOGWARNING)
                                ensure_media_playable(pf['filename'])
                            if os.path.exists(local_path):
                                valid_files.append(pf)

                        if not valid_files:
                            xbmc.log("[Dohled] Mix playlist: žádné platné soubory", xbmc.LOGERROR)
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            return

                        # Nastavit globální playlist pro monitoring
                        current_mixed_playlist = [pf['filename'] for pf in valid_files]
                        current_mixed_playlist_position = 0
                        xbmc.log(f"[Dohled] Mixed playlist nastaven: {current_mixed_playlist}", xbmc.LOGINFO)

                        # Speciální případ: jeden obrázek = zobrazit trvale
                        if len(valid_files) == 1 and is_image_file(valid_files[0]['filename']):
                            filename = valid_files[0]['filename']
                            local_path = get_local_media_path(filename)
                            xbmc.log(f"[Dohled] Mix: zobrazuji obrázek {filename} (trvale)", xbmc.LOGINFO)
                            # Video→obrázek přes transition (obrázek překryje video).
                            # POZOR: nikdy nevolat player.stop() nad zobrazeným obrázkem -
                            # zavřelo by slideshow a odhalilo Kodi MENU.
                            if player.isPlayingVideo():
                                transition_to_image_from_video(player, local_path)
                                current_displayed_image = filename
                            elif show_picture_safe(local_path):
                                current_displayed_image = filename  # Pro monitoring
                            else:
                                show_black_filler("selhalo zobrazení obrázku")
                                current_displayed_image = None
                            # Čekat dokud není playlist změněn + hlídat, že nevyskočilo menu
                            _guard = 0
                            while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                                time.sleep(1)
                                _guard += 1
                                if _guard % 3 == 0 and is_menu_visible():
                                    xbmc.log("[Dohled] Mix: menu přes trvalý obrázek - obnovuji", xbmc.LOGWARNING)
                                    show_picture_safe(local_path)
                            xbmc.log(f"[Dohled] Mix: obrázek {filename} ukončen (nový playlist)", xbmc.LOGINFO)
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            return

                        is_first_item = True  # Pro správné zavření overlay po prvním souboru

                        while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                            pf = valid_files[current_index]
                            filename = pf['filename']
                            local_path = get_local_media_path(filename)
                            # Aktualizovat pozici pro monitoring
                            current_mixed_playlist_position = current_index

                            if not is_my_playlist_active():
                                xbmc.log(f"[Dohled] Mix playlist {my_playlist_id}: zastaveno (nový playlist)", xbmc.LOGINFO)
                                break

                            # Proaktivní kontrola integrity (viz startup smyčka - poškozený
                            # obrázek Kodi "zobrazí" jako smetí, takže reaktivní kontrola nestačí)
                            if os.path.exists(local_path):
                                _v, _w = validate_media_file(local_path)
                                if not _v:
                                    xbmc.log(f"[Dohled] Mix: {filename} je VADNÝ ({_w}) - opravuji", xbmc.LOGWARNING)
                                    repair_media_file(filename, _w)

                            if is_video_file(filename):
                                # Video - přehrát celé (bez opakování)
                                xbmc.log(f"[Dohled] Mix: přehrávám video {filename}", xbmc.LOGINFO)
                                if current_displayed_image is not None:
                                    # Obrazek → Video: plynuly prechod
                                    transition_to_video_from_image(player, local_path)
                                    current_displayed_image = None
                                else:
                                    # Video → Video nebo START (nad vším může být krycí černá)
                                    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                                    xbmc.executebuiltin("PlayerControl(RepeatOff)")
                                    play_video_uncovered(player, local_path, builtin=True)
                                time.sleep(1)
                                xbmc.executebuiltin("PlayerControl(RepeatOff)")
                                is_first_item = False

                                # Zjistit co je dalsi polozka
                                next_idx = (current_index + 1) % len(valid_files)
                                next_is_image = is_image_file(valid_files[next_idx]['filename'])

                                # Cekat na video - spustit prechod na dalsi polozku
                                # 2s PRED koncem (kdy video jeste bezi = plynuly prechod)
                                video_started = False
                                transition_started = False
                                wait_count = 0
                                next_path = get_local_media_path(valid_files[next_idx]['filename'])
                                while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                                    if player.isPlayingVideo():
                                        video_started = True
                                        if not transition_started:
                                            try:
                                                total = player.getTotalTime()
                                                current_pos = player.getTime()
                                                remaining = total - current_pos
                                                if remaining < 2.0 and total > 3.0:
                                                    xbmc.log(f"[Dohled] Mix: video konci za {remaining:.1f}s, startuji pre-transition", xbmc.LOGINFO)
                                                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                                                    if next_is_image:
                                                        transition_to_image_from_video(player, next_path)
                                                        current_displayed_image = valid_files[next_idx]['filename']
                                                    else:
                                                        # Video → Video: primo nahradit (video jeste bezi = plynule)
                                                        player.play(next_path)
                                                    transition_started = True
                                                    break
                                            except:
                                                pass
                                        time.sleep(0.3)
                                    elif video_started:
                                        break
                                    else:
                                        wait_count += 1
                                        if wait_count > 20:
                                            xbmc.log(f"[Dohled] Mix: video {filename} se nespustilo", xbmc.LOGWARNING)
                                            break
                                        time.sleep(0.5)

                                if transition_started:
                                    xbmc.log(f"[Dohled] Mix: video {filename} dokonceno (pre-transition)", xbmc.LOGINFO)
                                    current_index = next_idx
                                    current_mixed_playlist_position = current_index
                                    if next_is_image:
                                        # Obrazek - pockat dobu zobrazeni
                                        img_duration = valid_files[next_idx].get('duration') or DEFAULT_IMAGE_DISPLAY_TIME
                                        elapsed = 0
                                        while elapsed < img_duration and is_my_playlist_active():
                                            time.sleep(0.5)
                                            if playlist_paused:
                                                continue   # PAUZA: cas nebezi
                                            elapsed += 0.5
                                    else:
                                        # Video - cekat na dokonceni (rekurzivne se resi v dalsi iteraci)
                                        pass
                                    # Prejit na dalsi polozku (pokud video, uz bezi z pre-transition)
                                    if next_is_image:
                                        current_index = (current_index + 1) % len(valid_files)
                                        current_mixed_playlist_position = current_index
                                    continue
                                else:
                                    time.sleep(0.3)
                                    xbmc.log(f"[Dohled] Mix: video {filename} dokončeno", xbmc.LOGINFO)
                                    # Po dohrání videa se Kodi vrací na HOME - okamžitě zakrýt
                                    if is_my_playlist_active() and not is_content_on_screen():
                                        show_black_filler("video dohrálo - zakrytí mezery")

                            elif is_image_file(filename):
                                # Obrázek - zobrazit na specifikovanou dobu
                                duration = pf['duration'] or DEFAULT_IMAGE_DISPLAY_TIME
                                xbmc.log(f"[Dohled] Mix: zobrazuji obrázek {filename} ({duration}s)", xbmc.LOGINFO)
                                if player.isPlayingVideo():
                                    transition_to_image_from_video(player, local_path)
                                    current_displayed_image = filename
                                else:
                                    # Obrázek→obrázek: ShowPicture nahradí atomicky, nic nezavírat
                                    if show_picture_safe(local_path):
                                        current_displayed_image = filename
                                    else:
                                        show_black_filler("selhalo zobrazení obrázku")
                                        current_displayed_image = None
                                is_first_item = False
                                # Čekat po menších intervalech pro rychlejší reakci na stop
                                elapsed = 0
                                while elapsed < duration and is_my_playlist_active():
                                    time.sleep(0.5)
                                    if playlist_paused:
                                        continue   # PAUZA: cas nebezi
                                    elapsed += 0.5
                                    # Hlídat, že obsah je stále v popředí (menu nikdy)
                                    if int(elapsed * 2) % 8 == 0 and is_menu_visible():
                                        xbmc.log("[Dohled] Mix: menu během obrázku - obnovuji", xbmc.LOGWARNING)
                                        show_picture_safe(local_path)
                                # Nepredcistovat dalsi prechod - nechame to na zacatku dalsi iterace

                            if not is_my_playlist_active():
                                current_displayed_image = None  # Playlist ukončen
                                break

                            # Přejít na další soubor
                            next_index = (current_index + 1) % len(valid_files)
                            if next_index == 0:
                                xbmc.log(f"[Dohled] Mix playlist: opakuji od začátku (položka 1/{len(valid_files)})", xbmc.LOGINFO)
                            else:
                                xbmc.log(f"[Dohled] Mix playlist: další položka {next_index + 1}/{len(valid_files)}", xbmc.LOGINFO)

                            current_index = next_index
                            current_mixed_playlist_position = current_index  # Aktualizovat pozici ihned

                        # Cleanup při ukončení loopu
                        current_displayed_image = None
                        current_mixed_playlist = []
                        current_mixed_playlist_position = -1
                        xbmc.log(f"[Dohled] Mix playlist {my_playlist_id} loop ukončen", xbmc.LOGINFO)

                    mixed_playlist_thread = threading.Thread(target=mixed_playback_loop, daemon=True)
                    mixed_playlist_thread.start()
            else:
                xbmc.log("[Dohled] Příkaz play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "add_to_playlist":
            # Přidat soubor do aktuálního playlistu
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)
                if os.path.exists(local_path):
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.add(local_path)
                    xbmc.log(f"[Dohled] Přidáno do playlistu: {filename}", xbmc.LOGINFO)
                    # Pokud nic nehraje, spustit
                    player = xbmc.Player()
                    if not player.isPlaying():
                        # NEVOLAT close_image_viewer() - nasadi KRYCI CERNOU a video by hralo POD ni
                        # (cerna obrazovka). Video slideshow prebije samo; odkryva se az PO spusteni.
                        player.play(playlist)
                        time.sleep(1)
                        uncover_if_covered(player, 'video')
                        current_displayed_image = None
                        xbmc.executebuiltin("PlayerControl(RepeatAll)")
                        # Okamžité odeslání stavu
                        send_immediate_state_update(filename, playing=True, paused=False)
                else:
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz add_to_playlist bez parametru filename", xbmc.LOGWARNING)

        elif command == "clear_playlist":
            # Vyčistit playlist
            xbmc.log("[Dohled] Příkaz: Vyčistit playlist", xbmc.LOGINFO)
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()

        else:
            xbmc.log(f"[Dohled] Neznámý příkaz: {command}", xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vykonávání příkazu {command}: {e}", xbmc.LOGERROR)
        send_command_ack(command, command_id, ok=False, error=str(e))
    else:
        # Probehlo bez vyjimky. Restartovaci prikazy uz potvrdily vyse (do te doby,
        # nez se stihne dojit sem, uz zarizeni rebootuje).
        if command not in ("restart", "update_video", "refresh_config"):
            send_command_ack(command, command_id, ok=True)

# Interval pro HTTP polling příkazů (fallback když není WebSocket)
# Zvýšeno zpět na 5s protože je to jen fallback
COMMAND_POLL_INTERVAL = 5


def command_polling_loop(device_id):
    """HTTP fallback pro příkazy - běží pouze když není WebSocket."""
    global stop_monitoring, ws_connected

    xbmc.log(f"[Dohled] Spuštěn HTTP fallback polling příkazů", xbmc.LOGINFO)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        # Pouze pollovat pokud není WebSocket připojen
        if not ws_connected:
            try:
                command, params, cmd_id = check_for_commands(device_id)
                if command:
                    # Parsovat params pokud je to JSON string
                    if params and isinstance(params, str):
                        try:
                            params = json.loads(params)
                        except:
                            pass
                    execute_command(command, params, cmd_id)

            except Exception as e:
                xbmc.log(f"[Dohled] Chyba v HTTP polling: {e}", xbmc.LOGERROR)

        # Čekat COMMAND_POLL_INTERVAL sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(COMMAND_POLL_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break

    xbmc.log("[Dohled] HTTP polling příkazů ukončen", xbmc.LOGINFO)

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        return api_request(url, timeout=5)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        return api_request(url, timeout=5)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
    try:
        return api_request(api_url, timeout=10)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def fetch_expected_file_with_locality(device_id, locality=None):
    """Načte očekávaný soubor z API - bere v potaz device override.

    Vrací tuple (filename, source) kde source je "device" nebo "locality".
    Parametr locality je volitelný fallback pro nová zařízení.
    """
    # Přidat boot_time pro detekci restartu - API vymaže UserInitiatedPlayback při změně boot_time
    boot_time = get_boot_time()
    params = []
    if locality:
        params.append(f"locality={locality}")
    if boot_time:
        params.append(f"boot_time={urllib.parse.quote(boot_time)}")
    query_string = "?" + "&".join(params) if params else ""
    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file{query_string}"
    try:
        data = api_request(api_url, timeout=5)
        filename = data.get("filename")
        source = data.get("source")
        if filename:
            xbmc.log(f"[Dohled] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
        return filename, source
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání očekávaného souboru: {e}", xbmc.LOGERROR)
        return None, None

# NOVÉ FUNKCE PRO LEPŠÍ DETEKCI MEDIÁLNÍCH SOUBORŮ

# Přípony pro filtrování
VIDEO_EXTENSIONS = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.webm', '.m4v')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

def get_media_type(filename):
    """Vrátí typ média podle přípony."""
    lower = filename.lower()
    if any(lower.endswith(ext) for ext in VIDEO_EXTENSIONS):
        return "video"
    elif any(lower.endswith(ext) for ext in IMAGE_EXTENSIONS):
        return "image"
    return None

def get_local_video_files():
    """Vrátí seznam lokálních mediálních souborů (videa z VIDEO_DIR, obrázky z IMAGE_DIR)."""
    try:
        files = []

        # Skenovat VIDEO_DIR (videa)
        if os.path.exists(VIDEO_DIR):
            for filename in os.listdir(VIDEO_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(VIDEO_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Skenovat IMAGE_DIR (obrázky)
        if os.path.exists(IMAGE_DIR):
            for filename in os.listdir(IMAGE_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(IMAGE_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Seřadit podle jména
        files.sort(key=lambda x: x["name"].lower())
        video_count = sum(1 for f in files if f.get("type") == "video")
        image_count = sum(1 for f in files if f.get("type") == "image")
        xbmc.log(f"[Dohled] Nalezeno {len(files)} lokálních souborů ({video_count} videí, {image_count} obrázků)", xbmc.LOGINFO)
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání lokálních souborů: {e}", xbmc.LOGERROR)
        return []


def get_storage_info():
    """Vrátí informace o úložišti (volné místo, celková kapacita)."""
    try:
        stat = os.statvfs(VIDEO_DIR)
        free_bytes = stat.f_bavail * stat.f_frsize
        total_bytes = stat.f_blocks * stat.f_frsize
        used_bytes = total_bytes - free_bytes

        return {
            "free_mb": round(free_bytes / 1024 / 1024, 2),
            "total_mb": round(total_bytes / 1024 / 1024, 2),
            "used_mb": round(used_bytes / 1024 / 1024, 2),
            "free_percent": round((free_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 0
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa: {e}", xbmc.LOGERROR)
        return {"free_mb": 0, "total_mb": 0, "used_mb": 0, "free_percent": 0}


def get_video_files_sorted_by_age():
    """Vrátí seznam video souborů seřazený od nejstaršího."""
    try:
        if not os.path.exists(VIDEO_DIR):
            return []

        files = []
        for filename in os.listdir(VIDEO_DIR):
            if filename.lower().endswith(VIDEO_EXTENSIONS) and not filename.startswith('.'):
                filepath = os.path.join(VIDEO_DIR, filename)
                if os.path.isfile(filepath):
                    try:
                        mtime = os.path.getmtime(filepath)
                        size = os.path.getsize(filepath)
                        files.append({
                            "name": filename,
                            "path": filepath,
                            "mtime": mtime,
                            "size": size,
                            "size_mb": round(size / 1024 / 1024, 2)
                        })
                    except:
                        pass

        # Seřadit od nejstaršího
        files.sort(key=lambda x: x["mtime"])
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání seznamu souborů: {e}", xbmc.LOGERROR)
        return []


def cleanup_old_videos(needed_space_mb=0, keep_current=True):
    """
    Vyčistí staré video soubory pouze pokud je nedostatek volného místa.
    Neomezuje počet souborů - uživatel může mít libovolně mnoho souborů v playlistu.

    Args:
        needed_space_mb: Kolik MB potřebujeme uvolnit (0 = jen kontrola MIN_FREE_SPACE_MB)
        keep_current: Ponechat aktuálně přehrávaný soubor

    Returns:
        Počet smazaných souborů
    """
    try:
        storage = get_storage_info()
        total_needed = needed_space_mb + MIN_FREE_SPACE_MB

        # Kontrola zda je potřeba uvolnit místo
        if storage["free_mb"] >= total_needed:
            xbmc.log(f"[Dohled] Storage: Dostatek místa ({storage['free_mb']} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0

        files = get_video_files_sorted_by_age()
        if not files:
            return 0

        # Zjistit aktuálně přehrávaný soubor
        current_file = None
        if keep_current:
            player = xbmc.Player()
            if player.isPlayingVideo():
                playing_path = player.getPlayingFile()
                current_file = os.path.basename(playing_path) if playing_path else None

        deleted_count = 0
        freed_space_mb = 0
        space_to_free = total_needed - storage["free_mb"]

        xbmc.log(f"[Dohled] Storage: Málo místa ({storage['free_mb']} MB volných), potřeba uvolnit {space_to_free} MB", xbmc.LOGWARNING)

        for f in files:
            if freed_space_mb >= space_to_free:
                break
            if f["name"] == current_file:
                xbmc.log(f"[Dohled] Storage: Přeskakuji aktuálně přehrávaný soubor: {f['name']}", xbmc.LOGINFO)
                continue
            try:
                os.remove(f["path"])
                deleted_count += 1
                freed_space_mb += f["size_mb"]
                xbmc.log(f"[Dohled] Storage: Smazán pro uvolnění místa: {f['name']} ({f['size_mb']} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Storage: Nelze smazat {f['name']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            xbmc.log(f"[Dohled] Storage: Celkem smazáno {deleted_count} souborů, uvolněno {freed_space_mb} MB", xbmc.LOGINFO)

        return deleted_count

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění souborů: {e}", xbmc.LOGERROR)
        return 0


def ensure_space_for_download(needed_mb):
    """Zajistí dostatek místa pro stažení nového souboru."""
    storage = get_storage_info()
    if storage["free_mb"] < needed_mb + MIN_FREE_SPACE_MB:
        xbmc.log(f"[Dohled] Storage: Před stahováním potřeba uvolnit místo pro {needed_mb} MB", xbmc.LOGINFO)
        cleanup_old_videos(needed_space_mb=needed_mb)
        return True
    return False


def find_current_video_file():
    """Najde aktuálně přehrávaný nebo nejnovější video soubor."""
    try:
        # 1. Zkusit najít aktuálně přehrávaný soubor
        player = xbmc.Player()
        if player.isPlayingVideo():
            playing_file = player.getPlayingFile()
            if playing_file and playing_file.startswith("/storage/videos/") and playing_file.endswith(".mp4"):
                xbmc.log(f"[Dohled] Nalezen přehrávaný soubor: {playing_file}", xbmc.LOGINFO)
                return playing_file
        
        # 2. Zkusit načíst z last_filename.txt (pokud existuje)
        if os.path.exists(LAST_FILENAME_FILE):
            try:
                with open(LAST_FILENAME_FILE, 'r', encoding='utf-8') as f:
                    last_filename = f.read().strip()
                    if last_filename:
                        potential_path = get_local_media_path(last_filename)
                        if os.path.exists(potential_path):
                            xbmc.log(f"[Dohled] Nalezen soubor z last_filename: {potential_path}", xbmc.LOGINFO)
                            return potential_path
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při čtení last_filename.txt: {e}", xbmc.LOGERROR)
        
        # 3. Najít nejnovější MP4 soubor v /storage/videos/
        video_dir = "/storage/videos/"
        if os.path.exists(video_dir):
            video_files = []
            for filename in os.listdir(video_dir):
                if filename.endswith('.mp4'):
                    filepath = os.path.join(video_dir, filename)
                    if os.path.exists(filepath):
                        mtime = os.path.getmtime(filepath)
                        video_files.append((filepath, mtime))
            
            if video_files:
                # Seřadit podle času úpravy (nejnovější první)
                video_files.sort(key=lambda x: x[1], reverse=True)
                xbmc.log(f"[Dohled] Nalezen nejnovější soubor: {video_files[0][0]}", xbmc.LOGINFO)
                return video_files[0][0]
        
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return None
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání aktuálního video souboru: {e}", xbmc.LOGERROR)
        return None

def get_video_file_info(expected_filename, expected_file_size=None):
    """Získá informace o video souboru a vyhodnotí potřebu aktualizace."""
    try:
        # 1. Zkusit nejdříve očekávaný soubor z API
        if expected_filename:
            # Použít basename - soubory ze složek jsou uloženy bez cesty
            local_expected = os.path.basename(expected_filename)
            expected_path = get_local_media_path(local_expected)
            if os.path.exists(expected_path):
                stat = os.stat(expected_path)
                file_size = stat.st_size
                
                # Vyhodnotit, zda je soubor aktuální
                # expected_file_size 0 nebo None = neznámá velikost, nepovažovat za neshodou
                size_matches = (not expected_file_size or file_size == expected_file_size)
                
                xbmc.log(f"[Dohled] Očekávaný soubor existuje: {local_expected}, velikost OK: {size_matches}", xbmc.LOGINFO)

                return {
                    'path': expected_path,
                    'filename': local_expected,  # Vrátit basename - skutečný název lokálního souboru
                    'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                    'file_size': file_size,
                    'is_expected': True,
                    'update_needed': not size_matches  # Aktualizace potřeba, pokud se velikost neshoduje
                }
        
        # 2. Pokud očekávaný soubor neexistuje, najít aktuální
        current_video = find_current_video_file()
        if current_video and os.path.exists(current_video):
            stat = os.stat(current_video)
            filename = os.path.basename(current_video)
            
            xbmc.log(f"[Dohled] Očekávaný soubor ({expected_filename}) neexistuje, používám aktuální: {filename}", xbmc.LOGWARNING)
            
            return {
                'path': current_video,
                'filename': filename,
                'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                'file_size': stat.st_size,
                'is_expected': False,
                'update_needed': True  # Pokud nemáme očekávaný soubor, aktualizace je potřeba
            }
        
        # 3. Žádný soubor nenalezen
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True  # Pokud nemáme žádný soubor, aktualizace je potřeba
        }
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání info o video souboru: {e}", xbmc.LOGERROR)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True
        }

def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    # Zapisovat heartbeat aby watchdog nerestartoval Kodi behem setup
    write_heartbeat()

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    write_heartbeat()
    names = fetch_device_setup_name()
    if names:
        # API vrací seznam stringů, ne slovníků
        name_options = sorted(names, key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    write_heartbeat()
    localities = fetch_localities()
    if localities:
        locality_pairs = sorted(
            [(loc['name'], loc['code']) for loc in localities],
            key=lambda x: x[0].lower()
        )
        locality_options = [f"{name} ({code})" for name, code in locality_pairs]
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = locality_pairs[selected_locality][1]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    with open("/storage/.cache/hostname", "w") as f:
        f.write(name + "\n")

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    mark_reboot("setup")
    os.system("reboot")

# ======= FEATURE A: DETEKCE PŘEKRYTÍ OBSAHU (menu/dialog/OSD/screensaver přes obsah) =======
content_obscured = False  # poslední zjištěný stav - reportuje se do monitoringu (dashboard varování)

# Nemodální překryvy (OSD, seekbar, hlasitost, kontextové menu, nastavení) dle jmen oken.
_OVERLAY_WINDOWS = (
    "Window.IsVisible(videoosd) | Window.IsVisible(seekbar) | Window.IsVisible(volumebar) | "
    "Window.IsVisible(contextmenu) | Window.IsVisible(osdvideosettings) | Window.IsVisible(osdaudiosettings) | "
    "Window.IsVisible(fullscreeninfo) | Window.IsVisible(playercontrols)"
)


def check_content_obscured():
    """Zjistí, zda je přes přehrávaný obsah GUI okno/dialog/OSD/screensaver nebo MENU.

    POZOR (oprava regrese z 3.5.0): slideshow okno 12007, kterým zobrazujeme OBRÁZKY,
    je v Kodi implementované jako MODÁLNÍ DIALOG. Původní kontrola ho proto vyhodnotila
    jako "překryv" a clear_content_overlays() ho zavřela -> obrazovka bez obsahu -> MENU.
    Náš vlastní slideshow (a přechodový busydialog) se proto NESMÍ počítat jako překryv.
    """
    try:
        if xbmc.getCondVisibility("System.ScreenSaverActive | System.DPMSActive"):
            return True, "screensaver/dpms"
        # Menu v popředí = obsah není vidět (nejhorší stav pro digital signage)
        if is_menu_visible():
            return True, "home_menu"
        # KRYCÍ ČERNÁ NAD HRAJÍCÍM VIDEEM: zařízení hlásí playing=True se správným
        # souborem, ale divák vidí ČERNOU OBRAZOVKU. Dashboard to jinak nemá jak poznat
        # (v testech výměny obsahu hlásil OK, přesto že 243 s svítila černá).
        # Během přechodu je to normální stav, proto se to hlásí jen mimo přechod.
        if (xbmc.getCondVisibility("Player.HasVideo") and not _transition_running()
                and xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive")):
            try:
                if os.path.basename(xbmc.getInfoLabel('Slideshow.Filename') or '') == \
                        os.path.basename(BLACK_IMAGE_PATH):
                    return True, "cerna_pres_video"
            except Exception:
                pass
        # Nemodální překryvy (OSD, seekbar, kontextové menu...) - ty zavřít lze
        if xbmc.getCondVisibility(_OVERLAY_WINDOWS):
            return True, "overlay_osd"
        if xbmc.getCondVisibility("System.HasVisibleModalDialog | System.HasActiveModalDialog"):
            # Náš obsah/přechod - NENÍ to překryv
            if xbmc.getCondVisibility("Window.IsVisible(slideshow) | Window.IsVisible(busydialog) | Window.IsVisible(busydialognocancel)"):
                return False, ""
            return True, "modal_dialog"
        return False, ""
    except Exception:
        return False, ""


# Dialogy, které patří NÁM a nesmí se zavírat: slideshow s obrázkem + přechodový busydialog.
# 9999 = "žádný aktivní dialog" (návratová hodnota xbmcgui.getCurrentWindowDialogId()).
_OUR_DIALOG_IDS = {12007, 10138, 10160, 9999}


def close_foreign_dialogs():
    """Zavře JAKÝKOLIV cizí dialog nad obsahem - podle jeho ID, ne podle jména.

    DŮVOD: jmenný seznam překryvů nikdy nepokryje všechno (změřeno: 'Nabídka vypnutí'
    (10111) zůstala nad videem, protože v seznamu nebyla, a 30s monitor loop ji nestihl).
    Tímto se pokryjí i dialogy nastavení, chybová okna, kontextová menu atd.
    Náš slideshow (12007) a přechodový busydialog se NIKDY nezavírají - je to obsah.
    """
    try:
        did = xbmcgui.getCurrentWindowDialogId()
        if did and did not in _OUR_DIALOG_IDS:
            xbmc.log(f"[Dohled] Pojistka: cizí dialog ID={did} nad obsahem - zavírám", xbmc.LOGWARNING)
            # Kodi se po zavření modálního dialogu na okamžik vrací na HOME, než znovu
            # aktivuje slideshow. Když nehraje video (to zůstane ve fullscreenu samo),
            # nejdřív znovu nasadit zobrazený obrázek nebo černou a teprve pak zavřít.
            if not xbmc.Player().isPlayingVideo():
                _img = get_local_media_path(current_displayed_image) if current_displayed_image else None
                if _img and os.path.exists(_img):
                    xbmc.executebuiltin(f'ShowPicture("{_img}")')
                else:
                    show_black_filler("zavření cizího dialogu")
            xbmc.executebuiltin(f"Dialog.Close({did},true)")
            return True
    except Exception:
        pass
    return False


# Jak dlouho smí nad hrajícím videem zůstat krycí okno, než to pojistka vyhodnotí
# jako zaseknuté krytí (přechody trvají do ~0,5 s, takže 3 s je bezpečná mez).
STUCK_COVER_SECONDS = 3.0
_video_under_slideshow_since = 0.0
_video_windowed_streak = 0


def uncover_stuck_cover():
    """POJISTKA proti zaseknuté krycí černé nad hrajícím videem (STUCK_COVER_SECONDS).

    Volá se KAŽDÝCH 0,5 s z menu_guard_loop. Dřív ležela jen uvnitř clear_content_overlays(),
    kterou rychlá smyčka volala jen při viditelném OSD - reálně tedy běžela až z monitor_loop
    (~35 s). Nalezeno 2.9.2026 nezávislou kontrolou kódu (changelog tvrdil 3 s).
    """
    try:
        # Obnovit fullscreen videa, pokud video hraje mimo fullscreen.
        #
        # POZOR - když je vidět náš slideshow, NESMÍ se použít Action(FullScreen):
        # uprostřed přechodu obrázek→video hraje video ZÁMĚRNĚ pod slideshow oknem a
        # Action(FullScreen) nad otevřeným slideshow video NEODKRYJE, jen zavře obrázek
        # a ukáže HOME (změřeno harnessem: HOME ~1,9 s, 3/3 pokusů).
        has_video = xbmc.getCondVisibility("Player.HasVideo")
        slideshow_up = xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive")
        # POZOR: VideoPlayer.IsFullscreen se na zaseknuté krytí SPOLEHNOUT NELZE - Kodi
        # považuje video pod otevřeným slideshow oknem pořád za "fullscreen" (změřeno:
        # krycí černá visela nad hrajícím videem 40+ s a podmínka na IsFullscreen mlčela).
        # Rozhoduje proto, CO je ve slideshow okně: black.png je vždycky jen KRYTÍ,
        # nikdy ne cílový obsah - takže nad hrajícím videem tam nemá co dělat.
        cover_up = False
        if slideshow_up:
            try:
                cover_up = os.path.basename(
                    xbmc.getInfoLabel('Slideshow.Filename') or '') == os.path.basename(BLACK_IMAGE_PATH)
            except Exception:
                cover_up = False
        global _video_under_slideshow_since, _video_windowed_streak
        if has_video and not slideshow_up and not xbmc.getCondVisibility("VideoPlayer.IsFullscreen"):
            # Video hraje mimo fullscreen a nad nim neni nas slideshow (typicky HOME menu
            # nad videem). Ted se kontroluje 2x/s, proto: NIKDY behem oznaceneho prechodu
            # (video->obrazek ma ~0,3 s okno, kdy video jeste "hraje" a fullscreen uz neni)
            # a teprve kdyz stav drzi 2 kontroly po sobe (~1 s) - jednoframove stavy se neresi.
            _video_windowed_streak += 1
            if not _transition_running() and _video_windowed_streak >= 2:
                xbmc.log("[Dohled] POJISTKA: video hraje mimo fullscreen bez krytí - obnovuji fullscreen", xbmc.LOGINFO)
                ensure_fullscreen_video()
                _video_windowed_streak = 0
            _video_under_slideshow_since = 0.0
        elif has_video and cover_up and not _transition_running():
            _video_windowed_streak = 0
            # ZASEKNUTÁ KRYCÍ ČERNÁ nad hrajícím videem -> divák vidí ČERNOU OBRAZOVKU.
            # Během přechodu je tenhle stav normální (a je označený značkou), takže sem
            # se dostane jen stav, který přechod není. Chvíli se ještě počká, aby se
            # nezasahovalo do neoznačeného krátkého přepnutí.
            if not _video_under_slideshow_since:
                _video_under_slideshow_since = time.monotonic()
            elif time.monotonic() - _video_under_slideshow_since > STUCK_COVER_SECONDS:
                xbmc.log("[Dohled] POJISTKA: nad hrajícím videem zůstalo krycí okno "
                         f"({round(time.monotonic() - _video_under_slideshow_since, 1)}s) "
                         "- odkrývám video", xbmc.LOGWARNING)
                # Odkrytí ATOMICKY přímo tady (ne přes uncover_video_from_image):
                # ta funkce nastavuje značku přechodu, a protože pojistka běží v jiném
                # vlákně než playlist, mohla by tím shodit ochranu právě běžícího přechodu.
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace (na RPi3 pri ni prosvitalo HOME)
                ensure_fullscreen_video()   # idempotentni - Action(FullScreen) je prepinac
                _video_under_slideshow_since = 0.0
        else:
            _video_under_slideshow_since = 0.0
            _video_windowed_streak = 0
    except Exception:
        pass


def clear_content_overlays():
    """Zavře překryvy tak, aby se NIKDY neodhalilo menu ani prázdná obrazovka.

    KRITICKÉ: NEPOUŽÍVAT Dialog.Close(all,true) - zavřelo by i náš slideshow (12007),
    kterým zobrazujeme obrázky, a obrazovka by spadla na HOME (přesně ten bug).
    Zavíráme proto jen KONKRÉTNÍ překryvná okna a obsah necháváme být.
    """
    try:
        for win in ("videoosd", "seekbar", "volumebar", "contextmenu", "osdvideosettings",
                    "osdaudiosettings", "fullscreeninfo", "playercontrols", "notification"):
            if xbmc.getCondVisibility(f"Window.IsVisible({win})"):
                xbmc.executebuiltin(f"Dialog.Close({win},true)")
        # Kodi chybové dialogy ("Přehrávání selhalo", potvrzovací okna) na reklamní
        # obrazovce nemají co dělat - zavřít cíleně (NIKDY Dialog.Close(all), to by
        # zavřelo i náš slideshow s obsahem).
        for win in ("okdialog", "yesnodialog", "progressdialog", "extendedprogressdialog"):
            if xbmc.getCondVisibility(f"Window.IsVisible({win})"):
                xbmc.log(f"[Dohled] Zavírám chybový/potvrzovací dialog: {win}", xbmc.LOGINFO)
                xbmc.executebuiltin(f"Dialog.Close({win},true)")
        uncover_stuck_cover()
    except Exception:
        pass


# ======= POJISTKA: MENU SE NIKDY NESMÍ UKÁZAT =======
_last_menu_recovery = 0.0
MENU_RECOVERY_COOLDOWN = 3.0  # s - aby oprava nejela v nekonečné smyčce


_menu_seen_streak = 0  # kolik kontrol po sobě vidělo menu (debounce proti jednoframovým blikům)


def ensure_content_visible():
    """Když v popředí ZŮSTÁVÁ Kodi MENU, přebije ho obsahem.

    DEBOUNCE: reaguje teprve když je menu vidět 2x po sobě (~0,5 s). Při přechodech
    (zavření slideshow / start videa) totiž prosvitne jediný frame - a "oprava" takového
    bliknutí byla ŠKODLIVÁ: pojistka jednou spustila fallback obrázek přes rozjíždějící
    se video, rozbila playlist a způsobila 3 s narušení (změřeno). Jednoframové bliky
    se proto ignorují; řeší se v příčině (pořadí operací v transition funkcích).

    Když běží playlist, pojistka NIKDY nespouští fallback - playlist si obsah nasadí sám
    do zlomku sekundy, stačí zakrýt černou.
    """
    global _last_menu_recovery, _menu_seen_streak

    try:
        if not is_menu_visible():
            _menu_seen_streak = 0
            return False
        # Nezasahovat, pokud uživatel zastavil přehrávání záměrně (stop příkaz)
        if user_stopped:
            _menu_seen_streak = 0
            return False

        _menu_seen_streak += 1
        if _menu_seen_streak < 2:
            return False   # jednoframový blik při přechodu - neřešit

        now = time.monotonic()
        if now - _last_menu_recovery < MENU_RECOVERY_COOLDOWN:
            return False
        _last_menu_recovery = now

        xbmc.log("[Dohled] POJISTKA: v popředí ZŮSTÁVÁ MENU - obnovuji obsah", xbmc.LOGWARNING)

        # 1) Okamžité krytí - menu zmizí i když obnova obsahu chvíli trvá
        show_black_filler("pojistka proti menu")

        player = xbmc.Player()

        # 2a-0) PRÁVĚ SE ROZJÍŽDÍ OBSAH Z PŘÍKAZU (stream, soubor, playlist)? Jen krýt.
        #       Fallback by spustil DRUHÉ přehrávání proti tomu, které startuje - a dvě
        #       OpenFile na jednom přehrávači z různých vláken shodila Kodi na RPi3
        #       (změřeno 28.8.2026: příkaz play_stream v 12:55:31.953 a fallback pojistky
        #       ve 12:55:31.974 -> pád v 12:55:39). Značka sama vyprší, viz _transition_*.
        if _transition_running():
            xbmc.log("[Dohled] POJISTKA: právě nabíhá obsah z příkazu - jen krytí", xbmc.LOGINFO)
            return True

        # 2a) Běží playlist? Nechat ho být - sám zobrazí další položku. Žádný fallback,
        #     jinak bychom mu přehráli cizí soubor a rozbili smyčku.
        if current_mixed_playlist:
            xbmc.log("[Dohled] POJISTKA: běží playlist - jen krytí, obsah nasadí playlist sám", xbmc.LOGINFO)
            return True

        # 2b) Obnovit konkrétní zobrazený obrázek
        if current_displayed_image:
            path = get_local_media_path(current_displayed_image)
            if path and os.path.exists(path):
                xbmc.executebuiltin(f'ShowPicture("{path}")')
                xbmc.log(f"[Dohled] POJISTKA: obnoven obrázek {current_displayed_image}", xbmc.LOGINFO)
                return True

        # 2c) Hraje video - jen vrátit do fullscreenu
        if player.isPlayingVideo():
            xbmc.executebuiltin('Action(FullScreen)')
            return True

        # 2d) Krátce po startu ještě nic nespouštět - startup_playback obsah nasadí do
        #     několika sekund. Jinak by se na ~1 s ukázal starý nesouvisející soubor.
        if (time.monotonic() - ADDON_START_MONOTONIC) < 25:
            xbmc.log("[Dohled] POJISTKA: krátce po startu - jen krytí, obsah nasadí startup", xbmc.LOGINFO)
            return True

        # 2e) Nic neběží ani není playlist - teprve teď fallback soubor
        fallback = find_best_fallback_file()
        if fallback and os.path.exists(fallback):
            xbmc.log(f"[Dohled] POJISTKA: spouštím fallback {os.path.basename(fallback)}", xbmc.LOGINFO)
            play_media_file(fallback)
            return True
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] POJISTKA: chyba při obnově obsahu: {e}", xbmc.LOGERROR)
        return False


def menu_guard_loop():
    """Samostatné vlákno: každé 2s hlídá, že v popředí není Kodi menu.

    Vlastní vlákno (ne součást state_update_loop) proto, že state_update_loop se spouští
    jen když je dostupná WebSocket knihovna - pojistka proti menu musí fungovat VŽDY.
    """
    monitor = xbmc.Monitor()
    xbmc.log("[Dohled] Pojistka proti menu spuštěna (kontrola 2x/s)", xbmc.LOGINFO)
    while not stop_monitoring and not monitor.abortRequested():
        try:
            ensure_content_visible()
            uncover_stuck_cover()   # zaseknuta cerna nad videem - kontrola 2x/s, ne az z monitoringu
            # Uklidit i překryvy PŘES obsah (videoosd, seekbar, hlasitost, kontextové menu).
            # Na reklamní obrazovce nemá svítit lišta přehrávače - a 30s monitor_loop
            # by ji nechal viset až půl minuty.
            if xbmc.getCondVisibility(_OVERLAY_WINDOWS):
                xbmc.log("[Dohled] Pojistka: překryv přes obsah (OSD/lišta) - zavírám", xbmc.LOGINFO)
                clear_content_overlays()
            # Cokoli cizího nad obsahem (nabídka vypnutí, nastavení, chybové okno...) zavřít podle ID
            close_foreign_dialogs()
        except Exception:
            pass
        if monitor.waitForAbort(0.5):
            break


def monitor_loop():
    global ws_connected, ws_app
    config = load_config()
    device_id = get_device_id()
    monitor = xbmc.Monitor()

    # Počkat na navázání WebSocket spojení (max 15 sekund)
    # Tím se vyhneme zbytečnému HTTP fallbacku při startu
    ws_wait_timeout = 15
    waited = 0
    while not ws_connected and waited < ws_wait_timeout and not stop_monitoring and not monitor.abortRequested():
        # Použít waitForAbort místo time.sleep - okamžitě se vrátí při abort
        if monitor.waitForAbort(1):
            return  # Kodi požaduje ukončení
        waited += 1
        # Logovat průběh čekání každých 5 sekund
        if waited % 5 == 0 and not ws_connected:
            xbmc.log(f"[Dohled] Čekám na WebSocket... {waited}s/{ws_wait_timeout}s", xbmc.LOGINFO)

    # Dát WebSocketu ještě chvíli na dokončení připojení
    if not ws_connected:
        if monitor.waitForAbort(1):
            return

    if ws_connected:
        xbmc.log(f"[Dohled] WebSocket připojen po {waited}s, spouštím monitoring", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] WebSocket timeout ({ws_wait_timeout}s), spouštím monitoring s HTTP fallback", xbmc.LOGWARNING)

    # Log upload tracking
    _log_upload_position = 0
    _last_log_upload_time = 0
    if os.path.exists(KODI_LOG_PATH):
        try:
            _log_upload_position = os.path.getsize(KODI_LOG_PATH)
            xbmc.log(f"[Dohled] Log upload: startovni pozice {_log_upload_position}", xbmc.LOGINFO)
        except:
            pass

    while not stop_monitoring and not monitor.abortRequested():
        global current_displayed_image
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            boot_time = get_boot_time()

            # Feature A: detekce a zavření překrytí obsahu (menu/dialog/OSD/screensaver)
            global content_obscured
            _obscured, _obscured_reason = check_content_obscured()
            if _obscured:
                xbmc.log(f"[Dohled] Obsah je překryt ({_obscured_reason}) - zavírám překryvy", xbmc.LOGWARNING)
                clear_content_overlays()
                _obscured, _obscured_reason = check_content_obscured()  # znovu ověřit po pokusu o zavření
            content_obscured = _obscured

            # Načíst očekávaný název souboru z API - bere v potaz device override!
            expected_filename, file_source = fetch_expected_file(device_id)
            expected_file_size = None

            # Vynutit trvalé ztlumení zařízení (příznak Muted z API)
            set_kodi_mute(device_muted)

            # Fallback na FTP config pro velikost souboru (pouze pokud není device override)
            if file_source != "device":
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    expected_file_size = ftp_config.get("expected_file_size")
                    # Pokud fetch_expected_file selhal, použít FTP config
                    if not expected_filename:
                        expected_filename = ftp_config.get("file_name")

            # Speciální handling pro playlisty - nekontrolovat existenci souboru
            is_playlist = expected_filename and expected_filename.startswith("playlist:")

            # Global declaration musí být před jakýmkoliv použitím proměnné
            global current_mixed_playlist, current_mixed_playlist_position

            if is_playlist:
                # Pro playlist neověřujeme existenci souboru, update není potřeba
                xbmc.log(f"[Dohled] Playlist mode: {expected_filename}", xbmc.LOGINFO)
                last_modified = None
                file_size = None
                current_filename = expected_filename  # Ponechat celý playlist string
                update_needed = False

                # Parsovat playlist a nastavit globální proměnnou pro reporting
                # Formát: playlist:file1:dur1,file2,file3:dur3,...
                # ALE: Pouze pokud playlist ještě neběží (abychom nepřepisovali běžící playlist)
                if current_mixed_playlist_position < 0:
                    # Playlist neběží, nastavit pro monitoring
                    playlist_str = expected_filename[9:]  # Odstranit "playlist:" prefix
                    parsed_files = []
                    for item in playlist_str.split(','):
                        item = item.strip()
                        if not item:
                            continue
                        # Formát: "filename" nebo "filename:duration"
                        last_colon = item.rfind(':')
                        if last_colon > 0:
                            possible_duration = item[last_colon+1:]
                            if possible_duration.isdigit():
                                parsed_files.append(item[:last_colon])
                            else:
                                parsed_files.append(item)
                        else:
                            parsed_files.append(item)
                    if parsed_files:
                        current_mixed_playlist = parsed_files
                        xbmc.log(f"[Dohled] Mixed playlist nastaven (zdroj: {file_source}): {current_mixed_playlist}", xbmc.LOGINFO)
            else:
                # Standardní logika pro jednotlivé soubory
                # === DŮLEŽITÉ: Vymazat starý playlist pokud se přepnulo z playlist na single file ===
                # Jinak state_update_loop bude posílat staré soubory z playlistu
                # ALE: Respektovat uživatelem manuálně spuštěný playlist!
                if current_mixed_playlist:
                    # Pokud user_initiated_file je playlist, NEMAZAT - uživatel ho spustil manuálně
                    if user_initiated_file and user_initiated_file.startswith('playlist:'):
                        xbmc.log(f"[Dohled] Zachovávám user-initiated playlist: {current_mixed_playlist}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"[Dohled] Očekávaný soubor není playlist - mažu starý playlist: {current_mixed_playlist}", xbmc.LOGINFO)
                        current_mixed_playlist = []
                        current_mixed_playlist_position = -1

                video_info = get_video_file_info(expected_filename, expected_file_size)

                last_modified = video_info['last_modified']
                file_size = video_info['file_size']
                current_filename = video_info['filename']
                update_needed = video_info['update_needed']

                # Logování pro debug
                if update_needed:
                    if video_info['is_expected']:
                        reason = "velikost se neshoduje"
                    elif current_filename:
                        reason = f"název se liší (aktuální: {current_filename}, očekávaný: {expected_filename})"
                    else:
                        reason = "žádný soubor nenalezen"
                    xbmc.log(f"[Dohled] Aktualizace potřeba - důvod: {reason}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[Dohled] Soubor je aktuální: {current_filename}", xbmc.LOGINFO)

                    # Zkontrolovat jestli se přehrává správný soubor
                    # Pokud ne, spustit přehrávání očekávaného souboru
                    # ALE: Přeskočit auto-play pokud běží uživatelem spuštěný playlist
                    if current_mixed_playlist:
                        # Playlist běží, nepřepisovat ho souborem z lokality
                        pass
                    else:
                        player_check = xbmc.Player()
                        is_slideshow = xbmc.getCondVisibility("Slideshow.IsActive")
                        is_playing_video = player_check.isPlayingVideo()
                        # Také zkontrolovat náš vlastní tracking pro obrázky zobrazené přes ShowPicture
                        is_showing_image = current_displayed_image is not None
                        is_playing_anything = is_playing_video or is_slideshow or is_showing_image

                        playing_now = None
                        if is_playing_video:
                            try:
                                playing_now = os.path.basename(player_check.getPlayingFile())
                            except:
                                pass
                        elif is_showing_image:
                            playing_now = current_displayed_image

                        expected_basename = os.path.basename(expected_filename) if expected_filename else None
                        if expected_basename and current_filename == expected_basename:
                            # Zkontrolovat jestli přehráváme správný soubor
                            needs_play = False
                            if user_stopped:
                                # Uživatel manuálně zastavil - nespouštět automaticky
                                xbmc.log("[Dohled] Auto-play přeskočen - uživatel zastavil přehrávání", xbmc.LOGINFO)
                                needs_play = False
                            elif pending_new_content:
                                # Nový obsah čeká na restart - nespouštět automaticky
                                xbmc.log("[Dohled] Auto-play přeskočen - nový obsah čeká na restart", xbmc.LOGINFO)
                                needs_play = False
                            elif user_initiated_file and '://' in user_initiated_file:
                                # Běží user-initiated stream - auto-play ho nesmí přepsat lokálním souborem
                                # Stream se obnovuje přes stream watchdog, ne přes auto-play
                                xbmc.log("[Dohled] Auto-play přeskočen - aktivní user-initiated stream", xbmc.LOGINFO)
                                needs_play = False
                            elif not is_playing_anything:
                                needs_play = True  # Nic nehraje
                            elif playing_now and playing_now != expected_basename and playing_now != user_initiated_file and (not user_initiated_file or playing_now != os.path.basename(user_initiated_file)):
                                # Hraje špatný soubor - ALE respektovat uživatelem ručně spuštěný obsah
                                # Pro stream/URL porovnat i basename (např. "101" vs "rtsp://.../.../101")
                                # Také zkontrolovat zda playing_now není součástí user-initiated playlistu
                                # DŮLEŽITÉ: Použít current_mixed_playlist (list) pro správnou membership check, ne substring match!
                                _user_pl = []
                                if user_initiated_file and user_initiated_file.startswith('playlist:'):
                                    # Docasny playlist JEN Z VIDEI bezi nativnim Kodi playlistem a
                                    # current_mixed_playlist je u nej PRAZDNY - clenstvi se proto
                                    # bere primo z user_initiated_file (basename, bez ':doby').
                                    # Jinak auto-play do 35 s prepsal docasny playlist souborem
                                    # lokality (nalezeno 2.9.2026 nezavislou kontrolou kodu).
                                    _user_pl = [os.path.basename(strip_playlist_duration(i.strip()))
                                                for i in user_initiated_file[9:].split(',') if i.strip()]
                                    _user_pl += [os.path.basename(x) for x in current_mixed_playlist]
                                if _user_pl and os.path.basename(playing_now) in _user_pl:
                                    xbmc.log(f"[Dohled] Auto-play přeskočen - {playing_now} je součástí user-initiated playlistu", xbmc.LOGINFO)
                                    needs_play = False
                                else:
                                    needs_play = True

                            # Speciální případ: Očekáváme video, ale je zobrazen obrázek
                            # ALE: Respektovat uživatelem ručně puštěný soubor, manuální stop, pending_new_content a user-initiated playlist
                            user_initiated_is_playlist = user_initiated_file and user_initiated_file.startswith('playlist:')
                            # DŮLEŽITÉ: Použít current_mixed_playlist (list) pro správnou membership check, ne substring match!
                            image_in_user_playlist = user_initiated_is_playlist and current_displayed_image and current_mixed_playlist and current_displayed_image in current_mixed_playlist
                            user_initiated_is_stream = user_initiated_file and '://' in user_initiated_file
                            if not user_stopped and not pending_new_content and not user_initiated_is_playlist and not user_initiated_is_stream and is_showing_image and is_video_file(expected_basename) and user_initiated_file != current_displayed_image:
                                xbmc.log(f"[Dohled] Auto-play: Video očekáváno, ale zobrazen obrázek {current_displayed_image}", xbmc.LOGINFO)
                                local_path = get_local_media_path(expected_basename)

                                # NEJDŘÍVE zavřít obrázek pomocí spolehlivé funkce
                                # NEVOLAT close_image_viewer() - nasadi KRYCI CERNOU a video by hralo POD ni
                                # (cerna obrazovka). Video slideshow prebije samo; odkryva se az PO spusteni.

                                # Pak spustit video (pokud existuje)
                                if os.path.exists(local_path):
                                    xbmc.log(f"[Dohled] Auto-play: Spouštím video {expected_basename}", xbmc.LOGINFO)
                                    player_check.play(local_path)
                                    current_displayed_image = None
                                    # Počkat až video začne hrát (max 2s)
                                    for _ in range(20):
                                        if player_check.isPlayingVideo():
                                            break
                                        time.sleep(0.1)
                                    xbmc.executebuiltin("PlayerControl(RepeatOne)")
                                    # Odkryt az kdyz video opravdu bezi (jedno volani staci)
                                    uncover_if_covered(player_check, expected_basename)

                                # Okamžité odeslání stavu
                                time.sleep(0.3)
                                send_immediate_state_update(expected_basename, playing=True, paused=False)
                                needs_play = False  # Už jsme to vyřešili

                            if needs_play:
                                local_path = get_local_media_path(expected_basename)
                                if os.path.exists(local_path):
                                    xbmc.log(f"[Dohled] Auto-play: Spouštím {expected_basename} (aktuálně hraje: {playing_now})", xbmc.LOGINFO)
                                    if is_image_file(expected_basename):
                                        # Video → Obrázek: nejdřív zobrazit obrázek, pak zastavit video
                                        if is_playing_video:
                                            if show_picture_safe(local_path):
                                                current_displayed_image = expected_basename
                                            else:
                                                current_displayed_image = None
                                            time.sleep(0.2)
                                            player_check.stop()
                                        else:
                                            if show_picture_safe(local_path):
                                                current_displayed_image = expected_basename
                                            else:
                                                current_displayed_image = None
                                        if current_displayed_image:
                                            send_immediate_state_update(expected_basename, playing=True, paused=False)
                                    else:
                                        # Spustit video - nejdřív zavřít obrázek pokud je zobrazen
                                        # NEVOLAT close_image_viewer() - nasadi KRYCI CERNOU a video by hralo POD ni
                                        # (cerna obrazovka). Video slideshow prebije samo; odkryva se az PO spusteni.
                                        player_check.play(local_path)
                                        time.sleep(0.5)
                                        uncover_if_covered(player_check, 'video')
                                        current_displayed_image = None
                                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                                        send_immediate_state_update(expected_basename, playing=True, paused=False)

            next_reboot = get_next_reboot()
            last_reboot = get_last_reboot_date()

            player = xbmc.Player()
            is_playing_video = player.isPlayingVideo()
            playing_file = player.getPlayingFile() if is_playing_video else None

            # Detekce slideshow
            is_slideshow_active = xbmc.getCondVisibility("Slideshow.IsActive")
            slideshow_position = None
            slideshow_total = None
            slideshow_current_picture = None

            if is_slideshow_active:
                slideshow_current_picture = xbmc.getInfoLabel("Slideshow.CurrentPicture")
                # Slideshow pozici získáme z InfoLabel
                try:
                    slideshow_position = int(xbmc.getInfoLabel("Slideshow.CurrentSlide") or 0)
                    slideshow_total = int(xbmc.getInfoLabel("Slideshow.CountSlide") or 0)
                except (ValueError, TypeError):
                    slideshow_position = 1
                    slideshow_total = 1

            # Určení typu média - včetně obrázků zobrazených přes ShowPicture
            # (global current_displayed_image už je deklarován na začátku while loopu)

            # Přečíst info z service.smycky (pokud něco přehrává)
            smycky_playing = get_smycky_current_playing()

            # V playlist módu použít konzistentní filename z playlistu podle pozice
            if is_playlist and current_mixed_playlist and current_mixed_playlist_position >= 0:
                if current_mixed_playlist_position < len(current_mixed_playlist):
                    current_filename = nazev_pro_hlaseni(current_mixed_playlist[current_mixed_playlist_position])
                    # Určit media type podle souboru
                    if is_video_file(current_filename):
                        media_type = "video"
                        # POZNÁMKA: Neresetovat current_displayed_image zde!
                        # Monitoring pouze čte stav, nemodifikuje ho.
                        # Reset se dělá v execute_command při play_file.
                    elif is_image_file(current_filename):
                        media_type = "image"
                    else:
                        media_type = "video"  # Fallback
            elif is_playing_video:
                media_type = "video"
                # POZNÁMKA: Neresetovat current_displayed_image zde!
                # Monitoring pouze čte stav, nemodifikuje ho.
                # Dřívější reset způsoboval desync mezi trackingem a realitou.
                if smycky_playing and is_video_file(smycky_playing):
                    current_filename = smycky_playing
                elif playing_file:
                    # Pro stream URL zachovat celou URL (ne basename)
                    if user_initiated_file and '://' in user_initiated_file:
                        current_filename = user_initiated_file
                    else:
                        current_filename = os.path.basename(playing_file)
            elif is_slideshow_active:
                if slideshow_total and slideshow_total > 1:
                    media_type = "slideshow"
                else:
                    media_type = "image"
                # Pro slideshow použít aktuální obrázek
                if slideshow_current_picture:
                    current_filename = slideshow_current_picture.split('/')[-1]
                    playing_file = slideshow_current_picture
            elif current_displayed_image:
                # Obrázek zobrazený přes ShowPicture z service.dohled
                media_type = "image"
                playing_file = get_local_media_path(current_displayed_image)
                current_filename = nazev_pro_hlaseni(current_displayed_image)
            elif smycky_playing and is_image_file(smycky_playing):
                # Obrázek zobrazený z service.smycky
                media_type = "image"
                playing_file = get_local_media_path(smycky_playing)
                current_filename = smycky_playing
            else:
                media_type = None

            # Zjistit, zda něco hraje (video, slideshow nebo statický obrázek)
            is_playing_actual = is_playing_video or is_slideshow_active or (current_displayed_image is not None) or (smycky_playing and is_image_file(smycky_playing))

            # Pauza nad obrazkem: Kodi o ni nevi (obrazek neni "player"),
            # drzi ji nas priznak - jinak by dashboard ukazoval "hraje".
            is_paused = xbmc.getCondVisibility("Player.Paused") or playlist_paused

            # Debouncing pro playing=false (stejná logika jako v state_update_loop)
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            global last_playing_true_time
            current_time = time.time()
            PLAYING_FALSE_TOLERANCE = 5

            if is_playing_actual:
                last_playing_true_time = current_time
                is_playing = True
            else:
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    is_playing = True  # Stále v toleranci
                else:
                    is_playing = False

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] isPlaying: {is_playing}, Paused: {is_paused}, File: {playing_file}, MediaType: {media_type}, WS: {ws_connected}", xbmc.LOGINFO)

            # Získat seznam lokálních video souborů
            local_files = get_local_video_files()

            # Získat info o playlistu
            playlist_items = get_current_playlist()
            playlist_position = get_playlist_position()

            # Získat info o úložišti
            storage_info = get_storage_info()

            payload = {
                "device_id": device_id,
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": boot_time,
                "next_reboot": next_reboot,
                "last_reboot": last_reboot,
                "locality": locality,
                "playing": is_playing,
                "playing_file": playing_file,
                "paused": is_paused,
                "addon_version": ADDON_VERSION,
                "smycky_version": get_smycky_version(),
                "current_filename": current_filename,
                "expected_filename": expected_filename,
                "update_needed": update_needed,
                "content_obscured": content_obscured,
                "local_files": local_files,
                "ws_connected": ws_connected,
                "playlist": playlist_items,
                "playlist_position": playlist_position,
                "storage": storage_info,
                # Nová pole pro obrázky a slideshow
                "media_type": media_type,  # "video", "image", "slideshow" nebo None
                "slideshow_position": slideshow_position,  # aktuální pozice v slideshow
                "slideshow_total": slideshow_total,  # celkový počet obrázků v slideshow
                "slideshow_current_picture": slideshow_current_picture  # název aktuálního obrázku
            }

            # Detekce stale WS - pokud zadny ACK za 90s, spojeni je mrtve
            if ws_connected and last_ws_ack_time > 0 and (time.time() - last_ws_ack_time) > WS_STALE_TIMEOUT:
                xbmc.log(f"[Dohled] WS stale: zadny ACK za {time.time() - last_ws_ack_time:.0f}s, vynucuji reconnect", xbmc.LOGWARNING)
                ws_connected = False
                try:
                    if ws_app:
                        ws_app.close()
                except:
                    pass

            # Zkusit odeslat přes WebSocket, jinak HTTP fallback
            sent_via_ws = False
            if ws_connected and ws_app:
                try:
                    ws_app.send(json.dumps({
                        "type": "monitoring",
                        "payload": payload
                    }))
                    sent_via_ws = True
                    xbmc.log("[Dohled] Monitoring data odeslána přes WebSocket", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání přes WS, použiji HTTP: {e}", xbmc.LOGWARNING)
                    ws_connected = False

            if not sent_via_ws:
                # HTTP fallback
                url = "https://apidohled.noreason.eu/api/monitoring"
                response = send_data(payload, url)

                # Zpracovat odpověď serveru
                if response and response.get("status") == "saved":
                    server_update_needed = response.get("update_needed")
                    if server_update_needed != update_needed:
                        xbmc.log(f"[Dohled] Server přepsal update_needed: {update_needed} -> {server_update_needed}", xbmc.LOGINFO)

                    # Piggyback příkazy - server může poslat příkaz v odpovědi na monitoring
                    piggyback_command = response.get("command")
                    if piggyback_command:
                        piggyback_params = response.get("command_params")
                        xbmc.log(f"[Dohled] Piggyback příkaz z monitoring odpovědi: {piggyback_command}", xbmc.LOGINFO)
                        execute_command(piggyback_command, piggyback_params,
                                        response.get("command_id"))

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        # === Log upload (kazdych 60s) ===
        try:
            now_ts = time.time()
            if ws_connected and ws_app and (now_ts - _last_log_upload_time) >= LOG_UPLOAD_INTERVAL:
                if os.path.exists(KODI_LOG_PATH):
                    file_size_now = os.path.getsize(KODI_LOG_PATH)
                    # Detekce rotace logu (Kodi restartoval a soubor je mensi)
                    if file_size_now < _log_upload_position:
                        xbmc.log("[Dohled] Log upload: detekce rotace, reset pozice", xbmc.LOGINFO)
                        _log_upload_position = 0
                    if file_size_now > _log_upload_position:
                        with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                            f.seek(_log_upload_position)
                            new_lines = f.read(LOG_UPLOAD_MAX_SIZE)
                        if new_lines:
                            ws_app.send(json.dumps({
                                "type": "log_upload",
                                "lines": new_lines
                            }))
                            _log_upload_position += len(new_lines.encode('utf-8'))
                            xbmc.log(f"[Dohled] Log upload: odeslan {len(new_lines)} znaku", xbmc.LOGINFO)
                _last_log_upload_time = now_ts
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v log uploadu: {e}", xbmc.LOGWARNING)

        # Monitoring interval: 30 sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_MONITORING_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break


def send_immediate_state_update(filename, playing=True, paused=False):
    """
    Okamžité odeslání state update po změně souboru.
    Volat po přepnutí souboru pro rychlou aktualizaci dashboardu.

    DŮLEŽITÉ: Má HTTP fallback pro garantované doručení při výpadku WS.
    """
    global ws_connected, ws_app, last_filename, last_playing_state, last_paused_state, last_stopped_content

    # Zjistit zda lze obnovit přehrávání (pro zelené tlačítko play)
    can_resume = last_stopped_content is not None and bool(last_stopped_content)

    filename = nazev_pro_hlaseni(filename)
    payload = {
        "playing": playing,
        "paused": paused,
        "current_filename": filename,
        "can_resume": can_resume,
        "user_initiated_file": user_initiated_file  # Pro API - nastaví UserInitiatedPlayback
    }

    sent = False

    # 1. Zkusit WebSocket (nejrychlejší)
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "state_update",
                "payload": payload
            }))
            sent = True
            xbmc.log(f"[Dohled] Immediate state update odeslán přes WS: {filename}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] WS send failed, zkouším HTTP fallback: {e}", xbmc.LOGWARNING)

    # 2. HTTP fallback - garantované doručení při změně stavu
    if not sent:
        try:
            config = load_config()
            device_id = get_device_id()

            # Získat IP adresu pro HTTP fallback
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                ip_address = s.getsockname()[0]
                s.close()
            except:
                ip_address = "unknown"

            # Payload pro state update - MUSÍ obsahovat name a ip_address (povinná pole API)
            # Také musí obsahovat update_needed aby dashboard správně zobrazoval stav
            base_filename = os.path.basename(filename) if filename else ""
            http_payload = {
                "device_id": device_id,
                "name": config.get("name", "unknown"),
                "ip_address": ip_address,
                "locality": config.get("locality", ""),
                "playing": playing,
                "playing_file": filename,
                "paused": paused,
                "current_filename": base_filename,
                "update_needed": False,  # Když přehráváme, update není potřeba
                "can_resume": can_resume,
                "ws_connected": False,  # Indikace že jdeme přes HTTP
                "state_update_only": True  # Server může zpracovat jako lehký update
            }

            url = "https://apidohled.noreason.eu/api/monitoring"
            response = send_data(http_payload, url)
            if response:
                sent = True
                xbmc.log(f"[Dohled] Immediate state update odeslán přes HTTP fallback: {filename}", xbmc.LOGINFO)
            else:
                xbmc.log("[Dohled] HTTP fallback selhal", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba HTTP fallback: {e}", xbmc.LOGERROR)

    # Aktualizovat poslední známý stav
    if sent:
        last_filename = filename
        last_playing_state = playing
        last_paused_state = paused

    return sent


def state_update_loop():
    """
    Rychlá smyčka pro aktualizaci stavu přehrávání.
    - Kontroluje stav každé WS_STATE_CHECK_INTERVAL sekund (rychlá detekce změn)
    - Odesílá pouze při ZMĚNĚ stavu nebo po WS_STATE_HEARTBEAT_INTERVAL sekundách (heartbeat)
    - Používá debouncing pro playing=false (5 sekund tolerance pro přechody smyčky)
    - HTTP FALLBACK: Když WS není připojen, odesílá přes HTTP s throttlingem (10s)
    """
    global last_playing_state, last_paused_state, last_filename, ws_connected, ws_app, last_playing_true_time
    global user_initiated_file, user_stopped, current_displayed_image, last_stopped_content

    # Tolerance pro přechod mezi videi ve smyčce (sekundy)
    PLAYING_FALSE_TOLERANCE = 5

    # HTTP fallback throttling - nechceme zahltit server HTTP requesty
    HTTP_FALLBACK_INTERVAL = 10  # Sekund mezi HTTP requesty když WS není k dispozici

    # Čas posledního odeslání (pro heartbeat)
    last_send_time = 0
    last_http_send_time = 0  # Pro HTTP fallback throttling
    stream_watchdog_fails = 0  # Počítadlo neúspěšných pokusů watchdogu
    stream_stable_since = 0  # Cas kdy stream zacal stabilne hrat
    monitor = xbmc.Monitor()

    # Inicializace last_filename z disku pokud je None (při startu addonu)
    if last_filename is None:
        try:
            video_path = find_current_video_file()
            if video_path:
                last_filename = os.path.basename(video_path)
                xbmc.log(f"[Dohled] Inicializace last_filename z disku: {last_filename}", xbmc.LOGINFO)
        except:
            pass

    xbmc.log(f"[Dohled] State update smyčka: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)

    while not stop_monitoring and not monitor.abortRequested():
        try:
            # Zapsat heartbeat pro externí watchdog (vždy, i bez WS)
            write_heartbeat()

            # POJISTKA: menu Kodi se nikdy nesmí ukázat. Tato smyčka běží každé 2s,
            # takže i kdyby nějaká cesta obsah zavřela, menu okamžitě přebijeme.
            ensure_content_visible()

            # Zjistit aktuální stav (vždy, i bez WS - pro HTTP fallback)
            player = xbmc.Player()
            is_playing_video = player.isPlayingVideo()
            is_slideshow_active = xbmc.getCondVisibility("Slideshow.IsActive")

            # Přečíst info z service.smycky (pokud něco přehrává)
            smycky_playing = get_smycky_current_playing()

            # Detekce obrázků zobrazených přes ShowPicture
            # (global current_displayed_image už je deklarován na začátku while loopu)
            showing_image = (current_displayed_image is not None) or (smycky_playing and is_image_file(smycky_playing))

            # Je něco přehráváno/zobrazeno?
            is_playing_actual = is_playing_video or is_slideshow_active or showing_image

            is_paused = (xbmc.getCondVisibility("Player.Paused") if is_playing_video else False) or playlist_paused

            # Určit aktuální soubor a pozici
            global current_mixed_playlist, current_mixed_playlist_position
            playlist_position = None

            # V playlist módu použít konzistentní data z playlistu
            if current_mixed_playlist and current_mixed_playlist_position >= 0:
                if current_mixed_playlist_position < len(current_mixed_playlist):
                    current_file = nazev_pro_hlaseni(current_mixed_playlist[current_mixed_playlist_position])
                    playlist_position = current_mixed_playlist_position
                else:
                    current_file = last_filename
            elif is_playing_video:
                # Pro stream URL zachovat celou URL (ne jen basename)
                if user_initiated_file and '://' in user_initiated_file:
                    current_file = user_initiated_file
                else:
                    current_file = player.getPlayingFile().split('/')[-1]
                # Pokud service.smycky hlásí video, použít to (má správný název)
                if smycky_playing and is_video_file(smycky_playing):
                    current_file = smycky_playing
            elif current_displayed_image:
                current_file = nazev_pro_hlaseni(current_displayed_image)
            elif smycky_playing and is_image_file(smycky_playing):
                current_file = smycky_playing
            elif is_slideshow_active:
                slideshow_pic = xbmc.getInfoLabel("Slideshow.CurrentPicture")
                current_file = slideshow_pic.split('/')[-1] if slideshow_pic else last_filename
            else:
                # Nic nehraje - zachovat poslední známý soubor
                current_file = last_filename

            # Debouncing pro playing=false
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            # Reportujeme playing=false až po PLAYING_FALSE_TOLERANCE sekundách
            current_time = time.time()

            if is_playing_actual:
                # Aktualizovat čas posledního playing=true
                last_playing_true_time = current_time
                is_playing = True
            else:
                # playing je false - zkontrolovat toleranci
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    # Stále v toleranci - reportovat jako playing=true (pravděpodobně jen přechod smyčky)
                    is_playing = True
                else:
                    # Mimo toleranci - skutečně není playing
                    is_playing = False

            # === Stream watchdog ===
            # Pokud user_initiated_file je stream URL a nic nehraje, automaticky restartovat
            if user_initiated_file and '://' in user_initiated_file and not is_playing_actual and not user_stopped:
                stream_stable_since = 0  # Stream nehra - reset stability
                if last_playing_true_time and (current_time - last_playing_true_time) > 8:
                    stream_watchdog_fails += 1
                    max_retries = 5

                    if stream_watchdog_fails <= max_retries:
                        xbmc.log(f"[Dohled] Stream watchdog: stream vypadl, pokus {stream_watchdog_fails}/{max_retries} - restartuji {user_initiated_file}", xbmc.LOGINFO)
                        # NEJDŘÍV krytí, PAK zavřít chybové dialogy - a NIKDY Dialog.Close(all):
                        # to zavře i naši krycí černou a do dalšího ShowPicture svítí HOME
                        # (změřeno 2.9.2026 v E4: 170 ms menu při každém pokusu watchdogu).
                        show_black_filler("restart streamu")
                        xbmc.sleep(100)
                        for _w in ("okdialog", "yesnodialog", "busydialog"):
                            xbmc.executebuiltin(f'Dialog.Close({_w},true)')
                        try:
                            url_lower = user_initiated_file.lower()

                            if not stream_dostupny(user_initiated_file):
                                # Nedostupny stream Kodi nepredavat (viz stream_dostupny) - pocita
                                # se jako neuspesny pokus, cerna zustava.
                                xbmc.log(f"[Dohled] Stream watchdog: stream nedostupný (pokus {stream_watchdog_fails})", xbmc.LOGWARNING)
                                last_playing_true_time = current_time
                                raise StopIteration
                            if url_lower.startswith(('rtsp://', 'rtp://', 'udp://', 'rtmp://')):
                                player.play(item=user_initiated_file)
                            else:
                                play_item = xbmcgui.ListItem(path=user_initiated_file)
                                play_item.setProperty('IsPlayable', 'true')
                                player.play(item=user_initiated_file, listitem=play_item)
                            xbmc.sleep(5000)
                            if player.isPlaying():
                                xbmc.executebuiltin('PlayerControl(RepeatOne)')
                                # Krytí z tohoto bloku musí jít pryč, jinak by stream hrál
                                # pod černou (divák by viděl černou obrazovku)
                                uncover_if_covered(player, "stream")
                                # NERESETOVAT pocitadlo hned - az po 30s stabilniho prehravani
                                xbmc.log(f"[Dohled] Stream watchdog: stream spusten, cekam na stabilitu (pokus {stream_watchdog_fails})", xbmc.LOGINFO)
                            else:
                                xbmc.log(f"[Dohled] Stream watchdog: stream se nespustil (pokus {stream_watchdog_fails})", xbmc.LOGWARNING)
                            last_playing_true_time = current_time
                        except StopIteration:
                            pass
                        except Exception as e:
                            xbmc.log(f"[Dohled] Stream watchdog chyba: {e}", xbmc.LOGERROR)
                    else:
                        xbmc.log(f"[Dohled] Stream watchdog: {max_retries} neúspěšných pokusů, ukončuji stream", xbmc.LOGWARNING)
                        user_initiated_file = None
                        stream_watchdog_fails = 0
                        # Krytí PŘED zavíráním dialogů (viz výše) - obnova z lokality chvíli trvá
                        show_black_filler("ukončení streamu, obnova lokality")
                        xbmc.sleep(100)
                        for _w in ("okdialog", "yesnodialog", "busydialog"):
                            xbmc.executebuiltin(f'Dialog.Close({_w},true)')
                        xbmc.sleep(100)
                        # Ve VLAKNE - startup_playback dela FTP/HTTP (i desitky sekund) a tahle
                        # smycka posila stav pres WS kazde 2 s; nesmi stat.
                        threading.Thread(target=startup_playback, daemon=True).start()
                        xbmc.log("[Dohled] Stream watchdog: obnova prehravani z lokality spustena", xbmc.LOGINFO)
            elif user_initiated_file and '://' in user_initiated_file and is_playing_actual:
                # Stream hraje - trackovat stabilitu
                if stream_stable_since == 0:
                    stream_stable_since = current_time
                # Reset pocitadla az po 30s nepretrziteho prehravani
                if stream_watchdog_fails > 0 and (current_time - stream_stable_since) > 30:
                    stream_watchdog_fails = 0
                    xbmc.log("[Dohled] Stream watchdog: stream stabilni 30s, reset pocitadla", xbmc.LOGINFO)

            # Detekce změny stavu
            state_changed = (
                is_playing != last_playing_state or
                is_paused != last_paused_state or
                current_file != last_filename
            )

            # Heartbeat - odeslat i bez změny po určitém čase
            time_since_last_send = current_time - last_send_time
            heartbeat_needed = time_since_last_send >= WS_STATE_HEARTBEAT_INTERVAL

            # Připravit payload (společný pro WS i HTTP)
            can_resume = last_stopped_content is not None and bool(last_stopped_content)
            payload = {
                "playing": is_playing,
                "paused": is_paused,
                "current_filename": current_file,
                "can_resume": can_resume,
                "user_initiated_file": user_initiated_file
            }
            if playlist_position is not None:
                payload["playlist_position"] = playlist_position

            # 1. POKUS O WS - rychlý update každé 2s při změně nebo heartbeat
            if ws_connected and ws_app and (state_changed or heartbeat_needed):
                try:
                    if user_initiated_file:
                        xbmc.log(f"[Dohled] DEBUG state_update: user_initiated_file={user_initiated_file}", xbmc.LOGINFO)
                    ws_app.send(json.dumps({
                        "type": "state_update",
                        "payload": payload
                    }))
                    last_send_time = current_time

                    if state_changed:
                        xbmc.log(f"[Dohled] Změna stavu (WS): playing={is_playing}, paused={is_paused}, file={current_file}", xbmc.LOGINFO)

                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání state update přes WS: {e}", xbmc.LOGWARNING)

            # 2. HTTP FALLBACK - když WS není k dispozici
            elif not ws_connected or not ws_app:
                # Při změně stavu odeslat okamžitě, jinak throttlovat na HTTP_FALLBACK_INTERVAL
                time_since_http = current_time - last_http_send_time
                http_needed = state_changed or (time_since_http >= HTTP_FALLBACK_INTERVAL)

                if http_needed:
                    try:
                        config = load_config()
                        device_id = get_device_id()

                        # Získat IP adresu pro HTTP fallback
                        try:
                            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                            s.connect(("8.8.8.8", 80))
                            ip_address = s.getsockname()[0]
                            s.close()
                        except:
                            ip_address = "unknown"

                        # Payload MUSÍ obsahovat name a ip_address (povinná pole API)
                        # Také musí obsahovat update_needed aby dashboard správně zobrazoval stav
                        # Když přehráváme správný soubor, není potřeba update
                        base_filename = os.path.basename(current_file) if current_file else ""
                        http_payload = {
                            "device_id": device_id,
                            "name": config.get("name", "unknown"),
                            "ip_address": ip_address,
                            "locality": config.get("locality", ""),
                            "playing": is_playing,
                            "playing_file": current_file,
                            "paused": is_paused,
                            "current_filename": base_filename,
                            "update_needed": False,  # Když přehráváme, update není potřeba
                            "can_resume": can_resume,
                            "ws_connected": False,
                            "state_update_only": True
                        }

                        url = "https://apidohled.noreason.eu/api/monitoring"
                        response = send_data(http_payload, url)
                        if response:
                            last_http_send_time = current_time
                            last_send_time = current_time
                            xbmc.log(f"[Dohled] HTTP fallback odeslán: playing={is_playing}, file={current_file}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba HTTP fallback v state update: {e}", xbmc.LOGWARNING)

            # Uložit poslední stav
            last_playing_state = is_playing
            last_paused_state = is_paused
            last_filename = current_file

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v state update loop: {e}", xbmc.LOGERROR)

        # Čekat na další kontrolu - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_STATE_CHECK_INTERVAL):
            break  # Kodi požaduje ukončení


# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}


# ======= STARTUP SEKVENCE (nahrazuje service.smycky) =======

def startup_playback():
    """
    Spustí přehrávání při startu zařízení.
    Nahrazuje funkcionalitu service.smycky.
    """
    global current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, current_displayed_image

    xbmc.log("[Dohled] === Spuštění přehrávání při startu ===", xbmc.LOGINFO)

    # PRVNÍ VĚC: krycí černá obrazovka. Než se stáhne konfigurace z API a připraví obsah
    # (HTTP + případně FTP = klidně desítky sekund), svítilo by na TV Kodi MENU.
    show_black_filler("start - příprava obsahu")

    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")
        device_id = get_device_id()

        if not locality:
            xbmc.log("[Dohled] Startup: Locality není nastavena, přeskakuji přehrávání", xbmc.LOGWARNING)
            return

        xbmc.log(f"[Dohled] Startup: Locality={locality}, DeviceID={device_id}", xbmc.LOGINFO)

        # 2. Získat očekávaný soubor (device override nebo locality)
        # Předáváme locality jako fallback pro nová zařízení bez záznamu v DB
        expected_file, source = fetch_expected_file_with_locality(device_id, locality)

        if not expected_file:
            xbmc.log("[Dohled] Startup: Žádný očekávaný soubor, zkouším fallback", xbmc.LOGWARNING)
            fallback = find_best_fallback_file()
            if fallback:
                xbmc.log(f"[Dohled] Startup: Přehrávám fallback: {fallback}", xbmc.LOGINFO)
                play_media_file(fallback)
            return

        xbmc.log(f"[Dohled] Startup: Očekávaný soubor '{expected_file}' (zdroj: {source})", xbmc.LOGINFO)

        # 3. Zkontrolovat zda je playlist
        if expected_file.startswith("playlist:"):
            # Playlist mode
            playlist_content = expected_file[9:]  # Odstranit "playlist:" prefix
            xbmc.log(f"[Dohled] Startup: Detekován playlist: {playlist_content}", xbmc.LOGINFO)

            # Parsovat playlist
            playlist_items = parse_playlist_string(playlist_content)
            if not playlist_items:
                xbmc.log("[Dohled] Startup: Playlist je prázdný", xbmc.LOGWARNING)
                return

            # Kontrola a stažení souborů z playlistu
            ftp_config = fetch_ftp_config(locality)
            valid_files = []

            _ftp_kontrola = None          # jedno FTP spojeni pro kontrolu velikosti polozek
            _ftp_kontrola_selhala = False
            for item in playlist_items:
                filename = item['filename']
                local_path = get_local_media_path(filename)

                # Zkontrolovat zda soubor existuje lokálně
                if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
                    # Soubor na FTP mohl byt NAHRAZEN (stejny nazev, jina velikost) - v single
                    # rezimu se to kontroluje, u playlistu se to driv nikdy nedotahlo a server
                    # to ted hlasi jako "Aktualizace" (zastarale_polozky_playlistu). Porovnat a
                    # pripadne stahnout znovu; pri chybe FTP nechat lokalni soubor.
                    # JEDNO FTP spojeni pro vsechny polozky (viz _ftp_kontrola nize) - spojeni
                    # na kazdou polozku by pod kryci cernou trvalo N x az 30 s.
                    _znovu = False
                    if _ftp_kontrola is None and ftp_config and not _ftp_kontrola_selhala:
                        try:
                            from ftplib import FTP as _FTP
                            _ftp_kontrola = _FTP()
                            _ftp_kontrola.connect(ftp_config.get('ftp_host'), timeout=10)
                            _ftp_kontrola.login(ftp_config.get('ftp_user'), ftp_config.get('ftp_pass'))
                            _ftp_kontrola.voidcmd("TYPE I")
                        except Exception as _e:
                            xbmc.log(f"[Dohled] Startup: FTP pro kontrolu velikosti nedostupne ({_e}) - kontrola vynechana", xbmc.LOGWARNING)
                            _ftp_kontrola = None
                            _ftp_kontrola_selhala = True
                    if _ftp_kontrola is not None:
                        try:
                            _rs = _ftp_kontrola.size(ftp_config.get('ftp_path') + filename)
                            if _rs and int(_rs) != os.path.getsize(local_path):
                                xbmc.log(f"[Dohled] Startup: {filename} má na FTP jinou velikost "
                                         f"({_rs} vs {os.path.getsize(local_path)}) - stahuji znovu", xbmc.LOGWARNING)
                                _znovu = True
                        except Exception as _e:
                            xbmc.log(f"[Dohled] Startup: kontrola velikosti {filename} selhala: {_e}", xbmc.LOGWARNING)
                    if _znovu and not download_file_ftp(
                            ftp_config.get('ftp_host'), ftp_config.get('ftp_user'),
                            ftp_config.get('ftp_pass'), ftp_config.get('ftp_path'), filename, local_path):
                        xbmc.log(f"[Dohled] Startup: nové stažení {filename} selhalo - hraji lokální verzi", xbmc.LOGWARNING)
                    valid_files.append(item)
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} existuje lokálně", xbmc.LOGINFO)
                elif ftp_config:
                    # Zkusit stáhnout z FTP
                    xbmc.log(f"[Dohled] Startup: Stahuji {filename} z FTP", xbmc.LOGINFO)
                    if download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        filename,
                        local_path
                    ):
                        valid_files.append(item)
                    else:
                        xbmc.log(f"[Dohled] Startup: Nepodařilo se stáhnout {filename}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} nenalezen a FTP není dostupné", xbmc.LOGWARNING)

            if not valid_files:
                xbmc.log("[Dohled] Startup: Žádné platné soubory v playlistu", xbmc.LOGERROR)
                fallback = find_best_fallback_file()
                if fallback:
                    play_media_file(fallback)
                return

            if _ftp_kontrola is not None:
                try:
                    _ftp_kontrola.quit()
                except Exception:
                    pass
            # Spustit playlist
            xbmc.log(f"[Dohled] Startup: Spouštím playlist s {len(valid_files)} soubory", xbmc.LOGINFO)
            start_mixed_playlist_startup(valid_files)

        else:
            # Single file mode
            local_path = get_local_media_path(expected_file)

            # 4. Zkontrolovat zda soubor existuje a je aktuální
            needs_download = False

            if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
                needs_download = True
                xbmc.log(f"[Dohled] Startup: Soubor {expected_file} neexistuje lokálně", xbmc.LOGINFO)
            else:
                # Zkontrolovat zda je na FTP novější verze
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    remote_time, remote_size = get_remote_file_info(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file
                    )
                    local_time, local_size = get_local_file_info(local_path)

                    if remote_time and remote_size:
                        if remote_size != local_size or remote_time > local_time + 60:
                            needs_download = True
                            xbmc.log(f"[Dohled] Startup: Na FTP je novější verze souboru", xbmc.LOGINFO)

            # 5. Stáhnout pokud potřeba
            if needs_download:
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    xbmc.log(f"[Dohled] Startup: Stahuji {expected_file} z FTP", xbmc.LOGINFO)
                    download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file,
                        local_path
                    )
                else:
                    xbmc.log("[Dohled] Startup: FTP konfigurace není dostupná", xbmc.LOGWARNING)

            # 6. Kontrola integrity PŘED přehráním - poškozený soubor by jinak
            #    způsobil smyčku "pořád se zkouší spustit přehrávání".
            _exp_size = ftp_config.get("expected_file_size") if 'ftp_config' in dir() and ftp_config else None
            if not validate_media_file(local_path, _exp_size)[0]:
                xbmc.log(f"[Dohled] Startup: soubor {expected_file} je vadný - opravuji", xbmc.LOGWARNING)
                ensure_media_playable(expected_file, _exp_size, locality)

            # 7. Přehrát soubor
            file_to_play = get_best_available_file(local_path)
            if file_to_play:
                xbmc.log(f"[Dohled] Startup: Přehrávám {file_to_play}", xbmc.LOGINFO)
                play_media_file(file_to_play)
            else:
                xbmc.log("[Dohled] Startup: Žádný soubor k přehrání!", xbmc.LOGERROR)
                xbmcgui.Dialog().notification("Chyba", "Žádný soubor k přehrání", xbmcgui.NOTIFICATION_ERROR, 5000)

    except Exception as e:
        xbmc.log(f"[Dohled] Startup: Chyba - {e}", xbmc.LOGERROR)
        # Zkusit fallback
        fallback = find_best_fallback_file()
        if fallback:
            xbmc.log(f"[Dohled] Startup: Používám fallback po chybě: {fallback}", xbmc.LOGWARNING)
            play_media_file(fallback)


def start_mixed_playlist_startup(playlist_items):
    """Spustí přehrávání mixed playlistu při startu."""
    global current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, current_displayed_image, mixed_playlist_thread

    # Inkrementovat playlist ID
    current_playlist_id += 1
    my_playlist_id = current_playlist_id

    # Ukončit případnou PŘEDCHOZÍ smyčku, než spustíme novou. Bez toho by dvě vlákna
    # současně přepínala obrázky (každé to své) a obrazovka by problikávala.
    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
        xbmc.log("[Dohled] Ukončuji předchozí playlist smyčku před startem nové", xbmc.LOGINFO)
        mixed_playlist_thread.join(timeout=3)

    # Nastavit globální playlist pro monitoring
    current_mixed_playlist = [item['filename'] for item in playlist_items]
    current_mixed_playlist_position = 0

    xbmc.log(f"[Dohled] Start mixed playlist ID={my_playlist_id}: {current_mixed_playlist}", xbmc.LOGINFO)

    def is_my_playlist_active():
        return current_playlist_id == my_playlist_id

    def mixed_playback_loop():
        """Obal proti výjimkám - po neočekávané chybě nesmí zůstat prázdná obrazovka/menu."""
        try:
            _mixed_playback_loop_impl()
        except Exception as e:
            xbmc.log(f"[Dohled] Mixed playlist: neočekávaná chyba: {e}", xbmc.LOGERROR)
            try:
                if not is_content_on_screen():
                    show_black_filler("chyba playlist smyčky")
            except Exception:
                pass

    def _mixed_playback_loop_impl():
        global current_displayed_image, current_mixed_playlist_position

        player = xbmc.Player()
        current_index = 0

        # Speciální případ: jeden soubor
        if len(playlist_items) == 1:
            item = playlist_items[0]
            file_path = get_local_media_path(item['filename'])

            if is_video_file(item['filename']):
                RepeatVideo(file_path)
            else:
                # show_picture_safe (ne ShowImage) - má retry i detekci černé obrazovky
                if show_picture_safe(file_path):
                    current_displayed_image = item['filename']
                else:
                    show_black_filler("selhalo zobrazení jediného obrázku")
                    current_displayed_image = None
                # Čekat dokud není playlist změněn + hlídat, že obsah nezmizel
                _g = 0
                while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                    time.sleep(1)
                    _g += 1
                    if _g % 3 == 0 and is_menu_visible():
                        xbmc.log("[Dohled] Jediný obrázek zmizel (menu) - obnovuji", xbmc.LOGWARNING)
                        show_picture_safe(file_path)
            return

        # Loop přes všechny soubory
        is_first_item = True  # První položka nepotřebuje overlay

        while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
            item = playlist_items[current_index]
            file_path = get_local_media_path(item['filename'])
            current_mixed_playlist_position = current_index

            if not os.path.exists(file_path):
                # CHYBĚJÍCÍ SOUBOR SI DOTÁHNOUT, ne ho jen přeskakovat!
                # Dřív se tady jen zalogovalo a pokračovalo dál, takže chybějící položka
                # se přeskakovala navždy (změřeno: 243 s a nic) a zařízení hrálo zkrácený
                # playlist, dokud ho někdo nenasadil znovu. Stahování má vlastní strop
                # pokusů i cooldown (MEDIA_REPAIR_*), takže tohle nebuší do FTP.
                xbmc.log(f"[Dohled] Mixed playlist: soubor neexistuje {item['filename']}"
                         " - zkouším dotáhnout z FTP", xbmc.LOGWARNING)
                if not ensure_media_playable(item['filename']):
                    # Nesmí vzniknout busy-loop s prázdnou obrazovkou - když chybí VŠE, krýt černou
                    if not any(os.path.exists(get_local_media_path(it['filename'])) for it in playlist_items):
                        show_black_filler("žádný soubor playlistu neexistuje")
                        time.sleep(2)
                    current_index = (current_index + 1) % len(playlist_items)
                    continue

            # PROAKTIVNÍ kontrola integrity před přehráním (stat + 16 B hlavičky = zanedbatelné).
            # Reaktivní kontrola nestačí: poškozený JPEG Kodi "zobrazí" jako smetí, takže
            # show_picture_safe() uspěje a vadný soubor by se nikdy neopravil (změřeno).
            _valid, _why = validate_media_file(file_path)
            if not _valid:
                xbmc.log(f"[Dohled] Mixed playlist: {item['filename']} je VADNÝ ({_why}) - opravuji", xbmc.LOGWARNING)
                repair_media_file(item['filename'], _why)

            if is_video_file(item['filename']):
                # Video - přehrát jednou
                xbmc.log(f"[Dohled] Mixed: video {item['filename']}", xbmc.LOGINFO)

                if current_displayed_image is not None:
                    # Obrázek→video: video se spustí POD slideshow a teprve pak se slideshow
                    # zavře (video ho překryje) - nikdy nevzniká prázdná obrazovka s menu.
                    transition_to_video_from_image(player, file_path)
                    current_displayed_image = None
                else:
                    # Video→video (nebo START, kdy je nad vším krycí černá): dokončit
                    # předchozí a spustit nové - a odkrýt, kdyby nad tím viselo krytí.
                    play_video_uncovered(player, file_path, wait_stop=2.0)
                time.sleep(0.5)
                is_first_item = False

                # Kontrola integrity: když se video do 6s nerozjelo, je pravděpodobně
                # poškozené (přerušené stahování, vadné úložiště). Smazat, stáhnout znovu
                # a přehrát - jinak by se přehrávání pořád dokola zkoušelo spustit.
                _vstart = time.time()
                while time.time() - _vstart < 6.0 and not player.isPlayingVideo():
                    if not is_my_playlist_active():
                        break
                    time.sleep(0.3)
                if is_my_playlist_active() and not player.isPlayingVideo():
                    xbmc.log(f"[Dohled] Video {item['filename']} se nerozjelo - kontrola integrity", xbmc.LOGWARNING)
                    if ensure_media_playable(item['filename']):
                        player.play(file_path)
                        time.sleep(1.0)

                # KRITICKÉ: video NESMÍ dohrát samo do konce!
                # Když přehrávání skončí, Kodi zavolá WindowManager::PreviousWindow() a
                # protože historie oken je [HOME], skočí na HOME MENU (změřeno: 4-6x za 110 s,
                # ~0,3 s pokaždé - reaktivně se to dohnat nedá).
                # Řešení: pustit video ve SMYČCE (RepeatOne), takže nikdy neskončí, a přepnout
                # na další položku SAMI po uplynutí jeho délky - přes bezešvou transition.
                xbmc.executebuiltin("PlayerControl(RepeatOne)")

                total = 0
                for _ in range(25):   # délku videa Kodi zpřístupní až po rozjezdu
                    if not is_my_playlist_active():
                        break
                    try:
                        t = player.getTotalTime()
                        if t and t > 0:
                            total = t
                            break
                    except Exception:
                        pass
                    time.sleep(0.2)

                # Přepnout podle SKUTEČNÉ POZICE v přehrávání (player.getTime()), NE podle
                # uplynulého času od téhle chvíle!
                # BUG, který to řešil: čas startu se ukládal až tady, tedy ~2,7 s po rozjezdu
                # videa (0,5 s pauza + kontrola integrity + čtení délky). Odpočet "délka - 0,6 s"
                # pak skončil až po ~10 s přehrávání 8s videa -> video se kvůli RepeatOne
                # vrátilo na začátek a divák viděl znovu jeho úvod, než se přepnulo na obrázek.
                started = time.monotonic()
                switch_at = max(0.5, total - 1.2) if total else None
                xbmc.log(f"[Dohled] Mixed: video {item['filename']} délka={total:.1f}s, "
                         f"přepnu v pozici {switch_at if switch_at else '?'}s", xbmc.LOGINFO)
                while is_my_playlist_active():
                    # PAUZA: pozice videa nebezi, tak nesmi bezet ani zalozni odpocet
                    if playlist_paused:
                        time.sleep(0.2)
                        started += 0.2
                        continue
                    pos = None
                    try:
                        pos = player.getTime()
                    except Exception:
                        pass

                    if switch_at is not None:
                        # Primární kritérium: pozice ve videu
                        if pos is not None and pos >= switch_at:
                            break
                        # Pojistka: kdyby pozice nešla číst, přepnout podle uplynulého času.
                        # Nikdy nečekat déle než délku videa (jinak by se stihlo zacyklit).
                        if (time.monotonic() - started) >= switch_at:
                            break
                    elif (time.monotonic() - started) >= 30.0:
                        break

                    if not player.isPlaying():
                        # Přesto skončilo (krátké/vadné video) - zakrýt mezeru
                        if not is_content_on_screen():
                            show_black_filler("video skončilo dřív")
                        break
                    time.sleep(0.2)

                if not is_my_playlist_active():
                    break

            else:
                # Obrázek - zobrazit na dobu duration
                duration = item.get('duration') or DEFAULT_IMAGE_DISPLAY_TIME
                xbmc.log(f"[Dohled] Mixed: obrázek {item['filename']} ({duration}s)", xbmc.LOGINFO)

                # Video zastavit JEN pokud skutečně hraje.
                # KRITICKÉ (příčina prosvitnutí menu): player.stop() nad běžícím
                # SLIDESHOW okno zavřel a Kodi vyskočilo na HOME. Když navíc nic nehrálo,
                # wait_for_player_stop(3s) držel prázdnou obrazovku (= menu) další sekundy.
                if player.isPlayingVideo() or player.isPlaying():
                    # Video→obrázek: ShowPicture PŘED stopem, aby obrázek video překryl
                    transition_to_image_from_video(player, file_path)
                    current_displayed_image = item['filename']
                else:
                    # Obrázek→obrázek: ShowPicture nahradí předchozí ATOMICKY, nic nezavírat
                    if show_picture_safe(file_path):
                        current_displayed_image = item['filename']
                    else:
                        # Zobrazení selhalo -> soubor je pravděpodobně poškozený.
                        # Smazat, znovu stáhnout z FTP a zkusit ještě raz.
                        show_black_filler("selhalo zobrazení obrázku")
                        current_displayed_image = None
                        if ensure_media_playable(item['filename']) and show_picture_safe(file_path):
                            current_displayed_image = item['filename']
                            xbmc.log(f"[Dohled] Obrázek {item['filename']} opraven a zobrazen", xbmc.LOGINFO)
                is_first_item = False

                # Čekat zadanou dobu nebo dokud není playlist změněn.
                # Průběžně hlídat, že obsah je stále v popředí (kdyby ho něco zavřelo).
                tick = -1
                while tick < duration * 2 - 1:
                    tick += 1
                    if not is_my_playlist_active():
                        break
                    # PAUZA: obrazek zustane na obrazovce, cas se nepocita
                    while playlist_paused and is_my_playlist_active():
                        time.sleep(0.5)
                    # Obnovit JEN když obsah opravdu zmizel (is_menu_visible už zohledňuje,
                    # že slideshow je dialog nad 'home' - jinak by se obrázek překresloval
                    # pořád dokola a obrazovka by problikávala).
                    if tick % 4 == 3 and is_menu_visible():
                        xbmc.log("[Dohled] Mixed: obsah zmizel, v popředí MENU - obnovuji", xbmc.LOGWARNING)
                        show_picture_safe(file_path)
                    time.sleep(0.5)

                if not is_my_playlist_active():
                    break

                # NIC nezavírat před dalším souborem:
                # - obrázek→obrázek: ShowPicture nový obrázek nahradí
                # - obrázek→video:   video slideshow přebije (transition_to_video_from_image)
                # Dřív se tu volalo dismiss_image()/close_image_viewer() -> mezera -> MENU.

            current_index = (current_index + 1) % len(playlist_items)
            current_mixed_playlist_position = current_index  # Aktualizovat pozici ihned

        # Cleanup
        current_displayed_image = None
        xbmc.log(f"[Dohled] Mixed playlist ID={my_playlist_id} ukončen", xbmc.LOGINFO)

    # Spustit ve vlákně
    mixed_playlist_thread = threading.Thread(target=mixed_playback_loop, daemon=True)
    mixed_playlist_thread.start()


def main():
    global ws_thread

    xbmc.log("[Dohled] === Spuštění doplňku Dohled ===", xbmc.LOGINFO)

    # Cleanup: Smazat zastaralý current_playing.txt od service.smycky
    # Od verze 2.7.0 service.dohled přebírá přehrávání, tento soubor už není potřeba
    # a může obsahovat stará data která způsobují chybné reportování
    if os.path.exists(CURRENT_PLAYING_FILE):
        try:
            os.remove(CURRENT_PLAYING_FILE)
            xbmc.log(f"[Dohled] Smazán zastaralý {CURRENT_PLAYING_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] Nelze smazat {CURRENT_PLAYING_FILE}: {e}", xbmc.LOGWARNING)

    # PRVNÍ KROK: Synchronizace času (před čímkoli jiným)
    ensure_time_synchronized()

    # ========================================
    # WATCHDOG DAEMON (automatický restart při pádu)
    # ========================================
    # Spustit watchdog jako oddělený daemon proces
    # Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi
    xbmc.log("[Dohled] === Spouštění watchdog daemonu ===", xbmc.LOGINFO)
    spawn_watchdog_daemon()

    # Načtení konfigurace - PRED aktualizaci addonu!
    # Pokud neni nakonfigurovano, nejdrive dokoncit setup, pak teprve updatovat
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
        # prompt_for_config konci rebootem, sem se nedostaneme
        return
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    # Aktualizace doplňků - spustit na pozadí AZ PO dokonceni konfigurace
    # (update muze restartovat addon/Kodi, coz by prerusilo prvotni nastaveni)
    threading.Thread(target=force_update_addons, kwargs={'retry_count': 3, 'retry_delay': 15}, daemon=True).start()
    xbmc.log("[Dohled] Aktualizace addonů spuštěna na pozadí", xbmc.LOGINFO)

    # Získat device_id pro komunikaci
    device_id = get_device_id()
    xbmc.log(f"[Dohled] Device ID: {device_id}", xbmc.LOGINFO)

    # Spuštění WebSocket connection loop (prioritní real-time kanál)
    if WEBSOCKET_AVAILABLE:
        ws_thread = threading.Thread(target=ws_connection_loop, args=(device_id,), daemon=True)
        ws_thread.start()
        xbmc.log("[Dohled] WebSocket connection loop spuštěn", xbmc.LOGINFO)

        # Spuštění rychlé state update smyčky (každé 2s, pouze přes WS)
        threading.Thread(target=state_update_loop, daemon=True).start()
        xbmc.log("[Dohled] Rychlá state update smyčka spuštěna (2s interval)", xbmc.LOGINFO)
    else:
        xbmc.log("[Dohled] WebSocket není dostupný, použije se pouze HTTP", xbmc.LOGWARNING)

    # Spuštění monitorovací smyčky (odesílá data každých 30s přes WS nebo HTTP)
    threading.Thread(target=monitor_loop, daemon=True).start()

    # Spuštění HTTP fallback pollingu příkazů (aktivní pouze když není WS)
    threading.Thread(target=command_polling_loop, args=(device_id,), daemon=True).start()

    # Spuštění periodické kontroly aktualizací addonů (každou hodinu, první za 5 minut)
    threading.Thread(target=addon_update_loop, daemon=True).start()
    xbmc.log("[Dohled] Periodická kontrola aktualizací spuštěna", xbmc.LOGINFO)

    # ========================================
    # ZAKÁZÁNÍ SCREENSAVERU (prevence ztlumení obrazovky)
    # ========================================
    xbmc.log("[Dohled] Zakázání screensaveru (InhibitScreensaver)", xbmc.LOGINFO)
    xbmc.executebuiltin('InhibitScreensaver(true)')

    # ========================================
    # STARTUP PŘEHRÁVÁNÍ (nahrazuje service.smycky)
    # ========================================
    xbmc.log("[Dohled] === Spuštění startup přehrávání ===", xbmc.LOGINFO)
    threading.Thread(target=startup_playback, daemon=True).start()

    # ========================================
    # KODI LOG MONITOR (detekce černé obrazovky)
    # ========================================
    global kodi_log_monitor
    xbmc.log("[Dohled] === Spuštění KodiLogMonitor ===", xbmc.LOGINFO)
    kodi_log_monitor = KodiLogMonitor()
    kodi_log_monitor.start()

    # ========================================
    # POJISTKA PROTI KODI MENU
    # ========================================
    # Menu se nikdy nesmí ukázat - hlídá se každé 2s nezávisle na WebSocketu.
    threading.Thread(target=menu_guard_loop, daemon=True).start()

    # ========================================
    # OCHRANA PROTI SMYČCE RESTARTŮ
    # ========================================
    # Vynuluje počítadlo automatických restartů po stabilním uptime (monotonic).
    threading.Thread(target=reset_auto_reboot_counter_when_stable, daemon=True).start()

    # ========================================
    # PLÁNOVÁNÍ RESTARTU
    # ========================================
    xbmc.log("[Dohled] === Plánování denního restartu ===", xbmc.LOGINFO)
    schedule_random_reboot(load_config().get("locality"))

    xbmc.log("[Dohled] === Inicializace dokončena ===", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] WebSocket: {'ANO' if WEBSOCKET_AVAILABLE else 'NE'}", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] State updates: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)
    xbmc.log("[Dohled] Startup přehrávání: ANO (nahrazuje service.smycky)", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] Krytí přechodů: černý obrázek"
             f"{' + krycí video (Amlogic)' if USE_BLACK_TRANSITION_VIDEO else ' (krycí video se nepoužívá)'}",
             xbmc.LOGINFO)

    # ========================================
    # HLAVNÍ SMYČKA - ČEKÁNÍ NA ABORT
    # ========================================
    # KRITICKÉ: Tato smyčka je nutná pro správné ukončení addonu!
    # Bez ní Kodi nemůže gracefully zastavit addon a zabije ho po 5 sekundách.
    monitor = xbmc.Monitor()
    xbmc.log("[Dohled] Spouštím hlavní smyčku (čekám na abort)", xbmc.LOGINFO)

    while not monitor.abortRequested():
        # Čekat 1 sekundu, ale okamžitě se probudit při abort requestu
        if monitor.waitForAbort(1):
            break

    # ========================================
    # GRACEFUL SHUTDOWN
    # ========================================
    xbmc.log("[Dohled] === Ukončování addonu ===", xbmc.LOGINFO)

    # Nastavit stop_monitoring flag pro všechny vlákna
    stop_monitoring = True

    # Zavřít WebSocket spojení (toto probudí blokující run_forever)
    if ws_app:
        try:
            xbmc.log("[Dohled] Zavírám WebSocket spojení...", xbmc.LOGINFO)
            ws_app.close()
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při zavírání WS: {e}", xbmc.LOGWARNING)

    # Zastavit KodiLogMonitor
    if kodi_log_monitor:
        try:
            kodi_log_monitor.stop()
        except:
            pass

    xbmc.log("[Dohled] === Addon ukončen ===", xbmc.LOGINFO)


if __name__ == "__main__":
    main()