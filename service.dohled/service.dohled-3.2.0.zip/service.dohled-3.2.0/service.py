import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import socket
import threading
import time
import urllib.request
import urllib.parse
import uuid
import subprocess
import ssl
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta
from ftplib import FTP
import shutil
import random
import sqlite3
import re

# Přidat cestu k bundlované websocket knihovně
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
sys.path.insert(0, ADDON_PATH)

# Import websocket knihovny (bundlovaná s addonem)
try:
    import websocket
    WEBSOCKET_AVAILABLE = True
    xbmc.log("[Dohled] WebSocket knihovna načtena", xbmc.LOGINFO)
except ImportError:
    WEBSOCKET_AVAILABLE = False
    xbmc.log("[Dohled] WebSocket knihovna není dostupná, použije se HTTP fallback", xbmc.LOGWARNING)

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')
DEVICE_ID_FILE = os.path.join(PROFILE_DIR, 'device_id.txt')
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
TIME_SYNC_FILE = "/storage/.kodi/userdata/time_synced.flag"
STOP_SMYCKY_FLAG = "/storage/.kodi/userdata/stop_smycky_playlist.flag"  # Signal pro zastavení playlistu v service.smycky
CURRENT_PLAYING_FILE = "/storage/.kodi/userdata/current_playing.txt"  # Sdílení aktuálně přehrávaného souboru z service.smycky
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"  # Heartbeat pro externí watchdog
WATCHDOG_SCRIPT = "/storage/.kodi/temp/dohled_watchdog.py"  # Self-spawned watchdog daemon
WATCHDOG_PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"  # PID watchdogu
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# WebSocket konfigurace
WS_URL = "wss://apidohled.noreason.eu/ws/"
WS_RECONNECT_INTERVAL = 5  # Sekund mezi pokusy o reconnect
WS_PING_INTERVAL = 30  # Sekund mezi ping zprávami

# Monotonic čas startu addonu - nezávislý na změnách systémového času (NTP sync)
# time.monotonic() je nezávislé na NTP/čase, takže můžeme později vypočítat správný boot_time
# Toto se změní při každém restartu Kodi (i bez rebootu celého systému)
ADDON_START_MONOTONIC = time.monotonic()
WS_MONITORING_INTERVAL = 30  # Sekund mezi plnými monitoring zprávami přes WebSocket
WS_STATE_CHECK_INTERVAL = 2  # Sekund mezi kontrolami stavu (rychlá detekce změn)
WS_STATE_HEARTBEAT_INTERVAL = 10  # Sekund - max interval pro heartbeat i bez změny stavu

# Správa úložiště
VIDEO_DIR = "/storage/videos/"
IMAGE_DIR = "/storage/pictures/"  # Obrázky patří do /storage/pictures/, ne videos!
MIN_FREE_SPACE_MB = 1000  # Minimální volné místo v MB - jediné kritérium pro mazání souborů

# Soubor pro sledování restartů
REBOOT_TRACK_FILE = "/storage/.kodi/userdata/reboot_log.txt"


def get_local_media_path(filename):
    """
    Vrátí správnou lokální cestu pro mediální soubor.
    Obrázky jdou do IMAGE_DIR, videa do VIDEO_DIR.

    Args:
        filename: Název souboru (může obsahovat cestu, použije se jen basename)

    Returns:
        Úplná cesta k souboru nebo None pokud filename je prázdný
    """
    if not filename:
        return None
    base_filename = os.path.basename(filename)
    if is_image_file(base_filename):
        return os.path.join(IMAGE_DIR, base_filename)
    else:
        return os.path.join(VIDEO_DIR, base_filename)


def mark_reboot(source="manual"):
    """
    Zaznamená restart do REBOOT_TRACK_FILE před provedením restartu.
    Volat VŽDY před os.system("reboot") nebo xbmc.executebuiltin("Reboot").

    Args:
        source: Zdroj restartu (manual, scheduled, update_video, refresh_config, setup)
    """
    try:
        from datetime import datetime
        now = datetime.now()
        date_str = now.strftime('%Y-%m-%d')
        time_str = now.strftime('%Y-%m-%d %H:%M:%S')

        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {date_str}\n")
            f.write(f"Čas restartu: {time_str}\n")
            f.write(f"Zdroj: {source}\n")
            f.flush()
            os.fsync(f.fileno())

        xbmc.log(f"[Dohled] Zaznamenán restart: {time_str} (zdroj: {source})", xbmc.LOGINFO)
        time.sleep(0.5)  # Krátká pauza pro jistotu zápisu na disk
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při záznamu restartu: {e}", xbmc.LOGERROR)


def write_heartbeat():
    """
    Zapíše aktuální timestamp do heartbeat souboru.
    Externí watchdog kontroluje tento soubor a restartuje Kodi pokud je příliš starý.
    """
    try:
        with open(HEARTBEAT_FILE, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass  # Tiché selhání - nechceme crashovat kvůli heartbeatu


def spawn_watchdog_daemon():
    """
    Vytvoří a spustí watchdog jako oddělený daemon proces.
    Watchdog běží NEZÁVISLE na Kodi a přežije i když Kodi addon zabije.
    Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi.
    """
    # Watchdog script - self-contained Python (bez xbmc importů)
    watchdog_code = '''#!/usr/bin/env python3
"""
Dohled Watchdog Daemon - automaticky restartuje Kodi pokud service.dohled přestane fungovat.
Tento script běží jako ODDĚLENÝ PROCES, nezávisle na Kodi.
"""
import os
import sys
import time
import signal

# Konfigurace
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"
PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"
LOG_FILE = "/storage/.kodi/temp/dohled_watchdog.log"
CHECK_INTERVAL = 60  # Kontrolovat každých 60 sekund
MAX_HEARTBEAT_AGE = 600  # Max stáří heartbeatu (10 minut)
STARTUP_GRACE_PERIOD = 300  # 5 minut po startu čekat na service.dohled

def log(message):
    """Zapíše zprávu do logu."""
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, 'a') as f:
            f.write(f"[{timestamp}] {message}\\n")
    except:
        pass

def get_heartbeat_age():
    """Vrátí stáří heartbeat souboru v sekundách, nebo None pokud neexistuje."""
    try:
        if not os.path.exists(HEARTBEAT_FILE):
            return None
        with open(HEARTBEAT_FILE, 'r') as f:
            last_beat = float(f.read().strip())
        return time.time() - last_beat
    except:
        return None

def restart_kodi():
    """Restartuje Kodi přes systemctl (přežije pád Kodi)."""
    log("RESTARTUJI KODI - service.dohled neodpovídá!")
    try:
        os.remove(HEARTBEAT_FILE)
    except:
        pass
    # Restart přes systemctl - funguje i když Kodi neodpovídá
    os.system("systemctl restart kodi")
    sys.exit(0)  # Watchdog se ukončí, nový se spustí s novým Kodi

def check_existing_watchdog():
    """Zkontroluje a ukončí existující watchdog pokud běží."""
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, 'r') as f:
                old_pid = int(f.read().strip())
            # Zkontrolovat jestli proces běží
            os.kill(old_pid, 0)  # Pokud neběží, vyhodí výjimku
            # Proces běží - ukončit ho
            os.kill(old_pid, signal.SIGTERM)
            time.sleep(1)
            try:
                os.kill(old_pid, signal.SIGKILL)
            except:
                pass
            log(f"Ukončen starý watchdog PID {old_pid}")
        except (ProcessLookupError, ValueError, FileNotFoundError):
            pass  # Proces neběží nebo špatný PID
        try:
            os.remove(PID_FILE)
        except:
            pass

def write_pid():
    """Zapíše PID do souboru."""
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

def main():
    # Ukončit starý watchdog
    check_existing_watchdog()

    # Zapsat náš PID
    write_pid()

    log(f"Watchdog daemon spuštěn (PID {os.getpid()})")
    log(f"Grace period: {STARTUP_GRACE_PERIOD}s, Max heartbeat age: {MAX_HEARTBEAT_AGE}s")

    # Startup grace period
    log(f"Čekám {STARTUP_GRACE_PERIOD}s na spuštění service.dohled...")
    time.sleep(STARTUP_GRACE_PERIOD)
    log("Grace period dokončena, začínám monitorovat heartbeat")

    # Hlavní smyčka
    while True:
        age = get_heartbeat_age()

        if age is None:
            log("Heartbeat soubor neexistuje, čekám...")
        elif age > MAX_HEARTBEAT_AGE:
            log(f"Heartbeat je starý {int(age)}s (max {MAX_HEARTBEAT_AGE}s)")
            restart_kodi()
            return

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    # Double-fork pro plnou daemonizaci
    if os.fork() > 0:
        sys.exit(0)  # Parent exits

    os.setsid()  # Nová session

    if os.fork() > 0:
        sys.exit(0)  # First child exits

    # Druhé dítě je daemon
    # Uzavřít file descriptory
    sys.stdin.close()
    sys.stdout.close()
    sys.stderr.close()

    # Redirect to /dev/null
    fd = os.open('/dev/null', os.O_RDWR)
    os.dup2(fd, 0)
    os.dup2(fd, 1)
    os.dup2(fd, 2)

    main()
'''

    try:
        # Zapsat watchdog script
        with open(WATCHDOG_SCRIPT, 'w') as f:
            f.write(watchdog_code)
        os.chmod(WATCHDOG_SCRIPT, 0o755)

        # Spustit watchdog jako samostatný proces
        # Použijeme os.system s nohup aby proces přežil ukončení rodiče
        subprocess.Popen(
            ['python3', WATCHDOG_SCRIPT],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        xbmc.log("[Dohled] Watchdog daemon spuštěn", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při spouštění watchdog daemonu: {e}", xbmc.LOGERROR)


# Podporované formáty souborů
VIDEO_EXTENSIONS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

# Výchozí doba zobrazení obrázku (v sekundách)
DEFAULT_IMAGE_DISPLAY_TIME = 10

# Texture cache - pro detekci a opravu černé obrazovky
TEXTURE_DB_PATH = "/storage/.kodi/userdata/Database/Textures13.db"
THUMBNAILS_PATH = "/storage/.kodi/userdata/Thumbnails"
BLACK_SCREEN_MAX_RETRIES = 2
BLACK_SCREEN_VERIFY_DELAY = 0.5  # sekundy čekání na zobrazení
KODI_LOG_PATH = "/storage/.kodi/temp/kodi.log"
BLACK_SCREEN_LOG_MONITOR_INTERVAL = 0.5  # sekundy mezi kontrolami logu

# Sledování aktuálně zobrazeného obrázku (pro monitoring)
# Nastavuje se při play_file/play_playlist, None když hraje video nebo nic
current_displayed_image = None

# Sledování uživatelem ručně puštěného souboru
# Monitoring loop nebude přepisovat soubor dokud je toto nastaveno
user_initiated_file = None

# Flag pro manuální zastavení - monitoring loop nebude auto-startovat
# Nastavuje se při stop příkazu, resetuje se při play/play_file/play_playlist
user_stopped = False

# Uložení posledního stopnutého obsahu pro možnost obnovení přehrávání
# Formát: {'type': 'single'/'playlist', 'file': 'filename', 'files': ['file1', 'file2']}
last_stopped_content = None

# Flag pro nový obsah čekající na restart - zabrání auto-play nového obsahu
# Nastavuje se při download_only/download_only_playlist, resetuje se při restartu
pending_new_content = False

# Tracking čerstvě stažených souborů pro správné přehrávání obrázků
# {filename: timestamp} - soubory stažené v posledních 60 sekundách
# play_file handler kontroluje tuto dict a volá show_picture_safe s freshly_downloaded=True
recently_downloaded_files = {}
RECENTLY_DOWNLOADED_TTL = 60  # sekund - jak dlouho považovat soubor za "čerstvě stažený"


# === ODSTRANĚNO: BLACK OVERLAY - způsobovalo problémy ===
# Veškeré překrývání a skrývání Kodi UI bylo odstraněno pro stabilitu


def get_smycky_current_playing():
    """Přečte aktuálně přehrávaný soubor z service.smycky."""
    try:
        if os.path.exists(CURRENT_PLAYING_FILE):
            with open(CURRENT_PLAYING_FILE, 'r') as f:
                return f.read().strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení current_playing: {e}", xbmc.LOGERROR)
    return None


def is_video_file(filename):
    """Zjistí, zda je soubor video podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(VIDEO_EXTENSIONS)


def is_image_file(filename):
    """Zjistí, zda je soubor obrázek podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(IMAGE_EXTENSIONS)


def is_supported_file(filename):
    """Zjistí, zda je soubor podporovaný (video nebo obrázek)."""
    if not filename:
        return False
    return filename.lower().endswith(SUPPORTED_EXTENSIONS)


def get_media_type(filename):
    """Vrátí typ média: 'video', 'image' nebo None."""
    if not filename:
        return None
    lower_name = filename.lower()
    if lower_name.endswith(VIDEO_EXTENSIONS):
        return 'video'
    elif lower_name.endswith(IMAGE_EXTENSIONS):
        return 'image'
    return None


# ======= FUNKCE PRO TEXTURE CACHE (černá obrazovka) =======

def clear_image_from_texture_cache(image_path):
    """
    Vyčistí konkrétní obrázek z Kodi texture cache.
    Smaže záznam z Textures13.db a odpovídající soubor z Thumbnails.

    Args:
        image_path: Cesta k obrázku (např. /storage/videos/image.jpg)

    Returns:
        bool: True pokud byla cache vyčištěna, False při chybě
    """
    if not os.path.exists(TEXTURE_DB_PATH):
        xbmc.log(f"[Dohled] Texture DB nenalezena: {TEXTURE_DB_PATH}", xbmc.LOGWARNING)
        return False

    try:
        conn = sqlite3.connect(TEXTURE_DB_PATH)
        cursor = conn.cursor()

        # Najít záznamy pro tento obrázek (hledáme podle cesty)
        cursor.execute(
            "SELECT id, cachedurl FROM texture WHERE url LIKE ?",
            (f"%{os.path.basename(image_path)}%",)
        )
        rows = cursor.fetchall()

        if not rows:
            xbmc.log(f"[Dohled] Obrázek není v texture cache: {image_path}", xbmc.LOGINFO)
            conn.close()
            return True  # Není v cache = OK

        for row in rows:
            texture_id, cached_url = row

            # Smazat thumbnail soubor pokud existuje
            if cached_url:
                thumbnail_path = os.path.join(THUMBNAILS_PATH, cached_url)
                if os.path.exists(thumbnail_path):
                    try:
                        os.remove(thumbnail_path)
                        xbmc.log(f"[Dohled] Smazán thumbnail: {thumbnail_path}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Nelze smazat thumbnail: {e}", xbmc.LOGWARNING)

            # Smazat záznam z DB
            cursor.execute("DELETE FROM texture WHERE id = ?", (texture_id,))
            xbmc.log(f"[Dohled] Smazán texture cache záznam ID={texture_id} pro {image_path}", xbmc.LOGINFO)

        conn.commit()
        conn.close()
        return True

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění texture cache: {e}", xbmc.LOGERROR)
        return False


def verify_image_displayed():
    """
    Ověří, zda je obrázek skutečně zobrazen.
    Kontroluje různé Kodi conditions pro picture viewer/slideshow.

    Returns:
        bool: True pokud je obrázek zobrazen, False pokud černá obrazovka
    """
    # Kodi conditions pro zobrazený obrázek
    conditions = [
        "Window.IsActive(slideshow)",
        "Window.IsVisible(slideshow)",
        "Slideshow.IsActive",
        "Window.IsActive(pictures)",
        "Window.IsVisible(pictures)",
    ]

    for condition in conditions:
        if xbmc.getCondVisibility(condition):
            return True

    # Žádná z podmínek není splněna = pravděpodobně černá obrazovka
    return False


def wait_for_player_stop(timeout=3.0, poll_interval=0.1):
    """
    Čeká, dokud Kodi player skutečně nezastaví přehrávání.
    KRITICKÉ: Kodi potřebuje čas na uvolnění video rendereru před zobrazením obrázku.

    Args:
        timeout: Maximální čas čekání v sekundách
        poll_interval: Interval mezi kontrolami

    Returns:
        bool: True pokud player zastaven, False při timeoutu
    """
    player = xbmc.Player()
    start_time = time.time()
    checks = 0

    while time.time() - start_time < timeout:
        checks += 1
        # Kontrola zda video skutečně neběží
        if not player.isPlayingVideo() and not player.isPlaying():
            elapsed = time.time() - start_time
            xbmc.log(f"[Dohled] Player zastaven po {elapsed:.2f}s ({checks} kontrol)", xbmc.LOGINFO)
            # Extra čekání pro uvolnění GPU/renderer resources
            time.sleep(0.5)
            return True
        time.sleep(poll_interval)

    elapsed = time.time() - start_time
    xbmc.log(f"[Dohled] VAROVÁNÍ: Timeout čekání na zastavení playeru ({elapsed:.2f}s, {checks} kontrol)", xbmc.LOGWARNING)
    return False


def verify_image_file_ready(image_path, expected_size=None, timeout=5.0):
    """
    Ověří, že obrazový soubor je plně zapsán na disk a je čitelný.
    Kritické pro soubory právě stažené z FTP - Kodi je nemůže načíst okamžitě.

    Args:
        image_path: Cesta k souboru
        expected_size: Očekávaná velikost souboru (volitelné)
        timeout: Maximální čas čekání v sekundách

    Returns:
        bool: True pokud je soubor připraven, False pokud timeout
    """
    start_time = time.time()
    attempt = 0

    while time.time() - start_time < timeout:
        attempt += 1
        try:
            # 1. Ověřit že soubor existuje a má velikost
            if not os.path.exists(image_path):
                xbmc.log(f"[Dohled] verify_image: Soubor neexistuje (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            file_size = os.path.getsize(image_path)
            if file_size == 0:
                xbmc.log(f"[Dohled] verify_image: Soubor má nulovou velikost (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 2. Ověřit očekávanou velikost (pokud je známá)
            if expected_size and file_size != expected_size:
                xbmc.log(f"[Dohled] verify_image: Neúplný soubor {file_size}/{expected_size} (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 3. Pokusit se otevřít a přečíst celý soubor - klíčové pro ověření
            with open(image_path, 'rb') as f:
                data = f.read()

            if len(data) != file_size:
                xbmc.log(f"[Dohled] verify_image: Přečteno {len(data)}, očekáváno {file_size} (pokus {attempt})", xbmc.LOGDEBUG)
                time.sleep(0.1)
                continue

            # 4. Pro JPEG ověřit strukturu (SOI marker na začátku, EOI na konci)
            is_jpeg = image_path.lower().endswith(('.jpg', '.jpeg'))
            if is_jpeg:
                # JPEG musí začínat FF D8 a končit FF D9
                if len(data) < 4:
                    xbmc.log(f"[Dohled] verify_image: Soubor příliš malý pro JPEG (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[0:2] != b'\xff\xd8':
                    xbmc.log(f"[Dohled] verify_image: Chybí JPEG SOI marker (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[-2:] != b'\xff\xd9':
                    xbmc.log(f"[Dohled] verify_image: Chybí JPEG EOI marker - soubor neúplný (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

            # 5. Pro PNG ověřit signaturu
            is_png = image_path.lower().endswith('.png')
            if is_png:
                # PNG musí začínat specifickou 8-byte signaturou
                if len(data) < 8:
                    xbmc.log(f"[Dohled] verify_image: Soubor příliš malý pro PNG (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

                if data[0:8] != b'\x89PNG\r\n\x1a\n':
                    xbmc.log(f"[Dohled] verify_image: Chybí PNG signatura (pokus {attempt})", xbmc.LOGDEBUG)
                    time.sleep(0.1)
                    continue

            # Všechny kontroly prošly
            elapsed = time.time() - start_time
            xbmc.log(f"[Dohled] verify_image: Soubor připraven po {attempt} pokusech ({elapsed:.2f}s): {image_path}", xbmc.LOGINFO)
            return True

        except IOError as e:
            xbmc.log(f"[Dohled] verify_image: IO chyba (pokus {attempt}): {e}", xbmc.LOGDEBUG)
            time.sleep(0.1)
            continue
        except Exception as e:
            xbmc.log(f"[Dohled] verify_image: Chyba (pokus {attempt}): {e}", xbmc.LOGWARNING)
            time.sleep(0.1)
            continue

    elapsed = time.time() - start_time
    xbmc.log(f"[Dohled] verify_image: TIMEOUT po {elapsed:.2f}s a {attempt} pokusech: {image_path}", xbmc.LOGERROR)
    return False


def show_picture_safe(image_path, _retry_count=0, freshly_downloaded=False):
    """
    Zobrazí obrázek s detekcí černé obrazovky a auto-opravou.
    Pro čerstvě stažené soubory používá speciální přístup.

    Args:
        image_path: Cesta k obrázku
        _retry_count: Interní počítadlo pokusů
        freshly_downloaded: True pokud byl soubor právě stažen (vyžaduje extra opatrnost)

    Returns:
        bool: True pokud se obrázek zobrazil, False při selhání
    """
    filename = os.path.basename(image_path)

    # PRO ČERSTVĚ STAŽENÉ SOUBORY: Speciální příprava
    if freshly_downloaded and _retry_count == 0:
        xbmc.log(f"[Dohled] show_picture_safe: Čerstvě stažený soubor - speciální příprava", xbmc.LOGINFO)

        # 1. KRITICKÉ: Kompletně zastavit video player a uvolnit GPU/decoder resources!
        # Použít xbmc.Player().stop() s kontrolou isPlaying() - spolehlivější než PlayerControl(Stop)
        player = xbmc.Player()
        if player.isPlaying():
            xbmc.log(f"[Dohled] show_picture_safe: Player běží - zastavuji", xbmc.LOGINFO)
            player.stop()

            # Čekat až se player skutečně zastaví (max 5 sekund)
            max_wait = 50  # 50 x 100ms = 5 sekund
            wait_count = 0
            while player.isPlaying() and wait_count < max_wait:
                xbmc.sleep(100)
                wait_count += 1

            if wait_count >= max_wait:
                xbmc.log(f"[Dohled] show_picture_safe: VAROVÁNÍ - player se nezastavil po 5s!", xbmc.LOGWARNING)
            else:
                xbmc.log(f"[Dohled] show_picture_safe: Player zastaven po {wait_count * 100}ms", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Dohled] show_picture_safe: Player neběží", xbmc.LOGINFO)

        # Krátká pauza po zastavení playeru (problém byl ve složce, ne v GPU)
        xbmc.sleep(300)

        # 2. Container.Refresh pro jistotu
        xbmc.executebuiltin("Container.Refresh")
        xbmc.sleep(200)

        # 4. PREVENTIVNĚ vyčistit texture cache
        clear_image_from_texture_cache(image_path)

        # 5. Ověřit že soubor je čitelný (otevřít a přečíst hlavičku)
        try:
            with open(image_path, 'rb') as f:
                header = f.read(16)
                xbmc.log(f"[Dohled] show_picture_safe: Soubor čitelný, header {len(header)} bytes", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] show_picture_safe: CHYBA - soubor není čitelný: {e}", xbmc.LOGERROR)
            return False

        # 6. Krátká pauza před zobrazením (sníženo z 500ms, problém byl ve složce)
        xbmc.sleep(100)

    # Zobrazit obrázek pomocí SlideShow (může být spolehlivější než ShowPicture pro single image)
    # SlideShow s jedním souborem = zobrazí jen ten jeden obrázek
    parent_dir = os.path.dirname(image_path)
    xbmc.log(f"[Dohled] show_picture_safe: Zobrazuji {filename}", xbmc.LOGINFO)
    xbmc.executebuiltin(f'ShowPicture("{image_path}")')

    # Počkat a ověřit zobrazení (použít xbmc.sleep pro lepší integraci s Kodi)
    xbmc.sleep(int(BLACK_SCREEN_VERIFY_DELAY * 1000))

    if not verify_image_displayed():
        # ČERNÁ OBRAZOVKA DETEKOVÁNA!
        xbmc.log(f"[Dohled] ČERNÁ OBRAZOVKA detekována: {filename} (pokus {_retry_count + 1})", xbmc.LOGERROR)

        if _retry_count < BLACK_SCREEN_MAX_RETRIES:
            # Pokus o opravu - vyčistit cache a zkusit znovu
            xbmc.log(f"[Dohled] Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)
            xbmc.sleep(500)
            return show_picture_safe(image_path, _retry_count + 1, freshly_downloaded=False)
        else:
            # Všechny pokusy selhaly - zkusit JSON-RPC jako poslední možnost
            xbmc.log(f"[Dohled] Zkouším JSON-RPC Player.Open jako fallback", xbmc.LOGINFO)
            try:
                import json
                request = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "Player.Open",
                    "params": {"item": {"file": image_path}},
                    "id": 1
                })
                response = xbmc.executeJSONRPC(request)
                xbmc.log(f"[Dohled] JSON-RPC response: {response}", xbmc.LOGINFO)
                xbmc.sleep(1000)
                if verify_image_displayed():
                    xbmc.log(f"[Dohled] JSON-RPC úspěšné pro: {filename}", xbmc.LOGINFO)
                    return True
            except Exception as e:
                xbmc.log(f"[Dohled] JSON-RPC selhalo: {e}", xbmc.LOGERROR)

            xbmc.log(f"[Dohled] Všechny pokusy selhaly pro: {filename}", xbmc.LOGERROR)
            return False

    # Úspěch
    if _retry_count > 0:
        xbmc.log(f"[Dohled] Obrázek zobrazen po {_retry_count + 1} pokusech: {filename}", xbmc.LOGINFO)
    return True


# ======= KODI LOG MONITOR PRO DETEKCI ČERNÉ OBRAZOVKY =======

class KodiLogMonitor(threading.Thread):
    """
    Monitoruje Kodi log pro detekci chyby 'Error loading the current image'.
    Když je chyba detekována, automaticky vyčistí texture cache a pokusí se
    obrázek znovu zobrazit.
    """

    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._last_position = 0
        self._last_error_time = 0  # Pro debouncing - nechceme reagovat na každý řádek
        self._processed_images = {}  # {image_path: timestamp} - pro tracking již zpracovaných
        self._fix_attempts = {}  # {image_path: count} - počet pokusů o opravu
        self._max_fix_attempts = 2  # Maximální počet pokusů o auto-fix
        # Pattern pro detekci chyby: Error loading the current image 0: /storage/videos/filename.jpg
        self._error_pattern = re.compile(r'Error loading the current image \d+: (.+)$')

    def stop(self):
        self._stop_event.set()

    def run(self):
        xbmc.log("[Dohled] KodiLogMonitor spuštěn", xbmc.LOGINFO)

        # Přeskočit existující obsah logu
        if os.path.exists(KODI_LOG_PATH):
            try:
                with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                    f.seek(0, 2)  # Seek to end
                    self._last_position = f.tell()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při inicializaci pozice: {e}", xbmc.LOGWARNING)

        while not self._stop_event.is_set():
            try:
                self._check_log()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor chyba: {e}", xbmc.LOGWARNING)

            self._stop_event.wait(BLACK_SCREEN_LOG_MONITOR_INTERVAL)

        xbmc.log("[Dohled] KodiLogMonitor ukončen", xbmc.LOGINFO)

    def _check_log(self):
        """Kontroluje nové řádky v Kodi logu."""
        if not os.path.exists(KODI_LOG_PATH):
            return

        try:
            with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                # Zkontrolovat zda soubor nebyl rotován (pozice větší než velikost)
                f.seek(0, 2)
                current_size = f.tell()
                if self._last_position > current_size:
                    self._last_position = 0

                # Číst od poslední pozice
                f.seek(self._last_position)
                new_lines = f.readlines()
                self._last_position = f.tell()

                for line in new_lines:
                    self._process_line(line)
        except Exception as e:
            xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při čtení logu: {e}", xbmc.LOGWARNING)

    def _process_line(self, line):
        """Zpracuje jeden řádek logu."""
        # Hledáme "error <general>: Error loading the current image"
        if 'Error loading the current image' not in line:
            return

        match = self._error_pattern.search(line)
        if not match:
            return

        image_path = match.group(1).strip()
        current_time = time.time()

        # Debouncing - Kodi loguje tuto chybu opakovaně, zpracuj jen jednou za 5 sekund pro daný obrázek
        if image_path in self._processed_images:
            if current_time - self._processed_images[image_path] < 5:
                return

        self._processed_images[image_path] = current_time

        # Vyčistit staré záznamy (processed a fix_attempts)
        self._processed_images = {k: v for k, v in self._processed_images.items()
                                   if current_time - v < 60}
        # Reset fix_attempts po 2 minutách
        self._fix_attempts = {k: v for k, v in self._fix_attempts.items()
                              if k in self._processed_images}

        # Kontrola počtu pokusů - po vyčerpání přestat zkoušet
        attempts = self._fix_attempts.get(image_path, 0)
        if attempts >= self._max_fix_attempts:
            xbmc.log(f"[Dohled] KodiLogMonitor: Černá obrazovka pro {image_path} - max pokusů ({self._max_fix_attempts}) vyčerpáno", xbmc.LOGWARNING)
            return

        self._fix_attempts[image_path] = attempts + 1
        xbmc.log(f"[Dohled] KodiLogMonitor: Detekována černá obrazovka pro: {image_path} (pokus {attempts + 1}/{self._max_fix_attempts})", xbmc.LOGERROR)

        # Spustit opravu v separátním vlákně aby neblokoval monitor
        threading.Thread(target=self._fix_black_screen, args=(image_path,), daemon=True).start()

    def _fix_black_screen(self, image_path):
        """Pokusí se opravit černou obrazovku vyčištěním cache a znovuzobrazením."""
        filename = os.path.basename(image_path)

        try:
            # 1. Vyčistit texture cache
            xbmc.log(f"[Dohled] Auto-fix: Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)

            # 2. Krátká pauza
            time.sleep(0.3)

            # 3. Zavřít aktuální slideshow
            xbmc.executebuiltin('Action(Stop)')
            time.sleep(0.2)

            # 4. Znovu zobrazit obrázek
            xbmc.log(f"[Dohled] Auto-fix: Znovu zobrazuji: {filename}", xbmc.LOGINFO)
            xbmc.executebuiltin(f'ShowPicture("{image_path}")')

            # 5. Počkat a zkontrolovat
            time.sleep(1)

            # Pokud se opět objeví chyba, bude zachycena dalším průchodem
            xbmc.log(f"[Dohled] Auto-fix: Oprava dokončena pro: {filename}", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[Dohled] Auto-fix: Chyba při opravě {filename}: {e}", xbmc.LOGERROR)


# Instance log monitoru (globální)
kodi_log_monitor = None


# ======= FUNKCE PRO SPRÁVU DISKU =======

def get_disk_space_mb(path):
    """Vrátí volné místo na disku v MB."""
    try:
        statvfs = os.statvfs(path)
        free_bytes = statvfs.f_frsize * statvfs.f_bavail
        return free_bytes / (1024 * 1024)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa na disku: {e}", xbmc.LOGERROR)
        return 0


def get_file_size_mb(filepath):
    """Vrátí velikost souboru v MB."""
    try:
        if os.path.exists(filepath):
            return os.path.getsize(filepath) / (1024 * 1024)
        return 0
    except:
        return 0


def cleanup_old_media(current_filename, needed_space_mb=0):
    """
    Vyčistí staré mediální soubory pouze pokud je nedostatek volného místa.
    Maže nejstarší soubory dokud není dostatek místa (MIN_FREE_SPACE_MB + needed_space_mb).
    """
    try:
        free_space = get_disk_space_mb(VIDEO_DIR)
        total_needed = MIN_FREE_SPACE_MB + needed_space_mb

        if free_space >= total_needed:
            xbmc.log(f"[Dohled] Dostatek místa ({free_space:.0f} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0, 0

        space_to_free = total_needed - free_space
        xbmc.log(f"[Dohled] Nedostatek místa ({free_space:.0f} MB), potřeba uvolnit {space_to_free:.0f} MB", xbmc.LOGWARNING)

        media_files = []
        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                mtime = os.path.getmtime(filepath)
                size_mb = get_file_size_mb(filepath)
                media_files.append({
                    'filename': filename,
                    'filepath': filepath,
                    'mtime': mtime,
                    'size_mb': size_mb
                })

        # Seřadit od nejstaršího (nejstarší budou smazány první)
        media_files.sort(key=lambda x: x['mtime'])
        xbmc.log(f"[Dohled] Nalezeno {len(media_files)} mediálních souborů", xbmc.LOGINFO)

        deleted_count = 0
        freed_space_mb = 0

        for file_info in media_files:
            if freed_space_mb >= space_to_free:
                break

            # Chránit aktuálně přehrávaný soubor
            if file_info['filename'] == current_filename:
                xbmc.log(f"[Dohled] Chráním aktuální soubor: {file_info['filename']}", xbmc.LOGINFO)
                continue

            try:
                os.remove(file_info['filepath'])
                deleted_count += 1
                freed_space_mb += file_info['size_mb']
                xbmc.log(f"[Dohled] Smazán starý soubor: {file_info['filename']} ({file_info['size_mb']:.1f} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při mazání {file_info['filename']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            pass  # Notifikace odstraněna - info je v logu

        return deleted_count, freed_space_mb

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění starých souborů: {e}", xbmc.LOGERROR)
        return 0, 0


def analyze_disk_usage():
    """Analyzuje využití disku a vrátí statistiky."""
    try:
        media_files = []
        total_size_mb = 0

        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                size_mb = get_file_size_mb(filepath)
                mtime = os.path.getmtime(filepath)
                media_files.append({
                    'filename': filename,
                    'size_mb': size_mb,
                    'mtime': mtime,
                    'type': get_media_type(filename)
                })
                total_size_mb += size_mb

        media_files.sort(key=lambda x: x['size_mb'], reverse=True)
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        video_count = sum(1 for f in media_files if f['type'] == 'video')
        image_count = sum(1 for f in media_files if f['type'] == 'image')

        return {
            'media_count': len(media_files),
            'video_count': video_count,
            'image_count': image_count,
            'total_size_mb': total_size_mb,
            'free_space_mb': free_space_mb,
            'largest_files': media_files[:3]
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při analýze disku: {e}", xbmc.LOGERROR)
        return None


# ======= FTP FUNKCE =======

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url, timeout=10) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def fetch_expected_file(device_id):
    """Získá očekávaný soubor z API - nejprve zkontroluje device override, pak locality."""
    if not device_id:
        return None, None

    # Přidat boot_time pro detekci restartu - API vymaže UserInitiatedPlayback při změně boot_time
    boot_time = get_boot_time()
    boot_param = f"&boot_time={urllib.parse.quote(boot_time)}" if boot_time else ""
    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file?apikey={API_KEY}{boot_param}"
    try:
        with urllib.request.urlopen(api_url, timeout=10) as response:
            data = json.loads(response.read().decode())
            filename = data.get("filename")
            source = data.get("source")

            if filename:
                xbmc.log(f"[Dohled] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
                return filename, source
            return None, None
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání očekávaného souboru: {e}", xbmc.LOGWARNING)
        return None, None


def get_remote_file_info(host, user, password, path, filename):
    """Získá datum poslední úpravy a velikost souboru na FTP serveru."""
    try:
        xbmc.log(f"[Dohled] Připojuji se k FTP serveru {host}...", xbmc.LOGINFO)

        ftp = FTP(host, timeout=30)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")

        try:
            size = ftp.size(path + filename)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání velikosti souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        try:
            modified_time = ftp.sendcmd("MDTM " + path + filename)[4:].strip()
            remote_timestamp = time.mktime(datetime.strptime(modified_time, "%Y%m%d%H%M%S").timetuple())
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání data úpravy souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        ftp.quit()
        xbmc.log(f"[Dohled] FTP info: velikost {size/1024/1024:.1f}MB", xbmc.LOGINFO)
        return remote_timestamp, size

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba FTP při připojení k {host}: {e}", xbmc.LOGERROR)
        return None, None


def get_local_file_info(path):
    """Získá datum poslední úpravy a velikost lokálního souboru."""
    if os.path.exists(path):
        return os.path.getmtime(path), os.path.getsize(path)
    return 0, 0


def download_file_ftp(host, user, password, path, filename, local_path):
    """Stáhne soubor z FTP s kontrolou místa na disku."""
    try:
        ftp = FTP(host, timeout=30)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        remote_size = ftp.size(path + filename)
        ftp.quit()

        remote_size_mb = remote_size / (1024 * 1024)
        free_space_mb = get_disk_space_mb(VIDEO_DIR)

        if free_space_mb < remote_size_mb + MIN_FREE_SPACE_MB:
            xbmc.log(f"[Dohled] Nedostatek místa, spouštím cleanup", xbmc.LOGWARNING)
            cleanup_old_media(os.path.basename(local_path), remote_size_mb)

        temp_path = local_path + "_tmp"
        xbmc.log(f"[Dohled] Stahuji {filename}...", xbmc.LOGINFO)

        with open(temp_path, "wb") as out_file:
            ftp = FTP(host, timeout=30)
            ftp.login(user, password)
            ftp.voidcmd("TYPE I")

            downloaded = 0

            def write_block(block):
                nonlocal downloaded
                out_file.write(block)
                downloaded += len(block)

            ftp.retrbinary("RETR " + path + filename, write_block, blocksize=1024*1024)
            ftp.quit()

        if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
            shutil.move(temp_path, local_path)
            xbmc.log(f"[Dohled] Soubor {filename} úspěšně stažen ({remote_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Aktualizovat last_filename
            try:
                with open(LAST_FILENAME_FILE, "w", encoding="utf-8") as f:
                    f.write(filename)
            except:
                pass

            return True
        else:
            raise ValueError("Stažený soubor je prázdný!")

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při stahování z FTP: {e}", xbmc.LOGERROR)
        temp_path = local_path + "_tmp"
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass
        return False


# ======= PLAYLIST PARSING =======

def parse_playlist_item(item, default_duration=10):
    """Parsuje položku playlistu ve formátu 'soubor' nebo 'soubor:sekundy'."""
    item = item.strip()
    if not item:
        return None

    if ':' in item:
        parts = item.rsplit(':', 1)
        if len(parts) == 2 and parts[1].isdigit():
            return {'filename': parts[0], 'duration': int(parts[1])}

    return {'filename': item, 'duration': None}


def parse_playlist_string(playlist_str, default_duration=10):
    """Parsuje celý playlist string."""
    items = []
    for item in playlist_str.split(','):
        parsed = parse_playlist_item(item, default_duration)
        if parsed:
            items.append(parsed)
    return items


# ======= PŘEHRÁVÁNÍ MÉDIÍ =======

def dismiss_image():
    """Zavře zobrazený obrázek pro přechod na jiný obrázek.

    Používá Dialog.Close, ale NEJDE na home screen - pro image-to-image přechody.
    """
    global current_displayed_image

    if current_displayed_image is None:
        return False

    xbmc.log(f"[Dohled] Dismiss obrázek pro přechod: {current_displayed_image}", xbmc.LOGINFO)

    # Dialog.Close zavře picture viewer
    xbmc.executebuiltin('Dialog.Close(all,true)')
    time.sleep(0.15)

    # Nemazat current_displayed_image - bude nastaven nový obrázek
    return True


def close_image_viewer():
    """Spolehlivě zavře obrázek zobrazený přes ShowPicture.

    Action(Back) nefunguje spolehlivě, proto používáme kombinaci příkazů.
    Používat pro přechod z obrázku na VIDEO nebo při úplném zastavení.
    """
    global current_displayed_image

    if current_displayed_image is None:
        return False

    xbmc.log(f"[Dohled] Zavírám obrázek (pro video/stop): {current_displayed_image}", xbmc.LOGINFO)

    # Kombinace příkazů pro spolehlivé zavření
    xbmc.executebuiltin('Dialog.Close(all,true)')
    time.sleep(0.1)
    xbmc.executebuiltin('Action(Stop)')
    time.sleep(0.1)
    xbmc.executebuiltin('ActivateWindow(home)')
    time.sleep(0.2)

    current_displayed_image = None
    return True


def RepeatVideo(local_file):
    """Spustí přehrávání videa ve smyčce."""
    global current_displayed_image

    filename = os.path.basename(local_file)
    player = xbmc.Player()

    # Pokud je zobrazen obrázek, musíme ho NEJDŘÍVE zavřít
    if current_displayed_image:
        xbmc.log(f"[Dohled] Přechod obrázek→video: {current_displayed_image} → {filename}", xbmc.LOGINFO)
        close_image_viewer()  # Použít spolehlivou funkci

    # Spustit video
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(local_file)
    player.play(playlist)

    xbmc.executebuiltin("PlayerControl(RepeatOne)")
    xbmc.log(f"[Dohled] Přehrávám video ve smyčce: {filename}", xbmc.LOGINFO)

    # Okamžité odeslání stavu na dashboard
    send_immediate_state_update(filename, playing=True, paused=False)


def ShowImage(image_path, display_time=None, _retry_count=0):
    """
    Zobrazí jeden obrázek s detekcí černé obrazovky a auto-opravou.

    Args:
        image_path: Cesta k obrázku
        display_time: Nepoužito (pro kompatibilitu)
        _retry_count: Interní počítadlo pokusů (nepoužívat přímo)

    Returns:
        bool: True pokud se obrázek zobrazil, False při selhání
    """
    global current_displayed_image

    if not os.path.exists(image_path):
        xbmc.log(f"[Dohled] Obrázek nenalezen: {image_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(image_path)
    player = xbmc.Player()
    was_playing_video = player.isPlayingVideo()

    # Zobrazit obrázek
    if was_playing_video:
        xbmc.log(f"[Dohled] Přechod video→obrázek: → {filename}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ShowPicture({image_path})')
        current_displayed_image = filename
        time.sleep(0.2)
        player.stop()
    else:
        xbmc.log(f"[Dohled] Zobrazuji obrázek: {filename}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'ShowPicture({image_path})')
        current_displayed_image = filename

    # Počkat a ověřit zobrazení
    time.sleep(BLACK_SCREEN_VERIFY_DELAY)

    if not verify_image_displayed():
        # ČERNÁ OBRAZOVKA DETEKOVÁNA!
        xbmc.log(f"[Dohled] ČERNÁ OBRAZOVKA detekována: {filename} (pokus {_retry_count + 1})", xbmc.LOGERROR)

        if _retry_count < BLACK_SCREEN_MAX_RETRIES:
            # Pokus o opravu - vyčistit cache a zkusit znovu
            xbmc.log(f"[Dohled] Čistím texture cache pro: {filename}", xbmc.LOGINFO)
            clear_image_from_texture_cache(image_path)

            # Krátká pauza před dalším pokusem
            time.sleep(0.3)

            # Rekurzivní pokus
            return ShowImage(image_path, display_time, _retry_count + 1)
        else:
            # Všechny pokusy selhaly
            xbmc.log(f"[Dohled] Všechny pokusy selhaly pro: {filename}", xbmc.LOGERROR)
            current_displayed_image = None
            return False

    # Úspěch - obrázek se zobrazil
    if _retry_count > 0:
        xbmc.log(f"[Dohled] Obrázek zobrazen po {_retry_count + 1} pokusech: {filename}", xbmc.LOGINFO)

    # Okamžité odeslání stavu na dashboard
    time.sleep(0.2)
    send_immediate_state_update(filename, playing=True, paused=False)
    return True


def play_media_file(file_path, image_display_time=DEFAULT_IMAGE_DISPLAY_TIME):
    """Přehraje soubor podle jeho typu - video nebo obrázek."""
    if not os.path.exists(file_path):
        xbmc.log(f"[Dohled] Soubor neexistuje: {file_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(file_path)
    media_type = get_media_type(filename)

    if media_type == 'video':
        RepeatVideo(file_path)
        return True
    elif media_type == 'image':
        return ShowImage(file_path, display_time=None)
    else:
        xbmc.log(f"[Dohled] Nepodporovaný typ souboru: {filename}", xbmc.LOGERROR)
        return False


# ======= RESTART SCHEDULING =======

def get_last_reboot_date():
    """Přečte datum posledního restartu z REBOOT_TRACK_FILE."""
    if os.path.exists(REBOOT_TRACK_FILE):
        try:
            with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if lines:
                    first_line = lines[0].strip()
                    if first_line.startswith("Poslední restart:"):
                        return first_line.replace("Poslední restart:", "").strip()
        except:
            pass
    return "Žádný"


def save_planned_reboot(last_reboot_date, planned_time_str):
    """Uloží naplánovaný restart do souboru."""
    try:
        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {last_reboot_date}\n")
            f.write(f"Naplánovaný restart: {planned_time_str}\n")
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při ukládání plánovaného restartu: {e}", xbmc.LOGERROR)


def schedule_random_reboot():
    """Naplánuje náhodný restart mezi 21:00 a 5:00 v samostatném vlákně."""
    global stop_monitoring

    def reboot_task():
        monitor = xbmc.Monitor()
        now = datetime.now()
        last_reboot_date = get_last_reboot_date()

        # Určit restart okno podle aktuálního času:
        # - Před 05:00: Jsme v "noční" části okna (včera 21:00 - dnes 05:00)
        #   → Plánovat na DALŠÍ okno (dnes 21:00 - zítra 05:00)
        # - 05:00 až 21:00: Jsme mimo okno
        #   → Plánovat na dnešní noc (dnes 21:00 - zítra 05:00)
        # - Po 21:00: Jsme na začátku okna
        #   → Plánovat na toto okno (dnes 21:00 - zítra 05:00)

        if now.hour < 5:
            # Před 05:00 - restart v tomto okně už proběhl (proto zařízení bootuje)
            # Plánovat na DNEŠNÍ NOC (dnes 21:00 - zítra 05:00)
            start_time = now.replace(hour=21, minute=0, second=0, microsecond=0)
            end_time = (now + timedelta(days=1)).replace(hour=4, minute=59, second=59, microsecond=0)
            xbmc.log(f"[Dohled] Boot před 05:00, plánuji restart na dnešní noc (21:00-05:00)", xbmc.LOGINFO)
        elif now.hour >= 21:
            # Po 21:00 - jsme v aktuálním okně, plánovat sem
            start_time = now.replace(hour=21, minute=0, second=0, microsecond=0)
            end_time = (now + timedelta(days=1)).replace(hour=4, minute=59, second=59, microsecond=0)
            xbmc.log(f"[Dohled] Po 21:00, plánuji restart na tuto noc", xbmc.LOGINFO)
        else:
            # Mezi 05:00 a 21:00 - plánovat na dnešní noc
            start_time = now.replace(hour=21, minute=0, second=0, microsecond=0)
            end_time = (now + timedelta(days=1)).replace(hour=4, minute=59, second=59, microsecond=0)
            xbmc.log(f"[Dohled] Mezi 05:00-21:00, plánuji restart na dnešní noc", xbmc.LOGINFO)

        # Vygenerovat náhodný čas restartu (musí být v budoucnosti)
        max_attempts = 100
        for _ in range(max_attempts):
            random_reboot_time = start_time + timedelta(minutes=random.randint(0, int((end_time - start_time).total_seconds() / 60)))
            if random_reboot_time > now:
                break
        else:
            # Všechny časy v okně jsou v minulosti - tohle by nemělo nastat
            xbmc.log(f"[Dohled] CHYBA: Nepodařilo se najít platný čas restartu", xbmc.LOGERROR)
            return

        restart_date_time = random_reboot_time.strftime('%Y-%m-%d %H:%M:%S')

        # Uložit plánovaný restart
        save_planned_reboot(last_reboot_date, restart_date_time)

        xbmc.log(f"[Dohled] Naplánovaný restart: {restart_date_time}", xbmc.LOGINFO)

        # Čekat do naplánovaného času - použít waitForAbort pro rychlé ukončení
        # Místo jednoho dlouhého spánku čekáme po minutových intervalech
        wait_seconds = (random_reboot_time - datetime.now()).total_seconds()
        while wait_seconds > 0 and not stop_monitoring and not monitor.abortRequested():
            # Čekat max 60 sekund, pak zkontrolovat znovu
            sleep_time = min(60, wait_seconds)
            if monitor.waitForAbort(sleep_time):
                xbmc.log("[Dohled] Plánovaný restart zrušen (Kodi se vypíná)", xbmc.LOGINFO)
                return
            wait_seconds = (random_reboot_time - datetime.now()).total_seconds()

        # Pokud byl addon zastaven, neprovádět restart
        if stop_monitoring or monitor.abortRequested():
            xbmc.log("[Dohled] Plánovaný restart zrušen (addon se vypíná)", xbmc.LOGINFO)
            return

        # Použít mark_reboot() pro spolehlivý záznam
        xbmc.log("[Dohled] Provádím naplánovaný restart zařízení...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Restart", "Zařízení se nyní restartuje", xbmcgui.NOTIFICATION_WARNING)
        mark_reboot("scheduled")
        xbmc.executebuiltin("Reboot")

    threading.Thread(target=reboot_task, daemon=True).start()


# ======= FALLBACK FUNKCE =======

def find_best_fallback_file():
    """Najde nejlepší fallback soubor."""
    try:
        if os.path.exists(LAST_FILENAME_FILE):
            with open(LAST_FILENAME_FILE, encoding="utf-8") as f:
                last_file = f.read().strip()
                possible = get_local_media_path(last_file)
                if possible and os.path.exists(possible):
                    xbmc.log(f"[Dohled] Fallback z last_filename: {possible}", xbmc.LOGINFO)
                    return possible

        # Hledat v obou adresářích (VIDEO_DIR a IMAGE_DIR)
        media_files = []
        for media_dir in [VIDEO_DIR, IMAGE_DIR]:
            if os.path.exists(media_dir):
                for filename in os.listdir(media_dir):
                    if is_supported_file(filename):
                        filepath = os.path.join(media_dir, filename)
                        mtime = os.path.getmtime(filepath)
                        media_files.append((filepath, mtime, get_media_type(filename)))

        if media_files:
            media_files.sort(key=lambda x: (x[2] != 'video', -x[1]))
            xbmc.log(f"[Dohled] Fallback nejnovější: {media_files[0][0]}", xbmc.LOGINFO)
            return media_files[0][0]

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání fallback souboru: {e}", xbmc.LOGERROR)

    return None


def get_best_available_file(preferred_file):
    """Najde nejlepší dostupný soubor pro přehrání."""
    if preferred_file and os.path.exists(preferred_file) and os.path.getsize(preferred_file) > 0:
        return preferred_file

    fallback_file = find_best_fallback_file()
    if fallback_file and os.path.exists(fallback_file) and os.path.getsize(fallback_file) > 0:
        return fallback_file

    try:
        if os.path.exists("/storage/videos/"):
            for filename in os.listdir("/storage/videos/"):
                if is_supported_file(filename):
                    filepath = os.path.join("/storage/videos/", filename)
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        xbmc.log(f"[Dohled] Nouzový soubor: {filepath}", xbmc.LOGWARNING)
                        return filepath
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání nouzového souboru: {e}", xbmc.LOGERROR)

    return None


# Globální stav WebSocket spojení
ws_connected = False
ws_app = None
ws_thread = None

# Globální stav pro detekci změn (rychlé aktualizace)
last_playing_state = None
last_playing_true_time = None  # Čas kdy bylo naposledy playing=True (pro debouncing)
last_paused_state = None
last_filename = None

# Globální stav pro mixed playlist playback
# Používáme playlist_id místo stop_flag pro spolehlivé zastavení předchozího playlistu
current_playlist_id = 0
mixed_playlist_thread = None
# Globální proměnné pro sledování celého playlistu (včetně obrázků)
current_mixed_playlist = []  # Seznam názvů souborů v aktuálním playlistu
current_mixed_playlist_position = -1  # Aktuální pozice v mixed playlistu


class WebSocketClient:
    """WebSocket klient pro real-time komunikaci s API serverem."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.ws = None
        self.connected = False
        self.should_reconnect = True
        self.last_monitoring_time = 0

    def on_message(self, ws, message):
        """Zpracování příchozí zprávy ze serveru."""
        try:
            data = json.loads(message)
            msg_type = data.get("type")

            xbmc.log(f"[Dohled WS] Přijata zpráva typu: {msg_type}", xbmc.LOGINFO)

            if msg_type == "command":
                # Okamžité zpracování příkazu!
                command = data.get("command")
                params = data.get("params", {})
                if command:
                    xbmc.log(f"[Dohled WS] Příkaz: {command}, params: {params}", xbmc.LOGINFO)
                    execute_command(command, params)

            elif msg_type == "ping":
                # Odpovědět na ping
                self.send_pong()

            elif msg_type == "welcome":
                # KRITICKÉ: Teprve zde nastavujeme ws_connected = True
                # Toto je potvrzení že server nás skutečně přijal a zařadil do active_connections
                global ws_connected
                ws_connected = True
                xbmc.log(f"[Dohled WS] Server potvrdil spojení! device_id={data.get('device_id')}", xbmc.LOGINFO)

            elif msg_type == "ack":
                xbmc.log(f"[Dohled WS] Server potvrdil monitoring data", xbmc.LOGINFO)

        except json.JSONDecodeError:
            xbmc.log(f"[Dohled WS] Neplatná JSON zpráva: {message[:100]}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba zpracování zprávy: {e}", xbmc.LOGERROR)

    def on_error(self, ws, error):
        """Zpracování chyby WebSocket."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Chyba: {error}", xbmc.LOGERROR)
        self.connected = False
        ws_connected = False  # Povolit HTTP fallback

    def on_close(self, ws, close_status_code, close_msg):
        """Zpracování uzavření spojení."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Spojení uzavřeno: {close_status_code} - {close_msg}", xbmc.LOGWARNING)
        self.connected = False
        ws_connected = False

        if self.should_reconnect:
            xbmc.log(f"[Dohled WS] Pokus o reconnect za {WS_RECONNECT_INTERVAL}s...", xbmc.LOGINFO)

    def on_open(self, ws):
        """Zpracování navázání spojení - čekáme na welcome zprávu ze serveru."""
        # DŮLEŽITÉ: Nenastavujeme ws_connected = True zde!
        # Čekáme na welcome zprávu ze serveru jako potvrzení že je spojení skutečně funkční
        xbmc.log("[Dohled WS] TCP spojení navázáno, čekám na welcome zprávu ze serveru...", xbmc.LOGINFO)
        self.connected = True  # Lokální flag pro send_json
        # ws_connected = True se nastaví až po přijetí welcome zprávy

        # Odeslat identifikaci
        self.send_json({
            "type": "identify",
            "device_id": self.device_id
        })

    def send_json(self, data):
        """Odeslání JSON zprávy přes WebSocket."""
        if self.ws and self.connected:
            try:
                self.ws.send(json.dumps(data))
                return True
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba při odesílání: {e}", xbmc.LOGERROR)
                self.connected = False
        return False

    def send_pong(self):
        """Odpověď na ping."""
        self.send_json({"type": "pong"})

    def send_monitoring(self, payload):
        """Odeslání monitoring dat přes WebSocket."""
        return self.send_json({
            "type": "monitoring",
            "payload": payload
        })

    def connect(self):
        """Navázání WebSocket spojení."""
        global ws_app, ws_connected

        url = f"{WS_URL}{self.device_id}"
        xbmc.log(f"[Dohled WS] Připojuji se k: {url}", xbmc.LOGINFO)

        try:
            # Nastavení SSL kontextu (pro self-signed certifikáty)
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

            self.ws = websocket.WebSocketApp(
                url,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close,
                on_open=self.on_open
            )
            ws_app = self.ws

            # Spustit WebSocket v blokovacím režimu (v samostatném vlákně)
            self.ws.run_forever(
                sslopt={"cert_reqs": ssl.CERT_NONE, "check_hostname": False},
                ping_interval=WS_PING_INTERVAL,
                ping_timeout=10
            )

        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba při připojování: {e}", xbmc.LOGERROR)
            self.connected = False
            ws_connected = False  # Povolit reconnect

    def disconnect(self):
        """Ukončení WebSocket spojení."""
        self.should_reconnect = False
        if self.ws:
            try:
                self.ws.close()
            except:
                pass


def ws_connection_loop(device_id):
    """Smyčka pro udržování WebSocket spojení."""
    global stop_monitoring, ws_connected

    if not WEBSOCKET_AVAILABLE:
        xbmc.log("[Dohled WS] WebSocket knihovna není dostupná, použije se HTTP", xbmc.LOGWARNING)
        return

    xbmc.log("[Dohled WS] Spouštím WebSocket connection loop", xbmc.LOGINFO)

    ws_client = WebSocketClient(device_id)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        if not ws_connected:
            try:
                ws_client.connect()
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba v connection loop: {e}", xbmc.LOGERROR)

        # Čekat před dalším pokusem o reconnect - použít waitForAbort místo time.sleep!
        # waitForAbort se okamžitě vrátí pokud Kodi požaduje ukončení
        if monitor.waitForAbort(WS_RECONNECT_INTERVAL):
            break
        if stop_monitoring:
            break

    ws_client.disconnect()
    xbmc.log("[Dohled WS] Connection loop ukončen", xbmc.LOGINFO)


# České NTP servery (seřazené podle priority)
CZ_NTP_SERVERS = [
    "antispam.oresi.cz",  # ORESI interní server
    "tik.cesnet.cz",      # CESNET stratum 1
    "tak.cesnet.cz",      # CESNET stratum 1
    "ntp.nic.cz",         # CZ.NIC stratum 1
    "ntp.cesnet.cz",      # CESNET
    "0.cz.pool.ntp.org",  # Czech NTP pool
    "1.cz.pool.ntp.org",
]

# České HTTP servery pro fallback (bez HTTPS - aby fungoval i při špatném čase)
CZ_HTTP_SERVERS = [
    "http://www.seznam.cz",
    "http://www.novinky.cz",
    "http://www.idnes.cz",
    "http://www.centrum.cz",
]

# Minimální platný rok pro kontrolu času
MIN_VALID_YEAR = 2024

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Maximální doba čekání na síť (v sekundách)
NETWORK_WAIT_TIMEOUT = 30

# KRITICKÉ: Okamžitě smazat starý sync flag při načtení modulu
# Toto musí proběhnout PŘED spuštěním doplňku Smycky
try:
    if os.path.exists(TIME_SYNC_FILE):
        os.remove(TIME_SYNC_FILE)
        xbmc.log("[Dohled] Okamžitě odstraněn starý sync flag při startu", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)

# ======= SYNCHRONIZACE ČASU =======

def wait_for_network(timeout=NETWORK_WAIT_TIMEOUT):
    """Čeká na dostupnost sítě (WiFi může trvat déle)."""
    xbmc.log("[Dohled] Čekám na dostupnost sítě...", xbmc.LOGINFO)

    waited = 0
    while waited < timeout:
        try:
            # Zkusit připojení na Google DNS (IP bez DNS resolvingu)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            xbmc.log(f"[Dohled] Síť dostupná po {waited}s", xbmc.LOGINFO)
            return True
        except:
            pass

        time.sleep(1)
        waited += 1

        # Informovat každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Dohled] Stále čekám na síť... ({waited}s)", xbmc.LOGINFO)

    xbmc.log(f"[Dohled] Timeout čekání na síť ({timeout}s)", xbmc.LOGWARNING)
    return False



def is_time_valid():
    """Zkontroluje, zda je systémový čas platný (rok >= MIN_VALID_YEAR)."""
    current_year = datetime.now().year
    is_valid = current_year >= MIN_VALID_YEAR
    xbmc.log(f"[Dohled] Kontrola času: rok {current_year}, platný: {is_valid}", xbmc.LOGINFO)
    return is_valid


def sync_time_ntp(timeout=5):
    """Pokusí se synchronizovat čas přes NTP pomocí ntpd."""
    for server in CZ_NTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o NTP sync: {server}", xbmc.LOGINFO)
            # ntpd -n -q = nedaemonizovat, ukončit po sync
            result = subprocess.run(
                ["ntpd", "-n", "-q", "-p", server],
                timeout=timeout,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                xbmc.log(f"[Dohled] NTP synchronizace úspěšná: {server}", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"[Dohled] NTP {server} selhalo: {result.stderr}", xbmc.LOGWARNING)
        except subprocess.TimeoutExpired:
            xbmc.log(f"[Dohled] NTP {server} timeout po {timeout}s", xbmc.LOGWARNING)
        except FileNotFoundError:
            xbmc.log("[Dohled] ntpd není dostupný, přeskakuji NTP", xbmc.LOGWARNING)
            return False
        except Exception as e:
            xbmc.log(f"[Dohled] NTP {server} chyba: {e}", xbmc.LOGERROR)
    return False


def sync_time_http(timeout=5):
    """Fallback: získá čas z HTTP Date hlavičky českých serverů."""
    for url in CZ_HTTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o HTTP time sync: {url}", xbmc.LOGINFO)

            # HTTP požadavek (bez SSL - funguje i při špatném systémovém čase)
            req = urllib.request.Request(url, method='HEAD')
            req.add_header('User-Agent', 'Mozilla/5.0')

            with urllib.request.urlopen(req, timeout=timeout) as response:
                date_header = response.headers.get('Date')
                if date_header:
                    # Parsování RFC 2822 data z hlavičky
                    server_time = parsedate_to_datetime(date_header)
                    # Formát pro Linux date příkaz
                    time_str = server_time.strftime("%Y-%m-%d %H:%M:%S")

                    xbmc.log(f"[Dohled] HTTP čas ze serveru: {time_str}", xbmc.LOGINFO)

                    # Nastavení systémového času
                    result = subprocess.run(
                        ["date", "--set", time_str],
                        capture_output=True,
                        text=True
                    )

                    if result.returncode == 0:
                        xbmc.log(f"[Dohled] Systémový čas nastaven na: {time_str}", xbmc.LOGINFO)
                        return True
                    else:
                        xbmc.log(f"[Dohled] Chyba nastavení času: {result.stderr}", xbmc.LOGERROR)
                else:
                    xbmc.log(f"[Dohled] {url} nevrátil Date hlavičku", xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log(f"[Dohled] HTTP sync {url} chyba: {e}", xbmc.LOGERROR)

    return False


def create_time_sync_flag():
    """Vytvoří signalizační soubor o úspěšné synchronizaci času."""
    try:
        sync_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(TIME_SYNC_FILE, "w") as f:
            f.write(sync_time_str)
        xbmc.log(f"[Dohled] Vytvořen sync flag: {TIME_SYNC_FILE}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vytváření sync flagu: {e}", xbmc.LOGERROR)


def remove_time_sync_flag():
    """Odstraní signalizační soubor (volá se při startu)."""
    try:
        if os.path.exists(TIME_SYNC_FILE):
            os.remove(TIME_SYNC_FILE)
            xbmc.log(f"[Dohled] Odstraněn starý sync flag", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)


def ensure_time_synchronized():
    """Zajistí synchronizaci času - hlavní funkce volaná při startu."""
    xbmc.log("[Dohled] === Zahajuji kontrolu a synchronizaci času ===", xbmc.LOGINFO)

    # Vždy odstranit starý flag při startu
    remove_time_sync_flag()

    # PRVNÍ: Počkat na síť (WiFi může trvat déle)
    if not wait_for_network():
        xbmc.log("[Dohled] Síť nedostupná, pokračuji bez synchronizace", xbmc.LOGWARNING)
        create_time_sync_flag()
        return False

    # Kontrola, zda je čas již platný
    if is_time_valid():
        xbmc.log("[Dohled] Systémový čas je již platný, sync není potřeba", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    xbmc.log("[Dohled] Systémový čas je neplatný, spouštím synchronizaci", xbmc.LOGWARNING)

    # Pokus 1: NTP (nejpřesnější)
    if sync_time_ntp(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes NTP", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    # Pokus 2: HTTP fallback
    xbmc.log("[Dohled] NTP selhalo, zkouším HTTP fallback", xbmc.LOGWARNING)
    if sync_time_http(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes HTTP", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    # Synchronizace selhala
    xbmc.log("[Dohled] KRITICKÉ: Synchronizace času selhala!", xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        "Chyba synchronizace",
        "Nepodařilo se synchronizovat čas!",
        xbmcgui.NOTIFICATION_ERROR,
        5000
    )

    # I při selhání vytvoříme flag, aby smyčky mohly pokračovat (s rizikem)
    # Lepší než aby se smyčky vůbec nespustily
    create_time_sync_flag()
    return False

# Odstranění blokujících update_rules z Kodi databáze
def fix_addon_update_rules():
    """
    Odstraní záznamy z tabulky update_rules v Kodi Addons databázi,
    které blokují aktualizace service.dohled a repository.noreason.

    Kodi update_rules hodnoty:
    - 0 = Auto-update (podle globálního nastavení)
    - 1 = Pouze notifikovat
    - 2 = Připnuto na aktuální verzi (NIKDY neaktualizovat)

    Pokud je addon "připnutý" (hodnota 2), aktualizace se nikdy neprovede.
    Tato funkce smaže tyto blokující záznamy.
    """
    try:
        import glob
        import sqlite3

        # Najít Addons databázi
        db_pattern = "/storage/.kodi/userdata/Database/Addons*.db"
        db_files = glob.glob(db_pattern)

        if not db_files:
            xbmc.log("[Dohled] Addons databáze nenalezena", xbmc.LOGWARNING)
            return False

        db_path = db_files[0]  # Použít první nalezenou
        xbmc.log(f"[Dohled] Kontroluji update_rules v {db_path}", xbmc.LOGINFO)

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Zkontrolovat existující pravidla
        cursor.execute("SELECT addonID, updateRule FROM update_rules WHERE addonID IN ('service.dohled', 'repository.noreason', 'service.smycky')")
        blocking_rules = cursor.fetchall()

        if blocking_rules:
            for addon_id, rule in blocking_rules:
                if rule == 2:  # Připnuto = blokuje aktualizace
                    xbmc.log(f"[Dohled] Addon {addon_id} má update_rule=2 (připnuto), odstraňuji", xbmc.LOGWARNING)

            # Smazat blokující pravidla
            cursor.execute("DELETE FROM update_rules WHERE addonID IN ('service.dohled', 'repository.noreason', 'service.smycky')")
            conn.commit()
            xbmc.log(f"[Dohled] Odstraněno {len(blocking_rules)} blokujících update pravidel", xbmc.LOGINFO)
            conn.close()
            return True
        else:
            xbmc.log("[Dohled] Žádná blokující update pravidla nenalezena", xbmc.LOGINFO)
            conn.close()
            return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při opravě update_rules: {e}", xbmc.LOGERROR)
        return False


def fix_addons_updatemode_setting():
    """
    Opraví nastavení addons.updatemode v guisettings.xml.

    Toto nastavení může blokovat aktualizace pokud má default="true".
    Hodnoty:
    - 0 = Automaticky instalovat aktualizace
    - 1 = Pouze notifikovat
    - 2 = Nikdy nekontrolovat
    """
    try:
        guisettings_path = "/storage/.kodi/userdata/guisettings.xml"

        if not os.path.exists(guisettings_path):
            return False

        with open(guisettings_path, 'r', encoding='utf-8') as f:
            content = f.read()

        needs_update = False
        new_content = content

        # Opravit default="true" na default="false" pro addons.updatemode
        if 'id="addons.updatemode"' in content and 'default="true"' in content:
            match = re.search(r'<setting id="addons\.updatemode"[^>]*default="true"', content)
            if match:
                new_content = re.sub(
                    r'(<setting id="addons\.updatemode"[^>]*) default="true"',
                    r'\1 default="false"',
                    new_content
                )
                needs_update = True
                xbmc.log('[Dohled] Opravuji addons.updatemode default="true" -> default="false"', xbmc.LOGWARNING)

        if needs_update:
            with open(guisettings_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            return True

        return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při opravě addons.updatemode: {e}", xbmc.LOGERROR)
        return False


def force_self_update_if_needed():
    """
    Zkontroluje jestli je dostupná novější verze service.dohled v repozitáři
    a pokud ano, provede manuální aktualizaci (obejde Kodi update systém).

    Toto řeší situace kdy:
    - Kodi update systém nefunguje správně
    - Addon má špatný origin v databázi
    - Jsou blokující update_rules
    - general.addonupdates nebo addons.updatemode mají špatné nastavení

    DŮLEŽITÉ: Zachovává origin v databázi pro budoucí automatické aktualizace.
    """
    try:
        import glob
        import zipfile
        import tempfile

        xbmc.log("[Dohled] Kontroluji dostupnost novější verze...", xbmc.LOGINFO)

        # 1. Získat aktuální nainstalovanou verzi
        addon = xbmcaddon.Addon()
        current_version = addon.getAddonInfo('version')
        xbmc.log(f"[Dohled] Aktuální verze: {current_version}", xbmc.LOGINFO)

        # 2. Zjistit dostupnou verzi z Kodi databáze
        db_pattern = "/storage/.kodi/userdata/Database/Addons*.db"
        db_files = glob.glob(db_pattern)

        if not db_files:
            xbmc.log("[Dohled] Addons databáze nenalezena", xbmc.LOGWARNING)
            return False

        db_path = db_files[0]
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Získat dostupnou verzi a URL pro stažení
        cursor.execute("""
            SELECT version, json_extract(metadata, '$.path') as download_url
            FROM addons
            WHERE addonID = 'service.dohled'
            ORDER BY version DESC
            LIMIT 1
        """)
        result = cursor.fetchone()

        if not result:
            xbmc.log("[Dohled] Informace o service.dohled nenalezeny v databázi", xbmc.LOGWARNING)
            conn.close()
            return False

        available_version, download_url = result
        xbmc.log(f"[Dohled] Dostupná verze: {available_version}, URL: {download_url}", xbmc.LOGINFO)

        # 3. Porovnat verze
        def parse_version(v):
            return tuple(map(int, v.split('.')))

        if parse_version(available_version) <= parse_version(current_version):
            xbmc.log(f"[Dohled] Již máme aktuální nebo novější verzi ({current_version} >= {available_version})", xbmc.LOGINFO)
            conn.close()
            return False

        xbmc.log(f"[Dohled] NALEZENA NOVĚJŠÍ VERZE: {available_version} > {current_version}", xbmc.LOGWARNING)

        # 4. Stáhnout ZIP
        xbmc.log(f"[Dohled] Stahuji aktualizaci z: {download_url}", xbmc.LOGINFO)

        temp_zip = "/storage/.kodi/temp/service.dohled_update.zip"
        try:
            # Timeout 60s pro pomalé sítě
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

            req = urllib.request.Request(download_url)
            req.add_header('User-Agent', 'Kodi-Addon-Updater/1.0')

            with urllib.request.urlopen(req, timeout=60, context=ssl_context) as response:
                with open(temp_zip, 'wb') as f:
                    f.write(response.read())

            xbmc.log(f"[Dohled] ZIP stažen: {os.path.getsize(temp_zip)} bajtů", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při stahování ZIP: {e}", xbmc.LOGERROR)
            conn.close()
            return False

        # 5. Extrahovat ZIP
        addons_dir = "/storage/.kodi/addons"
        addon_dir = os.path.join(addons_dir, "service.dohled")
        backup_dir = addon_dir + ".backup"

        try:
            # Vytvořit zálohu
            if os.path.exists(addon_dir):
                if os.path.exists(backup_dir):
                    shutil.rmtree(backup_dir)
                shutil.move(addon_dir, backup_dir)
                xbmc.log("[Dohled] Vytvořena záloha starého addonu", xbmc.LOGINFO)

            # Extrahovat
            with zipfile.ZipFile(temp_zip, 'r') as zf:
                zf.extractall(addons_dir)

            # ZIP vytváří složku s názvem service.dohled-X.X.X, přejmenovat
            extracted_dirs = glob.glob(os.path.join(addons_dir, "service.dohled-*"))
            if extracted_dirs:
                extracted_dir = extracted_dirs[0]
                if os.path.exists(addon_dir):
                    shutil.rmtree(addon_dir)
                shutil.move(extracted_dir, addon_dir)
                xbmc.log(f"[Dohled] Addon extrahován a přejmenován: {extracted_dir} -> {addon_dir}", xbmc.LOGINFO)

            # Smazat zálohu a temp soubory
            if os.path.exists(backup_dir):
                shutil.rmtree(backup_dir)
            if os.path.exists(temp_zip):
                os.remove(temp_zip)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při extrakci: {e}", xbmc.LOGERROR)
            # Obnovit zálohu
            if os.path.exists(backup_dir) and not os.path.exists(addon_dir):
                shutil.move(backup_dir, addon_dir)
            conn.close()
            return False

        # 6. Aktualizovat databázi - timestamp
        try:
            cursor.execute("""
                UPDATE installed
                SET lastUpdated = datetime('now')
                WHERE addonID = 'service.dohled'
            """)
            conn.commit()
            xbmc.log("[Dohled] Databáze aktualizována", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při aktualizaci databáze: {e}", xbmc.LOGWARNING)

        conn.close()

        # 7. Notifikovat uživatele a restartovat Kodi
        xbmc.log(f"[Dohled] AKTUALIZACE DOKONČENA: {current_version} -> {available_version}", xbmc.LOGWARNING)
        xbmc.executebuiltin('Notification(Dohled,Aktualizace na verzi ' + available_version + ' dokončena. Restartuje se...,5000)')

        # Počkat na zobrazení notifikace a restartovat Kodi
        time.sleep(3)
        xbmc.executebuiltin('RestartApp')

        return True

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při self-update: {e}", xbmc.LOGERROR)
        return False


# Zajištění že auto-update je zapnutý
def ensure_addon_autoupdate_enabled():
    """
    Zkontroluje a případně opraví nastavení automatických aktualizací doplňků.

    Kodi nastavení general.addonupdates:
    - 0 = Nikdy nekontrolovat aktualizace
    - 1 = Upozornit, ale neinstalovat
    - 2 = Automaticky stahovat a instalovat

    DŮLEŽITÉ: Pokud je v XML atribut default="true", Kodi ignoruje hodnotu
    a používá systémový default. Musíme změnit na default="false".

    Tato funkce zajistí, že hodnota je vždy 2 (automatické aktualizace).
    """
    try:
        guisettings_path = "/storage/.kodi/userdata/guisettings.xml"

        if not os.path.exists(guisettings_path):
            xbmc.log("[Dohled] guisettings.xml neexistuje, přeskakuji kontrolu auto-update", xbmc.LOGWARNING)
            return False

        # Načíst soubor
        with open(guisettings_path, 'r', encoding='utf-8') as f:
            content = f.read()

        import re
        needs_update = False
        new_content = content

        # Kontrola 1: Najít nastavení a zkontrolovat default atribut a hodnotu
        # Pattern pro celý element včetně atributů
        match = re.search(r'<setting id="general\.addonupdates"([^>]*)>(\d+)</setting>', new_content)

        if match:
            attributes = match.group(1)
            current_value = match.group(2)

            # Zkontrolovat jestli je default="true" - to způsobuje ignorování hodnoty
            if 'default="true"' in attributes:
                xbmc.log('[Dohled] Auto-update má default="true", měním na default="false"', xbmc.LOGWARNING)
                new_content = re.sub(
                    r'(<setting id="general\.addonupdates"[^>]*) default="true"([^>]*>)',
                    r'\1 default="false"\2',
                    new_content
                )
                needs_update = True

            # Zkontrolovat hodnotu
            if current_value != '2':
                xbmc.log(f"[Dohled] Auto-update nastavení je {current_value}, měním na 2", xbmc.LOGWARNING)
                new_content = re.sub(
                    r'(<setting id="general\.addonupdates"[^>]*>)\d+(</setting>)',
                    r'\g<1>2\g<2>',
                    new_content
                )
                needs_update = True

            if needs_update:
                # Zapsat změny
                with open(guisettings_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                xbmc.log("[Dohled] Auto-update nastavení opraveno (hodnota=2, default=false)", xbmc.LOGINFO)
                return True
            else:
                xbmc.log("[Dohled] Auto-update nastavení je správně (2, default=false)", xbmc.LOGINFO)
                return False
        else:
            xbmc.log("[Dohled] Nastavení general.addonupdates nenalezeno v guisettings.xml", xbmc.LOGWARNING)
            return False

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole auto-update nastavení: {e}", xbmc.LOGERROR)
        return False


# Vynucení kontroly aktualizací doplňků
def force_update_addons(retry_count=3, retry_delay=10):
    """
    Vynutí aktualizaci doplňků s retry mechanismem pro pomalá připojení.

    Kroky:
    1. Opravit nastavení auto-update (guisettings.xml)
    2. Opravit addons.updatemode (guisettings.xml)
    3. Odstranit blokující update pravidla z databáze
    4. Aktualizovat repozitáře a lokální addony
    5. Pokud se addon neaktualizoval automaticky, provést manuální update

    Args:
        retry_count: Počet pokusů o aktualizaci
        retry_delay: Čekání mezi pokusy v sekundách
    """
    # 1. Zajistit že auto-update je zapnutý
    ensure_addon_autoupdate_enabled()

    # 2. Opravit addons.updatemode nastavení
    fix_addons_updatemode_setting()

    # 3. Odstranit blokující update pravidla z databáze
    fix_addon_update_rules()

    # 4. Standardní Kodi update
    for attempt in range(retry_count):
        try:
            # Test připojení k internetu před pokusem o aktualizaci
            if not test_internet_connection():
                xbmc.log(f"[Dohled] Aktualizace addonů - pokus {attempt + 1}/{retry_count}: Síť nedostupná, čekám...", xbmc.LOGWARNING)
                time.sleep(retry_delay)
                continue

            xbmc.log(f"[Dohled] Aktualizace addonů - pokus {attempt + 1}/{retry_count}", xbmc.LOGINFO)

            # Aktualizovat repozitáře
            xbmc.executebuiltin('UpdateAddonRepos()')

            # Počkat na dokončení aktualizace repozitářů (neblokující příkaz)
            # Na pomalých připojeních může trvat déle
            wait_time = 15 + (attempt * 10)  # Prodloužit čekání s každým pokusem
            xbmc.log(f"[Dohled] Čekám {wait_time}s na aktualizaci repozitářů...", xbmc.LOGINFO)
            time.sleep(wait_time)

            # Aktualizovat lokální doplňky
            xbmc.executebuiltin('UpdateLocalAddons()')
            time.sleep(5)  # Krátké čekání na UpdateLocalAddons

            xbmc.log("[Dohled] Vynucená kontrola aktualizací addonů dokončena", xbmc.LOGINFO)
            break  # Dokončeno, pokračovat na kontrolu self-update

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při aktualizaci addonů (pokus {attempt + 1}): {e}", xbmc.LOGERROR)
            if attempt < retry_count - 1:
                time.sleep(retry_delay)

    # 5. Pokud Kodi auto-update nefunguje, provést manuální self-update
    # Toto zkontroluje jestli je dostupná novější verze a pokud ano, stáhne ji
    xbmc.log("[Dohled] Kontrola self-update (záložní mechanismus)...", xbmc.LOGINFO)
    force_self_update_if_needed()

    return True


def test_internet_connection(timeout=5):
    """Testuje připojení k internetu pomocí HTTP požadavku."""
    try:
        # Použít HTTP (ne HTTPS) pro rychlejší test bez SSL handshake
        req = urllib.request.Request("http://www.google.com", method='HEAD')
        req.add_header('User-Agent', 'Mozilla/5.0')
        urllib.request.urlopen(req, timeout=timeout)
        return True
    except:
        return False


def addon_update_loop():
    """
    Periodická smyčka pro kontrolu aktualizací doplňků.
    Běží na pozadí a kontroluje aktualizace každou hodinu.
    """
    global stop_monitoring
    monitor = xbmc.Monitor()

    # Počkat 5 minut po startu před první kontrolou (dát čas na stabilizaci)
    initial_delay = 300
    xbmc.log(f"[Dohled] Addon update loop: Čekám {initial_delay}s před první kontrolou", xbmc.LOGINFO)

    # Použít waitForAbort místo time.sleep - okamžitě se vrátí při abort
    if monitor.waitForAbort(initial_delay):
        return  # Kodi požaduje ukončení

    while not stop_monitoring and not monitor.abortRequested():
        try:
            xbmc.log("[Dohled] Periodická kontrola aktualizací addonů", xbmc.LOGINFO)
            force_update_addons(retry_count=2, retry_delay=30)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v addon update loop: {e}", xbmc.LOGERROR)

        # Čekat 1 hodinu před další kontrolou - použít waitForAbort
        if monitor.waitForAbort(3600):
            return  # Kodi požaduje ukončení

# Získá čas startu addonu (Kodi) - použít pro detekci restartu Kodi
# DŮLEŽITÉ: Používáme monotonic time pro výpočet správného boot_time,
# protože čas při startu addonu může být špatný (před NTP sync).
# time.monotonic() je nezávislé na změnách systémového času.
def get_boot_time():
    """
    Vypočítá skutečný čas startu addonu dynamicky.

    Princip:
    1. ADDON_START_MONOTONIC obsahuje monotonic čas při startu (nezávislý na NTP)
    2. Spočítáme kolik sekund addon běží: time.monotonic() - ADDON_START_MONOTONIC
    3. Odečteme tuto dobu od AKTUÁLNÍHO času (který je už správný po NTP sync)
    4. Výsledek = skutečný čas kdy addon nastartoval (se správným rokem)
    """
    uptime_seconds = time.monotonic() - ADDON_START_MONOTONIC
    real_start_timestamp = time.time() - uptime_seconds
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(real_start_timestamp))

# Načtení verze doplňku service.smycky přímo z addonu
def get_smycky_version():
    try:
        smycky_addon = xbmcaddon.Addon('service.smycky')
        return smycky_addon.getAddonInfo('version')
    except:
        return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení reboot_log.txt: {e}", xbmc.LOGERROR)
        return None
        
# Načíst nebo vytvořit DeviceID
def get_device_id():
    if xbmcvfs.exists(DEVICE_ID_FILE):
        with xbmcvfs.File(DEVICE_ID_FILE) as f:
            return f.read().strip()
    else:
        new_id = str(uuid.uuid4())
        with xbmcvfs.File(DEVICE_ID_FILE, 'w') as f:
            f.write(new_id)
        xbmc.log(f"[Dohled] Generuji nové DeviceID: {new_id}", xbmc.LOGINFO)
        return new_id

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'}, method="POST")
        with urllib.request.urlopen(req, timeout=10) as response:
            response_data = json.loads(response.read().decode())
            xbmc.log(f"[Dohled] Odesláno na API, status: {response.status}, odpověď: {response_data}", xbmc.LOGINFO)
            return response_data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)
        return None

def check_for_commands(device_id):
    """Zkontroluje a vrátí příkaz z API."""
    try:
        url = f"https://apidohled.noreason.eu/api/commands/{device_id}"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data.get("command"), data.get("params")
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole příkazů: {e}", xbmc.LOGERROR)
        return None, None


def send_download_progress(filename, percent, downloaded_mb, total_mb, status="downloading"):
    """Odešle průběh stahování přes WebSocket."""
    global ws_connected, ws_app
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "download_progress",
                "payload": {
                    "filename": filename,
                    "percent": percent,
                    "downloaded_mb": round(downloaded_mb, 1),
                    "total_mb": round(total_mb, 1),
                    "status": status  # "starting", "downloading", "completed", "error"
                }
            }))
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při odesílání progress: {e}", xbmc.LOGWARNING)


def download_and_play_file(filename):
    """Stáhne soubor z FTP a pak ho přehraje."""
    from ftplib import FTP
    global current_displayed_image, user_initiated_file

    try:
        # 0. OKAMŽITĚ zastavit současné přehrávání (aby neblikalo během stahování)
        xbmc.log(f"[Dohled] Download: Zastavuji současné přehrávání před stahováním {filename}", xbmc.LOGINFO)
        player = xbmc.Player()
        if player.isPlayingVideo():
            player.stop()
        if current_displayed_image:
            xbmc.log(f"[Dohled] Download: Zavírám obrázek {current_displayed_image}", xbmc.LOGINFO)
            close_image_viewer()  # Spolehlivě zavře obrázek (Dialog.Close + Stop + home)
        time.sleep(0.3)

        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně jen basename
        # ftp_path už obsahuje cestu ke složce (např. /smycky/Oresi/), takže stačí basename
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"/tmp/.downloading_{local_filename}"  # /tmp/ aby Kodi neviděl neúplný soubor

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + local_filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)

        # Kontrola místa před stahováním
        ensure_space_for_download(int(file_size_mb) + 50)  # +50 MB rezerva

        xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

        # Odeslat počáteční progress
        send_download_progress(filename, 0, 0, file_size_mb, "starting")

        downloaded = 0
        last_percent = 0
        last_progress_time = time.time()

        with open(temp_path, 'wb') as f:
            def callback(data):
                nonlocal downloaded, last_percent, last_progress_time
                f.write(data)
                downloaded += len(data)
                percent = int(downloaded * 100 / file_size)
                current_time = time.time()

                # Odeslat progress každých 500ms nebo při změně o 5%
                if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                    downloaded_mb = downloaded / (1024 * 1024)
                    send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                    last_progress_time = current_time

                if percent >= last_percent + 10:
                    last_percent = percent
                    xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

            ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

        ftp.quit()

        # 4. Přesunout dokončený soubor z /tmp/ do /storage/videos/
        # KRITICKÉ: os.rename nefunguje přes různé filesystémy (/tmp/ = tmpfs, /storage/ = main)
        import shutil
        if os.path.exists(local_path):
            os.remove(local_path)
        xbmc.log(f"[Dohled] Download: Kopíruji z /tmp/ do /storage/videos/", xbmc.LOGINFO)
        shutil.copy2(temp_path, local_path)
        os.remove(temp_path)

        # DŮLEŽITÉ: Vynutit zápis na disk - Kodi potřebuje vidět soubor
        os.sync()
        xbmc.log(f"[Dohled] Download: Filesystem sync dokončen", xbmc.LOGINFO)

        # KRITICKÉ: Informovat Kodi o novém souboru (invaliduje VFS cache)
        xbmc.executebuiltin(f'UpdateLibrary(video, "{target_dir}")')
        xbmc.log(f"[Dohled] Download: UpdateLibrary zavolán pro {target_dir}", xbmc.LOGINFO)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení
        send_download_progress(filename, 100, file_size_mb, file_size_mb, "completed")

        # 5. Přehrát/zobrazit soubor (video nebo obrázek)
        if is_image_file(local_filename):
            # KLÍČOVÉ: Ověřit že stažený soubor je plně přístupný
            xbmc.log(f"[Dohled] Download: Ověřuji dostupnost staženého souboru...", xbmc.LOGINFO)
            if not verify_image_file_ready(local_path, expected_size=file_size, timeout=5.0):
                xbmc.log(f"[Dohled] Download: CHYBA - stažený soubor není čitelný!", xbmc.LOGERROR)
                return

            # Nastavit jako user initiated PŘED zobrazením
            user_initiated_file = local_filename

            # Zastavit video pokud běží
            player = xbmc.Player()
            if player.isPlayingVideo():
                xbmc.log("[Dohled] Download: Zastavuji video", xbmc.LOGINFO)
                player.stop()
                # KRITICKÉ: Čekat na úplné zastavení playeru před zobrazením obrázku
                wait_for_player_stop(timeout=3.0)

            # NOVÝ PŘÍSTUP: Použít show_picture_safe() stejně jako play_file příkaz
            # Ten funguje pro už stažené soubory, měl by fungovat i pro nové
            xbmc.log(f"[Dohled] Download: Volám show_picture_safe pro originální soubor: {local_path}", xbmc.LOGINFO)

            # Zavřít všechny dialogy před zobrazením
            xbmc.executebuiltin('Dialog.Close(all,true)')
            time.sleep(0.1)

            # Zobrazit obrázek pomocí stejné funkce jako play_file
            if show_picture_safe(local_path, freshly_downloaded=True):
                xbmc.log(f"[Dohled] Download: show_picture_safe úspěšné", xbmc.LOGINFO)
            else:
                xbmc.log(f"[Dohled] Download: show_picture_safe selhalo, zkouším přímo ShowPicture", xbmc.LOGWARNING)
                xbmc.executebuiltin(f'ShowPicture("{local_path}")')
            current_displayed_image = local_filename

            # Cleanup starých temp souborů (z předchozích verzí)
            def cleanup():
                time.sleep(10)
                for f in os.listdir("/storage/videos/"):
                    if f.startswith(".disp_"):
                        try:
                            os.remove(f"/storage/videos/{f}")
                        except:
                            pass
            threading.Thread(target=cleanup, daemon=True).start()

            xbmc.log(f"[Dohled] Download: Obrázek zobrazen: {local_filename}", xbmc.LOGINFO)
        else:
            # Video - použít Player
            player = xbmc.Player()
            # Zavřít obrázek pokud je zobrazen
            if current_displayed_image:
                xbmc.log(f"[Dohled] Download: Zavírám obrázek {current_displayed_image} před videem", xbmc.LOGINFO)
                close_image_viewer()  # Použít spolehlivou funkci
            player.play(local_path)
            time.sleep(0.5)
            xbmc.executebuiltin("PlayerControl(RepeatOne)")
            xbmc.log(f"[Dohled] Download: Přehrávám video {local_filename}", xbmc.LOGINFO)
            send_immediate_state_update(local_filename, playing=True, paused=False)

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"/tmp/.downloading_{local_fname}"  # /tmp/ aby Kodi neviděl neúplný soubor
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def download_only_file(filename):
    """Stáhne soubor z FTP bez přehrání."""
    from ftplib import FTP

    try:
        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně jen basename
        # ftp_path už obsahuje cestu ke složce (např. /smycky/Oresi/), takže stačí basename
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"/tmp/.downloading_{local_filename}"  # /tmp/ aby Kodi neviděl neúplný soubor

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + local_filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)

        # Kontrola místa před stahováním
        ensure_space_for_download(int(file_size_mb) + 50)

        xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

        # Odeslat počáteční progress
        send_download_progress(filename, 0, 0, file_size_mb, "starting")

        downloaded = 0
        last_percent = 0
        last_progress_time = time.time()

        with open(temp_path, 'wb') as f:
            def callback(data):
                nonlocal downloaded, last_percent, last_progress_time
                f.write(data)
                downloaded += len(data)
                percent = int(downloaded * 100 / file_size)
                current_time = time.time()

                # Odeslat progress každých 500ms nebo při změně o 5%
                if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                    downloaded_mb = downloaded / (1024 * 1024)
                    send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                    last_progress_time = current_time

                if percent >= last_percent + 10:
                    last_percent = percent
                    xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

            ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

            # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
            f.flush()
            os.fsync(f.fileno())
            xbmc.log(f"[Dohled] Download: File flush + fsync dokončen", xbmc.LOGINFO)

        ftp.quit()

        # 4. Přesunout dokončený soubor z /tmp/ do /storage/videos/
        # KRITICKÉ: os.rename nefunguje přes různé filesystémy (/tmp/ = tmpfs, /storage/ = main)
        # Proto použijeme shutil.copy + os.remove
        import shutil
        if os.path.exists(local_path):
            os.remove(local_path)
        xbmc.log(f"[Dohled] Download: Kopíruji z /tmp/ do /storage/videos/", xbmc.LOGINFO)
        shutil.copy2(temp_path, local_path)
        os.remove(temp_path)

        # KRITICKÉ: Globální filesystem sync
        os.sync()
        xbmc.log(f"[Dohled] Download: Filesystem sync dokončen", xbmc.LOGINFO)

        # KRITICKÉ: Informovat Kodi o novém souboru (invaliduje VFS cache)
        xbmc.executebuiltin(f'UpdateLibrary(video, "{target_dir}")')
        xbmc.log(f"[Dohled] Download: UpdateLibrary zavolán pro {target_dir}", xbmc.LOGINFO)

        # KRITICKÉ: Ověřit velikost souboru před odesláním "completed"
        actual_size = os.path.getsize(local_path)
        if actual_size != file_size:
            xbmc.log(f"[Dohled] Download: CHYBA - velikost souboru neodpovídá! Očekáváno {file_size}, skutečná {actual_size}", xbmc.LOGERROR)
            send_download_progress(filename, 0, 0, 0, "error")
            return
        xbmc.log(f"[Dohled] Download: Velikost souboru ověřena OK ({actual_size} bytes)", xbmc.LOGINFO)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení - POUZE po úspěšné verifikaci
        send_download_progress(local_filename, 100, file_size_mb, file_size_mb, "completed")

        # DŮLEŽITÉ: Přidat do tracking čerstvě stažených souborů
        # play_file handler pak ví, že má použít freshly_downloaded=True
        recently_downloaded_files[local_filename] = time.time()
        xbmc.log(f"[Dohled] Download: Přidán do recently_downloaded_files: {local_filename}", xbmc.LOGINFO)

        # Nepřehrávat - pouze staženo

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"/tmp/.downloading_{local_fname}"  # /tmp/ aby Kodi neviděl neúplný soubor
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def download_files_from_cloud(filenames, ftp_config):
    """Stáhne více souborů z FTP. Vrací seznam úspěšně stažených lokálních souborů."""
    from ftplib import FTP

    ftp_host = ftp_config.get("ftp_host")
    ftp_user = ftp_config.get("ftp_user")
    ftp_pass = ftp_config.get("ftp_pass")
    ftp_path = ftp_config.get("ftp_path")

    downloaded_files = []

    try:
        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        for idx, filename in enumerate(filenames):
            try:
                # ftp_path už obsahuje cestu ke složce (např. /smycky/Oresi/), takže stačí basename
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                temp_path = f"/tmp/.downloading_{local_filename}"  # /tmp/ aby Kodi neviděl neúplný soubor

                remote_path = ftp_path + local_filename
                file_size = ftp.size(remote_path)
                file_size_mb = file_size / (1024 * 1024)

                # Kontrola místa
                ensure_space_for_download(int(file_size_mb) + 50)

                xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

                # Odeslat progress (filename je aktuální soubor)
                send_download_progress(f"playlist:{idx+1}/{len(filenames)}", 0, 0, file_size_mb, "downloading")

                downloaded = 0
                with open(temp_path, 'wb') as f:
                    def callback(data):
                        nonlocal downloaded
                        f.write(data)
                        downloaded += len(data)
                    ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

                    # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
                    f.flush()
                    os.fsync(f.fileno())

                # Přesunout dokončený soubor z /tmp/ do /storage/videos/
                # KRITICKÉ: os.rename nefunguje přes různé filesystémy
                import shutil
                if os.path.exists(local_path):
                    os.remove(local_path)
                shutil.copy2(temp_path, local_path)
                os.remove(temp_path)

                # KRITICKÉ: Globální filesystem sync
                os.sync()

                # KRITICKÉ: Ověřit velikost souboru
                actual_size = os.path.getsize(local_path)
                if actual_size != file_size:
                    xbmc.log(f"[Dohled] Playlist download: CHYBA - velikost {local_filename} neodpovídá! Očekáváno {file_size}, skutečná {actual_size}", xbmc.LOGERROR)
                    continue  # Přeskočit tento soubor, pokračovat s dalšími

                downloaded_files.append(local_filename)
                xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Hotovo: {local_filename} (ověřeno {actual_size} bytes)", xbmc.LOGINFO)

            except Exception as e:
                xbmc.log(f"[Dohled] Playlist download: Chyba při stahování {filename}: {e}", xbmc.LOGERROR)
                # Pokračovat s dalšími soubory
                continue

        ftp.quit()

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba FTP připojení: {e}", xbmc.LOGERROR)

    return downloaded_files


def download_and_play_playlist(filenames):
    """Stáhne více souborů z FTP a přehraje je jako playlist."""
    global current_displayed_image, current_playlist_id, mixed_playlist_thread, current_mixed_playlist, current_mixed_playlist_position

    try:
        # 0. Parsovat filenames - extrahovat skutečný název a duration
        # Formát může být "filename.jpg" nebo "filename.jpg:10" (s duration)
        parsed_files = []
        filenames_to_download = []
        for item in filenames:
            if ':' in item:
                parts = item.rsplit(':', 1)
                if len(parts) == 2 and parts[1].isdigit():
                    parsed_files.append({'filename': parts[0], 'duration': int(parts[1])})
                    filenames_to_download.append(parts[0])
                else:
                    parsed_files.append({'filename': item, 'duration': None})
                    filenames_to_download.append(item)
            else:
                parsed_files.append({'filename': item, 'duration': None})
                filenames_to_download.append(item)

        xbmc.log(f"[Dohled] Playlist download: Parsováno {len(parsed_files)} souborů", xbmc.LOGINFO)

        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory (pouze skutečné názvy bez :duration)
        xbmc.log(f"[Dohled] Playlist download: Stahuji {len(filenames_to_download)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames_to_download)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames_to_download, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download: Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # 5. Přehrát jako playlist (použít stejnou logiku jako play_playlist)
        xbmc.log(f"[Dohled] Playlist download: Hotovo, přehrávám {len(downloaded_files)} souborů", xbmc.LOGINFO)

        # Zavřít případný obrázek před spuštěním playlistu
        if current_displayed_image is not None:
            close_image_viewer()

        # Kategorizovat soubory - použít duration z parsed_files
        video_files = []
        image_files = []

        # Vytvořit lookup dict pro duration
        duration_lookup = {pf['filename']: pf['duration'] for pf in parsed_files}

        for filename in downloaded_files:
            local_path = get_local_media_path(filename)
            if os.path.exists(local_path):
                if is_video_file(filename):
                    video_files.append({"filename": filename})
                elif is_image_file(filename):
                    # Použít parsovanou duration nebo DEFAULT_IMAGE_DISPLAY_TIME
                    duration = duration_lookup.get(filename) or DEFAULT_IMAGE_DISPLAY_TIME
                    image_files.append({"filename": filename, "duration": duration})

        # Přehrát podle typu souborů
        if len(video_files) > 0 and len(image_files) == 0:
            # Pouze videa - klasický playlist
            current_playlist_id += 1
            current_mixed_playlist = []
            current_mixed_playlist_position = -1

            player = xbmc.Player()
            # NEVOLAT stop() - Kodi sám nahradí obsah playlistem
            # Pouze zavřít případný obrázek
            if current_displayed_image is not None:
                close_image_viewer()

            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            for vf in video_files:
                playlist.add(get_local_media_path(vf['filename']))

            player.play(playlist)
            xbmc.executebuiltin("PlayerControl(RepeatAll)")
            xbmc.log(f"[Dohled] Playlist download: Spuštěn video playlist ({len(video_files)} videí)", xbmc.LOGINFO)
            # Okamžité odeslání stavu - první soubor v playlistu
            if video_files:
                send_immediate_state_update(video_files[0]['filename'], playing=True, paused=False)

        else:
            # Mix videí a obrázků nebo pouze obrázky - použít mixed playlist logiku
            # Vytvořit seznam všech souborů v původním pořadí
            all_files = []
            for filename in downloaded_files:
                local_path = get_local_media_path(filename)
                if os.path.exists(local_path):
                    if is_video_file(filename):
                        all_files.append({"filename": filename, "type": "video"})
                    elif is_image_file(filename):
                        all_files.append({"filename": filename, "type": "image", "duration": 15})

            if not all_files:
                xbmc.log("[Dohled] Playlist download: Žádné platné soubory", xbmc.LOGERROR)
                return

            current_playlist_id += 1
            my_playlist_id = current_playlist_id

            if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                mixed_playlist_thread.join(timeout=3)

            def play_mixed_playlist():
                global current_displayed_image, current_mixed_playlist, current_mixed_playlist_position

                current_mixed_playlist = [f['filename'] for f in all_files]
                current_mixed_playlist_position = 0

                player = xbmc.Player()
                # NEVOLAT stop() - Kodi sám nahradí obsah
                # Pouze zavřít případný obrázek
                if current_displayed_image is not None:
                    close_image_viewer()
                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()

                while not xbmc.Monitor().abortRequested() and current_playlist_id == my_playlist_id:
                    for idx, file_info in enumerate(all_files):
                        current_mixed_playlist_position = idx

                        if current_playlist_id != my_playlist_id:
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            return

                        local_path = get_local_media_path(file_info['filename'])

                        if file_info['type'] == 'video':
                            # Zavřít obrázek pokud byl zobrazen (DŮLEŽITÉ!)
                            if current_displayed_image is not None:
                                close_image_viewer()  # Spolehlivě zavře obrázek před videem
                            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                            xbmc.executebuiltin("PlayerControl(RepeatOff)")
                            xbmc.executebuiltin(f'PlayMedia("{local_path}")')

                            time.sleep(2)
                            while not xbmc.Monitor().abortRequested() and current_playlist_id == my_playlist_id:
                                if not player.isPlaying():
                                    break
                                time.sleep(1)
                        else:
                            # Obrázek - zastavit video pokud běží
                            try:
                                if player.isPlaying():
                                    player.stop()
                                    # KRITICKÉ: Čekat na úplné zastavení playeru před zobrazením obrázku
                                    wait_for_player_stop(timeout=3.0)
                            except:
                                pass
                            if show_picture_safe(local_path):
                                current_displayed_image = file_info['filename']
                            else:
                                current_displayed_image = None

                            duration = file_info.get('duration', 15)
                            elapsed = 0
                            while elapsed < duration and current_playlist_id == my_playlist_id:
                                time.sleep(1)
                                elapsed += 1

                        if current_playlist_id != my_playlist_id:
                            current_displayed_image = None
                            return

                current_mixed_playlist = []
                current_mixed_playlist_position = -1

            mixed_playlist_thread = threading.Thread(target=play_mixed_playlist, daemon=True)
            mixed_playlist_thread.start()
            xbmc.log(f"[Dohled] Playlist download: Spuštěn mix playlist ({len(all_files)} souborů)", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def download_only_playlist(filenames):
    """Stáhne více souborů z FTP BEZ přehrání - pouze stažení."""
    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory
        xbmc.log(f"[Dohled] Playlist download (only): Stahuji {len(filenames)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download (only): Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # BEZ přehrávání - pouze staženo
        xbmc.log(f"[Dohled] Playlist download (only): Hotovo, staženo {len(downloaded_files)} souborů", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Staženo {len(downloaded_files)} souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download (only): Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def get_current_playlist():
    """Získá seznam souborů v aktuálním playlistu (včetně obrázků z mixed playlistu)."""
    global current_mixed_playlist, user_stopped

    # Pokud uživatel zastavil přehrávání, vrátit prázdný playlist
    if user_stopped:
        return []

    # Pokud běží mixed playlist (videa + obrázky), vrátit jeho seznam
    if current_mixed_playlist:
        return current_mixed_playlist

    # Fallback na Kodi video playlist - pouze pokud něco hraje
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return []  # Nic nehraje = prázdný playlist
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        items = []
        for i in range(playlist.size()):
            item = playlist[i]
            path = item.getPath() if hasattr(item, 'getPath') else str(item)
            filename = path.split('/')[-1] if path else f"Item {i}"
            items.append(filename)
        return items
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení playlistu: {e}", xbmc.LOGERROR)
        return []


def get_playlist_position():
    """Vrátí aktuální pozici v playlistu (včetně mixed playlistu)."""
    global current_mixed_playlist, current_mixed_playlist_position, user_stopped

    # Pokud uživatel zastavil přehrávání, vrátit -1
    if user_stopped:
        return -1

    # Pokud běží mixed playlist, vrátit jeho pozici
    if current_mixed_playlist and current_mixed_playlist_position >= 0:
        return current_mixed_playlist_position

    # Fallback na Kodi video playlist pozici - pouze pokud něco hraje
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return -1  # Nic nehraje
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        return playlist.getposition()
    except:
        return -1


def execute_command(command, params=None):
    """Vykoná přijatý příkaz."""
    global current_playlist_id, mixed_playlist_thread, current_displayed_image, current_mixed_playlist, current_mixed_playlist_position, user_initiated_file, user_stopped, pending_new_content, last_playing_true_time, last_stopped_content
    xbmc.log(f"[Dohled] Vykonávám příkaz: {command}, params: {params}", xbmc.LOGINFO)

    try:
        if command == "restart":
            xbmc.log("[Dohled] Příkaz: RESTART zařízení", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Přijat příkaz k restartu...", xbmcgui.NOTIFICATION_WARNING, 3000)
            time.sleep(2)
            mark_reboot("manual")
            os.system("reboot")

        elif command == "update_video":
            xbmc.log("[Dohled] Příkaz: Vynucená aktualizace videa", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Vynucená aktualizace videa - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            mark_reboot("update_video")
            os.system("reboot")  # Restart způsobí stažení nového videa

        elif command == "play":
            xbmc.log("[Dohled] Příkaz: Spustit přehrávání", xbmc.LOGINFO)
            user_stopped = False  # Reset stop flagu
            player = xbmc.Player()
            if player.isPlaying():
                # Pokud je pausnuto, spustit
                if xbmc.getCondVisibility("Player.Paused"):
                    player.pause()  # Toggle pause off
                    xbmc.log("[Dohled] Přehrávání obnoveno z pauzy", xbmc.LOGINFO)
            elif last_stopped_content:
                # RESUME: Obnovit naposledy stopnutý obsah
                xbmc.log(f"[Dohled] Obnovuji naposledy zastavený obsah: {last_stopped_content}", xbmc.LOGINFO)
                if last_stopped_content.get('type') == 'playlist':
                    # Obnovit playlist
                    files = last_stopped_content.get('files', [])
                    if files:
                        xbmc.log(f"[Dohled] Resume: spouštím playlist s {len(files)} soubory", xbmc.LOGINFO)
                        execute_command("play_playlist", {"files": files})
                    else:
                        xbmc.log("[Dohled] Resume: playlist je prázdný", xbmc.LOGWARNING)
                elif last_stopped_content.get('type') == 'single':
                    # Obnovit single file
                    filename = last_stopped_content.get('file')
                    if filename:
                        xbmc.log(f"[Dohled] Resume: spouštím soubor {filename}", xbmc.LOGINFO)
                        execute_command("play_file", {"filename": filename})
                    else:
                        xbmc.log("[Dohled] Resume: filename chybí", xbmc.LOGWARNING)
            else:
                # Není nic přehráváno a nemáme co obnovit - zkusit Kodi builtin
                xbmc.executebuiltin("PlayerControl(Play)")
                xbmc.log("[Dohled] Pokus o spuštění přehrávání (Kodi builtin)", xbmc.LOGINFO)

        elif command == "stop":
            xbmc.log("[Dohled] Příkaz: Zastavit přehrávání", xbmc.LOGINFO)

            # ULOŽIT AKTUÁLNÍ OBSAH PŘED ZASTAVENÍM (pro možnost obnovení přehrávání)
            if current_mixed_playlist and len(current_mixed_playlist) > 0:
                # Byl spuštěn playlist
                last_stopped_content = {
                    'type': 'playlist',
                    'files': list(current_mixed_playlist)  # Kopie seznamu
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: playlist s {len(current_mixed_playlist)} soubory", xbmc.LOGINFO)
            elif user_initiated_file:
                # Byl spuštěn jednotlivý soubor
                last_stopped_content = {
                    'type': 'single',
                    'file': user_initiated_file
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: single file {user_initiated_file}", xbmc.LOGINFO)
            else:
                # Zkusit získat aktuální soubor z přehrávače
                try:
                    player = xbmc.Player()
                    if player.isPlaying():
                        current_file = os.path.basename(player.getPlayingFile())
                        if current_file:
                            last_stopped_content = {
                                'type': 'single',
                                'file': current_file
                            }
                            xbmc.log(f"[Dohled] Uložen obsah pro resume: player file {current_file}", xbmc.LOGINFO)
                except:
                    pass

            # DŮLEŽITÉ: Zastavit běžící playlist
            current_playlist_id += 1
            current_mixed_playlist = []
            current_mixed_playlist_position = -1
            xbmc.log(f"[Dohled] stop: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

            # Nastavit flag že uživatel zastavil - monitoring nebude auto-startovat
            user_stopped = True
            xbmc.log("[Dohled] User stopped flag nastaven - auto-play deaktivován", xbmc.LOGINFO)

            # Vymazat user_initiated_file
            user_initiated_file = None

            # Zavřít zobrazený obrázek
            if current_displayed_image is not None:
                close_image_viewer()

            # Zastavit video
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
            xbmc.log("[Dohled] Přehrávání zastaveno", xbmc.LOGINFO)

            # DŮLEŽITÉ: Resetovat last_playing_true_time aby state detection
            # okamžitě reportoval playing=False (bez 5s tolerance debouncing)
            last_playing_true_time = None

            # Okamžité odeslání stavu - nic se nepřehrává
            send_immediate_state_update("", playing=False, paused=False)

        elif command == "pause":
            xbmc.log("[Dohled] Příkaz: Pozastavit/pokračovat přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            if player.isPlaying():
                player.pause()  # Toggle pause
                is_paused = xbmc.getCondVisibility("Player.Paused")
                status = "pozastaveno" if is_paused else "pokračuje"
                xbmc.log(f"[Dohled] Přehrávání {status}", xbmc.LOGINFO)

                # Okamžité odeslání stavu s aktuálním souborem
                try:
                    current_file = os.path.basename(player.getPlayingFile())
                except:
                    current_file = user_initiated_file or ""
                send_immediate_state_update(current_file, playing=True, paused=is_paused)
            else:
                xbmc.log("[Dohled] Nic se nepřehrává, nelze pozastavit", xbmc.LOGWARNING)

        elif command == "play_file":
            # Přehrát konkrétní lokální soubor (video nebo obrázek)
            user_stopped = False  # Reset stop flagu
            if params and params.get("filename"):
                filename = params.get("filename")
                # Pro soubory ze složek použít basename (soubor je uložen bez cesty)
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                if os.path.exists(local_path):
                    xbmc.log(f"[Dohled] Příkaz: Přehrát soubor {local_path}", xbmc.LOGINFO)

                    # Nastavit že uživatel ručně pustil soubor - monitoring loop ho nepřepíše
                    user_initiated_file = local_filename
                    xbmc.log(f"[Dohled] User initiated file: {local_filename}", xbmc.LOGINFO)

                    # DŮLEŽITÉ: Zastavit běžící playlist před přehráním nového souboru
                    current_playlist_id += 1
                    # Vyčistit mixed playlist (bude nastaven jen jeden soubor, ne playlist)
                    current_mixed_playlist = []
                    current_mixed_playlist_position = -1
                    xbmc.log(f"[Dohled] play_file: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                    # Signál pro service.smycky aby zastavilo svůj playlist
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na ukončení předchozího playlistu
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        mixed_playlist_thread.join(timeout=2)

                    # Zjistit co aktuálně běží
                    player = xbmc.Player()
                    is_video_playing = player.isPlayingVideo()
                    is_image_displayed = current_displayed_image is not None

                    if is_image_file(local_filename):
                        # CÍLEM JE OBRÁZEK
                        if is_video_playing:
                            # Video → Obrázek: NEJDŘÍV zastavit video, PAK zobrazit obrázek
                            xbmc.log("[Dohled] Přepínám z videa na obrázek - zastavuji video", xbmc.LOGINFO)
                            player.stop()
                            # KRITICKÉ: Čekat na úplné zastavení playeru před zobrazením obrázku
                            wait_for_player_stop(timeout=3.0)
                        elif is_image_displayed:
                            # Obrázek → Obrázek: zavřít starý, zobrazit nový
                            xbmc.log("[Dohled] Přepínám z obrázku na obrázek", xbmc.LOGINFO)
                            dismiss_image()  # Pouze Dialog.Close, nejde na home
                        else:
                            xbmc.log(f"[Dohled] Zobrazuji obrázek: {local_filename}", xbmc.LOGINFO)

                        # KONTROLA: Byl soubor čerstvě stažen? (v posledních 60s)
                        is_freshly_downloaded = False
                        if local_filename in recently_downloaded_files:
                            download_time = recently_downloaded_files[local_filename]
                            if time.time() - download_time < RECENTLY_DOWNLOADED_TTL:
                                is_freshly_downloaded = True
                                xbmc.log(f"[Dohled] play_file: Detekován čerstvě stažený soubor: {local_filename}", xbmc.LOGINFO)
                                # Odstranit z tracku - použijeme jen jednou
                                del recently_downloaded_files[local_filename]
                            else:
                                # Starý záznam - odstranit
                                del recently_downloaded_files[local_filename]

                        # Zobrazit obrázek s detekcí černé obrazovky
                        if show_picture_safe(local_path, freshly_downloaded=is_freshly_downloaded):
                            current_displayed_image = local_filename
                            xbmc.log(f"[Dohled] Obrázek zobrazen: {local_filename}", xbmc.LOGINFO)
                            # Okamžité odeslání stavu
                            send_immediate_state_update(local_filename, playing=True, paused=False)
                        else:
                            current_displayed_image = None

                    elif is_video_file(local_filename):
                        # CÍLEM JE VIDEO
                        if is_image_displayed:
                            # Obrázek → Video: NEJDŘÍV zavřít obrázek, PAK spustit video
                            xbmc.log("[Dohled] Přepínám z obrázku na video - zavírám obrázek", xbmc.LOGINFO)
                            close_image_viewer()  # Spolehlivě zavře obrázek (Dialog.Close + Stop + home)
                            xbmc.log("[Dohled] Obrázek zavřen, spouštím video", xbmc.LOGINFO)
                            player.play(local_path)
                        elif is_video_playing:
                            # Video → Video: NEVOLAT STOP! Kodi sám nahradí video
                            xbmc.log("[Dohled] Přepínám z videa na video (bez stop)", xbmc.LOGINFO)
                            player.play(local_path)
                        else:
                            # Nic neběží, spouštíme video
                            # DŮLEŽITÉ: I když current_displayed_image je None, může být stále
                            # zobrazen obrázek (např. po ukončení playlistu který vyčistil proměnnou)
                            # Proto vždy zavřeme případné dialogy před spuštěním videa
                            xbmc.log("[Dohled] Spouštím video (nic neběželo) - preventivní zavření dialogů", xbmc.LOGINFO)
                            xbmc.executebuiltin('Dialog.Close(all,true)')
                            time.sleep(0.1)
                            xbmc.executebuiltin('Action(Stop)')
                            time.sleep(0.1)
                            xbmc.executebuiltin('ActivateWindow(home)')
                            time.sleep(0.2)
                            player.play(local_path)

                        current_displayed_image = None
                        time.sleep(0.5)
                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                        # Okamžité odeslání stavu
                        send_immediate_state_update(local_filename, playing=True, paused=False)
                    else:
                        # Zkusit přehrát jako video (fallback)
                        xbmc.log(f"[Dohled] Neznámý typ souboru, zkouším jako video", xbmc.LOGWARNING)
                        # Zavřít případný obrázek před spuštěním videa
                        if current_displayed_image is not None:
                            close_image_viewer()
                        player = xbmc.Player()
                        player.play(local_path)
                        time.sleep(1)
                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                        # Okamžité odeslání stavu
                        send_immediate_state_update(local_filename, playing=True, paused=False)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {local_filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz play_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_and_play":
            # Stáhnout soubor z FTP a pak přehrát
            user_stopped = False  # Reset stop flagu
            if params and params.get("filename"):
                filename = params.get("filename")
                local_filename = os.path.basename(filename)
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát {filename}", xbmc.LOGINFO)

                # DŮLEŽITÉ: Zastavit běžící playlist před stahováním
                current_playlist_id += 1
                current_mixed_playlist = []
                current_mixed_playlist_position = -1
                xbmc.log(f"[Dohled] download_and_play: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                # Signál pro service.smycky aby zastavilo svůj playlist
                try:
                    with open(STOP_SMYCKY_FLAG, "w") as f:
                        f.write(str(time.time()))
                    xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                # Počkat na ukončení předchozího playlistu
                if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                    mixed_playlist_thread.join(timeout=2)

                # Nastavit user_initiated_file
                user_initiated_file = local_filename
                xbmc.log(f"[Dohled] User initiated file: {local_filename}", xbmc.LOGINFO)

                # Spustit stahování v samostatném vlákně
                threading.Thread(target=download_and_play_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_only":
            # Pouze stáhnout soubor z FTP bez přehrání
            # Nastavit pending_new_content flag - zabrání auto-play do restartu
            if params and params.get("filename"):
                filename = params.get("filename")
                xbmc.log(f"[Dohled] Příkaz: Pouze stáhnout {filename}", xbmc.LOGINFO)
                pending_new_content = True
                xbmc.log("[Dohled] pending_new_content nastaven - auto-play zablokován do restartu", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně (bez přehrání)
                threading.Thread(target=download_only_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_and_play_playlist":
            # Stáhnout více souborů z FTP a přehrát jako playlist
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát playlist ({len(files)} souborů)", xbmc.LOGINFO)

                # DŮLEŽITÉ: Zastavit běžící playlist před stahováním
                current_playlist_id += 1
                current_mixed_playlist = []
                current_mixed_playlist_position = -1
                xbmc.log(f"[Dohled] download_and_play_playlist: Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)

                # Signál pro service.smycky aby zastavilo svůj playlist
                try:
                    with open(STOP_SMYCKY_FLAG, "w") as f:
                        f.write(str(time.time()))
                    xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                # Počkat na ukončení předchozího playlistu
                if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                    mixed_playlist_thread.join(timeout=2)

                # Nastavit user_initiated_file jako playlist string
                playlist_str = "playlist:" + ",".join(files)
                user_initiated_file = playlist_str
                xbmc.log(f"[Dohled] User initiated playlist: {len(files)} souborů", xbmc.LOGINFO)

                # Spustit stahování a přehrávání v samostatném vlákně
                threading.Thread(target=download_and_play_playlist, args=(files,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "download_only_playlist":
            # Stáhnout více souborů z FTP BEZ přehrání
            # Nastavit pending_new_content flag - zabrání auto-play do restartu
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout {len(files)} souborů (bez přehrání)", xbmc.LOGINFO)
                pending_new_content = True
                xbmc.log("[Dohled] pending_new_content nastaven - auto-play zablokován do restartu", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně
                threading.Thread(target=download_only_playlist, args=(files,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "delete_file":
            # Smazat lokální soubor
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)

                # Kontrola že soubor není právě přehráván
                player = xbmc.Player()
                if player.isPlayingVideo():
                    playing_file = player.getPlayingFile()
                    if playing_file and playing_file.endswith(filename):
                        xbmc.log(f"[Dohled] Nelze smazat přehrávaný soubor: {filename}", xbmc.LOGWARNING)
                        xbmcgui.Dialog().notification("Dohled", f"Nelze smazat - soubor se přehrává", xbmcgui.NOTIFICATION_ERROR, 3000)
                        return

                if os.path.exists(local_path):
                    try:
                        os.remove(local_path)
                        xbmc.log(f"[Dohled] Soubor smazán: {local_path}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při mazání souboru: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().notification("Dohled", f"Chyba mazání: {str(e)[:20]}", xbmcgui.NOTIFICATION_ERROR, 3000)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor neexistuje", xbmcgui.NOTIFICATION_WARNING, 2000)
            else:
                xbmc.log("[Dohled] Příkaz delete_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "notification":
            title = params.get("title", "Dohled") if params else "Dohled"
            message = params.get("message", "") if params else ""
            duration = params.get("duration", 5000) if params else 5000
            xbmc.log(f"[Dohled] Příkaz: Notifikace - {title}: {message}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, duration)

        elif command == "update_addons":
            xbmc.log("[Dohled] Příkaz: Aktualizace doplňků", xbmc.LOGINFO)
            force_update_addons()

        elif command == "refresh_config":
            xbmc.log("[Dohled] Příkaz: Obnovení konfigurace", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Obnovuji konfiguraci - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            mark_reboot("refresh_config")
            os.system("reboot")

        elif command == "shell":
            if params and params.get("cmd"):
                cmd = params.get("cmd")
                xbmc.log(f"[Dohled] Příkaz: Shell - {cmd}", xbmc.LOGINFO)
                result = os.system(cmd)
                xbmc.log(f"[Dohled] Shell příkaz dokončen s kódem: {result}", xbmc.LOGINFO)
            else:
                xbmc.log("[Dohled] Shell příkaz bez parametru cmd", xbmc.LOGWARNING)

        elif command == "play_playlist":
            # Přehrát více souborů za sebou (playlist) - podpora videí i obrázků
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                current_displayed_image = None  # Playlist spravuje zobrazení sám
                files = params.get("files")  # Seznam názvů souborů (může obsahovat filename:duration)
                xbmc.log(f"[Dohled] Příkaz: Přehrát playlist s {len(files)} soubory", xbmc.LOGINFO)

                # KRITICKÉ: Nastavit user_initiated_file jako playlist string
                # Toto zajistí že API synchronizuje UserInitiatedPlayback a monitoring loop nepřepíše playlist
                playlist_filenames = []
                for item in files:
                    if ':' in item:
                        parts = item.rsplit(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            playlist_filenames.append(item)  # Zachovat duration
                        else:
                            playlist_filenames.append(item)
                    else:
                        playlist_filenames.append(item)
                user_initiated_file = "playlist:" + ",".join(playlist_filenames)
                xbmc.log(f"[Dohled] user_initiated_file nastaven: {user_initiated_file}", xbmc.LOGINFO)

                # Parsovat soubory - může být "filename" nebo "filename:duration"
                parsed_files = []
                for item in files:
                    if ':' in item:
                        parts = item.rsplit(':', 1)
                        if len(parts) == 2 and parts[1].isdigit():
                            parsed_files.append({'filename': parts[0], 'duration': int(parts[1])})
                        else:
                            parsed_files.append({'filename': item, 'duration': None})
                    else:
                        parsed_files.append({'filename': item, 'duration': None})

                # Rozdělit na videa a obrázky
                video_files = []
                image_files = []
                for pf in parsed_files:
                    local_path = get_local_media_path(pf['filename'])
                    if os.path.exists(local_path):
                        if is_video_file(pf['filename']):
                            video_files.append(pf)
                            xbmc.log(f"[Dohled] Playlist: video {pf['filename']}", xbmc.LOGINFO)
                        elif is_image_file(pf['filename']):
                            image_files.append(pf)
                            duration = pf['duration'] or DEFAULT_IMAGE_DISPLAY_TIME
                            xbmc.log(f"[Dohled] Playlist: obrázek {pf['filename']} ({duration}s)", xbmc.LOGINFO)
                        else:
                            xbmc.log(f"[Dohled] Playlist: nepodporovaný typ {pf['filename']}", xbmc.LOGWARNING)
                    else:
                        xbmc.log(f"[Dohled] Playlist: soubor neexistuje {pf['filename']}", xbmc.LOGWARNING)

                has_videos = len(video_files) > 0
                has_images = len(image_files) > 0
                total_count = len(video_files) + len(image_files)

                if total_count == 0:
                    xbmcgui.Dialog().notification("Dohled", "Žádné soubory nenalezeny", xbmcgui.NOTIFICATION_ERROR, 3000)
                elif has_videos and not has_images:
                    # Pouze videa - klasický video playlist

                    # DŮLEŽITÉ: Zastavit service.smycky playlist
                    current_playlist_id += 1
                    current_mixed_playlist = []
                    current_mixed_playlist_position = -1
                    xbmc.log(f"[Dohled] play_playlist (video): Zastavuji playlist (nové ID: {current_playlist_id})", xbmc.LOGINFO)
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky (video playlist)", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na ukončení předchozího playlistu
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        mixed_playlist_thread.join(timeout=2)

                    # NEVOLAT stop() - Kodi sám nahradí přehrávaný obsah playlistem
                    # Pouze zavřít případný obrázek
                    if current_displayed_image is not None:
                        close_image_viewer()  # Spolehlivě zavře obrázek pro video playlist

                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.clear()
                    for vf in video_files:
                        playlist.add(get_local_media_path(vf['filename']))

                    player = xbmc.Player()
                    player.play(playlist)
                    time.sleep(1)
                    xbmc.executebuiltin("PlayerControl(RepeatAll)")
                    # Okamžité odeslání stavu - první soubor v playlistu
                    if video_files:
                        send_immediate_state_update(video_files[0]['filename'], playing=True, paused=False)
                else:
                    # Mix videí a obrázků NEBO jeden soubor - custom playback loop

                    # Inkrementovat playlist ID - tím se automaticky zastaví předchozí playlist
                    current_playlist_id += 1
                    my_playlist_id = current_playlist_id
                    xbmc.log(f"[Dohled] Nový playlist ID: {my_playlist_id}", xbmc.LOGINFO)

                    # Signál pro service.smycky aby zastavilo svůj playlist
                    try:
                        with open(STOP_SMYCKY_FLAG, "w") as f:
                            f.write(str(time.time()))
                        xbmc.log("[Dohled] Vytvořen STOP flag pro service.smycky", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při vytváření STOP flagu: {e}", xbmc.LOGERROR)

                    # Počkat na zastavení předchozího playbacku
                    if mixed_playlist_thread and mixed_playlist_thread.is_alive():
                        xbmc.log("[Dohled] Čekám na zastavení předchozího playlistu...", xbmc.LOGINFO)
                        # Zavřít případný zobrazený obrázek (ale NEVOLAT stop() na video!)
                        if current_displayed_image is not None:
                            close_image_viewer()  # Spolehlivě zavře obrázek
                        # Počkat max 2 sekundy na zastavení vlákna (nový obsah nahradí starý)
                        mixed_playlist_thread.join(timeout=2)

                    xbmc.log(f"[Dohled] Spouštím mix playlist: {len(video_files)} videí + {len(image_files)} obrázků", xbmc.LOGINFO)

                    # Pomocná funkce pro kontrolu zda je tento playlist stále aktivní
                    def is_my_playlist_active():
                        return current_playlist_id == my_playlist_id

                    # Spustit playback loop ve vlákně
                    def mixed_playback_loop():
                        global current_displayed_image, current_mixed_playlist, current_mixed_playlist_position
                        player = xbmc.Player()
                        current_index = 0
                        all_files = parsed_files  # Zachovat původní pořadí

                        # Filtrovat jen existující soubory
                        valid_files = []
                        for pf in all_files:
                            local_path = get_local_media_path(pf['filename'])
                            if os.path.exists(local_path) and is_supported_file(pf['filename']):
                                valid_files.append(pf)

                        if not valid_files:
                            xbmc.log("[Dohled] Mix playlist: žádné platné soubory", xbmc.LOGERROR)
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            return

                        # Nastavit globální playlist pro monitoring
                        current_mixed_playlist = [pf['filename'] for pf in valid_files]
                        current_mixed_playlist_position = 0
                        xbmc.log(f"[Dohled] Mixed playlist nastaven: {current_mixed_playlist}", xbmc.LOGINFO)

                        # Speciální případ: jeden obrázek = zobrazit trvale
                        if len(valid_files) == 1 and is_image_file(valid_files[0]['filename']):
                            filename = valid_files[0]['filename']
                            local_path = get_local_media_path(filename)
                            xbmc.log(f"[Dohled] Mix: zobrazuji obrázek {filename} (trvale)", xbmc.LOGINFO)
                            # Zastavit video pokud běží
                            try:
                                if player.isPlaying():
                                    player.stop()
                                    time.sleep(0.2)
                            except:
                                pass
                            if show_picture_safe(local_path):
                                current_displayed_image = filename  # Pro monitoring
                            else:
                                current_displayed_image = None
                            # Čekat dokud není playlist změněn
                            while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                                time.sleep(1)
                            xbmc.log(f"[Dohled] Mix: obrázek {filename} ukončen (nový playlist)", xbmc.LOGINFO)
                            current_mixed_playlist = []
                            current_mixed_playlist_position = -1
                            return

                        is_first_item = True  # Pro správné zavření overlay po prvním souboru

                        while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                            pf = valid_files[current_index]
                            filename = pf['filename']
                            local_path = get_local_media_path(filename)
                            # Aktualizovat pozici pro monitoring
                            current_mixed_playlist_position = current_index

                            if not is_my_playlist_active():
                                xbmc.log(f"[Dohled] Mix playlist {my_playlist_id}: zastaveno (nový playlist)", xbmc.LOGINFO)
                                break

                            if is_video_file(filename):
                                # Video - přehrát celé (bez opakování)
                                xbmc.log(f"[Dohled] Mix: přehrávám video {filename}", xbmc.LOGINFO)
                                # Zavřít obrázek pokud byl zobrazen
                                if current_displayed_image is not None:
                                    close_image_viewer()  # Spolehlivě zavře obrázek před videem
                                # Vyčistit playlist aby se nic neopakovalo
                                xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                                # Vypnout repeat mód
                                xbmc.executebuiltin("PlayerControl(RepeatOff)")
                                # Přehrát video pomocí PlayMedia - nahradí aktuální video bez stop()
                                xbmc.executebuiltin(f'PlayMedia("{local_path}")')
                                time.sleep(1)
                                # Znovu vypnout repeat pro jistotu (po spuštění videa)
                                xbmc.executebuiltin("PlayerControl(RepeatOff)")
                                is_first_item = False
                                # Čekat na dokončení videa
                                video_started = False
                                wait_count = 0
                                while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                                    if player.isPlayingVideo():
                                        video_started = True
                                        time.sleep(0.5)
                                    elif video_started:
                                        # Video běželo a skončilo
                                        break
                                    else:
                                        # Čekáme na start videa
                                        wait_count += 1
                                        if wait_count > 20:  # Max 10 sekund čekání na start
                                            xbmc.log(f"[Dohled] Mix: video {filename} se nespustilo", xbmc.LOGWARNING)
                                            break
                                        time.sleep(0.5)
                                # Krátká pauza pro jistotu že video skončilo
                                time.sleep(0.3)
                                xbmc.log(f"[Dohled] Mix: video {filename} dokončeno", xbmc.LOGINFO)
                            elif is_image_file(filename):
                                # Obrázek - zobrazit na specifikovanou dobu
                                duration = pf['duration'] or DEFAULT_IMAGE_DISPLAY_TIME
                                xbmc.log(f"[Dohled] Mix: zobrazuji obrázek {filename} ({duration}s)", xbmc.LOGINFO)
                                # VŽDY zastavit video před zobrazením obrázku
                                try:
                                    player.stop()
                                    # KRITICKÉ: Čekat na úplné zastavení playeru
                                    wait_for_player_stop(timeout=3.0)
                                except:
                                    pass
                                if show_picture_safe(local_path):
                                    current_displayed_image = filename  # Pro monitoring
                                else:
                                    current_displayed_image = None
                                is_first_item = False
                                # Čekat po menších intervalech pro rychlejší reakci na stop
                                elapsed = 0
                                while elapsed < duration and is_my_playlist_active():
                                    time.sleep(0.5)
                                    elapsed += 0.5
                                if is_my_playlist_active():
                                    # Zjistit co je další položka - video nebo obrázek
                                    next_idx = (current_index + 1) % len(valid_files)
                                    next_file = valid_files[next_idx]['filename']
                                    if is_video_file(next_file):
                                        close_image_viewer()  # Úplné zavření pro přechod na video
                                    else:
                                        dismiss_image()  # Jen Dialog.Close pro obrázek→obrázek
                                        current_displayed_image = None

                            if not is_my_playlist_active():
                                current_displayed_image = None  # Playlist ukončen
                                break

                            # Přejít na další soubor
                            next_index = (current_index + 1) % len(valid_files)
                            if next_index == 0:
                                xbmc.log(f"[Dohled] Mix playlist: opakuji od začátku (položka 1/{len(valid_files)})", xbmc.LOGINFO)
                            else:
                                xbmc.log(f"[Dohled] Mix playlist: další položka {next_index + 1}/{len(valid_files)}", xbmc.LOGINFO)

                            current_index = next_index
                            current_mixed_playlist_position = current_index  # Aktualizovat pozici ihned

                        # Cleanup při ukončení loopu
                        current_displayed_image = None
                        current_mixed_playlist = []
                        current_mixed_playlist_position = -1
                        xbmc.log(f"[Dohled] Mix playlist {my_playlist_id} loop ukončen", xbmc.LOGINFO)

                    mixed_playlist_thread = threading.Thread(target=mixed_playback_loop, daemon=True)
                    mixed_playlist_thread.start()
            else:
                xbmc.log("[Dohled] Příkaz play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "add_to_playlist":
            # Přidat soubor do aktuálního playlistu
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)
                if os.path.exists(local_path):
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.add(local_path)
                    xbmc.log(f"[Dohled] Přidáno do playlistu: {filename}", xbmc.LOGINFO)
                    # Pokud nic nehraje, spustit
                    player = xbmc.Player()
                    if not player.isPlaying():
                        # Zavřít případný obrázek před spuštěním video playlistu
                        if current_displayed_image is not None:
                            close_image_viewer()
                        player.play(playlist)
                        time.sleep(1)
                        xbmc.executebuiltin("PlayerControl(RepeatAll)")
                        # Okamžité odeslání stavu
                        send_immediate_state_update(filename, playing=True, paused=False)
                else:
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz add_to_playlist bez parametru filename", xbmc.LOGWARNING)

        elif command == "clear_playlist":
            # Vyčistit playlist
            xbmc.log("[Dohled] Příkaz: Vyčistit playlist", xbmc.LOGINFO)
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()

        else:
            xbmc.log(f"[Dohled] Neznámý příkaz: {command}", xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vykonávání příkazu {command}: {e}", xbmc.LOGERROR)


# Interval pro HTTP polling příkazů (fallback když není WebSocket)
# Zvýšeno zpět na 5s protože je to jen fallback
COMMAND_POLL_INTERVAL = 5


def command_polling_loop(device_id):
    """HTTP fallback pro příkazy - běží pouze když není WebSocket."""
    global stop_monitoring, ws_connected

    xbmc.log(f"[Dohled] Spuštěn HTTP fallback polling příkazů", xbmc.LOGINFO)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        # Pouze pollovat pokud není WebSocket připojen
        if not ws_connected:
            try:
                command, params = check_for_commands(device_id)
                if command:
                    # Parsovat params pokud je to JSON string
                    if params and isinstance(params, str):
                        try:
                            params = json.loads(params)
                        except:
                            pass
                    execute_command(command, params)

            except Exception as e:
                xbmc.log(f"[Dohled] Chyba v HTTP polling: {e}", xbmc.LOGERROR)

        # Čekat COMMAND_POLL_INTERVAL sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(COMMAND_POLL_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break

    xbmc.log("[Dohled] HTTP polling příkazů ukončen", xbmc.LOGINFO)

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url, timeout=10) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def fetch_expected_file_with_locality(device_id, locality=None):
    """Načte očekávaný soubor z API - bere v potaz device override.

    Vrací tuple (filename, source) kde source je "device" nebo "locality".
    Parametr locality je volitelný fallback pro nová zařízení.
    """
    # Přidat boot_time pro detekci restartu - API vymaže UserInitiatedPlayback při změně boot_time
    boot_time = get_boot_time()
    params = []
    if locality:
        params.append(f"locality={locality}")
    if boot_time:
        params.append(f"boot_time={urllib.parse.quote(boot_time)}")
    query_string = "?" + "&".join(params) if params else ""
    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file{query_string}"
    try:
        with urllib.request.urlopen(api_url, timeout=5) as response:
            data = json.loads(response.read().decode())
            filename = data.get("filename")
            source = data.get("source")
            if filename:
                xbmc.log(f"[Dohled] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
            return filename, source
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání očekávaného souboru: {e}", xbmc.LOGERROR)
        return None, None

# NOVÉ FUNKCE PRO LEPŠÍ DETEKCI MEDIÁLNÍCH SOUBORŮ

# Přípony pro filtrování
VIDEO_EXTENSIONS = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.webm', '.m4v')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

def get_media_type(filename):
    """Vrátí typ média podle přípony."""
    lower = filename.lower()
    if any(lower.endswith(ext) for ext in VIDEO_EXTENSIONS):
        return "video"
    elif any(lower.endswith(ext) for ext in IMAGE_EXTENSIONS):
        return "image"
    return None

def get_local_video_files():
    """Vrátí seznam lokálních mediálních souborů (videa z VIDEO_DIR, obrázky z IMAGE_DIR)."""
    try:
        files = []

        # Skenovat VIDEO_DIR (videa)
        if os.path.exists(VIDEO_DIR):
            for filename in os.listdir(VIDEO_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(VIDEO_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Skenovat IMAGE_DIR (obrázky)
        if os.path.exists(IMAGE_DIR):
            for filename in os.listdir(IMAGE_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(IMAGE_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Seřadit podle jména
        files.sort(key=lambda x: x["name"].lower())
        video_count = sum(1 for f in files if f.get("type") == "video")
        image_count = sum(1 for f in files if f.get("type") == "image")
        xbmc.log(f"[Dohled] Nalezeno {len(files)} lokálních souborů ({video_count} videí, {image_count} obrázků)", xbmc.LOGINFO)
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání lokálních souborů: {e}", xbmc.LOGERROR)
        return []


def get_storage_info():
    """Vrátí informace o úložišti (volné místo, celková kapacita)."""
    try:
        stat = os.statvfs(VIDEO_DIR)
        free_bytes = stat.f_bavail * stat.f_frsize
        total_bytes = stat.f_blocks * stat.f_frsize
        used_bytes = total_bytes - free_bytes

        return {
            "free_mb": round(free_bytes / 1024 / 1024, 2),
            "total_mb": round(total_bytes / 1024 / 1024, 2),
            "used_mb": round(used_bytes / 1024 / 1024, 2),
            "free_percent": round((free_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 0
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa: {e}", xbmc.LOGERROR)
        return {"free_mb": 0, "total_mb": 0, "used_mb": 0, "free_percent": 0}


def get_video_files_sorted_by_age():
    """Vrátí seznam video souborů seřazený od nejstaršího."""
    try:
        if not os.path.exists(VIDEO_DIR):
            return []

        files = []
        for filename in os.listdir(VIDEO_DIR):
            if filename.lower().endswith(VIDEO_EXTENSIONS) and not filename.startswith('.'):
                filepath = os.path.join(VIDEO_DIR, filename)
                if os.path.isfile(filepath):
                    try:
                        mtime = os.path.getmtime(filepath)
                        size = os.path.getsize(filepath)
                        files.append({
                            "name": filename,
                            "path": filepath,
                            "mtime": mtime,
                            "size": size,
                            "size_mb": round(size / 1024 / 1024, 2)
                        })
                    except:
                        pass

        # Seřadit od nejstaršího
        files.sort(key=lambda x: x["mtime"])
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání seznamu souborů: {e}", xbmc.LOGERROR)
        return []


def cleanup_old_videos(needed_space_mb=0, keep_current=True):
    """
    Vyčistí staré video soubory pouze pokud je nedostatek volného místa.
    Neomezuje počet souborů - uživatel může mít libovolně mnoho souborů v playlistu.

    Args:
        needed_space_mb: Kolik MB potřebujeme uvolnit (0 = jen kontrola MIN_FREE_SPACE_MB)
        keep_current: Ponechat aktuálně přehrávaný soubor

    Returns:
        Počet smazaných souborů
    """
    try:
        storage = get_storage_info()
        total_needed = needed_space_mb + MIN_FREE_SPACE_MB

        # Kontrola zda je potřeba uvolnit místo
        if storage["free_mb"] >= total_needed:
            xbmc.log(f"[Dohled] Storage: Dostatek místa ({storage['free_mb']} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0

        files = get_video_files_sorted_by_age()
        if not files:
            return 0

        # Zjistit aktuálně přehrávaný soubor
        current_file = None
        if keep_current:
            player = xbmc.Player()
            if player.isPlayingVideo():
                playing_path = player.getPlayingFile()
                current_file = os.path.basename(playing_path) if playing_path else None

        deleted_count = 0
        freed_space_mb = 0
        space_to_free = total_needed - storage["free_mb"]

        xbmc.log(f"[Dohled] Storage: Málo místa ({storage['free_mb']} MB volných), potřeba uvolnit {space_to_free} MB", xbmc.LOGWARNING)

        for f in files:
            if freed_space_mb >= space_to_free:
                break
            if f["name"] == current_file:
                xbmc.log(f"[Dohled] Storage: Přeskakuji aktuálně přehrávaný soubor: {f['name']}", xbmc.LOGINFO)
                continue
            try:
                os.remove(f["path"])
                deleted_count += 1
                freed_space_mb += f["size_mb"]
                xbmc.log(f"[Dohled] Storage: Smazán pro uvolnění místa: {f['name']} ({f['size_mb']} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Storage: Nelze smazat {f['name']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            xbmc.log(f"[Dohled] Storage: Celkem smazáno {deleted_count} souborů, uvolněno {freed_space_mb} MB", xbmc.LOGINFO)

        return deleted_count

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění souborů: {e}", xbmc.LOGERROR)
        return 0


def ensure_space_for_download(needed_mb):
    """Zajistí dostatek místa pro stažení nového souboru."""
    storage = get_storage_info()
    if storage["free_mb"] < needed_mb + MIN_FREE_SPACE_MB:
        xbmc.log(f"[Dohled] Storage: Před stahováním potřeba uvolnit místo pro {needed_mb} MB", xbmc.LOGINFO)
        cleanup_old_videos(needed_space_mb=needed_mb)
        return True
    return False


def find_current_video_file():
    """Najde aktuálně přehrávaný nebo nejnovější video soubor."""
    try:
        # 1. Zkusit najít aktuálně přehrávaný soubor
        player = xbmc.Player()
        if player.isPlayingVideo():
            playing_file = player.getPlayingFile()
            if playing_file and playing_file.startswith("/storage/videos/") and playing_file.endswith(".mp4"):
                xbmc.log(f"[Dohled] Nalezen přehrávaný soubor: {playing_file}", xbmc.LOGINFO)
                return playing_file
        
        # 2. Zkusit načíst z last_filename.txt (pokud existuje)
        if os.path.exists(LAST_FILENAME_FILE):
            try:
                with open(LAST_FILENAME_FILE, 'r', encoding='utf-8') as f:
                    last_filename = f.read().strip()
                    if last_filename:
                        potential_path = get_local_media_path(last_filename)
                        if os.path.exists(potential_path):
                            xbmc.log(f"[Dohled] Nalezen soubor z last_filename: {potential_path}", xbmc.LOGINFO)
                            return potential_path
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při čtení last_filename.txt: {e}", xbmc.LOGERROR)
        
        # 3. Najít nejnovější MP4 soubor v /storage/videos/
        video_dir = "/storage/videos/"
        if os.path.exists(video_dir):
            video_files = []
            for filename in os.listdir(video_dir):
                if filename.endswith('.mp4'):
                    filepath = os.path.join(video_dir, filename)
                    if os.path.exists(filepath):
                        mtime = os.path.getmtime(filepath)
                        video_files.append((filepath, mtime))
            
            if video_files:
                # Seřadit podle času úpravy (nejnovější první)
                video_files.sort(key=lambda x: x[1], reverse=True)
                xbmc.log(f"[Dohled] Nalezen nejnovější soubor: {video_files[0][0]}", xbmc.LOGINFO)
                return video_files[0][0]
        
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return None
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání aktuálního video souboru: {e}", xbmc.LOGERROR)
        return None

def get_video_file_info(expected_filename, expected_file_size=None):
    """Získá informace o video souboru a vyhodnotí potřebu aktualizace."""
    try:
        # 1. Zkusit nejdříve očekávaný soubor z API
        if expected_filename:
            # Použít basename - soubory ze složek jsou uloženy bez cesty
            local_expected = os.path.basename(expected_filename)
            expected_path = get_local_media_path(local_expected)
            if os.path.exists(expected_path):
                stat = os.stat(expected_path)
                file_size = stat.st_size
                
                # Vyhodnotit, zda je soubor aktuální
                size_matches = (expected_file_size is None or file_size == expected_file_size)
                
                xbmc.log(f"[Dohled] Očekávaný soubor existuje: {local_expected}, velikost OK: {size_matches}", xbmc.LOGINFO)

                return {
                    'path': expected_path,
                    'filename': local_expected,  # Vrátit basename - skutečný název lokálního souboru
                    'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                    'file_size': file_size,
                    'is_expected': True,
                    'update_needed': not size_matches  # Aktualizace potřeba, pokud se velikost neshoduje
                }
        
        # 2. Pokud očekávaný soubor neexistuje, najít aktuální
        current_video = find_current_video_file()
        if current_video and os.path.exists(current_video):
            stat = os.stat(current_video)
            filename = os.path.basename(current_video)
            
            xbmc.log(f"[Dohled] Očekávaný soubor ({expected_filename}) neexistuje, používám aktuální: {filename}", xbmc.LOGWARNING)
            
            return {
                'path': current_video,
                'filename': filename,
                'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                'file_size': stat.st_size,
                'is_expected': False,
                'update_needed': True  # Pokud nemáme očekávaný soubor, aktualizace je potřeba
            }
        
        # 3. Žádný soubor nenalezen
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True  # Pokud nemáme žádný soubor, aktualizace je potřeba
        }
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání info o video souboru: {e}", xbmc.LOGERROR)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True
        }

def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    names = fetch_device_setup_name()
    if names:
        # API vrací seznam stringů, ne slovníků
        name_options = sorted(names, key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    localities = fetch_localities()
    if localities:
        locality_pairs = sorted(
            [(loc['name'], loc['code']) for loc in localities],
            key=lambda x: x[0].lower()
        )
        locality_options = [f"{name} ({code})" for name, code in locality_pairs]
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = locality_pairs[selected_locality][1]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    with open("/storage/.cache/hostname", "w") as f:
        f.write(name + "\n")

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    mark_reboot("setup")
    os.system("reboot")

def monitor_loop():
    global ws_connected, ws_app
    config = load_config()
    device_id = get_device_id()
    monitor = xbmc.Monitor()

    # Počkat na navázání WebSocket spojení (max 15 sekund)
    # Tím se vyhneme zbytečnému HTTP fallbacku při startu
    ws_wait_timeout = 15
    waited = 0
    while not ws_connected and waited < ws_wait_timeout and not stop_monitoring and not monitor.abortRequested():
        # Použít waitForAbort místo time.sleep - okamžitě se vrátí při abort
        if monitor.waitForAbort(1):
            return  # Kodi požaduje ukončení
        waited += 1
        # Logovat průběh čekání každých 5 sekund
        if waited % 5 == 0 and not ws_connected:
            xbmc.log(f"[Dohled] Čekám na WebSocket... {waited}s/{ws_wait_timeout}s", xbmc.LOGINFO)

    # Dát WebSocketu ještě chvíli na dokončení připojení
    if not ws_connected:
        if monitor.waitForAbort(1):
            return

    if ws_connected:
        xbmc.log(f"[Dohled] WebSocket připojen po {waited}s, spouštím monitoring", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] WebSocket timeout ({ws_wait_timeout}s), spouštím monitoring s HTTP fallback", xbmc.LOGWARNING)

    while not stop_monitoring and not monitor.abortRequested():
        global current_displayed_image
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            boot_time = get_boot_time()

            # Načíst očekávaný název souboru z API - bere v potaz device override!
            expected_filename, file_source = fetch_expected_file(device_id)
            expected_file_size = None

            # Fallback na FTP config pro velikost souboru (pouze pokud není device override)
            if file_source != "device":
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    expected_file_size = ftp_config.get("expected_file_size")
                    # Pokud fetch_expected_file selhal, použít FTP config
                    if not expected_filename:
                        expected_filename = ftp_config.get("file_name")

            # Speciální handling pro playlisty - nekontrolovat existenci souboru
            is_playlist = expected_filename and expected_filename.startswith("playlist:")

            # Global declaration musí být před jakýmkoliv použitím proměnné
            global current_mixed_playlist, current_mixed_playlist_position

            if is_playlist:
                # Pro playlist neověřujeme existenci souboru, update není potřeba
                xbmc.log(f"[Dohled] Playlist mode: {expected_filename}", xbmc.LOGINFO)
                last_modified = None
                file_size = None
                current_filename = expected_filename  # Ponechat celý playlist string
                update_needed = False

                # Parsovat playlist a nastavit globální proměnnou pro reporting
                # Formát: playlist:file1:dur1,file2,file3:dur3,...
                # ALE: Pouze pokud playlist ještě neběží (abychom nepřepisovali běžící playlist)
                if current_mixed_playlist_position < 0:
                    # Playlist neběží, nastavit pro monitoring
                    playlist_str = expected_filename[9:]  # Odstranit "playlist:" prefix
                    parsed_files = []
                    for item in playlist_str.split(','):
                        item = item.strip()
                        if not item:
                            continue
                        # Formát: "filename" nebo "filename:duration"
                        last_colon = item.rfind(':')
                        if last_colon > 0:
                            possible_duration = item[last_colon+1:]
                            if possible_duration.isdigit():
                                parsed_files.append(item[:last_colon])
                            else:
                                parsed_files.append(item)
                        else:
                            parsed_files.append(item)
                    if parsed_files:
                        current_mixed_playlist = parsed_files
                        xbmc.log(f"[Dohled] Mixed playlist nastaven (zdroj: {file_source}): {current_mixed_playlist}", xbmc.LOGINFO)
            else:
                # Standardní logika pro jednotlivé soubory
                # === DŮLEŽITÉ: Vymazat starý playlist pokud se přepnulo z playlist na single file ===
                # Jinak state_update_loop bude posílat staré soubory z playlistu
                # ALE: Respektovat uživatelem manuálně spuštěný playlist!
                if current_mixed_playlist:
                    # Pokud user_initiated_file je playlist, NEMAZAT - uživatel ho spustil manuálně
                    if user_initiated_file and user_initiated_file.startswith('playlist:'):
                        xbmc.log(f"[Dohled] Zachovávám user-initiated playlist: {current_mixed_playlist}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"[Dohled] Očekávaný soubor není playlist - mažu starý playlist: {current_mixed_playlist}", xbmc.LOGINFO)
                        current_mixed_playlist = []
                        current_mixed_playlist_position = -1

                video_info = get_video_file_info(expected_filename, expected_file_size)

                last_modified = video_info['last_modified']
                file_size = video_info['file_size']
                current_filename = video_info['filename']
                update_needed = video_info['update_needed']

                # Logování pro debug
                if update_needed:
                    if video_info['is_expected']:
                        reason = "velikost se neshoduje"
                    elif current_filename:
                        reason = f"název se liší (aktuální: {current_filename}, očekávaný: {expected_filename})"
                    else:
                        reason = "žádný soubor nenalezen"
                    xbmc.log(f"[Dohled] Aktualizace potřeba - důvod: {reason}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[Dohled] Soubor je aktuální: {current_filename}", xbmc.LOGINFO)

                    # Zkontrolovat jestli se přehrává správný soubor
                    # Pokud ne, spustit přehrávání očekávaného souboru
                    # ALE: Přeskočit auto-play pokud běží uživatelem spuštěný playlist
                    if current_mixed_playlist:
                        # Playlist běží, nepřepisovat ho souborem z lokality
                        pass
                    else:
                        player_check = xbmc.Player()
                        is_slideshow = xbmc.getCondVisibility("Slideshow.IsActive")
                        is_playing_video = player_check.isPlayingVideo()
                        # Také zkontrolovat náš vlastní tracking pro obrázky zobrazené přes ShowPicture
                        is_showing_image = current_displayed_image is not None
                        is_playing_anything = is_playing_video or is_slideshow or is_showing_image

                        playing_now = None
                        if is_playing_video:
                            try:
                                playing_now = os.path.basename(player_check.getPlayingFile())
                            except:
                                pass
                        elif is_showing_image:
                            playing_now = current_displayed_image

                        expected_basename = os.path.basename(expected_filename) if expected_filename else None
                        if expected_basename and current_filename == expected_basename:
                            # Zkontrolovat jestli přehráváme správný soubor
                            needs_play = False
                            if user_stopped:
                                # Uživatel manuálně zastavil - nespouštět automaticky
                                xbmc.log("[Dohled] Auto-play přeskočen - uživatel zastavil přehrávání", xbmc.LOGINFO)
                                needs_play = False
                            elif pending_new_content:
                                # Nový obsah čeká na restart - nespouštět automaticky
                                xbmc.log("[Dohled] Auto-play přeskočen - nový obsah čeká na restart", xbmc.LOGINFO)
                                needs_play = False
                            elif not is_playing_anything:
                                needs_play = True  # Nic nehraje
                            elif playing_now and playing_now != expected_basename and playing_now != user_initiated_file:
                                # Hraje špatný soubor - ALE respektovat uživatelem ručně spuštěný obsah
                                # Také zkontrolovat zda playing_now není součástí user-initiated playlistu
                                # DŮLEŽITÉ: Použít current_mixed_playlist (list) pro správnou membership check, ne substring match!
                                if user_initiated_file and user_initiated_file.startswith('playlist:') and current_mixed_playlist and playing_now in current_mixed_playlist:
                                    xbmc.log(f"[Dohled] Auto-play přeskočen - {playing_now} je součástí user-initiated playlistu", xbmc.LOGINFO)
                                    needs_play = False
                                else:
                                    needs_play = True

                            # Speciální případ: Očekáváme video, ale je zobrazen obrázek
                            # ALE: Respektovat uživatelem ručně puštěný soubor, manuální stop, pending_new_content a user-initiated playlist
                            user_initiated_is_playlist = user_initiated_file and user_initiated_file.startswith('playlist:')
                            # DŮLEŽITÉ: Použít current_mixed_playlist (list) pro správnou membership check, ne substring match!
                            image_in_user_playlist = user_initiated_is_playlist and current_displayed_image and current_mixed_playlist and current_displayed_image in current_mixed_playlist
                            if not user_stopped and not pending_new_content and not user_initiated_is_playlist and is_showing_image and is_video_file(expected_basename) and user_initiated_file != current_displayed_image:
                                xbmc.log(f"[Dohled] Auto-play: Video očekáváno, ale zobrazen obrázek {current_displayed_image}", xbmc.LOGINFO)
                                local_path = get_local_media_path(expected_basename)

                                # NEJDŘÍVE zavřít obrázek pomocí spolehlivé funkce
                                close_image_viewer()

                                # Pak spustit video (pokud existuje)
                                if os.path.exists(local_path):
                                    xbmc.log(f"[Dohled] Auto-play: Spouštím video {expected_basename}", xbmc.LOGINFO)
                                    player_check.play(local_path)
                                    # Počkat až video začne hrát (max 2s)
                                    for _ in range(20):
                                        if player_check.isPlayingVideo():
                                            break
                                        time.sleep(0.1)
                                    xbmc.executebuiltin("PlayerControl(RepeatOne)")

                                # Okamžité odeslání stavu
                                time.sleep(0.3)
                                send_immediate_state_update(expected_basename, playing=True, paused=False)
                                needs_play = False  # Už jsme to vyřešili

                            if needs_play:
                                local_path = get_local_media_path(expected_basename)
                                if os.path.exists(local_path):
                                    xbmc.log(f"[Dohled] Auto-play: Spouštím {expected_basename} (aktuálně hraje: {playing_now})", xbmc.LOGINFO)
                                    if is_image_file(expected_basename):
                                        # Video → Obrázek: nejdřív zobrazit obrázek, pak zastavit video
                                        if is_playing_video:
                                            if show_picture_safe(local_path):
                                                current_displayed_image = expected_basename
                                            else:
                                                current_displayed_image = None
                                            time.sleep(0.2)
                                            player_check.stop()
                                        else:
                                            if show_picture_safe(local_path):
                                                current_displayed_image = expected_basename
                                            else:
                                                current_displayed_image = None
                                        if current_displayed_image:
                                            send_immediate_state_update(expected_basename, playing=True, paused=False)
                                    else:
                                        # Spustit video - nejdřív zavřít obrázek pokud je zobrazen
                                        if current_displayed_image is not None:
                                            close_image_viewer()  # Spolehlivě zavře obrázek před videem
                                        player_check.play(local_path)
                                        time.sleep(0.5)
                                        xbmc.executebuiltin("PlayerControl(RepeatOne)")
                                        send_immediate_state_update(expected_basename, playing=True, paused=False)

            next_reboot = get_next_reboot()
            last_reboot = get_last_reboot_date()

            player = xbmc.Player()
            is_playing_video = player.isPlayingVideo()
            playing_file = player.getPlayingFile() if is_playing_video else None

            # Detekce slideshow
            is_slideshow_active = xbmc.getCondVisibility("Slideshow.IsActive")
            slideshow_position = None
            slideshow_total = None
            slideshow_current_picture = None

            if is_slideshow_active:
                slideshow_current_picture = xbmc.getInfoLabel("Slideshow.CurrentPicture")
                # Slideshow pozici získáme z InfoLabel
                try:
                    slideshow_position = int(xbmc.getInfoLabel("Slideshow.CurrentSlide") or 0)
                    slideshow_total = int(xbmc.getInfoLabel("Slideshow.CountSlide") or 0)
                except (ValueError, TypeError):
                    slideshow_position = 1
                    slideshow_total = 1

            # Určení typu média - včetně obrázků zobrazených přes ShowPicture
            # (global current_displayed_image už je deklarován na začátku while loopu)

            # Přečíst info z service.smycky (pokud něco přehrává)
            smycky_playing = get_smycky_current_playing()

            # V playlist módu použít konzistentní filename z playlistu podle pozice
            if is_playlist and current_mixed_playlist and current_mixed_playlist_position >= 0:
                if current_mixed_playlist_position < len(current_mixed_playlist):
                    current_filename = current_mixed_playlist[current_mixed_playlist_position]
                    # Určit media type podle souboru
                    if is_video_file(current_filename):
                        media_type = "video"
                        # POZNÁMKA: Neresetovat current_displayed_image zde!
                        # Monitoring pouze čte stav, nemodifikuje ho.
                        # Reset se dělá v execute_command při play_file.
                    elif is_image_file(current_filename):
                        media_type = "image"
                    else:
                        media_type = "video"  # Fallback
            elif is_playing_video:
                media_type = "video"
                # POZNÁMKA: Neresetovat current_displayed_image zde!
                # Monitoring pouze čte stav, nemodifikuje ho.
                # Dřívější reset způsoboval desync mezi trackingem a realitou.
                if smycky_playing and is_video_file(smycky_playing):
                    current_filename = smycky_playing
                elif playing_file:
                    current_filename = os.path.basename(playing_file)
            elif is_slideshow_active:
                if slideshow_total and slideshow_total > 1:
                    media_type = "slideshow"
                else:
                    media_type = "image"
                # Pro slideshow použít aktuální obrázek
                if slideshow_current_picture:
                    current_filename = slideshow_current_picture.split('/')[-1]
                    playing_file = slideshow_current_picture
            elif current_displayed_image:
                # Obrázek zobrazený přes ShowPicture z service.dohled
                media_type = "image"
                playing_file = get_local_media_path(current_displayed_image)
                current_filename = current_displayed_image
            elif smycky_playing and is_image_file(smycky_playing):
                # Obrázek zobrazený z service.smycky
                media_type = "image"
                playing_file = get_local_media_path(smycky_playing)
                current_filename = smycky_playing
            else:
                media_type = None

            # Zjistit, zda něco hraje (video, slideshow nebo statický obrázek)
            is_playing_actual = is_playing_video or is_slideshow_active or (current_displayed_image is not None) or (smycky_playing and is_image_file(smycky_playing))

            is_paused = xbmc.getCondVisibility("Player.Paused")

            # Debouncing pro playing=false (stejná logika jako v state_update_loop)
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            global last_playing_true_time
            current_time = time.time()
            PLAYING_FALSE_TOLERANCE = 5

            if is_playing_actual:
                last_playing_true_time = current_time
                is_playing = True
            else:
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    is_playing = True  # Stále v toleranci
                else:
                    is_playing = False

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] isPlaying: {is_playing}, Paused: {is_paused}, File: {playing_file}, MediaType: {media_type}, WS: {ws_connected}", xbmc.LOGINFO)

            # Získat seznam lokálních video souborů
            local_files = get_local_video_files()

            # Získat info o playlistu
            playlist_items = get_current_playlist()
            playlist_position = get_playlist_position()

            # Získat info o úložišti
            storage_info = get_storage_info()

            payload = {
                "device_id": device_id,
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": boot_time,
                "next_reboot": next_reboot,
                "last_reboot": last_reboot,
                "locality": locality,
                "playing": is_playing,
                "playing_file": playing_file,
                "paused": is_paused,
                "addon_version": ADDON_VERSION,
                "smycky_version": get_smycky_version(),
                "current_filename": current_filename,
                "expected_filename": expected_filename,
                "update_needed": update_needed,
                "local_files": local_files,
                "ws_connected": ws_connected,
                "playlist": playlist_items,
                "playlist_position": playlist_position,
                "storage": storage_info,
                # Nová pole pro obrázky a slideshow
                "media_type": media_type,  # "video", "image", "slideshow" nebo None
                "slideshow_position": slideshow_position,  # aktuální pozice v slideshow
                "slideshow_total": slideshow_total,  # celkový počet obrázků v slideshow
                "slideshow_current_picture": slideshow_current_picture  # název aktuálního obrázku
            }

            # Zkusit odeslat přes WebSocket, jinak HTTP fallback
            sent_via_ws = False
            if ws_connected and ws_app:
                try:
                    ws_app.send(json.dumps({
                        "type": "monitoring",
                        "payload": payload
                    }))
                    sent_via_ws = True
                    xbmc.log("[Dohled] Monitoring data odeslána přes WebSocket", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání přes WS, použiji HTTP: {e}", xbmc.LOGWARNING)

            if not sent_via_ws:
                # HTTP fallback
                url = "https://apidohled.noreason.eu/api/monitoring"
                response = send_data(payload, url)

                # Zpracovat odpověď serveru
                if response and response.get("status") == "saved":
                    server_update_needed = response.get("update_needed")
                    if server_update_needed != update_needed:
                        xbmc.log(f"[Dohled] Server přepsal update_needed: {update_needed} -> {server_update_needed}", xbmc.LOGINFO)

                    # Piggyback příkazy - server může poslat příkaz v odpovědi na monitoring
                    piggyback_command = response.get("command")
                    if piggyback_command:
                        piggyback_params = response.get("command_params")
                        xbmc.log(f"[Dohled] Piggyback příkaz z monitoring odpovědi: {piggyback_command}", xbmc.LOGINFO)
                        execute_command(piggyback_command, piggyback_params)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        # Monitoring interval: 30 sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_MONITORING_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break


def send_immediate_state_update(filename, playing=True, paused=False):
    """
    Okamžité odeslání state update po změně souboru.
    Volat po přepnutí souboru pro rychlou aktualizaci dashboardu.

    DŮLEŽITÉ: Má HTTP fallback pro garantované doručení při výpadku WS.
    """
    global ws_connected, ws_app, last_filename, last_playing_state, last_paused_state, last_stopped_content

    # Zjistit zda lze obnovit přehrávání (pro zelené tlačítko play)
    can_resume = last_stopped_content is not None and bool(last_stopped_content)

    payload = {
        "playing": playing,
        "paused": paused,
        "current_filename": filename,
        "can_resume": can_resume,
        "user_initiated_file": user_initiated_file  # Pro API - nastaví UserInitiatedPlayback
    }

    sent = False

    # 1. Zkusit WebSocket (nejrychlejší)
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "state_update",
                "payload": payload
            }))
            sent = True
            xbmc.log(f"[Dohled] Immediate state update odeslán přes WS: {filename}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] WS send failed, zkouším HTTP fallback: {e}", xbmc.LOGWARNING)

    # 2. HTTP fallback - garantované doručení při změně stavu
    if not sent:
        try:
            config = load_config()
            device_id = get_device_id()

            # Získat IP adresu pro HTTP fallback
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                ip_address = s.getsockname()[0]
                s.close()
            except:
                ip_address = "unknown"

            # Payload pro state update - MUSÍ obsahovat name a ip_address (povinná pole API)
            # Také musí obsahovat update_needed aby dashboard správně zobrazoval stav
            base_filename = os.path.basename(filename) if filename else ""
            http_payload = {
                "device_id": device_id,
                "name": config.get("name", "unknown"),
                "ip_address": ip_address,
                "locality": config.get("locality", ""),
                "playing": playing,
                "playing_file": filename,
                "paused": paused,
                "current_filename": base_filename,
                "update_needed": False,  # Když přehráváme, update není potřeba
                "can_resume": can_resume,
                "ws_connected": False,  # Indikace že jdeme přes HTTP
                "state_update_only": True  # Server může zpracovat jako lehký update
            }

            url = "https://apidohled.noreason.eu/api/monitoring"
            response = send_data(http_payload, url)
            if response:
                sent = True
                xbmc.log(f"[Dohled] Immediate state update odeslán přes HTTP fallback: {filename}", xbmc.LOGINFO)
            else:
                xbmc.log("[Dohled] HTTP fallback selhal", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba HTTP fallback: {e}", xbmc.LOGERROR)

    # Aktualizovat poslední známý stav
    if sent:
        last_filename = filename
        last_playing_state = playing
        last_paused_state = paused

    return sent


def state_update_loop():
    """
    Rychlá smyčka pro aktualizaci stavu přehrávání.
    - Kontroluje stav každé WS_STATE_CHECK_INTERVAL sekund (rychlá detekce změn)
    - Odesílá pouze při ZMĚNĚ stavu nebo po WS_STATE_HEARTBEAT_INTERVAL sekundách (heartbeat)
    - Používá debouncing pro playing=false (5 sekund tolerance pro přechody smyčky)
    - HTTP FALLBACK: Když WS není připojen, odesílá přes HTTP s throttlingem (10s)
    """
    global last_playing_state, last_paused_state, last_filename, ws_connected, ws_app, last_playing_true_time

    # Tolerance pro přechod mezi videi ve smyčce (sekundy)
    PLAYING_FALSE_TOLERANCE = 5

    # HTTP fallback throttling - nechceme zahltit server HTTP requesty
    HTTP_FALLBACK_INTERVAL = 10  # Sekund mezi HTTP requesty když WS není k dispozici

    # Čas posledního odeslání (pro heartbeat)
    last_send_time = 0
    last_http_send_time = 0  # Pro HTTP fallback throttling
    monitor = xbmc.Monitor()

    # Inicializace last_filename z disku pokud je None (při startu addonu)
    if last_filename is None:
        try:
            video_path = find_current_video_file()
            if video_path:
                last_filename = os.path.basename(video_path)
                xbmc.log(f"[Dohled] Inicializace last_filename z disku: {last_filename}", xbmc.LOGINFO)
        except:
            pass

    xbmc.log(f"[Dohled] State update smyčka: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)

    while not stop_monitoring and not monitor.abortRequested():
        try:
            # Zapsat heartbeat pro externí watchdog (vždy, i bez WS)
            write_heartbeat()

            # Zjistit aktuální stav (vždy, i bez WS - pro HTTP fallback)
            player = xbmc.Player()
            is_playing_video = player.isPlayingVideo()
            is_slideshow_active = xbmc.getCondVisibility("Slideshow.IsActive")

            # Přečíst info z service.smycky (pokud něco přehrává)
            smycky_playing = get_smycky_current_playing()

            # Detekce obrázků zobrazených přes ShowPicture
            # (global current_displayed_image už je deklarován na začátku while loopu)
            showing_image = (current_displayed_image is not None) or (smycky_playing and is_image_file(smycky_playing))

            # Je něco přehráváno/zobrazeno?
            is_playing_actual = is_playing_video or is_slideshow_active or showing_image

            is_paused = xbmc.getCondVisibility("Player.Paused") if is_playing_video else False

            # Určit aktuální soubor a pozici
            global current_mixed_playlist, current_mixed_playlist_position
            playlist_position = None

            # V playlist módu použít konzistentní data z playlistu
            if current_mixed_playlist and current_mixed_playlist_position >= 0:
                if current_mixed_playlist_position < len(current_mixed_playlist):
                    current_file = current_mixed_playlist[current_mixed_playlist_position]
                    playlist_position = current_mixed_playlist_position
                else:
                    current_file = last_filename
            elif is_playing_video:
                current_file = player.getPlayingFile().split('/')[-1]
                # Pokud service.smycky hlásí video, použít to (má správný název)
                if smycky_playing and is_video_file(smycky_playing):
                    current_file = smycky_playing
            elif current_displayed_image:
                current_file = current_displayed_image
            elif smycky_playing and is_image_file(smycky_playing):
                current_file = smycky_playing
            elif is_slideshow_active:
                slideshow_pic = xbmc.getInfoLabel("Slideshow.CurrentPicture")
                current_file = slideshow_pic.split('/')[-1] if slideshow_pic else last_filename
            else:
                # Nic nehraje - zachovat poslední známý soubor
                current_file = last_filename

            # Debouncing pro playing=false
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            # Reportujeme playing=false až po PLAYING_FALSE_TOLERANCE sekundách
            current_time = time.time()

            if is_playing_actual:
                # Aktualizovat čas posledního playing=true
                last_playing_true_time = current_time
                is_playing = True
            else:
                # playing je false - zkontrolovat toleranci
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    # Stále v toleranci - reportovat jako playing=true (pravděpodobně jen přechod smyčky)
                    is_playing = True
                else:
                    # Mimo toleranci - skutečně není playing
                    is_playing = False

            # Detekce změny stavu
            state_changed = (
                is_playing != last_playing_state or
                is_paused != last_paused_state or
                current_file != last_filename
            )

            # Heartbeat - odeslat i bez změny po určitém čase
            time_since_last_send = current_time - last_send_time
            heartbeat_needed = time_since_last_send >= WS_STATE_HEARTBEAT_INTERVAL

            # Připravit payload (společný pro WS i HTTP)
            can_resume = last_stopped_content is not None and bool(last_stopped_content)
            payload = {
                "playing": is_playing,
                "paused": is_paused,
                "current_filename": current_file,
                "can_resume": can_resume,
                "user_initiated_file": user_initiated_file
            }
            if playlist_position is not None:
                payload["playlist_position"] = playlist_position

            # 1. POKUS O WS - rychlý update každé 2s při změně nebo heartbeat
            if ws_connected and ws_app and (state_changed or heartbeat_needed):
                try:
                    if user_initiated_file:
                        xbmc.log(f"[Dohled] DEBUG state_update: user_initiated_file={user_initiated_file}", xbmc.LOGINFO)
                    ws_app.send(json.dumps({
                        "type": "state_update",
                        "payload": payload
                    }))
                    last_send_time = current_time

                    if state_changed:
                        xbmc.log(f"[Dohled] Změna stavu (WS): playing={is_playing}, paused={is_paused}, file={current_file}", xbmc.LOGINFO)

                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání state update přes WS: {e}", xbmc.LOGWARNING)

            # 2. HTTP FALLBACK - když WS není k dispozici
            elif not ws_connected or not ws_app:
                # Při změně stavu odeslat okamžitě, jinak throttlovat na HTTP_FALLBACK_INTERVAL
                time_since_http = current_time - last_http_send_time
                http_needed = state_changed or (time_since_http >= HTTP_FALLBACK_INTERVAL)

                if http_needed:
                    try:
                        config = load_config()
                        device_id = get_device_id()

                        # Získat IP adresu pro HTTP fallback
                        try:
                            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                            s.connect(("8.8.8.8", 80))
                            ip_address = s.getsockname()[0]
                            s.close()
                        except:
                            ip_address = "unknown"

                        # Payload MUSÍ obsahovat name a ip_address (povinná pole API)
                        # Také musí obsahovat update_needed aby dashboard správně zobrazoval stav
                        # Když přehráváme správný soubor, není potřeba update
                        base_filename = os.path.basename(current_file) if current_file else ""
                        http_payload = {
                            "device_id": device_id,
                            "name": config.get("name", "unknown"),
                            "ip_address": ip_address,
                            "locality": config.get("locality", ""),
                            "playing": is_playing,
                            "playing_file": current_file,
                            "paused": is_paused,
                            "current_filename": base_filename,
                            "update_needed": False,  # Když přehráváme, update není potřeba
                            "can_resume": can_resume,
                            "ws_connected": False,
                            "state_update_only": True
                        }

                        url = "https://apidohled.noreason.eu/api/monitoring"
                        response = send_data(http_payload, url)
                        if response:
                            last_http_send_time = current_time
                            last_send_time = current_time
                            xbmc.log(f"[Dohled] HTTP fallback odeslán: playing={is_playing}, file={current_file}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba HTTP fallback v state update: {e}", xbmc.LOGWARNING)

            # Uložit poslední stav
            last_playing_state = is_playing
            last_paused_state = is_paused
            last_filename = current_file

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v state update loop: {e}", xbmc.LOGERROR)

        # Čekat na další kontrolu - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_STATE_CHECK_INTERVAL):
            break  # Kodi požaduje ukončení


# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}


# ======= STARTUP SEKVENCE (nahrazuje service.smycky) =======

def startup_playback():
    """
    Spustí přehrávání při startu zařízení.
    Nahrazuje funkcionalitu service.smycky.
    """
    global current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, current_displayed_image

    xbmc.log("[Dohled] === Spuštění přehrávání při startu ===", xbmc.LOGINFO)

    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")
        device_id = get_device_id()

        if not locality:
            xbmc.log("[Dohled] Startup: Locality není nastavena, přeskakuji přehrávání", xbmc.LOGWARNING)
            return

        xbmc.log(f"[Dohled] Startup: Locality={locality}, DeviceID={device_id}", xbmc.LOGINFO)

        # 2. Získat očekávaný soubor (device override nebo locality)
        # Předáváme locality jako fallback pro nová zařízení bez záznamu v DB
        expected_file, source = fetch_expected_file_with_locality(device_id, locality)

        if not expected_file:
            xbmc.log("[Dohled] Startup: Žádný očekávaný soubor, zkouším fallback", xbmc.LOGWARNING)
            fallback = find_best_fallback_file()
            if fallback:
                xbmc.log(f"[Dohled] Startup: Přehrávám fallback: {fallback}", xbmc.LOGINFO)
                play_media_file(fallback)
            return

        xbmc.log(f"[Dohled] Startup: Očekávaný soubor '{expected_file}' (zdroj: {source})", xbmc.LOGINFO)

        # 3. Zkontrolovat zda je playlist
        if expected_file.startswith("playlist:"):
            # Playlist mode
            playlist_content = expected_file[9:]  # Odstranit "playlist:" prefix
            xbmc.log(f"[Dohled] Startup: Detekován playlist: {playlist_content}", xbmc.LOGINFO)

            # Parsovat playlist
            playlist_items = parse_playlist_string(playlist_content)
            if not playlist_items:
                xbmc.log("[Dohled] Startup: Playlist je prázdný", xbmc.LOGWARNING)
                return

            # Kontrola a stažení souborů z playlistu
            ftp_config = fetch_ftp_config(locality)
            valid_files = []

            for item in playlist_items:
                filename = item['filename']
                local_path = get_local_media_path(filename)

                # Zkontrolovat zda soubor existuje lokálně
                if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
                    valid_files.append(item)
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} existuje lokálně", xbmc.LOGINFO)
                elif ftp_config:
                    # Zkusit stáhnout z FTP
                    xbmc.log(f"[Dohled] Startup: Stahuji {filename} z FTP", xbmc.LOGINFO)
                    if download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        filename,
                        local_path
                    ):
                        valid_files.append(item)
                    else:
                        xbmc.log(f"[Dohled] Startup: Nepodařilo se stáhnout {filename}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} nenalezen a FTP není dostupné", xbmc.LOGWARNING)

            if not valid_files:
                xbmc.log("[Dohled] Startup: Žádné platné soubory v playlistu", xbmc.LOGERROR)
                fallback = find_best_fallback_file()
                if fallback:
                    play_media_file(fallback)
                return

            # Spustit playlist
            xbmc.log(f"[Dohled] Startup: Spouštím playlist s {len(valid_files)} soubory", xbmc.LOGINFO)
            start_mixed_playlist_startup(valid_files)

        else:
            # Single file mode
            local_path = get_local_media_path(expected_file)

            # 4. Zkontrolovat zda soubor existuje a je aktuální
            needs_download = False

            if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
                needs_download = True
                xbmc.log(f"[Dohled] Startup: Soubor {expected_file} neexistuje lokálně", xbmc.LOGINFO)
            else:
                # Zkontrolovat zda je na FTP novější verze
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    remote_time, remote_size = get_remote_file_info(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file
                    )
                    local_time, local_size = get_local_file_info(local_path)

                    if remote_time and remote_size:
                        if remote_size != local_size or remote_time > local_time + 60:
                            needs_download = True
                            xbmc.log(f"[Dohled] Startup: Na FTP je novější verze souboru", xbmc.LOGINFO)

            # 5. Stáhnout pokud potřeba
            if needs_download:
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    xbmc.log(f"[Dohled] Startup: Stahuji {expected_file} z FTP", xbmc.LOGINFO)
                    download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file,
                        local_path
                    )
                else:
                    xbmc.log("[Dohled] Startup: FTP konfigurace není dostupná", xbmc.LOGWARNING)

            # 6. Přehrát soubor
            file_to_play = get_best_available_file(local_path)
            if file_to_play:
                xbmc.log(f"[Dohled] Startup: Přehrávám {file_to_play}", xbmc.LOGINFO)
                play_media_file(file_to_play)
            else:
                xbmc.log("[Dohled] Startup: Žádný soubor k přehrání!", xbmc.LOGERROR)
                xbmcgui.Dialog().notification("Chyba", "Žádný soubor k přehrání", xbmcgui.NOTIFICATION_ERROR, 5000)

    except Exception as e:
        xbmc.log(f"[Dohled] Startup: Chyba - {e}", xbmc.LOGERROR)
        # Zkusit fallback
        fallback = find_best_fallback_file()
        if fallback:
            xbmc.log(f"[Dohled] Startup: Používám fallback po chybě: {fallback}", xbmc.LOGWARNING)
            play_media_file(fallback)


def start_mixed_playlist_startup(playlist_items):
    """Spustí přehrávání mixed playlistu při startu."""
    global current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, current_displayed_image, mixed_playlist_thread

    # Inkrementovat playlist ID
    current_playlist_id += 1
    my_playlist_id = current_playlist_id

    # Nastavit globální playlist pro monitoring
    current_mixed_playlist = [item['filename'] for item in playlist_items]
    current_mixed_playlist_position = 0

    xbmc.log(f"[Dohled] Start mixed playlist ID={my_playlist_id}: {current_mixed_playlist}", xbmc.LOGINFO)

    def is_my_playlist_active():
        return current_playlist_id == my_playlist_id

    def mixed_playback_loop():
        global current_displayed_image, current_mixed_playlist_position

        player = xbmc.Player()
        current_index = 0

        # Speciální případ: jeden soubor
        if len(playlist_items) == 1:
            item = playlist_items[0]
            file_path = get_local_media_path(item['filename'])

            if is_video_file(item['filename']):
                RepeatVideo(file_path)
            else:
                ShowImage(file_path)
                current_displayed_image = item['filename']
                # Čekat dokud není playlist změněn
                while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                    time.sleep(1)
            return

        # Loop přes všechny soubory
        is_first_item = True  # První položka nepotřebuje overlay

        while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
            item = playlist_items[current_index]
            file_path = get_local_media_path(item['filename'])
            current_mixed_playlist_position = current_index

            if not os.path.exists(file_path):
                xbmc.log(f"[Dohled] Mixed playlist: soubor neexistuje {item['filename']}", xbmc.LOGWARNING)
                current_index = (current_index + 1) % len(playlist_items)
                continue

            if is_video_file(item['filename']):
                # Video - přehrát jednou
                xbmc.log(f"[Dohled] Mixed: video {item['filename']}", xbmc.LOGINFO)

                # KRITICKÉ: Ujistit se, že je image viewer zavřený před spuštěním videa
                # Bez tohoto může obrázek zůstat zobrazený a video běžet pod ním
                if current_displayed_image is not None:
                    close_image_viewer()  # Spolehlivě zavře obrázek (Dialog.Close + Stop + home)

                # Ujistit se, že předchozí video je zastaveno (video→video přechod)
                wait_for_player_stop(timeout=2.0)

                player.play(file_path)
                time.sleep(0.5)
                is_first_item = False

                # Čekat na konec videa
                while player.isPlaying() and is_my_playlist_active():
                    time.sleep(0.5)

                if not is_my_playlist_active():
                    break

            else:
                # Obrázek - zobrazit na dobu duration
                duration = item.get('duration') or DEFAULT_IMAGE_DISPLAY_TIME
                xbmc.log(f"[Dohled] Mixed: obrázek {item['filename']} ({duration}s)", xbmc.LOGINFO)

                # VŽDY zastavit video před zobrazením obrázku
                # player.isPlaying() může selhat v přechodových stavech
                try:
                    player.stop()
                except:
                    pass
                # KRITICKÉ: Čekat na úplné zastavení playeru před zobrazením obrázku
                # Bez tohoto čekání může video "běžet na pozadí" během zobrazení obrázku
                wait_for_player_stop(timeout=3.0)

                if show_picture_safe(file_path):
                    current_displayed_image = item['filename']
                else:
                    current_displayed_image = None
                is_first_item = False

                # Čekat zadanou dobu nebo dokud není playlist změněn
                for _ in range(duration * 2):
                    if not is_my_playlist_active():
                        break
                    time.sleep(0.5)

                if not is_my_playlist_active():
                    break

                # Zavřít obrázek před dalším souborem
                next_idx = (current_index + 1) % len(playlist_items)
                next_item = playlist_items[next_idx]
                if is_video_file(next_item['filename']):
                    close_image_viewer()  # Úplné zavření pro přechod na video
                else:
                    dismiss_image()  # Jen Dialog.Close pro obrázek→obrázek
                    current_displayed_image = None

            current_index = (current_index + 1) % len(playlist_items)
            current_mixed_playlist_position = current_index  # Aktualizovat pozici ihned

        # Cleanup
        current_displayed_image = None
        xbmc.log(f"[Dohled] Mixed playlist ID={my_playlist_id} ukončen", xbmc.LOGINFO)

    # Spustit ve vlákně
    mixed_playlist_thread = threading.Thread(target=mixed_playback_loop, daemon=True)
    mixed_playlist_thread.start()


def main():
    global ws_thread

    xbmc.log("[Dohled] === Spuštění doplňku Dohled ===", xbmc.LOGINFO)

    # Cleanup: Smazat zastaralý current_playing.txt od service.smycky
    # Od verze 2.7.0 service.dohled přebírá přehrávání, tento soubor už není potřeba
    # a může obsahovat stará data která způsobují chybné reportování
    if os.path.exists(CURRENT_PLAYING_FILE):
        try:
            os.remove(CURRENT_PLAYING_FILE)
            xbmc.log(f"[Dohled] Smazán zastaralý {CURRENT_PLAYING_FILE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[Dohled] Nelze smazat {CURRENT_PLAYING_FILE}: {e}", xbmc.LOGWARNING)

    # PRVNÍ KROK: Synchronizace času (před čímkoli jiným)
    ensure_time_synchronized()

    # ========================================
    # WATCHDOG DAEMON (automatický restart při pádu)
    # ========================================
    # Spustit watchdog jako oddělený daemon proces
    # Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi
    xbmc.log("[Dohled] === Spouštění watchdog daemonu ===", xbmc.LOGINFO)
    spawn_watchdog_daemon()

    # Aktualizace doplňků - spustit na pozadí aby neblokovala start
    # Na pomalých připojeních (WiFi) může trvat dlouho
    threading.Thread(target=force_update_addons, kwargs={'retry_count': 3, 'retry_delay': 15}, daemon=True).start()
    xbmc.log("[Dohled] Aktualizace addonů spuštěna na pozadí", xbmc.LOGINFO)

    # Načtení konfigurace
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    # Získat device_id pro komunikaci
    device_id = get_device_id()
    xbmc.log(f"[Dohled] Device ID: {device_id}", xbmc.LOGINFO)

    # Spuštění WebSocket connection loop (prioritní real-time kanál)
    if WEBSOCKET_AVAILABLE:
        ws_thread = threading.Thread(target=ws_connection_loop, args=(device_id,), daemon=True)
        ws_thread.start()
        xbmc.log("[Dohled] WebSocket connection loop spuštěn", xbmc.LOGINFO)

        # Spuštění rychlé state update smyčky (každé 2s, pouze přes WS)
        threading.Thread(target=state_update_loop, daemon=True).start()
        xbmc.log("[Dohled] Rychlá state update smyčka spuštěna (2s interval)", xbmc.LOGINFO)
    else:
        xbmc.log("[Dohled] WebSocket není dostupný, použije se pouze HTTP", xbmc.LOGWARNING)

    # Spuštění monitorovací smyčky (odesílá data každých 30s přes WS nebo HTTP)
    threading.Thread(target=monitor_loop, daemon=True).start()

    # Spuštění HTTP fallback pollingu příkazů (aktivní pouze když není WS)
    threading.Thread(target=command_polling_loop, args=(device_id,), daemon=True).start()

    # Spuštění periodické kontroly aktualizací addonů (každou hodinu, první za 5 minut)
    threading.Thread(target=addon_update_loop, daemon=True).start()
    xbmc.log("[Dohled] Periodická kontrola aktualizací spuštěna", xbmc.LOGINFO)

    # ========================================
    # ZAKÁZÁNÍ SCREENSAVERU (prevence ztlumení obrazovky)
    # ========================================
    xbmc.log("[Dohled] Zakázání screensaveru (InhibitScreensaver)", xbmc.LOGINFO)
    xbmc.executebuiltin('InhibitScreensaver(true)')

    # ========================================
    # STARTUP PŘEHRÁVÁNÍ (nahrazuje service.smycky)
    # ========================================
    xbmc.log("[Dohled] === Spuštění startup přehrávání ===", xbmc.LOGINFO)
    threading.Thread(target=startup_playback, daemon=True).start()

    # ========================================
    # KODI LOG MONITOR (detekce černé obrazovky)
    # ========================================
    global kodi_log_monitor
    xbmc.log("[Dohled] === Spuštění KodiLogMonitor ===", xbmc.LOGINFO)
    kodi_log_monitor = KodiLogMonitor()
    kodi_log_monitor.start()

    # ========================================
    # PLÁNOVÁNÍ RESTARTU
    # ========================================
    xbmc.log("[Dohled] === Plánování denního restartu ===", xbmc.LOGINFO)
    schedule_random_reboot()

    xbmc.log("[Dohled] === Inicializace dokončena ===", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] WebSocket: {'ANO' if WEBSOCKET_AVAILABLE else 'NE'}", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] State updates: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)
    xbmc.log("[Dohled] Startup přehrávání: ANO (nahrazuje service.smycky)", xbmc.LOGINFO)

    # ========================================
    # HLAVNÍ SMYČKA - ČEKÁNÍ NA ABORT
    # ========================================
    # KRITICKÉ: Tato smyčka je nutná pro správné ukončení addonu!
    # Bez ní Kodi nemůže gracefully zastavit addon a zabije ho po 5 sekundách.
    monitor = xbmc.Monitor()
    xbmc.log("[Dohled] Spouštím hlavní smyčku (čekám na abort)", xbmc.LOGINFO)

    while not monitor.abortRequested():
        # Čekat 1 sekundu, ale okamžitě se probudit při abort requestu
        if monitor.waitForAbort(1):
            break

    # ========================================
    # GRACEFUL SHUTDOWN
    # ========================================
    xbmc.log("[Dohled] === Ukončování addonu ===", xbmc.LOGINFO)

    # Nastavit stop_monitoring flag pro všechny vlákna
    stop_monitoring = True

    # Zavřít WebSocket spojení (toto probudí blokující run_forever)
    if ws_app:
        try:
            xbmc.log("[Dohled] Zavírám WebSocket spojení...", xbmc.LOGINFO)
            ws_app.close()
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při zavírání WS: {e}", xbmc.LOGWARNING)

    # Zastavit KodiLogMonitor
    if kodi_log_monitor:
        try:
            kodi_log_monitor.stop()
        except:
            pass

    xbmc.log("[Dohled] === Addon ukončen ===", xbmc.LOGINFO)


if __name__ == "__main__":
    main()