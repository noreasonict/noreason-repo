import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import json
import socket
import threading
import time
import urllib.request

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Získá čas posledního restartu ze systémového uptime
def get_boot_time():
    try:
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            boot_timestamp = time.time() - uptime_seconds
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(boot_timestamp))
    except:
        return None

# Načtení verze doplňku pro aktualizaci         
def get_smycky_version():
    try:
        with open("/storage/.kodi/userdata/smycky_version.txt", "r") as f:
            return f.read().strip()
    except:
        return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except:
        return None

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'}, method="POST")
        with urllib.request.urlopen(req) as response:
            xbmc.log(f"[Dohled] Odesláno na API, status: {response.status}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    # Výběr názvu zařízení
    names = fetch_device_setup_name()
    if names:
        name_options = sorted([n["name"] for n in names], key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    # Výběr lokality
    localities = fetch_localities()
    if localities:
        locality_options = sorted(
            [f"{loc['name']} ({loc['code']})" for loc in localities],
            key=lambda x: x.lower()
        )
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = localities[selected_locality]["code"]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    # Uložení konfigurace
    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    with open("/storage/.cache/hostname", "w") as f:
        f.write(name + "\n")

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    os.system("reboot")


# Smyčka monitorující stav zařízení
def monitor_loop():
    config = load_config()
    while not stop_monitoring:
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            boot_time = get_boot_time()

            video_path = "/storage/videos/Oresi_CZ.mp4"
            if os.path.exists(video_path):
                stat = os.stat(video_path)
                last_modified = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime))
                file_size = stat.st_size
            else:
                last_modified = None
                file_size = None

            next_reboot = get_next_reboot()

            player = xbmc.Player()
            is_playing = player.isPlayingVideo()
            playing_file = player.getPlayingFile() if is_playing else None

            is_paused = xbmc.getCondVisibility("Player.Paused")

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] isPlaying: {is_playing}, Paused: {is_paused}, File: {playing_file}", xbmc.LOGINFO)

            payload = {
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": boot_time,
                "next_reboot": next_reboot,
                "locality": locality,
                "playing": is_playing,
                "playing_file": playing_file,
                "paused": is_paused,
                "addon_version": ADDON_VERSION,
                "smycky_version": get_smycky_version()
            }

            url = "https://apidohled.noreason.eu/api/monitoring"
            send_data(payload, url)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        for _ in range(60):
            if stop_monitoring:
                break
            time.sleep(1)

# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}

# Hlavní spouštění doplňku
def main():
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    threading.Thread(target=monitor_loop, daemon=True).start()

if __name__ == "__main__":
    main()
