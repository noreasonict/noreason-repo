import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import socket
import threading
import time
import urllib.request
import urllib.parse
import urllib.error
import uuid
import queue
import subprocess
import ssl
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta, timezone
from ftplib import FTP
import random
import sqlite3
import re
import glob

# Přidat cestu k bundlované websocket knihovně
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
sys.path.insert(0, ADDON_PATH)

# Import websocket knihovny (bundlovaná s addonem)
try:
    import websocket
    WEBSOCKET_AVAILABLE = True
    xbmc.log("[Dohled] WebSocket knihovna načtena", xbmc.LOGINFO)
except ImportError:
    WEBSOCKET_AVAILABLE = False
    xbmc.log("[Dohled] WebSocket knihovna není dostupná, použije se HTTP fallback", xbmc.LOGWARNING)

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')
DEVICE_ID_FILE = os.path.join(PROFILE_DIR, 'device_id.txt')
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"  # Heartbeat pro externí watchdog
WATCHDOG_SCRIPT = "/storage/.kodi/temp/dohled_watchdog.py"  # Self-spawned watchdog daemon
WATCHDOG_PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"  # PID watchdogu
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# SSL kontext pro HTTPS na náš server - VŽDY ověřené certifikáty (3.6.0: bez fallbacku).
# Do 3.5.9 se při chybě TLS zkoušelo spojení BEZ ověření. Z logů flotily (27.10.2026):
# 291x šlo o UNEXPECTED_EOF (výpadek spojení - fallback byl jen opakování) a 4x o
# "certificate is not yet valid" při špatných hodinách (síť nebyla při startu, čas se
# nesynchronizoval). WebSocket fallback nikdy neměl a ověřené TLS mají všechna zařízení.
# Příčina špatného času se teď opravuje u zdroje: hlídání času (hlidat_cas) synchronizuje,
# dokud není čas OVĚŘENÝ, a chyba certifikátu způsobená hodinami (not yet valid / expired)
# v HTTP i WS spustí synchronizaci hned (pri_chybe_tls).
_ssl_context = ssl.create_default_context()


def get_ssl_context():
    return _ssl_context


def api_request(url, data=None, method=None, timeout=10):
    """HTTP request na náš server: Authorization: Bearer + ověřené TLS (R1)."""
    headers = {
        'Authorization': f'Bearer {API_KEY}'
    }
    if data is not None:
        headers['Content-Type'] = 'application/json'
        encoded = json.dumps(data).encode('utf-8') if isinstance(data, dict) else data
        req = urllib.request.Request(url, data=encoded, headers=headers, method=method or 'POST')
    else:
        req = urllib.request.Request(url, headers=headers, method=method or 'GET')
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl_context) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        pri_chybe_tls(e, "HTTP")   # certifikát "not yet valid"/"expired" -> synchronizace času
        raise

# WebSocket konfigurace
WS_URL = "wss://apidohled.noreason.eu/ws/"
WS_RECONNECT_INTERVAL = 5  # Sekund mezi pokusy o reconnect
WS_PING_INTERVAL = 30  # Sekund mezi ping zprávami
# Sekund - timeout socketu WebSocketu (TCP spojení, TLS i HTTP handshake). Knihovna bez něj čeká
# na handshake neomezeně: pokus o spojení rozjetý během výpadku sítě visel i po jejím obnovení
# (TCP opakuje až do tcp_retries2, ~15 min) a WS se obnovil až restartem Kodi (regrese 28.10.).
WS_SOCKET_TIMEOUT = 30
if WEBSOCKET_AVAILABLE:
    websocket.setdefaulttimeout(WS_SOCKET_TIMEOUT)

# Monotonic čas startu addonu - nezávislý na změnách systémového času (NTP sync)
# time.monotonic() je nezávislé na NTP/čase, takže můžeme později vypočítat správný boot_time
# Toto se změní při každém restartu Kodi (i bez rebootu celého systému)
ADDON_START_MONOTONIC = time.monotonic()
WS_MONITORING_INTERVAL = 30  # Sekund mezi plnými monitoring zprávami přes WebSocket
WS_STATE_CHECK_INTERVAL = 2  # Sekund mezi kontrolami stavu (rychlá detekce změn)
WS_STATE_HEARTBEAT_INTERVAL = 10  # Sekund - max interval pro heartbeat i bez změny stavu
LOG_UPLOAD_INTERVAL = 60  # Sekund mezi odesilanim logu na server
LOG_UPLOAD_MAX_SIZE = 500 * 1024  # Max 500 KB per upload
# Pozice v kodi.log při startu doplňku: upload posílá log od ní, tedy i start doplňku (časové
# pásmo, synchronizace času, watchdog). Do 3.6.2 se brala až v monitorovací smyčce po připojení
# WebSocketu a řádky ze startu se na server nedostaly nikdy (31.10.2026: přepnutí pásma 08-20).
LOG_UPLOAD_ZACATEK = None

# Správa úložiště
VIDEO_DIR = "/storage/videos/"
IMAGE_DIR = "/storage/pictures/"  # Obrázky patří do /storage/pictures/, ne videos!
# Staging složka pro stahování. MUSÍ být na stejném filesystému jako VIDEO_DIR/IMAGE_DIR.
# NESMÍ být /tmp - to je na Kodi boxu tmpfs v RAM (~512 MB), velké soubory se tam nevejdou
# (1GB video -> [Errno 28] No space left on device). /storage má desítky GB volných.
DOWNLOAD_STAGING_DIR = "/storage/"

# Zámky stahování PER SOUBOR. Dvě vlákna (download_only z nastavení souboru lokality
# + download_and_play od technika) stahovala TÝŽ soubor do TÉHOŽ staging souboru
# .downloading_<název>, vzájemně si ho přepsala/odstranila -> přehrání selhalo a auto-play
# zůstal zablokovaný (nalezeno 2.9.2026 testem V23). Druhé vlákno teď počká a když už je
# soubor stažený ve správné velikosti, stahování přeskočí.
_zamky_stahovani = {}
_zamky_stahovani_guard = threading.Lock()


def nazev_pro_hlaseni(f):
    """Název souboru pro monitoring: lokální soubory VŽDY jen basename (zařízení je ukládá
    bez cesty), stream URL a playlist string beze změny. Dřív se hlásil jednou s podsložkou
    ('Oresi/x.jpg' z položky playlistu) a jindy bez ní - server to musel normalizovat na
    devíti místech (2.9.2026); od teď je hlášení jednotné už u zdroje."""
    if not f:
        return f
    if '://' in f or f.startswith('playlist:'):
        return f
    return os.path.basename(f)


def stream_dostupny(url, timeout=6.0):
    """Rychlá kontrola dostupnosti streamu PŘED předáním Kodi.

    PROČ: neúspěšný OpenFile v Kodi zavře naše krycí okno a ukáže HOME + chybový dialog
    (změřeno 2.9.2026 v E4: ~170 ms menu při každém pokusu, pořadí zavírání dialogů
    nepomůže). Mrtvou URL proto Kodi vůbec nedostane - krycí černá zůstane a watchdog
    zkouší znovu bez přehrávání. http/https: GET s krátkým čtením; rtsp/rtmp: TCP connect;
    udp/rtp (multicast) ověřit nelze -> True.
    """
    try:
        u = urllib.parse.urlparse(url)
        scheme = (u.scheme or "").lower()
        if scheme in ("http", "https"):
            ctx = ssl._create_unverified_context() if scheme == "https" else None
            req = urllib.request.Request(url, headers={"User-Agent": "Kodi-dohled"})
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                    r.read(1024)
            except urllib.error.HTTPError:
                # Server odpovedel (401/403/404...): ZIJE - autentizaci v URL, Range apod.
                # zvlada Kodi; tady se chytaji jen MRTVE cile (odmitnute spojeni, timeout, DNS).
                return True
            return True
        if scheme in ("rtsp", "rtmp", "rtmps"):
            port = u.port or {"rtsp": 554, "rtmp": 1935, "rtmps": 443}[scheme]
            with socket.create_connection((u.hostname, port), timeout=timeout):
                pass
            return True
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Stream nedostupný ({e}): {url}", xbmc.LOGWARNING)
        return False


def zamek_stahovani(local_filename):
    with _zamky_stahovani_guard:
        z = _zamky_stahovani.get(local_filename)
        if z is None:
            z = threading.Lock()
            _zamky_stahovani[local_filename] = z
        return z
MIN_FREE_SPACE_MB = 1000  # Minimální volné místo v MB - jediné kritérium pro mazání souborů

# Soubor pro sledování restartů
REBOOT_TRACK_FILE = "/storage/.kodi/userdata/reboot_log.txt"


def get_local_media_path(filename):
    """
    Vrátí správnou lokální cestu pro mediální soubor.
    Obrázky jdou do IMAGE_DIR, videa do VIDEO_DIR.

    Args:
        filename: Název souboru (může obsahovat cestu, použije se jen basename)

    Returns:
        Úplná cesta k souboru nebo None pokud filename je prázdný
    """
    if not filename:
        return None
    base_filename = os.path.basename(filename)
    if is_image_file(base_filename):
        return os.path.join(IMAGE_DIR, base_filename)
    else:
        return os.path.join(VIDEO_DIR, base_filename)


def mark_reboot(source="manual"):
    """
    Zaznamená restart do REBOOT_TRACK_FILE před provedením restartu.
    Volat VŽDY před os.system("reboot") nebo xbmc.executebuiltin("Reboot").

    Args:
        source: Zdroj restartu (manual, scheduled, refresh_config, setup)
    """
    try:
        from datetime import datetime
        now = datetime.now()
        date_str = now.strftime('%Y-%m-%d')
        time_str = now.strftime('%Y-%m-%d %H:%M:%S')

        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {date_str}\n")
            f.write(f"Čas restartu: {time_str}\n")
            f.write(f"Zdroj: {source}\n")
            f.flush()
            os.fsync(f.fileno())

        xbmc.log(f"[Dohled] Zaznamenán restart: {time_str} (zdroj: {source})", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při záznamu restartu: {e}", xbmc.LOGERROR)


# ======= OCHRANA PROTI SMYČCE AUTOMATICKÝCH RESTARTŮ =======
# Zabraňuje boot-loopu: pokud addon provede příliš mnoho automatických restartů
# za sebou (bez toho, aby zařízení bylo delší dobu stabilní), další automatické
# restarty se potlačí. Chrání proti VŠEM automatickým reboot cestám (scheduled
# reboot, RestartApp po instalaci inputstream / self-update), i kdyby jejich vlastní
# logika selhala (např. skok systémového času). Manuální / backend příkazy tím
# záměrně neprocházejí - ty jsou vždy vyžádané.
AUTO_REBOOT_COUNTER_FILE = "/storage/.kodi/userdata/dohled_auto_reboot_count.txt"
AUTO_REBOOT_MAX = 3               # max po sobě jdoucích automatických restartů
AUTO_REBOOT_STABLE_UPTIME = 1800  # sekund běhu (monotonic), po kterých se počítadlo vynuluje


def _read_auto_reboot_count():
    try:
        with open(AUTO_REBOOT_COUNTER_FILE, "r", encoding="utf-8") as f:
            return int((f.read().strip() or "0"))
    except Exception:
        return 0


def _write_auto_reboot_count(value):
    try:
        with open(AUTO_REBOOT_COUNTER_FILE, "w", encoding="utf-8") as f:
            f.write(str(int(value)))
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zápisu auto-reboot počítadla: {e}", xbmc.LOGWARNING)


def can_auto_reboot(source="scheduled"):
    """
    Vrátí True pokud je bezpečné provést AUTOMATICKÝ restart, a zvýší počítadlo.
    Pokud proběhlo už příliš mnoho rychlých automatických restartů za sebou
    (bez stabilního uptime), vrátí False -> restart se NEPROVEDE (rozbije boot-loop).
    Fail-open: při chybě FS vrátí True, aby se neblokovaly legitimní restarty.
    """
    try:
        count = _read_auto_reboot_count()
        if count >= AUTO_REBOOT_MAX:
            xbmc.log(f"[Dohled] SMYČKA RESTARTŮ detekována ({count}x, zdroj: {source}) - automatický restart POTLAČEN", xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification("Dohled", "Detekována smyčka restartů - restart potlačen", xbmcgui.NOTIFICATION_WARNING, 8000)
            except Exception:
                pass
            return False
        _write_auto_reboot_count(count + 1)
        xbmc.log(f"[Dohled] Automatický restart povolen (počítadlo {count + 1}/{AUTO_REBOOT_MAX}, zdroj: {source})", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba v can_auto_reboot ({e}), povoluji restart (fail-open)", xbmc.LOGWARNING)
        return True


def reset_auto_reboot_counter_when_stable():
    """
    Vynuluje počítadlo automatických restartů, jakmile zařízení běží stabilně.
    Uptime se měří přes time.monotonic() (nezávislé na skoku systémového času).
    Když se zařízení restartuje ve smyčce (< AUTO_REBOOT_STABLE_UPTIME mezi resty),
    počítadlo se nikdy nevynuluje a can_auto_reboot() smyčku po AUTO_REBOOT_MAX zastaví.
    """
    monitor = xbmc.Monitor()
    while (time.monotonic() - ADDON_START_MONOTONIC) < AUTO_REBOOT_STABLE_UPTIME:
        remaining = AUTO_REBOOT_STABLE_UPTIME - (time.monotonic() - ADDON_START_MONOTONIC)
        if monitor.waitForAbort(min(60, max(1, remaining))):
            return
    _write_auto_reboot_count(0)
    xbmc.log("[Dohled] Zařízení běží stabilně, počítadlo automatických restartů vynulováno", xbmc.LOGINFO)
    while not monitor.abortRequested():
        if monitor.waitForAbort(3600):
            return
        _write_auto_reboot_count(0)


def write_heartbeat():
    """
    Zapíše aktuální timestamp do heartbeat souboru.
    Externí watchdog kontroluje tento soubor a restartuje Kodi pokud je příliš starý.
    """
    try:
        with open(HEARTBEAT_FILE, 'w', encoding="utf-8") as f:
            f.write(str(time.time()))
    except Exception:
        pass  # Tiché selhání - nechceme crashovat kvůli heartbeatu


def spawn_watchdog_daemon():
    """
    Vytvoří a spustí watchdog jako oddělený daemon proces.
    Watchdog běží NEZÁVISLE na Kodi a přežije i když Kodi addon zabije.
    Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi.
    """
    # Watchdog script - self-contained Python (bez xbmc importů)
    watchdog_code = '''#!/usr/bin/env python3
"""
Dohled Watchdog Daemon - automaticky restartuje Kodi pokud service.dohled přestane fungovat.
Tento script běží jako ODDĚLENÝ PROCES, nezávisle na Kodi.
"""
import os
import sys
import time
import signal

# Konfigurace
HEARTBEAT_FILE = "/storage/.kodi/temp/dohled_heartbeat"
PID_FILE = "/storage/.kodi/temp/dohled_watchdog.pid"
LOG_FILE = "/storage/.kodi/temp/dohled_watchdog.log"
CHECK_INTERVAL = 60  # Kontrolovat každých 60 sekund
MAX_HEARTBEAT_AGE = 600  # Max stáří heartbeatu (10 minut)
STARTUP_GRACE_PERIOD = 300  # 5 minut po startu čekat na service.dohled

def log(message):
    """Zapíše zprávu do logu."""
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, 'a', encoding="utf-8") as f:
            f.write(f"[{timestamp}] {message}\\n")
    except:
        pass

def get_heartbeat_age():
    """Vrátí stáří heartbeat souboru v sekundách, nebo None pokud neexistuje."""
    try:
        if not os.path.exists(HEARTBEAT_FILE):
            return None
        with open(HEARTBEAT_FILE, 'r', encoding="utf-8", errors="replace") as f:
            last_beat = float(f.read().strip())
        return time.time() - last_beat
    except:
        return None

def restart_kodi():
    """Restartuje Kodi přes systemctl (přežije pád Kodi)."""
    log("RESTARTUJI KODI - service.dohled neodpovídá!")
    try:
        os.remove(HEARTBEAT_FILE)
    except:
        pass
    # Restart přes systemctl - funguje i když Kodi neodpovídá
    os.system("systemctl restart kodi")
    sys.exit(0)  # Watchdog se ukončí, nový se spustí s novým Kodi

def je_watchdog(pid):
    """Běží pod PID opravdu watchdog? PID_FILE leží v /storage a přežije reboot, po kterém
    stejné číslo dostane jiný proces - typicky Kodi (start má po každém bootu podobná PID)."""
    if pid == os.getpid():
        return False
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            return os.path.basename(__file__).encode() in f.read()
    except OSError:
        return False

def check_existing_watchdog():
    """Zkontroluje a ukončí existující watchdog pokud běží. Ukončí JEN watchdog: do 3.6.0
    se zabíjel jakýkoli proces s PID ze souboru a po rebootu to bývalo Kodi (Kodi pak
    systemd spustil podruhé, obrazovka a dashboard znovu startovaly; regrese V12 29.10.)."""
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, 'r', encoding="utf-8", errors="replace") as f:
                old_pid = int(f.read().strip())
            if je_watchdog(old_pid):
                os.kill(old_pid, signal.SIGTERM)
                time.sleep(1)
                if je_watchdog(old_pid):
                    os.kill(old_pid, signal.SIGKILL)
                log(f"Ukončen starý watchdog PID {old_pid}")
        except (ProcessLookupError, ValueError, FileNotFoundError):
            pass  # Proces neběží nebo špatný PID
        try:
            os.remove(PID_FILE)
        except:
            pass

def write_pid():
    """Zapíše PID do souboru."""
    with open(PID_FILE, 'w', encoding="utf-8") as f:
        f.write(str(os.getpid()))

def main():
    # Ukončit starý watchdog
    check_existing_watchdog()

    # Zapsat náš PID
    write_pid()

    log(f"Watchdog daemon spuštěn (PID {os.getpid()})")
    log(f"Grace period: {STARTUP_GRACE_PERIOD}s, Max heartbeat age: {MAX_HEARTBEAT_AGE}s")

    # Startup grace period
    log(f"Čekám {STARTUP_GRACE_PERIOD}s na spuštění service.dohled...")
    time.sleep(STARTUP_GRACE_PERIOD)
    log("Grace period dokončena, začínám monitorovat heartbeat")

    # Hlavní smyčka
    while True:
        age = get_heartbeat_age()

        if age is None:
            log("Heartbeat soubor neexistuje, čekám...")
        elif age > 86400:
            # Nereálně velké stáří = skok systémového času dopředu (ne mrtvý addon).
            # NErestartovat kvůli skoku hodin - jen počkat na další heartbeat.
            log(f"Heartbeat stáří {int(age)}s je nereálné (skok hodin?), restart NEProveden")
        elif age < 0:
            # Záporné stáří = hodiny se posunuly zpět; heartbeat je fakticky čerstvý.
            log(f"Heartbeat stáří {int(age)}s záporné (skok hodin zpět), ignoruji")
        elif age > MAX_HEARTBEAT_AGE:
            log(f"Heartbeat je starý {int(age)}s (max {MAX_HEARTBEAT_AGE}s)")
            restart_kodi()
            return

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    # Double-fork pro plnou daemonizaci
    if os.fork() > 0:
        sys.exit(0)  # Parent exits

    os.setsid()  # Nová session

    if os.fork() > 0:
        sys.exit(0)  # First child exits

    # Druhé dítě je daemon
    # Uzavřít file descriptory
    sys.stdin.close()
    sys.stdout.close()
    sys.stderr.close()

    # Redirect to /dev/null
    fd = os.open('/dev/null', os.O_RDWR)
    os.dup2(fd, 0)
    os.dup2(fd, 1)
    os.dup2(fd, 2)

    main()
'''

    try:
        # Zapsat watchdog script
        with open(WATCHDOG_SCRIPT, 'w', encoding="utf-8") as f:
            f.write(watchdog_code)
        os.chmod(WATCHDOG_SCRIPT, 0o755)

        # Spustit watchdog jako samostatný proces
        # Použijeme os.system s nohup aby proces přežil ukončení rodiče
        subprocess.Popen(
            ['python3', WATCHDOG_SCRIPT],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        xbmc.log("[Dohled] Watchdog daemon spuštěn", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při spouštění watchdog daemonu: {e}", xbmc.LOGERROR)


# Podporované formáty souborů
VIDEO_EXTENSIONS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

# Výchozí doba zobrazení obrázku (v sekundách)
DEFAULT_IMAGE_DISPLAY_TIME = 10

KODI_LOG_PATH = "/storage/.kodi/temp/kodi.log"
KODI_LOG_MONITOR_INTERVAL = 0.5  # sekundy mezi kontrolami logu

# CO JE NA OBRAZOVCE - vlastní stav přehrávání, ze kterého se hlásí stav na server
# (stav_prehravani). Kdo obsah nasadí, ten proměnnou nastaví; kdo ho nahradí, přepíše ji.
# Krytí (black.png) není obsah a nikdy se sem nezapisuje.
# - current_displayed_image: basename obrázku zobrazeného přes ShowPicture
# - current_video: basename JEDNOHO videa puštěného v opakování (RepeatOne) mimo playlist
# - playlist: current_mixed_playlist + current_mixed_playlist_position (viz níže)
# - stream: aktivni_stream
current_displayed_image = None
current_video = None

# Sledování uživatelem ručně puštěného souboru
# Monitoring loop nebude přepisovat soubor dokud je toto nastaveno
user_initiated_file = None
# URL právě běžícího streamu (i obsahu provozovny) - watchdog, ochrana před auto-play, hlášení
aktivni_stream = None
# Od kdy stream watchdog počítá výpadek (start streamu / poslední pokus / poslední přehrávání)
stream_watchdog_od = 0.0

# Flag pro manuální zastavení - monitoring loop nebude auto-startovat
# Nastavuje se při stop příkazu, resetuje se při play/play_file/play_playlist
user_stopped = False

# PAUZA PLAYLISTU. Nestaci pauznout prehravac: obrazek se zobrazuje pres ShowPicture,
# takze player.isPlaying() je False a puvodni pause() nad obrazkem NIC NEUDELAL
# (zmereno 1.9.2026: prikaz dorazil, ale playlist se do 8 s posunul na dalsi polozku).
# Playlistove smycky proto tenhle priznak respektuji a nepokracuji dal, dokud trva.
playlist_paused = False


def is_playlist_paused():
    return playlist_paused


# Per-device trvalé ztlumení (příznak Muted z API) - vynucuje monitoring loop
device_muted = False

# Uložení posledního stopnutého obsahu pro možnost obnovení přehrávání
# Formát: {'type': 'single'/'playlist', 'file': 'filename', 'files': ['file1', 'file2'],
#          'source': 'locality' (obsah provozovny) / '' (Jen teď)} - resume zdroj zachová
last_stopped_content = None

# Pořadí posledního příkazu ze serveru, který NASADIL nebo ZASTAVIL obsah. Start zařízení
# podle něj pozná, že obsah mezitím převzal příkaz (a nesmí ho přepsat). Počítá se SKUTEČNÉ
# nasazení: download_and_play(_playlist) až po stažení, když obsah opravdu přepíná (během
# stahování má dál běžet dosavadní obsah - i ten, který právě nasazuje start; při chybě
# stahování by jinak zůstala černá obrazovka). "play" se počítá, jen když opravdu obnoví
# zastavený obsah (RESUME) - odpauzování nebo play bez uloženého obsahu (po bootu) nic
# nenasazuje a start nesmí kvůli němu ustoupit (jinak by zařízení zůstalo na fallbacku).
_prikaz_obsahu_poradi = 0
PRIKAZY_OBSAHU = ("stop", "play_file", "play_playlist", "play_stream", "add_to_playlist")


def prikaz_nasazuje_obsah():
    global _prikaz_obsahu_poradi
    _prikaz_obsahu_poradi += 1


# === ODSTRANĚNO: BLACK OVERLAY - způsobovalo problémy ===
# Veškeré překrývání a skrývání Kodi UI bylo odstraněno pro stabilitu


def silent_install_addon(addon_id, zip_url, origin='repository.libreelec.tv'):
    """Tichá instalace addonu - stáhne ZIP, rozbalí do addons, zaregistruje v DB. Bez GUI."""
    import zipfile
    import sqlite3
    addons_dir = "/storage/.kodi/addons"
    addon_path = os.path.join(addons_dir, addon_id)
    tmp_zip = f"/tmp/{addon_id}.zip"

    try:
        # Stáhnout ZIP
        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: stahuji z {zip_url}", xbmc.LOGINFO)
        urllib.request.urlretrieve(zip_url, tmp_zip)

        # Rozbalit
        with zipfile.ZipFile(tmp_zip, 'r') as z:
            z.extractall(addons_dir)
        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: rozbaleno do {addon_path}", xbmc.LOGINFO)

        # Zaregistrovat v DB
        db_path = None
        db_dir = "/storage/.kodi/userdata/Database"
        for f in sorted(os.listdir(db_dir), reverse=True):
            if f.startswith("Addons") and f.endswith(".db"):
                db_path = os.path.join(db_dir, f)
                break

        if db_path:
            conn = sqlite3.connect(db_path)
            c = conn.cursor()
            c.execute(
                "INSERT OR REPLACE INTO installed (addonID, enabled, installDate, origin, lastUpdated, lastUsed) "
                "VALUES (?, 1, datetime('now'), ?, datetime('now'), datetime('now'))",
                (addon_id, origin)
            )
            conn.commit()
            conn.close()
            xbmc.log(f"[Dohled] Tichá instalace {addon_id}: zaregistrováno v DB ({db_path})", xbmc.LOGINFO)

        # Uklidit
        os.remove(tmp_zip)

        xbmc.log(f"[Dohled] Tichá instalace {addon_id}: HOTOVO (vyžaduje restart Kodi)", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Tichá instalace {addon_id} selhala: {e}", xbmc.LOGERROR)
        if os.path.exists(tmp_zip):
            try:
                os.remove(tmp_zip)
            except:
                pass
        return False


def ensure_inputstream_addons():
    """Zajistí tichou instalaci inputstream addonů potřebných pro streamy."""
    import platform
    arch = platform.machine()
    if arch == 'aarch64':
        base = 'https://addons.libreelec.tv/12.2.0/ARMv8/aarch64'
    else:
        base = 'https://addons.libreelec.tv/12.2.0/ARMv7/arm'
    xbmc.log(f"[Dohled] Architektura: {arch}, repo: {base}", xbmc.LOGINFO)
    addons = {
        'inputstream.ffmpegdirect': f'{base}/inputstream.ffmpegdirect/inputstream.ffmpegdirect-21.3.8.3.zip',
        'inputstream.adaptive': f'{base}/inputstream.adaptive/inputstream.adaptive-21.5.18.1.zip',
    }
    needs_restart = False
    for addon_id, zip_url in addons.items():
        if not xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
            xbmc.log(f"[Dohled] Addon {addon_id} chybí, spouštím tichou instalaci", xbmc.LOGINFO)
            if silent_install_addon(addon_id, zip_url):
                needs_restart = True
        else:
            xbmc.log(f"[Dohled] Addon {addon_id} již nainstalován", xbmc.LOGINFO)

    if needs_restart:
        # Pojistka proti smyčce: kdyby se addon po instalaci nikdy nezaregistroval
        # jako System.HasAddon, RestartApp by se opakoval na každém bootu.
        if not can_auto_reboot("inputstream"):
            xbmc.log("[Dohled] Inputstream vyžaduje restart, ale detekována smyčka - restart přeskočen", xbmc.LOGWARNING)
            return
        xbmc.log("[Dohled] Inputstream addony nainstalovány, plánuji restart Kodi za 10s", xbmc.LOGINFO)
        xbmc.sleep(10000)
        xbmc.executebuiltin('RestartApp')


def ensure_low_latency_cache():
    """Zajistí optimální nastavení cache pro low-latency streaming.
    Vytvoří/aktualizuje advancedsettings.xml s malým bufferem pro streamy."""
    adv_settings_path = "/storage/.kodi/userdata/advancedsettings.xml"
    desired_content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>20971520</memorysize>
        <readfactor>4</readfactor>
    </cache>
    <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>10</curllowspeedtime>
    </network>
</advancedsettings>
'''
    try:
        needs_update = True
        if os.path.exists(adv_settings_path):
            with open(adv_settings_path, 'r', encoding="utf-8", errors="replace") as f:
                current = f.read()
            # Zkontrolovat jestli cache nastavení už existuje
            if '<buffermode>1</buffermode>' in current and '<memorysize>20971520</memorysize>' in current:
                needs_update = False

        if needs_update:
            with open(adv_settings_path, 'w', encoding="utf-8") as f:
                f.write(desired_content)
            xbmc.log("[Dohled] advancedsettings.xml aktualizován pro low-latency streaming", xbmc.LOGINFO)
            return True  # Vyžaduje restart Kodi
        return False
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zápisu advancedsettings.xml: {e}", xbmc.LOGERROR)
        return False


def is_video_file(filename):
    """Zjistí, zda je soubor video podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(VIDEO_EXTENSIONS)


def is_image_file(filename):
    """Zjistí, zda je soubor obrázek podle přípony."""
    if not filename:
        return False
    return filename.lower().endswith(IMAGE_EXTENSIONS)


def is_supported_file(filename):
    """Zjistí, zda je soubor podporovaný (video nebo obrázek)."""
    if not filename:
        return False
    return filename.lower().endswith(SUPPORTED_EXTENSIONS)


def get_media_type(filename):
    """Vrátí typ média: 'video', 'image' nebo None."""
    if not filename:
        return None
    lower_name = filename.lower()
    if lower_name.endswith(VIDEO_EXTENSIONS):
        return 'video'
    elif lower_name.endswith(IMAGE_EXTENSIONS):
        return 'image'
    return None


def wait_for_player_stop(timeout=3.0, poll_interval=0.1):
    """
    Čeká, dokud Kodi player skutečně nezastaví přehrávání.
    KRITICKÉ: Kodi potřebuje čas na uvolnění video rendereru před zobrazením obrázku.

    Args:
        timeout: Maximální čas čekání v sekundách
        poll_interval: Interval mezi kontrolami

    Returns:
        bool: True pokud player zastaven, False při timeoutu
    """
    player = xbmc.Player()
    start_time = time.time()
    checks = 0

    while time.time() - start_time < timeout:
        checks += 1
        # Kontrola zda video skutečně neběží
        if not player.isPlayingVideo() and not player.isPlaying():
            elapsed = time.time() - start_time
            xbmc.log(f"[Dohled] Player zastaven po {elapsed:.2f}s ({checks} kontrol)", xbmc.LOGINFO)
            # Extra čekání pro uvolnění GPU/renderer resources
            time.sleep(0.5)
            return True
        time.sleep(poll_interval)

    elapsed = time.time() - start_time
    xbmc.log(f"[Dohled] VAROVÁNÍ: Timeout čekání na zastavení playeru ({elapsed:.2f}s, {checks} kontrol)", xbmc.LOGWARNING)
    return False


# ======= BLACK TRANSITION =======
# Plynule prechody mezi medii bez probliknuti Kodi GUI.
#
# Strategie pro kazdy typ prechodu:
# - Obrazek→Video: Spustit cerne video (nahradi slideshow), pak spustit skutecne video
# - Video→Obrazek: ShowPicture PRED player.stop() (obrazek prekryje video)
# - Obrazek→Obrazek: ShowPicture(novy) primo nahradi stary
#
# Cerne video ma na Amlogic HW nejvyssi z-order (HW overlay),
# takze zaruceně prekryje vse vcetne slideshow.

BLACK_VIDEO_PATH = os.path.join(ADDON_PATH, 'black_transition.mp4')


def _detect_amlogic():
    """True jen na Amlogic boxech (tam ma video HW overlay nad GUI).

    Krycí černé VIDEO se pouziva vyhradne tam. Na ostatnim HW (Raspberry/vc4, x86)
    je GUI nad videem, takze krytí zajisti cerny OBRAZEK ve slideshow okne - a to je
    lepsi, protoze:
      - nepotrebuje dekoder (mereno na Pi: ze 41 spusteni krycího videa 40x
        "OutputPicture - timeout waiting for buffer" a 6x uplne selhani otevreni
        = 15 % prechodu bez krytí -> prosvitlo HOME),
      - ubira jedno spusteni/zastaveni dekoderu na kazdy cyklus playlistu, coz je
        dulezite na slabych RPi3.
    """
    try:
        if os.path.exists('/sys/class/amhdmitx'):
            return True
        with open('/proc/device-tree/compatible', 'rb') as f:
            return b'amlogic' in f.read().lower()
    except Exception:
        pass
    return False


USE_BLACK_TRANSITION_VIDEO = _detect_amlogic()
# Krycí černý obrázek - drží slideshow okno (12007) v popředí s černým obsahem.
# Používá se všude, kde by jinak na obrazovce nezůstalo NIC a Kodi by ukázalo HOME menu.
BLACK_IMAGE_PATH = os.path.join(ADDON_PATH, 'black.png')


def show_black_filler(reason=""):
    """Okamžitě zobrazí černý obrázek jako krytí.

    PRAVIDLO PROJEKTU: menu Kodi se NIKDY nesmí ukázat. Když není připravený žádný
    obsah (start, chybějící soubor, selhání zobrazení, úplné zastavení), musí být
    obrazovka ČERNÁ - nikdy home menu. ShowPicture drží slideshow okno v popředí,
    takže černý obrázek spolehlivě přebije home.
    """
    try:
        if os.path.exists(BLACK_IMAGE_PATH):
            xbmc.executebuiltin(f'ShowPicture("{BLACK_IMAGE_PATH}")')
            if reason:
                xbmc.log(f"[Dohled] Krycí černá obrazovka ({reason})", xbmc.LOGINFO)
            return True
    except Exception as e:
        xbmc.log(f"[Dohled] Nepodařilo se zobrazit krycí černou: {e}", xbmc.LOGWARNING)
    return False


# Okna, která znamenají "náš obsah je na obrazovce" (obrázek / video / vizualizace).
_CONTENT_WINDOWS = (
    "Window.IsVisible(slideshow) | Window.IsVisible(pictures) | Slideshow.IsActive | "
    "Window.IsVisible(fullscreenvideo) | VideoPlayer.IsFullscreen | Window.IsVisible(visualisation)"
)


def is_content_on_screen():
    """True, pokud je v popředí náš obsah (obrázek přes slideshow nebo fullscreen video)."""
    try:
        return bool(xbmc.getCondVisibility(_CONTENT_WINDOWS))
    except Exception:
        return True  # při chybě raději předpokládat, že obsah běží (nezasahovat)


def is_menu_visible():
    """True JEN pokud je vidět Kodi menu a ZÁROVEŇ na obrazovce není žádný náš obsah.

    KRITICKÉ: slideshow (obrázky) je v Kodi DIALOG nad základním oknem 'home', takže
    Window.IsVisible(home) je True i když je obrázek přes celou obrazovku. Kontrolovat
    samotné home proto NELZE - pojistka by hlásila menu pořád a znovu spouštěla obsah
    (obrazovka by problikávala). Menu je problém jen tehdy, když nad ním NIC našeho není.
    """
    try:
        if is_content_on_screen():
            return False
        return bool(xbmc.getCondVisibility("Window.IsVisible(home) | Window.IsActive(home)"))
    except Exception:
        return False


# Značka běžícího přechodu. Uvnitř přechodu je stav "video hraje pod slideshow oknem"
# NORMÁLNÍ a pojistka do něj nesmí zasahovat (Action(FullScreen) nad otevřeným
# slideshow video neodkryje a ukáže HOME - změřeno ~1,9 s).
# Je to ČASOVÁ značka, ne počítadlo: sama vyprší, takže ani přechod ukončený výjimkou
# nemůže pojistku zablokovat natrvalo.
_transition_until = 0.0


def _transition_begin(max_seconds=8.0):
    global _transition_until
    _transition_until = time.monotonic() + max_seconds


def _transition_end():
    global _transition_until
    _transition_until = 0.0


def _transition_running():
    return time.monotonic() < _transition_until


def wait_slideshow_shows(filename, timeout=5.0):
    """Čeká, dokud slideshow neohlásí KONKRÉTNÍ soubor (infolabel Slideshow.Filename).

    Podmínka "slideshow okno je vidět" nestačí - jakmile se jako krytí nasadí černý
    obrázek, je splněná okamžitě a čekání by negarantovalo nic. Proto se čeká na jméno
    cílového souboru. 3.6.0: po vypršení se vrací False (do 3.5.9 "okno je vidět", tedy
    True i nad krycí černou - selhání zobrazení se tím maskovalo).
    """
    target = os.path.basename(filename)
    start = time.time()
    while time.time() - start < timeout:
        try:
            cur = xbmc.getInfoLabel('Slideshow.Filename') or ''
        except Exception:
            cur = ''
        if cur and os.path.basename(cur) == target:
            return True
        xbmc.sleep(50)
    return False


def uncover_video_from_image(player, timeout=3.0):
    """Odkryje UŽ SPUŠTĚNÉ video zpod slideshow okna, bez odhalení menu.

    Video na Amlogic HW běží pod slideshow oknem. Slideshow proto zavřeme TEPRVE až
    video skutečně hraje - tím pádem se pod ním hned objeví video, nikdy prázdno/menu.
    Používá se tam, kde se video spustilo jinde (např. video playlist) a je nad ním
    ještě zobrazený obrázek.
    """
    _transition_begin()
    try:
        start = time.time()
        while time.time() - start < timeout:
            if player.isPlayingVideo():
                break
            xbmc.executebuiltin('Dialog.Close(busydialog)')   # spinner nad obrázkem
            xbmc.sleep(50)
        xbmc.sleep(200)  # nechat vykreslit první frame
        # ATOMICKÉ ODKRYTÍ - vysvětlení a měření viz transition_to_video_from_image()
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace
        ensure_fullscreen_video()
        xbmc.sleep(50)
        # Když video z nějakého důvodu nehraje, nesmí zůstat prázdná obrazovka
        if not player.isPlayingVideo() and not is_content_on_screen():
            show_black_filler("video se nespustilo")
        elif is_menu_visible():
            show_black_filler("menu po odkrytí videa")
        xbmc.log("[Dohled] Video odkryto zpod obrázku", xbmc.LOGINFO)
    finally:
        _transition_end()


def ensure_fullscreen_video():
    """Prepne video do fullscreenu ZPUSOBEM, KTERY NEMUZE PREPNOUT SPATNE.

    Action(FullScreen) je PREPINAC: kdyz uz Kodi po zavreni dialogu ve fullscreenu je,
    slepe zavolany prikaz ho z fullscreenu VYHODI na HOME. Na RPi3 to bylo videt jako
        obrazek -> video (2 ms) -> HOME MENU (78 ms) -> video
    (menu vratila teprve pojistka). GUI.SetFullscreen je naopak IDEMPOTENTNI.

    Zachrana: na nekterem HW (merene driv na aarch64) samotne GUI.SetFullscreen video
    neodkrylo, proto se po chvili overi vysledek a teprve pak se pouzije prepinac.

    MERENO na RPi3 (harness script.transtest, vzorkovani 500 Hz = 2 ms):
      Close(true) + Action(FullScreen)      -> 1 z 6 prechodu blik 162 ms
      Close(true) + GUI.SetFullscreen       -> 0 z 6
      GUI.SetFullscreen PRED zavrenim       -> 4 z 6 SELHALO (video zustalo pod menu)
    """
    try:
        xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1,
                                        "method": "GUI.SetFullscreen",
                                        "params": {"fullscreen": True}}))
    except Exception:
        pass
    for _ in range(6):          # max ~60 ms
        if xbmc.getCondVisibility('VideoPlayer.IsFullscreen'):
            return True
        xbmc.sleep(10)
    xbmc.executebuiltin('Action(FullScreen)')
    return False


def safe_playing_file(player=None):
    """Plná cesta právě hraného souboru, nebo '' když nic nehraje.

    NIKDY nevolat player.getPlayingFile(): isPlayingVideo() a getPlayingFile() nejsou
    atomické - když video ve smyčce právě skončí, getPlayingFile() vyhodí RuntimeError
    a Kodi zaloguje ERROR "Kodi is not playing any file" (na flotile 1200-1800× denně).
    InfoLabel mimo přehrávání vrátí jen ''.
    """
    try:
        return xbmc.getInfoLabel('Player.FilenameAndPath') or ''
    except Exception:
        return ''


def uncover_if_covered(player, reason=""):
    """Když je nad hrajícím videem otevřené krycí okno, odkryje video.

    PROČ: video se v Kodi vykresluje POD GUI. Když nad ním zůstane slideshow okno
    (typicky krycí ČERNÁ z show_black_filler - po startu "příprava obsahu", po selhání
    zobrazení, po zastavení obsahu), divák vidí ČERNOU OBRAZOVKU, přesto že video hraje.
    Krytí se NEUKLÁDÁ do current_displayed_image (není to obsah), takže se podle té
    proměnné poznat nedá - rozhoduje jedině skutečná viditelnost slideshow okna.

    Tuhle chybu měly obě playlistové smyčky i RepeatVideo (nalezeno testy výměny obsahu
    2026-08-10: u jednoho videa i u playlistu jen z videí zůstala černá obrazovka natrvalo).
    """
    if xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
        xbmc.log(f"[Dohled] Nad videem je krycí okno{' (' + reason + ')' if reason else ''}"
                 " - odkrývám video", xbmc.LOGINFO)
        uncover_video_from_image(player)
        return True
    return False


def play_video_uncovered(player, file_path, wait_stop=0.0, builtin=False):
    """Spustí video a ZARUČENĚ ho odkryje zpod případného krycího okna."""
    if wait_stop:
        wait_for_player_stop(timeout=wait_stop)
    if builtin:
        xbmc.executebuiltin(f'PlayMedia("{file_path}")')
    else:
        player.play(file_path)
    uncover_if_covered(player, os.path.basename(file_path))
    check_video_started(player, file_path)


def transition_to_video_from_image(player, video_path, polozka=None):
    """Prechod obrazek→video:
    1. Spusti video (bezi pod slideshow)
    2. Pocka az video nabehne
    3. Zavre slideshow okno (ID 10134) - video je uz pod nim pripravene

    polozka = co předat přehrávači místo cesty (RepeatVideo předává 1položkový
    PLAYLIST_VIDEO, aby fungovalo RepeatOne).
    """
    xbmc.log(f"[Dohled] Transition obrazek→video: {os.path.basename(video_path)}", xbmc.LOGINFO)
    _transition_begin()
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    # Spustit video - bezi pod slideshow oknem
    player.play(polozka if polozka is not None else video_path)
    # Cekat az video zacne hrat (max 3s)
    start = time.time()
    while time.time() - start < 3.0:
        if player.isPlayingVideo():
            break
        # Kodi si pri otevirani souboru samo pusti busy spinner NAD obrazkem
        # (zmereno 94-185 ms) - hned ho zavirat, obsah ma byt cisty.
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.sleep(50)
    xbmc.sleep(200)  # Extra pauza pro jistotu ze je frame vykreslen
    # ATOMICKÉ ODKRYTÍ: zavření slideshow a přepnutí videa do fullscreenu musí jít
    # do Kodi BEZ JAKÉKOLI PAUZY MEZI TÍM - Kodi je pak vyřídí ve stejném frame
    # a divák nikdy neuvidí, co je pod slideshow.
    #
    # MĚŘENO (harness script.transtest + vzorkování okna na 200 Hz, tj. pod 1 frame):
    #   ActivateWindow(fullscreenvideo) + 150 ms + Dialog.Close + 80 ms + FullScreen
    #                                          -> HOME MENU 64-81 ms (3/3 pokusů)
    #   Dialog.Close(12007) + Action(FullScreen) bez pauzy   -> 0 ms (8/8 pokusů)
    #
    # POZOR - RASPBERRY PI 3 (změřeno 28.8.2026): tohle pořadí samo o sobě NESTAČÍ,
    # protože Action(FullScreen) je PŘEPÍNAČ - když Kodi po zavření dialogu do
    # fullscreenu přejde samo, druhý příkaz ho zase VYHODÍ na HOME. Proto se přepíná
    # přes ensure_fullscreen_video() (idempotentní GUI.SetFullscreen + záchrana).
    #
    # NAMĚŘENO NA RPi3 za reálného provozu (vzorkování 500 Hz, počítají se jen bliky
    # delší než jeden frame 16,7 ms):
    #   Close(12007) + Action(FullScreen)                -> 5 bliků / 240 s (21-266 ms)
    #   Close(12007,true) + Action(FullScreen)           -> 10 bliků / 600 s
    #   ... + čekací smyčka na IsFullscreen (ZHORŠENÍ!)  -> 38 bliků / 900 s
    #   Close(12007,true) + ensure_fullscreen_video()    -> 0 bliků / 1200 s
    # Zavírání BEZ animace (true) se v harnessu neprojevilo jako rozhodující, ale
    # škodit nemůže a zůstává. Rozhodující je NEPŘEPÍNACÍ přepnutí do fullscreenu.
    # ActivateWindow(fullscreenvideo) se pod modálním slideshow VŮBEC neuplatní
    # (base okno zůstane 'home'), takže po zavření dialogu prosvitlo menu přesně
    # na dobu následující pauzy. Proto je pauza pryč a ActivateWindow taky.
    # Varianty GUI.SetFullscreen / ReplaceWindow / Action(FullScreen) před zavřením
    # slideshow video vůbec neodkryly (HOME ~2 s) - nepoužívat.
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace
    ensure_fullscreen_video()
    xbmc.sleep(50)
    # Fallback pokud slideshow stale bezi
    if xbmc.getCondVisibility('Window.IsActive(slideshow)'):
        xbmc.executebuiltin('Action(Back)')
        xbmc.sleep(100)
        xbmc.executebuiltin('Action(FullScreen)')
    # Pojistka: kdyby přesto prosvitlo menu, okamžitě zakryt černou (nikdy menu)
    if is_menu_visible():
        xbmc.log("[Dohled] Transition obrázek→video: menu po zavření slideshow - kryji černou", xbmc.LOGWARNING)
        xbmc.executebuiltin('Action(FullScreen)')
        xbmc.sleep(50)
        if is_menu_visible():
            show_black_filler("menu po přechodu obrázek→video")
    _transition_end()
    xbmc.log("[Dohled] Transition obrazek→video: dokonceno", xbmc.LOGINFO)

def transition_to_image_from_video(player, image_path):
    """Prechod video→obrazek:
    1. KRYTÍ: cerny obrazek do slideshow okna (GUI vrstva, bez dekoderu - nemuze selhat)
    2. Jen na Amlogic navic krycí cerne video (HW overlay nad GUI)
    3. ShowPicture pripravi cilovy obrazek
    4. Slideshow do popredi a TEPRVE POTOM stop videa
    """
    xbmc.log(f"[Dohled] Transition video→obrazek: {os.path.basename(image_path)}", xbmc.LOGINFO)
    _transition_begin()
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    # KRYTÍ BEZ DEKODÉRU jako první krok. Kdyby cokoli dál selhalo (nepodařilo se
    # otevřít krycí video, Kodi zaneprázdněné, chyba souboru), je pod videem
    # připravená ČERNÁ - nikdy ne HOME menu.
    # MĚŘENO harnessem: se současným postupem prosvitlo HOME 5 ms při 3 ze 3 přechodů;
    # s tímto krytím 0 ms při 3 ze 3 - a to i ve variantě, kde krycí video záměrně
    # NEEXISTOVALO (simulace reálného selhání dekodéru).
    xbmc.executebuiltin(f'ShowPicture("{BLACK_IMAGE_PATH}")')
    if USE_BLACK_TRANSITION_VIDEO:
        # Spustit cerne video PRIMO (ne pres playlist - RepeatOne v playlistu nefunguje)
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        player.play(BLACK_VIDEO_PATH)
        # Cekat az cerne video zacne hrat (max 1,5 s - kdyz se nerozjede, kryje obrazek)
        start = time.time()
        black_ok = False
        while time.time() - start < 1.5:
            if player.isPlayingVideo():
                black_ok = True
                break
            xbmc.sleep(50)
        if not black_ok:
            xbmc.log("[Dohled] Transition: krycí video se nerozjelo - kryje černý obrázek",
                     xbmc.LOGWARNING)
        xbmc.sleep(150)
    # Zobrazit obrazek - slideshow okno se pripravi POD video vrstvou
    xbmc.executebuiltin(f'ShowPicture("{image_path}")')
    # Cekat, az slideshow ohlasi PRAVE TENTO soubor (max 5s)
    if wait_slideshow_shows(image_path, 5.0):
        xbmc.log("[Dohled] Transition: slideshow okno ready", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] Transition: slideshow neohlásil {os.path.basename(image_path)} "
                 f"- pokračuji (kryje černá)", xbmc.LOGWARNING)
    xbmc.sleep(50)
    # KRITICKÉ POŘADÍ: slideshow dát do popředí JEŠTĚ PŘED zastavením videa.
    # Když se video zastavilo první, Kodi na ~0,3 s spadlo na základní okno (HOME menu)
    # a teprve pak vykreslilo slideshow - měřením zachyceno 5x za 110 s.
    xbmc.executebuiltin('ActivateWindow(slideshow)')
    xbmc.sleep(120)
    # Teprve teď zastavit černé video - slideshow už je navrchu
    player.stop()
    xbmc.sleep(50)
    # Pojistka: kdyby stop přesto odhalil menu, okamžitě obrázek vrátit
    if is_menu_visible():
        xbmc.log("[Dohled] Transition video→obrázek: menu po stopu - vracím obrázek", xbmc.LOGWARNING)
        xbmc.executebuiltin(f'ShowPicture("{image_path}")')
    _transition_end()
    xbmc.log("[Dohled] Transition video→obrazek: dokonceno", xbmc.LOGINFO)

def show_picture_safe(image_path):
    """Zobrazí obrázek (ShowPicture nahradí předchozí obrázek atomicky) a počká, až ho
    slideshow ohlásí. Vrací True/False - při selhání si volající zakryje černou a soubor opraví.

    3.6.0: pryč je zvláštní "příprava čerstvě staženého souboru" (stop přehrávače, 300 ms,
    Container.Refresh, mazání texture cache) i opakování s mazáním cache a JSON-RPC
    Player.Open. Stahování je atomické (staging, fsync, kontrola velikosti, rename), takže
    "neúplný soubor" nastat nemůže, a slideshow Kodi čte obrázek přímo ze souboru (texture
    cache Textures13.db je pro náhledy). V logách flotily se žádná z těch větví nikdy
    neuplatnila (27.10.2026: 0x černá obrazovka, 0x čekání na soubor delší než 1 pokus).
    """
    filename = os.path.basename(image_path)
    xbmc.log(f"[Dohled] Zobrazuji obrázek {filename}", xbmc.LOGINFO)
    # Uvozovky jsou POVINNÉ - bez nich se obrázek s mezerou/čárkou v názvu nezobrazí vůbec
    xbmc.executebuiltin(f'ShowPicture("{image_path}")')
    if wait_slideshow_shows(image_path, 3.0):
        return True
    xbmc.log(f"[Dohled] Obrázek {filename} se nezobrazil (slideshow ho neohlásil)", xbmc.LOGWARNING)
    return False


# ======= KODI LOG MONITOR PRO DETEKCI ČERNÉ OBRAZOVKY =======

class KodiLogMonitor(threading.Thread):
    """Sleduje Kodi log:
    - 'Error loading the current image <cesta>' = Kodi obrázek nenačetl -> soubor je vadný,
      opravit (smazat + stáhnout znovu, repair_media_file má vlastní strop pokusů) a zobrazit.
    - dávky chyb dekodéru u hraného videa -> samooprava videa.

    3.6.0: dřív se na chybu obrázku nejdřív 2x mazala texture cache a obrázek se
    "znovu zobrazoval" - texture cache slideshow vůbec nepoužívá, takže to nic neopravilo
    (v logách flotily se ta větev nikdy neuplatnila). Opravuje se rovnou příčina = soubor.
    """

    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._last_position = 0
        self._processed_images = {}  # {image_path: timestamp} - Kodi chybu loguje opakovaně
        # Pattern pro detekci chyby: Error loading the current image 0: /storage/pictures/x.jpg
        self._error_pattern = re.compile(r'Error loading the current image \d+: (.+)$')
        # 3.5.4: chyby dekodéru = poškozená data videa (typicky vadná SD karta)
        self._decoder_errors = []  # časy chyb v okně DECODER_ERROR_WINDOW

    def stop(self):
        self._stop_event.set()

    def _on_decoder_error(self):
        """Dávka chyb dekodéru u LOKÁLNÍHO hraného videa -> samooprava souboru."""
        now = time.time()
        self._decoder_errors = [t for t in self._decoder_errors if now - t < DECODER_ERROR_WINDOW]
        self._decoder_errors.append(now)
        if len(self._decoder_errors) < DECODER_ERRORS_BEFORE_REPAIR:
            return
        self._decoder_errors = []
        try:
            player = xbmc.Player()
            playing = safe_playing_file(player) if player.isPlayingVideo() else ''
        except Exception:
            playing = ''
        if not playing or '://' in playing or not os.path.exists(playing):
            return
        base = os.path.basename(playing)
        xbmc.log(f"[Dohled] KodiLogMonitor: {DECODER_ERRORS_BEFORE_REPAIR}+ chyb dekodéru během "
                 f"{DECODER_ERROR_WINDOW // 60} min u {base} - video je pravděpodobně poškozené", xbmc.LOGWARNING)
        request_video_repair(base, 'opakované chyby dekodéru', replay_if_playing=True)

    def run(self):
        xbmc.log("[Dohled] KodiLogMonitor spuštěn", xbmc.LOGINFO)

        # Přeskočit existující obsah logu
        if os.path.exists(KODI_LOG_PATH):
            try:
                with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                    f.seek(0, 2)  # Seek to end
                    self._last_position = f.tell()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při inicializaci pozice: {e}", xbmc.LOGWARNING)

        while not self._stop_event.is_set():
            try:
                self._check_log()
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor chyba: {e}", xbmc.LOGWARNING)

            self._stop_event.wait(KODI_LOG_MONITOR_INTERVAL)

        xbmc.log("[Dohled] KodiLogMonitor ukončen", xbmc.LOGINFO)

    def _check_log(self):
        """Kontroluje nové řádky v Kodi logu."""
        if not os.path.exists(KODI_LOG_PATH):
            return

        try:
            with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                # Zkontrolovat zda soubor nebyl rotován (pozice větší než velikost)
                f.seek(0, 2)
                current_size = f.tell()
                if self._last_position > current_size:
                    self._last_position = 0

                # Číst od poslední pozice
                f.seek(self._last_position)
                new_lines = f.readlines()
                self._last_position = f.tell()

                for line in new_lines:
                    self._process_line(line)
        except Exception as e:
            xbmc.log(f"[Dohled] KodiLogMonitor: Chyba při čtení logu: {e}", xbmc.LOGWARNING)

    def _process_line(self, line):
        """Zpracuje jeden řádek logu."""
        if 'Invalid data found when processing input' in line and 'CDVDVideoCodec' in line:
            self._on_decoder_error()
            return
        if 'Error loading the current image' not in line:
            return
        match = self._error_pattern.search(line)
        if not match:
            return
        image_path = match.group(1).strip()
        now = time.time()
        # Kodi tuto chybu loguje opakovaně - zpracovat jednou za 60 s pro daný obrázek
        if now - self._processed_images.get(image_path, 0) < 60:
            return
        self._processed_images = {k: v for k, v in self._processed_images.items() if now - v < 60}
        self._processed_images[image_path] = now
        if os.path.basename(image_path) == os.path.basename(BLACK_IMAGE_PATH):
            xbmc.log(f"[Dohled] KodiLogMonitor: Kodi nenačetlo krycí černou {image_path}", xbmc.LOGERROR)
            return
        xbmc.log(f"[Dohled] KodiLogMonitor: Kodi nenačetlo obrázek {image_path} - soubor je vadný, "
                 "opravuji", xbmc.LOGWARNING)

        def _oprava():
            try:
                fn = os.path.basename(image_path)
                if repair_media_file(fn, "Kodi obrázek nenačetlo") and current_displayed_image == fn:
                    show_picture_safe(get_local_media_path(fn))
            except Exception as e:
                xbmc.log(f"[Dohled] KodiLogMonitor: oprava obrázku selhala: {e}", xbmc.LOGERROR)
        threading.Thread(target=_oprava, daemon=True).start()


# Instance log monitoru (globální)
kodi_log_monitor = None


# ======= FUNKCE PRO SPRÁVU DISKU =======

def get_disk_space_mb(path):
    """Vrátí volné místo na disku v MB."""
    try:
        statvfs = os.statvfs(path)
        free_bytes = statvfs.f_frsize * statvfs.f_bavail
        return free_bytes / (1024 * 1024)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa na disku: {e}", xbmc.LOGERROR)
        return 0


def get_file_size_mb(filepath):
    """Vrátí velikost souboru v MB."""
    try:
        if os.path.exists(filepath):
            return os.path.getsize(filepath) / (1024 * 1024)
        return 0
    except:
        return 0


def cleanup_old_media(current_filename, needed_space_mb=0):
    """
    Vyčistí staré mediální soubory pouze pokud je nedostatek volného místa.
    Maže nejstarší soubory dokud není dostatek místa (MIN_FREE_SPACE_MB + needed_space_mb).
    """
    try:
        free_space = get_disk_space_mb(VIDEO_DIR)
        total_needed = MIN_FREE_SPACE_MB + needed_space_mb

        if free_space >= total_needed:
            xbmc.log(f"[Dohled] Dostatek místa ({free_space:.0f} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0, 0

        space_to_free = total_needed - free_space
        xbmc.log(f"[Dohled] Nedostatek místa ({free_space:.0f} MB), potřeba uvolnit {space_to_free:.0f} MB", xbmc.LOGWARNING)

        media_files = []
        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                mtime = os.path.getmtime(filepath)
                size_mb = get_file_size_mb(filepath)
                media_files.append({
                    'filename': filename,
                    'filepath': filepath,
                    'mtime': mtime,
                    'size_mb': size_mb
                })

        # Seřadit od nejstaršího (nejstarší budou smazány první)
        media_files.sort(key=lambda x: x['mtime'])
        xbmc.log(f"[Dohled] Nalezeno {len(media_files)} mediálních souborů", xbmc.LOGINFO)

        deleted_count = 0
        freed_space_mb = 0

        for file_info in media_files:
            if freed_space_mb >= space_to_free:
                break

            # Chránit aktuálně přehrávaný soubor
            if file_info['filename'] == current_filename:
                xbmc.log(f"[Dohled] Chráním aktuální soubor: {file_info['filename']}", xbmc.LOGINFO)
                continue

            try:
                os.remove(file_info['filepath'])
                deleted_count += 1
                freed_space_mb += file_info['size_mb']
                xbmc.log(f"[Dohled] Smazán starý soubor: {file_info['filename']} ({file_info['size_mb']:.1f} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při mazání {file_info['filename']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            pass  # Notifikace odstraněna - info je v logu

        return deleted_count, freed_space_mb

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění starých souborů: {e}", xbmc.LOGERROR)
        return 0, 0


def analyze_disk_usage():
    """Analyzuje využití disku a vrátí statistiky."""
    try:
        media_files = []
        total_size_mb = 0

        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                size_mb = get_file_size_mb(filepath)
                mtime = os.path.getmtime(filepath)
                media_files.append({
                    'filename': filename,
                    'size_mb': size_mb,
                    'mtime': mtime,
                    'type': get_media_type(filename)
                })
                total_size_mb += size_mb

        media_files.sort(key=lambda x: x['size_mb'], reverse=True)
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        video_count = sum(1 for f in media_files if f['type'] == 'video')
        image_count = sum(1 for f in media_files if f['type'] == 'image')

        return {
            'media_count': len(media_files),
            'video_count': video_count,
            'image_count': image_count,
            'total_size_mb': total_size_mb,
            'free_space_mb': free_space_mb,
            'largest_files': media_files[:3]
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při analýze disku: {e}", xbmc.LOGERROR)
        return None


# ======= FTP FUNKCE =======

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
    try:
        return api_request(api_url, timeout=10)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def fetch_expected_file(device_id, locality=None):
    """JEDINÉ načtení očekávaného obsahu z API (/expected-file) -> (filename, source).

    API odpovědělo -> (filename, source); filename None = žádný obsah.
    Chyba (API nedostupné, TLS, ...) -> None: volající NIC nemění (hraje dál, co hraje,
    a zkusí to znovu) - start zařízení to rozlišuje od "žádný obsah" (_startup_playback).
    3.6.0: do 3.5.9 se při chybě monitoring vracel k file_name z
    locality_config (ignoroval override, playlist i kampaň) a existovala druhá kopie téhle
    funkce pro start (fetch_expected_file_with_locality).
    locality = jen pro start nového zařízení, které ještě nemá záznam v DB.
    Vedlejší efekty: device_muted (příznak Muted), plné názvy pro samoopravu.
    """
    global device_muted
    if not device_id:
        return None
    query = {}
    if locality:
        query["locality"] = locality
    boot_time = get_boot_time()   # API při změně boot_time maže dočasné přehrávání (restart)
    if boot_time:
        query["boot_time"] = boot_time
    qs = ("?" + urllib.parse.urlencode(query)) if query else ""
    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file{qs}"
    try:
        data = api_request(api_url, timeout=10)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání očekávaného obsahu (zkusím znovu): {e}", xbmc.LOGWARNING)
        return None
    device_muted = bool(data.get("muted", False))
    filename = data.get("filename")
    source = data.get("source")
    if filename:
        xbmc.log(f"[Dohled] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
        nastavit_ocekavane_nazvy(filename)
        return filename, source
    return None, source


def get_remote_file_info(host, user, password, path, filename):
    """Získá datum poslední úpravy a velikost souboru na FTP serveru."""
    try:
        xbmc.log(f"[Dohled] Připojuji se k FTP serveru {host}...", xbmc.LOGINFO)

        ftp = FTP(host, timeout=30)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")

        try:
            size = ftp.size(path + filename)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání velikosti souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        try:
            modified_time = ftp.sendcmd("MDTM " + path + filename)[4:].strip()
            remote_timestamp = time.mktime(datetime.strptime(modified_time, "%Y%m%d%H%M%S").timetuple())
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při získávání data úpravy souboru {filename}: {e}", xbmc.LOGERROR)
            ftp.quit()
            return None, None

        ftp.quit()
        xbmc.log(f"[Dohled] FTP info: velikost {size/1024/1024:.1f}MB", xbmc.LOGINFO)
        return remote_timestamp, size

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba FTP při připojení k {host}: {e}", xbmc.LOGERROR)
        return None, None


def get_local_file_info(path):
    """Získá datum poslední úpravy a velikost lokálního souboru."""
    if os.path.exists(path):
        return os.path.getmtime(path), os.path.getsize(path)
    return 0, 0


def download_file_ftp(host, user, password, path, filename, local_path):
    """Stáhne soubor z FTP (start, samooprava) - STEJNĚ ATOMICKY jako ostatní stahovací cesty:
    zámek per soubor, staging /storage/.downloading_<název>, fsync, kontrola velikosti,
    rename. 3.6.0: do 3.5.9 tahle cesta stahovala do <cíl>_tmp ve složce médií bez zámku,
    bez fsync a bez kontroly velikosti (CLAUDE.md: nová stahovací cesta MUSÍ zámek použít)."""
    local_filename = os.path.basename(local_path)
    temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"
    zamek = zamek_stahovani(local_filename)
    with zamek:
        try:
            ftp = FTP(host, timeout=30)
            ftp.login(user, password)
            ftp.voidcmd("TYPE I")
            remote_size = ftp.size(path + filename)
            remote_size_mb = remote_size / (1024 * 1024)
            if get_disk_space_mb(VIDEO_DIR) < remote_size_mb + MIN_FREE_SPACE_MB:
                xbmc.log("[Dohled] Nedostatek místa, spouštím cleanup", xbmc.LOGWARNING)
                cleanup_old_media(local_filename, remote_size_mb)
            xbmc.log(f"[Dohled] Stahuji {filename}...", xbmc.LOGINFO)
            with open(temp_path, "wb") as out_file:
                ftp.retrbinary("RETR " + path + filename, out_file.write, blocksize=1024*1024)
                out_file.flush()
                os.fsync(out_file.fileno())
            ftp.quit()
            actual = os.path.getsize(temp_path)
            if actual != remote_size:
                raise ValueError(f"velikost {actual} != {remote_size} na FTP")
            os.rename(temp_path, local_path)
            xbmc.log(f"[Dohled] Soubor {filename} úspěšně stažen ({remote_size_mb:.1f} MB)", xbmc.LOGINFO)
            try:
                with open(LAST_FILENAME_FILE, "w", encoding="utf-8") as f:
                    f.write(local_filename)
            except Exception:
                pass
            return True
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při stahování {filename} z FTP: {e}", xbmc.LOGERROR)
            try:
                os.remove(temp_path)
            except OSError:
                pass
            return False


# ======= OVĚŘOVÁNÍ INTEGRITY SOUBORŮ + SAMOOPRAVA =======
# Občas se lokální soubor poškodí (přerušené stahování, vadná SD karta, plný disk).
# Kodi ho pak nedokáže přehrát a vzniká smyčka, kdy se přehrávání pořád znovu spouští.
# Tady se poškozený soubor DETEKUJE, SMAŽE a znovu STÁHNE z FTP.

MEDIA_REPAIR_MAX_ATTEMPTS = 2      # kolikrát zkusit opravu téhož souboru
MEDIA_REPAIR_COOLDOWN = 900        # s - po tomto čase se počítadlo pokusů resetuje
_media_repair_state = {}           # filename -> {"attempts": int, "last": monotonic}

# PLNÉ FTP NÁZVY (s podsložkou, 'Oresi/x.mp4') obsahu, jak je poslal server. Lokálně se
# soubory ukládají pod basename; samooprava / dotažení chybějícího souboru ale potřebuje plný
# název. 3.6.0: místo globálního registru, který se plnil odevšad (a proto měl "opakování bez
# podsložky, kdyby byl registr špatný"), se drží jen názvy PRÁVĚ NASAZENÉHO obsahu (z příkazu)
# a OČEKÁVANÉHO obsahu (z /expected-file) - každý se při změně nahradí celý.
_nazvy_obsahu = {}       # basename -> plný název, obsah nasazený příkazem / startem
_nazvy_ocekavane = {}    # basename -> plný název, poslední /expected-file


def _mapa_nazvu(nazvy):
    mapa = {}
    for n in nazvy or []:
        n = strip_playlist_duration((n or "").strip())
        if n and '://' not in n:
            mapa[os.path.basename(n)] = n
    return mapa


def nastavit_nazvy_obsahu(nazvy, pridat=False):
    """Plné názvy obsahu nasazeného příkazem (play_file, play_playlist, download_*...)."""
    global _nazvy_obsahu
    if pridat:
        _nazvy_obsahu = {**_nazvy_obsahu, **_mapa_nazvu(nazvy)}
    else:
        _nazvy_obsahu = _mapa_nazvu(nazvy)


def nastavit_ocekavane_nazvy(expected):
    """Plné názvy z /expected-file ('Oresi/x.jpg' nebo 'playlist:a:10,b')."""
    global _nazvy_ocekavane
    if not expected:
        return
    if expected.startswith('playlist:'):
        _nazvy_ocekavane = _mapa_nazvu(expected[9:].split(','))
    else:
        _nazvy_ocekavane = _mapa_nazvu([expected])


def vzdaleny_nazev(nazev):
    """Plný FTP název pro soubor: název s podsložkou se vrátí beze změny, basename se dohledá
    v nasazeném a očekávaném obsahu. Neznámý basename zůstane (R6: server posílá vždy plné
    názvy, takže soubor mimo aktuální obsah se opravovat nemá)."""
    nazev = strip_playlist_duration(nazev or "")
    if '/' in nazev:
        return nazev
    return _nazvy_obsahu.get(nazev) or _nazvy_ocekavane.get(nazev) or nazev

# Očekávané hlavičky (magic bytes) pro rychlou detekci rozbitého/nedostaženého souboru
_MEDIA_MAGIC = {
    '.png': [b'\x89PNG\r\n\x1a\n'],
    '.jpg': [b'\xff\xd8\xff'],
    '.jpeg': [b'\xff\xd8\xff'],
    '.gif': [b'GIF87a', b'GIF89a'],
    '.bmp': [b'BM'],
    '.mkv': [b'\x1a\x45\xdf\xa3'],
    '.webm': [b'\x1a\x45\xdf\xa3'],
}


def validate_media_file(local_path, expected_size=None):
    """Rychlá kontrola, že mediální soubor není poškozený.

    Vrací (ok: bool, reason: str). Kontroluje se:
    - existence a nenulová velikost,
    - shoda s očekávanou velikostí z API (nedostažený/odseknutý soubor),
    - magic bytes hlavičky podle přípony (mp4/mov mají 'ftyp' na offsetu 4),
    - čitelnost souboru.
    """
    try:
        if not local_path or not os.path.exists(local_path):
            return False, "soubor neexistuje"
        size = os.path.getsize(local_path)
        if size == 0:
            return False, "nulová velikost"
        if expected_size and size != expected_size:
            return False, f"velikost {size} != očekávaná {expected_size}"

        ext = os.path.splitext(local_path)[1].lower()
        with open(local_path, 'rb') as f:
            head = f.read(16)
        if len(head) < 8:
            return False, "soubor je kratší než hlavička"

        if ext in _MEDIA_MAGIC:
            if not any(head.startswith(m) for m in _MEDIA_MAGIC[ext]):
                return False, f"poškozená hlavička {ext}"
        elif ext in ('.mp4', '.m4v', '.mov'):
            # ISO BMFF: box type na offsetu 4 bývá 'ftyp' (případně 'moov'/'mdat'/'free'/'skip')
            if head[4:8] not in (b'ftyp', b'moov', b'mdat', b'free', b'skip', b'wide'):
                return False, "poškozená hlavička mp4"
        elif ext == '.avi':
            if not (head.startswith(b'RIFF') and head[8:12] == b'AVI '):
                return False, "poškozená hlavička avi"
        return True, ""
    except Exception as e:
        return False, f"nelze přečíst: {e}"


def repair_media_file(filename, reason="", locality=None):
    """Smaže poškozený soubor a znovu ho stáhne z FTP.

    Chrání se počítadlem pokusů (MEDIA_REPAIR_MAX_ATTEMPTS) a cooldownem, aby z opravy
    nevznikla nová nekonečná smyčka. Vrací True, když je soubor po opravě v pořádku.
    """

    base = os.path.basename(filename)
    now = time.monotonic()
    st = _media_repair_state.get(base, {"attempts": 0, "last": 0.0})
    if now - st["last"] > MEDIA_REPAIR_COOLDOWN:
        st = {"attempts": 0, "last": now}   # dávno předtím -> nový začátek

    if st["attempts"] >= MEDIA_REPAIR_MAX_ATTEMPTS:
        xbmc.log(f"[Dohled] Oprava {base}: vyčerpány pokusy ({st['attempts']}) - nezkouším dál", xbmc.LOGWARNING)
        return False

    st["attempts"] += 1
    st["last"] = now
    _media_repair_state[base] = st

    # Plná relativní cesta pro FTP (soubor může být v podsložce, lokálně je pod basename)
    remote_name = vzdaleny_nazev(filename)
    xbmc.log(f"[Dohled] POŠKOZENÝ SOUBOR {base} ({reason}) - stahuji znovu z '{remote_name}' "
             f"(pokus {st['attempts']}/{MEDIA_REPAIR_MAX_ATTEMPTS})", xbmc.LOGERROR)

    if locality is None:
        locality = load_config().get("locality")
    ftp_config = fetch_ftp_config(locality) if locality else None
    if not ftp_config or not ftp_config.get("ftp_host"):
        xbmc.log("[Dohled] Oprava: FTP konfigurace není dostupná - vadný soubor RADĚJI NECHÁVÁM", xbmc.LOGERROR)
        return False

    local_path = get_local_media_path(base)
    backup_path = (local_path + ".corrupt") if local_path else None

    # KRITICKÉ: vadný soubor NESMAZAT dřív, než je ověřená náhrada. Dřív se mazal hned
    # a když stahování selhalo (např. špatná FTP cesta), zařízení zůstalo BEZ souboru
    # a Kodi hlásilo "Přehrávání selhalo". Proto ho jen odložíme stranou a při
    # neúspěchu vrátíme zpět.
    moved_aside = False
    try:
        if local_path and os.path.exists(local_path):
            if backup_path and os.path.exists(backup_path):
                os.remove(backup_path)
            os.rename(local_path, backup_path)
            moved_aside = True
    except Exception as e:
        xbmc.log(f"[Dohled] Oprava: nelze odložit vadný soubor: {e}", xbmc.LOGWARNING)

    # Plný název z nasazeného/očekávaného obsahu (vzdaleny_nazev). 3.6.0: bez opakování
    # "ještě bez podsložky" - to kompenzovalo špatný registr názvů, který už neexistuje.
    # Velikost proti FTP ověřuje už download_file_ftp.
    ok = download_file_ftp(
        ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"),
        ftp_config.get("ftp_path"), remote_name, local_path
    )
    valid, why = validate_media_file(local_path) if ok else (False, "stažení selhalo")

    if ok and valid:
        try:
            if moved_aside and backup_path and os.path.exists(backup_path):
                os.remove(backup_path)
        except Exception:
            pass
        xbmc.log(f"[Dohled] Oprava {base}: soubor znovu stažen a je v pořádku", xbmc.LOGINFO)
        sd_health_note_repair(base, reason)
        _video_start_failures.pop(base, None)
        return True

    # Neúspěch - vrátit původní soubor, ať zařízení neskončí úplně bez obsahu
    xbmc.log(f"[Dohled] Oprava {base} SELHALA ({why}) - vracím původní soubor", xbmc.LOGERROR)
    try:
        if moved_aside and backup_path and os.path.exists(backup_path) and not os.path.exists(local_path):
            os.rename(backup_path, local_path)
            xbmc.log("[Dohled] Oprava: původní soubor vrácen na místo", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Oprava: nelze vrátit původní soubor: {e}", xbmc.LOGERROR)
    return False


def ensure_media_playable(filename, expected_size=None, locality=None):
    """Ověří soubor a při poškození ho zkusí opravit. Vrací True, když je použitelný."""
    local_path = get_local_media_path(filename)
    ok, why = validate_media_file(local_path, expected_size)
    if ok:
        return True
    xbmc.log(f"[Dohled] Kontrola integrity {os.path.basename(filename)}: VADNÝ ({why})", xbmc.LOGWARNING)
    return repair_media_file(filename, why, locality)


# ======= SAMOOPRAVA VIDEA + STAV SD KARTY (3.5.4) =======
# Poškozené video (typicky vadná SD karta) projde validate_media_file - velikost i hlavička
# sedí, rozbitá jsou data uprostřed. Kodi pak buď hlásí stovky chyb dekodéru
# "Invalid data found when processing input", nebo se čtení souboru úplně zasekne a video
# se po OpenFile vůbec nerozjede (23.10.2026 "Prodejce - vchod" 22-03 a 22-04: soubor
# 34 s problikl a zmizel, dokola, dokud se ručně nesmazal a nestáhl znovu).
# Tady se proto reaguje na to, co skutečně vidí divák:
#   - video se N× po sobě nerozjede          -> smazat a stáhnout znovu (repair_media_file)
#   - dávka chyb dekodéru u hraného videa    -> totéž
# a zároveň se sbírají signály pro dashboard "vadná SD karta, nutná výměna".
# Automatická oprava téhož souboru je max. 1× za VIDEO_REPAIR_MIN_INTERVAL; když se čerstvě
# stažený soubor znovu poškodí, nestahuje se dokola, ale hlásí se opakované poškození (= SD).

VIDEO_START_FAILS_BEFORE_REPAIR = 2        # kolikrát po sobě se video nesmí rozjet
VIDEO_START_WAIT = 6.0                     # s - jak dlouho čekat, než se video rozjede
DECODER_ERROR_WINDOW = 600                 # s - okno pro počítání chyb dekodéru
DECODER_ERRORS_BEFORE_REPAIR = 30          # chyb dekodéru v okně = poškozené video
VIDEO_REPAIR_MIN_INTERVAL = 24 * 3600      # s - max. 1 automatická oprava souboru za 24 h
SD_HEALTH_FILE = "/storage/.dohled_sd_health.json"
SD_HEALTH_KEEP_DAYS = 14
SD_DMESG_INTERVAL = 600                    # s - jak často číst chyby karty z dmesg
# Jen SD karta (mmc0/mmcblk0) a jen SKUTEČNÉ chyby. mmc1 je na RPi3 WiFi (SDIO);
# "FAT-fs ... not properly unmounted" na /flash je po výpadku proudu běžné a neškodné;
# "mmc0: stop op 12 ... err 0" je jen doprovodný výpis obnovy po chybě (err 0 = bez chyby) -
# ve 3.5.4 se počítal a nafukoval čísla (zjištěno na flotile 23.10.2026).
_SD_IO_SECTOR = re.compile(r'I/O error, dev mmcblk0, sector (\d+)')
_SD_DMESG_PATTERNS = [
    _SD_IO_SECTOR,
    re.compile(r'Buffer I/O error on dev mmcblk0'),
    re.compile(r'EXT4-fs error.*mmcblk0'),
    re.compile(r'mmc0: .*(timed? ?out|CRC|error -\d+|err -\d+)', re.I),
]
_SD_KTIME = re.compile(r'^\[\s*(\d+\.\d+)\]')

_video_start_failures = {}       # basename -> počet neúspěšných startů po sobě
_video_repair_lock = threading.Lock()
_video_repair_running = set()    # basename, které se právě opravují (vlákno)
_sd_lock = threading.Lock()
# Události se počítají PRŮBĚŽNĚ od startu (ring buffer jádra se přepisuje, číst ho pořád
# celý znovu dávalo kolísající nesmyslná čísla) - jen řádky s časem jádra > last_kt.
_sd_dmesg_cache = {"t": 0.0, "count": 0, "last": "", "last_kt": -1.0, "sectors": set()}


def _sd_load():
    try:
        with open(SD_HEALTH_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {"repairs": [], "recorrupt": [], "last_repair": {}, "io_events": []}


def _sd_save(data):
    try:
        tmp = SD_HEALTH_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, SD_HEALTH_FILE)
    except Exception as e:
        xbmc.log(f"[Dohled] SD: nelze uložit stav: {e}", xbmc.LOGWARNING)


def _sd_prune(data):
    limit = time.time() - SD_HEALTH_KEEP_DAYS * 86400
    data["repairs"] = [x for x in data.get("repairs", []) if x.get("t", 0) >= limit]
    data["recorrupt"] = [x for x in data.get("recorrupt", []) if x.get("t", 0) >= limit]
    data["io_events"] = [x for x in data.get("io_events", []) if x.get("t", 0) >= limit]
    data["last_repair"] = {k: v for k, v in data.get("last_repair", {}).items() if v >= limit}
    return data


# Do stavu SD karty se počítají JEN opravy vyvolané přehráváním. "velikost != očekávaná"
# je běžná změna obsahu na FTP (soubor nahrazen) a poškozená hlavička vznikne i přerušeným
# stahováním - ty by dávaly falešné "Podezřelá SD karta" (nalezeno regresí 3.5.4).
SD_SIGNAL_REASONS = ("nerozjelo", "chyby dekodéru")


def sd_health_note_repair(base, reason):
    """Zaznamená úspěšnou opravu souboru poškozeného při PŘEHRÁVÁNÍ (signál vadné SD karty)."""
    if not reason or not any(k in reason for k in SD_SIGNAL_REASONS):
        return
    with _sd_lock:
        data = _sd_prune(_sd_load())
        data["repairs"].append({"t": time.time(), "f": base, "r": (reason or "")[:60]})
        data["last_repair"][base] = time.time()
        _sd_save(data)


def sd_health_note_recorrupt(base, reason):
    """Čerstvě stažený soubor je znovu poškozený - nejsilnější signál vadné SD karty."""
    with _sd_lock:
        data = _sd_prune(_sd_load())
        if not any(x.get("f") == base and time.time() - x.get("t", 0) < 3600
                   for x in data["recorrupt"]):
            data["recorrupt"].append({"t": time.time(), "f": base, "r": (reason or "")[:60]})
            _sd_save(data)
    xbmc.log(f"[Dohled] SD: {base} je ZNOVU poškozený po nedávném stažení ({reason}) - "
             "pravděpodobně vadná SD karta, nestahuji dokola", xbmc.LOGERROR)


def sd_health_note_io(new, last, new_sectors):
    """Nové chyby SD karty z jádra -> trvalý záznam (přežije restart, platí 14 dní)."""
    with _sd_lock:
        data = _sd_prune(_sd_load())
        data.setdefault("io_events", []).append({
            "t": time.time(), "n": int(new), "last": (last or "")[-160:],
            "s": sorted(new_sectors)[:20]})
        data["io_events"] = data["io_events"][-200:]
        _sd_save(data)


def _sd_recently_repaired(base):
    with _sd_lock:
        t = _sd_load().get("last_repair", {}).get(base)
    return bool(t) and (time.time() - t) < VIDEO_REPAIR_MIN_INTERVAL


def _sd_parse_dmesg(text, last_kt, sectors):
    """Projde výpis dmesg a vrátí (nové_chyby, poslední_řádek, nový_last_kt).
    Počítá jen řádky novější než last_kt; vadné sektory přidává do množiny sectors."""
    new, last, max_kt = 0, "", last_kt
    for line in text.splitlines():
        m = _SD_KTIME.match(line)
        kt = float(m.group(1)) if m else None
        if kt is not None:
            if kt <= last_kt:
                continue
            max_kt = max(max_kt, kt)
        if not any(p.search(line) for p in _SD_DMESG_PATTERNS):
            continue
        new += 1
        last = line.strip()[-160:]
        sm = _SD_IO_SECTOR.search(line)
        if sm and len(sectors) < 1000:
            sectors.add(int(sm.group(1)))
    return new, last, max_kt


def _sd_dmesg_errors():
    """Chyby SD karty v jádře od startu: (počet událostí, poslední řádek, počet vadných sektorů).
    Cache SD_DMESG_INTERVAL; dmesg se čte celý, ale počítají se jen nové řádky."""
    c = _sd_dmesg_cache
    now = time.time()
    if now - c["t"] < SD_DMESG_INTERVAL:
        return c["count"], c["last"], len(c["sectors"])
    c["t"] = now
    try:
        out = subprocess.run(["dmesg"], capture_output=True, timeout=10).stdout
        # Restart samotného Kodi (ne systému) nechá dmesg beze změny -> navázat na uloženou
        # pozici téhož startu systému, jinak by se staré chyby započítaly podruhé.
        try:
            with open("/proc/sys/kernel/random/boot_id", encoding="utf-8") as _f:
                _boot = _f.read().strip()   # ID startu SYSTÉMU (get_boot_time je start addonu)
        except Exception:
            _boot = ""
        if c["last_kt"] < 0:
            with _sd_lock:
                _pos = _sd_load().get("dmesg_pos") or {}
            if _boot and _pos.get("boot") == _boot:
                c["last_kt"] = float(_pos.get("kt", -1.0))
                c["count"] = int(_pos.get("count", 0))
                c["last"] = _pos.get("last", "")
                c["sectors"] = set(_pos.get("sectors", []))
        _pred = set(c["sectors"])
        _kt_pred = c["last_kt"]
        new, last, c["last_kt"] = _sd_parse_dmesg(out.decode("utf-8", "replace"), c["last_kt"], c["sectors"])
        if c["last_kt"] != _kt_pred and _boot:
            with _sd_lock:
                _d = _sd_load()
                _d["dmesg_pos"] = {"boot": _boot, "kt": c["last_kt"], "count": c["count"] + new,
                                   "last": last or c["last"], "sectors": sorted(c["sectors"])[:1000]}
                _sd_save(_d)
        if new:
            c["count"] += new
            c["last"] = last
            sd_health_note_io(new, last, c["sectors"] - _pred)
            xbmc.log(f"[Dohled] SD: jádro hlásí {new} nových chyb SD karty (celkem {c['count']}, "
                     f"vadných sektorů {len(c['sectors'])}), poslední: {last}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[Dohled] SD: dmesg nelze přečíst: {e}", xbmc.LOGDEBUG)
    return c["count"], c["last"], len(c["sectors"])


def sd_health_report():
    """Stav SD karty pro monitoring: ok / suspect / bad + podklady."""
    io_errors, io_last, io_sectors = _sd_dmesg_errors()
    with _sd_lock:
        data = _sd_prune(_sd_load())
    repairs = len(data.get("repairs", []))
    recorrupt = len(data.get("recorrupt", []))
    io_events = data.get("io_events", [])
    io_14d = sum(int(x.get("n", 0)) for x in io_events)
    io_sectors_14d = len({sec for x in io_events for sec in x.get("s", [])})
    if not io_last and io_events:
        io_last = io_events[-1].get("last", "")
    if io_errors > 0 or io_14d > 0 or recorrupt > 0:
        status = "bad"
    elif repairs >= 2:
        status = "suspect"
    else:
        status = "ok"
    return {
        "status": status,
        "io_errors": io_errors,
        "io_last": io_last,
        "io_sectors": io_sectors,
        "io_errors_14d": io_14d,
        "io_sectors_14d": io_sectors_14d,
        "io_last_seen": (int(io_events[-1]["t"]) if io_events else None),
        "repairs_14d": repairs,
        "recorrupt_14d": recorrupt,
        "last_repair_file": (data["repairs"][-1]["f"] if data.get("repairs") else None),
    }


_missing_downloads = set()      # basename, které se právě stahují, protože na kartě chyběly


def request_missing_download(filename):
    """Soubor obsahu na kartě chybí (smazaný, uklizený) - stáhnout na pozadí.
    Není to poškození: bez limitu samoopravy (1×/24 h) a nepočítá se do stavu SD karty.
    Vrací True, když se stahování spustilo."""
    base = os.path.basename(filename)
    remote = vzdaleny_nazev(filename)
    with _video_repair_lock:
        if base in _missing_downloads or base in _video_repair_running:
            return False
        _missing_downloads.add(base)

    def _run():
        try:
            xbmc.log(f"[Dohled] Soubor {base} na kartě chybí - stahuji znovu z '{remote}'", xbmc.LOGWARNING)
            download_only_file(remote)
        except Exception as e:
            xbmc.log(f"[Dohled] Stažení chybějícího {base} selhalo: {e}", xbmc.LOGERROR)
        finally:
            with _video_repair_lock:
                _missing_downloads.discard(base)

    threading.Thread(target=_run, daemon=True).start()
    return True


def request_video_repair(filename, reason, replay_if_playing=False):
    """Oprava poškozeného videa na pozadí (stažení může trvat minuty - nesmí blokovat
    monitoring/heartbeat). Vrací True, když se oprava spustila."""
    base = os.path.basename(filename)
    _lokalne = get_local_media_path(base)
    if _lokalne and not os.path.exists(_lokalne):
        # soubor chybí (ne poškození) - stáhnout hned, limit 24 h ani stav SD se netýká
        return request_missing_download(filename)
    if _sd_recently_repaired(base):
        sd_health_note_recorrupt(base, reason)
        return False
    with _video_repair_lock:
        if base in _video_repair_running:
            return False
        _video_repair_running.add(base)

    def _run():
        try:
            xbmc.log(f"[Dohled] Samooprava videa {base}: {reason} - mažu a stahuji znovu", xbmc.LOGWARNING)
            ok = repair_media_file(filename, reason)
            # Znovu pustit JEDNO video v opakování (current_video) - samostatný soubor i jedinou
            # položku playlistu (ta jde stejnou cestou RepeatVideo a smyčka jen čeká). Vícepoložkový
            # playlist current_video nenastavuje a opravený soubor si vezme sám v dalším kole.
            # 3.6.0 (HEAD 8e0f226): podmínka "not current_mixed_playlist" vynechala jednopoložkový
            # playlist - video po samoopravě už nikdo nepustil.
            if ok and replay_if_playing and current_video == base:
                try:
                    xbmc.log(f"[Dohled] Samooprava videa {base}: přehrávám opravený soubor", xbmc.LOGINFO)
                    RepeatVideo(get_local_media_path(base), je_vlastnik=lambda: current_video == base)
                except Exception as e:
                    xbmc.log(f"[Dohled] Samooprava videa {base}: nové přehrání selhalo: {e}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[Dohled] Samooprava videa {base} selhala: {e}", xbmc.LOGERROR)
        finally:
            with _video_repair_lock:
                _video_repair_running.discard(base)

    threading.Thread(target=_run, daemon=True).start()
    return True


def check_video_started(player, file_path):
    """Po spuštění videa ověří, že opravdu hraje. Když se stejné video
    VIDEO_START_FAILS_BEFORE_REPAIR× po sobě nerozjede, spustí samoopravu souboru.
    Vrací True, když video hraje."""
    base = os.path.basename(file_path or "")
    if not base or not is_video_file(base):
        return True
    start = time.time()
    while time.time() - start < VIDEO_START_WAIT:
        if player.isPlayingVideo():
            _video_start_failures.pop(base, None)
            return True
        xbmc.sleep(100)
    n = _video_start_failures.get(base, 0) + 1
    _video_start_failures[base] = n
    xbmc.log(f"[Dohled] Video {base} se nerozjelo ({n}/{VIDEO_START_FAILS_BEFORE_REPAIR})", xbmc.LOGWARNING)
    if n >= VIDEO_START_FAILS_BEFORE_REPAIR:
        _video_start_failures[base] = 0
        # replay: jedno video v opakování (current_video) se po opravě pustí znovu
        request_video_repair(base, f"video se {n}x po sobě nerozjelo", replay_if_playing=True)
    return False


# ======= PLAYLIST PARSING =======

def parse_playlist_item(item):
    """Položka playlistu 'soubor' nebo 'soubor:sekundy' -> {'filename', 'duration'}.
    filename zůstává PLNÝ název ze serveru (s podsložkou)."""
    item = (item or "").strip()
    if not item:
        return None
    head, sep, tail = item.rpartition(':')
    if sep and tail.isdigit():
        return {'filename': head, 'duration': int(tail)}
    return {'filename': item, 'duration': None}


def parse_playlist_items(items):
    """Seznam položek (z příkazu nebo z 'playlist:' řetězce) -> seznam dictů."""
    out = []
    for item in items:
        parsed = parse_playlist_item(item)
        if parsed:
            out.append(parsed)
    return out


# ======= PŘEHRÁVÁNÍ MÉDIÍ =======

def close_image_viewer():
    """Ukončí zobrazení obrázku BEZ odhalení menu - obrazovka zůstane ČERNÁ.

    HISTORIE BUGU: dřív dělala Dialog.Close(all) + Action(Stop) + ActivateWindow(home),
    tedy EXPLICITNĚ zapnula Kodi menu. Nyní se místo menu zobrazí krycí černý obrázek,
    který drží slideshow okno v popředí.
    Pro přechod obrázek→VIDEO tuto funkci není potřeba volat - video slideshow přebije
    samo (viz transition_to_video_from_image).
    """
    global current_displayed_image

    if current_displayed_image is None:
        return False

    xbmc.log(f"[Dohled] Ukončuji obrázek (krytí černou): {current_displayed_image}", xbmc.LOGINFO)

    # Krytí černou PŘED jakýmkoli zavíráním - na obrazovce tak nikdy není prázdno/menu
    show_black_filler("ukončení obrázku")
    time.sleep(0.1)

    current_displayed_image = None
    return True


def RepeatVideo(local_file, je_vlastnik=None):
    """Spustí JEDNO video v opakování (RepeatOne) - samostatně nebo jako jedinou položku
    playlistu. je_vlastnik = funkce "smím ještě nasadit obsah?" (playlistová smyčka,
    samooprava): kontroluje se pod _obrazovka_lock těsně před každým spuštěním, aby
    volající, kterému obsah mezitím převzal někdo jiný, nepřepsal obrazovku ani stav."""
    global current_displayed_image, current_video

    filename = os.path.basename(local_file)
    player = xbmc.Player()

    # Video se pouští VŽDY jako 1položkový PLAYLIST_VIDEO: RepeatOne platí pro aktivní
    # playlist přehrávače, u souboru puštěného mimo playlist by video dohrálo a Kodi by
    # ukázalo HOME (tuhle cestu má start zařízení ověřenou testem L1 - 15 min, 0 chyb).
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    with _obrazovka_lock:
        if je_vlastnik and not je_vlastnik():
            xbmc.log(f"[Dohled] Video {filename}: obsah mezitím převzal jiný - nespouštím", xbmc.LOGINFO)
            return
        playlist.clear()
        playlist.add(local_file)
        if current_displayed_image:
            # Obrázek → Video: video pod slideshow, pak atomické odkrytí
            xbmc.log(f"[Dohled] Přechod obrázek→video: {current_displayed_image} → {filename}", xbmc.LOGINFO)
            transition_to_video_from_image(player, local_file, polozka=playlist)
        else:
            player.play(playlist)
            # KRITICKÉ: nad videem může být KRYCÍ ČERNÁ (show_black_filler) - viz uncover_if_covered
            uncover_if_covered(player, filename)
        current_displayed_image = None
        current_video = filename

        xbmc.executebuiltin("PlayerControl(RepeatOne)")
    xbmc.log(f"[Dohled] Přehrávám video ve smyčce: {filename}", xbmc.LOGINFO)
    send_immediate_state_update()
    # Video, které se nerozjede, zkusit znovu; po VIDEO_START_FAILS_BEFORE_REPAIR neúspěších
    # spustí check_video_started samoopravu a ta opravené video pustí znovu (RepeatVideo).
    # 3.6.0: dřív druhý pokus obstarával auto-play monitoringu (zrušen, R4).
    for pokus in range(1, VIDEO_START_FAILS_BEFORE_REPAIR + 1):
        if check_video_started(player, local_file) or current_video != filename:
            break
        if pokus < VIDEO_START_FAILS_BEFORE_REPAIR:
            with _obrazovka_lock:
                if current_video != filename or (je_vlastnik and not je_vlastnik()):
                    break
                xbmc.log(f"[Dohled] Video {filename} se nerozjelo - zkouším znovu", xbmc.LOGWARNING)
                player.play(playlist)
                uncover_if_covered(player, filename)
    if not player.isPlayingVideo() and current_video == filename:
        # stav_prehravani hlásí pravdu (playing=False), samooprava běží na pozadí
        send_immediate_state_update()


def ShowImage(image_path):
    """Zobrazí jeden obrázek trvale (mimo playlist). Vrací True, když se zobrazil."""
    global current_displayed_image, current_video

    if not os.path.exists(image_path):
        xbmc.log(f"[Dohled] Obrázek nenalezen: {image_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(image_path)
    player = xbmc.Player()
    if player.isPlayingVideo():
        # Video → Obrázek: krytí + ShowPicture PŘED stopem videa
        xbmc.log(f"[Dohled] Přechod video→obrázek: → {filename}", xbmc.LOGINFO)
        transition_to_image_from_video(player, image_path)
        ok = wait_slideshow_shows(image_path, 1.0)
    else:
        ok = show_picture_safe(image_path)
    current_video = None
    if ok:
        current_displayed_image = filename
    else:
        current_displayed_image = None
        show_black_filler("selhalo zobrazení obrázku")
    send_immediate_state_update()
    return ok


def play_media_file(file_path):
    """Přehraje JEDEN soubor podle jeho typu - video v opakování nebo obrázek trvale."""
    if not os.path.exists(file_path):
        xbmc.log(f"[Dohled] Soubor neexistuje: {file_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(file_path)
    media_type = get_media_type(filename)

    if media_type == 'video':
        RepeatVideo(file_path)
        return True
    elif media_type == 'image':
        return ShowImage(file_path)
    else:
        xbmc.log(f"[Dohled] Nepodporovaný typ souboru: {filename}", xbmc.LOGERROR)
        return False


# ======= RESTART SCHEDULING =======

def get_last_reboot_date():
    """Přečte datum posledního restartu z REBOOT_TRACK_FILE."""
    if os.path.exists(REBOOT_TRACK_FILE):
        try:
            with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if lines:
                    first_line = lines[0].strip()
                    if first_line.startswith("Poslední restart:"):
                        return first_line.replace("Poslední restart:", "").strip()
        except:
            pass
    return "Žádný"


def save_planned_reboot(last_reboot_date, planned_time_str):
    """Uloží naplánovaný restart do souboru."""
    try:
        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {last_reboot_date}\n")
            f.write(f"Naplánovaný restart: {planned_time_str}\n")
            f.flush()
            os.fsync(f.fileno())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při ukládání plánovaného restartu: {e}", xbmc.LOGERROR)


# Generace plánovače restartu - inkrementuje se při každém (pře)plánování.
# reboot_task se ukončí bez restartu, pokud mezitím vznikla novější generace (reschedule_restart).
_reboot_generation = 0


def _parse_hm(value, default_h, default_m):
    """Parsuje 'HH:MM' -> (hodina, minuta); při chybě vrátí default."""
    try:
        if value:
            parts = str(value).split(':')
            return int(parts[0]), int(parts[1])
    except Exception:
        pass
    return default_h, default_m


def schedule_random_reboot(locality=None):
    """Naplánuje náhodný noční restart v samostatném vlákně.

    Feature B: okno a zapnutí/vypnutí se čtou z konfigurace lokality (/api/locality_config).
    - auto_restart=False -> žádný naplánovaný restart.
    - reboot_window_start/end (HH:MM) -> okno (výchozí 21:00-05:00), smí přes půlnoc.
    Podporuje přeplánování za běhu (reschedule_restart) přes _reboot_generation.
    """
    global _reboot_generation
    _reboot_generation += 1
    my_gen = _reboot_generation

    def reboot_task():
        monitor = xbmc.Monitor()

        # KRITICKÉ: Počkat (max ~180s), až bude systémový čas ověřený (viz boot-loop fix,
        # _cas_overen - uložený starý "platný" čas by posunul okno restartu).
        waited_for_time = 0
        while not _cas_overen.is_set() and waited_for_time < 180 and not monitor.abortRequested():
            if monitor.waitForAbort(5):
                return
            waited_for_time += 5
        if stop_monitoring or monitor.abortRequested() or _reboot_generation != my_gen:
            return

        # Feature B: načíst restart konfiguraci lokality
        auto_restart = True
        win_start, win_end = None, None
        if locality:
            try:
                cfg = fetch_ftp_config(locality)
                if cfg:
                    auto_restart = cfg.get('auto_restart', True)
                    win_start = cfg.get('reboot_window_start')
                    win_end = cfg.get('reboot_window_end')
            except Exception as e:
                xbmc.log(f"[Dohled] Nepodařilo se načíst restart config lokality: {e}", xbmc.LOGWARNING)

        if not auto_restart:
            xbmc.log("[Dohled] Automatický restart je pro tuto lokalitu VYPNUTÝ - neplánuji", xbmc.LOGINFO)
            return

        now = datetime.now()
        last_reboot_date = get_last_reboot_date()

        # Okno restartu (default 21:00-05:00); smí přesahovat půlnoc
        start_h, start_m = _parse_hm(win_start, 21, 0)
        end_h, end_m = _parse_hm(win_end, 5, 0)
        start_time = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
        end_time = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
        if (end_h, end_m) <= (start_h, start_m):
            end_time = end_time + timedelta(days=1)  # přes půlnoc
        # Pokud už celé okno proběhlo, posunout na další den
        if now >= end_time:
            start_time = start_time + timedelta(days=1)
            end_time = end_time + timedelta(days=1)
        xbmc.log(f"[Dohled] Restart okno {start_h:02d}:{start_m:02d}-{end_h:02d}:{end_m:02d}, plánuji na {start_time.date()}", xbmc.LOGINFO)

        # Vygenerovat náhodný čas restartu (musí být v budoucnosti)
        window_min = max(0, int((end_time - start_time).total_seconds() / 60))
        random_reboot_time = None
        for _ in range(100):
            cand = start_time + timedelta(minutes=random.randint(0, window_min))
            if cand > now:
                random_reboot_time = cand
                break
        if random_reboot_time is None:
            xbmc.log("[Dohled] CHYBA: Nepodařilo se najít platný čas restartu", xbmc.LOGERROR)
            return

        restart_date_time = random_reboot_time.strftime('%Y-%m-%d %H:%M:%S')
        save_planned_reboot(last_reboot_date, restart_date_time)
        xbmc.log(f"[Dohled] Naplánovaný restart: {restart_date_time}", xbmc.LOGINFO)

        # Čekání ukotveno na time.monotonic() (imunní vůči skoku hodin -> boot-loop fix)
        wait_seconds = (random_reboot_time - now).total_seconds()
        if wait_seconds <= 0:
            wait_seconds = 60
        deadline_monotonic = time.monotonic() + wait_seconds

        while (time.monotonic() < deadline_monotonic and not stop_monitoring
               and not monitor.abortRequested() and _reboot_generation == my_gen):
            remaining = deadline_monotonic - time.monotonic()
            if monitor.waitForAbort(min(60, max(1, remaining))):
                xbmc.log("[Dohled] Plánovaný restart zrušen (Kodi se vypíná)", xbmc.LOGINFO)
                return

        if stop_monitoring or monitor.abortRequested():
            xbmc.log("[Dohled] Plánovaný restart zrušen (addon se vypíná)", xbmc.LOGINFO)
            return
        if _reboot_generation != my_gen:
            xbmc.log("[Dohled] Plánovaný restart zrušen (přeplánováno)", xbmc.LOGINFO)
            return

        # Pojistka proti smyčce restartů (belt-and-suspenders)
        if not can_auto_reboot("scheduled"):
            return

        xbmc.log("[Dohled] Provádím naplánovaný restart zařízení...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Restart", "Zařízení se nyní restartuje", xbmcgui.NOTIFICATION_WARNING)
        mark_reboot("scheduled")
        xbmc.executebuiltin("Reboot")

    threading.Thread(target=reboot_task, daemon=True).start()


# ======= FALLBACK FUNKCE =======

def find_best_fallback_file():
    """Najde nejlepší fallback soubor."""
    try:
        if os.path.exists(LAST_FILENAME_FILE):
            with open(LAST_FILENAME_FILE, encoding="utf-8") as f:
                last_file = f.read().strip()
                possible = get_local_media_path(last_file)
                if possible and os.path.exists(possible):
                    xbmc.log(f"[Dohled] Fallback z last_filename: {possible}", xbmc.LOGINFO)
                    return possible

        # Hledat v obou adresářích (VIDEO_DIR a IMAGE_DIR)
        media_files = []
        for media_dir in [VIDEO_DIR, IMAGE_DIR]:
            if os.path.exists(media_dir):
                for filename in os.listdir(media_dir):
                    if is_supported_file(filename):
                        filepath = os.path.join(media_dir, filename)
                        mtime = os.path.getmtime(filepath)
                        media_files.append((filepath, mtime, get_media_type(filename)))

        if media_files:
            media_files.sort(key=lambda x: (x[2] != 'video', -x[1]))
            xbmc.log(f"[Dohled] Fallback nejnovější: {media_files[0][0]}", xbmc.LOGINFO)
            return media_files[0][0]

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání fallback souboru: {e}", xbmc.LOGERROR)

    return None


def get_best_available_file(preferred_file):
    """Najde nejlepší dostupný soubor pro přehrání."""
    if preferred_file and os.path.exists(preferred_file) and os.path.getsize(preferred_file) > 0:
        return preferred_file

    fallback_file = find_best_fallback_file()
    if fallback_file and os.path.exists(fallback_file) and os.path.getsize(fallback_file) > 0:
        return fallback_file

    try:
        if os.path.exists("/storage/videos/"):
            for filename in os.listdir("/storage/videos/"):
                if is_supported_file(filename):
                    filepath = os.path.join("/storage/videos/", filename)
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        xbmc.log(f"[Dohled] Nouzový soubor: {filepath}", xbmc.LOGWARNING)
                        return filepath
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání nouzového souboru: {e}", xbmc.LOGERROR)

    return None


# Globální stav WebSocket spojení
ws_connected = False
ws_app = None
ws_thread = None
last_ws_ack_time = 0  # Cas posledniho ACK od serveru
WS_STALE_TIMEOUT = 90  # Pokud zadny ACK za 90s, WS je mrtve

# Globální stav pro mixed playlist playback
# Používáme playlist_id místo stop_flag pro spolehlivé zastavení předchozího playlistu
current_playlist_id = 0
mixed_playlist_thread = None
# Předání obsahu mezi vlastníky: ukoncit_playlist mění current_playlist_id POD tímto zámkem
# a playlistová smyčka (i samooprava přes RepeatVideo) pod ním těsně před každým zápisem
# stavu obrazovky / zobrazením ověří, že je pořád vlastníkem. Stará smyčka tak po převzetí
# nic nepřepíše, ať doběhne kdykoli (3.5.9/3.6.0 spoléhaly na join s timeoutem 2 s).
_obrazovka_lock = threading.RLock()
# Globální proměnné pro sledování celého playlistu (včetně obrázků)
current_mixed_playlist = []  # Plné názvy položek běžícího playlistu (pro hlášení)
current_mixed_playlist_position = -1  # Aktuální pozice v playlistu
current_playlist_items = None  # TENTÝŽ seznam dictů, který prochází běžící smyčka (add_to_playlist)
# Akce z mobilu: běžící smyčka akce (files = TENTÝŽ seznam, který smyčka prochází -
# akce_append do něj přidává na konec; smyčka čte len() v každém kroku)
current_akce = {"id": None, "files": None, "playlist_id": None, "pending": []}
_akce_lock = threading.Lock()  # akce_append (vlákno) vs. start smyčky akce
# Pořadí posledního příkazu se stahováním (download_and_play*) - po stažení se přehrává jen
# nejnovější, starší dostažený příkaz už nic nepustí (souběh "běžný obsah" + "akce").
_posledni_stahovany_prikaz = 0


def _novy_stahovany_prikaz():
    global _posledni_stahovany_prikaz
    _posledni_stahovany_prikaz += 1
    return _posledni_stahovany_prikaz


def _stale_nejnovejsi(poradi, popis):
    if poradi is not None and poradi != _posledni_stahovany_prikaz:
        xbmc.log(f"[Dohled] {popis}: mezitím přišel novější příkaz - nepřehrávám", xbmc.LOGINFO)
        return False
    return True


class WebSocketClient:
    """WebSocket klient pro real-time komunikaci s API serverem."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.ws = None
        self.connected = False
        self.should_reconnect = True
        self.last_monitoring_time = 0

    def on_message(self, ws, message):
        """Zpracování příchozí zprávy ze serveru."""
        try:
            data = json.loads(message)
            msg_type = data.get("type")

            xbmc.log(f"[Dohled WS] Přijata zpráva typu: {msg_type}", xbmc.LOGINFO)

            if msg_type == "command":
                # Okamžité zpracování příkazu!
                command = data.get("command")
                params = data.get("params", {})
                if command:
                    xbmc.log(f"[Dohled WS] Příkaz: {command}, params: {params}", xbmc.LOGINFO)
                    # Vykoná se ve frontě příkazů (jedno vlákno, pořadí zachované) - přechody
                    # obrazovky trvají až ~14 s a WS vlákno má mezitím dál odpovídat na ping.
                    zaradit_prikaz(command, params, data.get("command_id"))

            elif msg_type == "ping":
                # Odpovědět na ping
                self.send_pong()

            elif msg_type == "welcome":
                # KRITICKÉ: Teprve zde nastavujeme ws_connected = True
                # Toto je potvrzení že server nás skutečně přijal a zařadil do active_connections
                global ws_connected
                ws_connected = True
                xbmc.log(f"[Dohled WS] Server potvrdil spojení! device_id={data.get('device_id')}", xbmc.LOGINFO)

            elif msg_type == "ack":
                global last_ws_ack_time
                last_ws_ack_time = time.time()
                xbmc.log("[Dohled WS] Server potvrdil monitoring data", xbmc.LOGINFO)

        except json.JSONDecodeError:
            xbmc.log(f"[Dohled WS] Neplatná JSON zpráva: {message[:100]}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba zpracování zprávy: {e}", xbmc.LOGERROR)

    def on_error(self, ws, error):
        """Zpracování chyby WebSocket."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Chyba: {error}", xbmc.LOGERROR)
        pri_chybe_tls(error, "WebSocket")   # certifikát neplatný vůči hodinám -> synchronizace času
        self.connected = False
        ws_connected = False  # Povolit HTTP fallback

    def on_close(self, ws, close_status_code, close_msg):
        """Zpracování uzavření spojení."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Spojení uzavřeno: {close_status_code} - {close_msg}", xbmc.LOGWARNING)
        self.connected = False
        ws_connected = False

        if self.should_reconnect:
            xbmc.log(f"[Dohled WS] Pokus o reconnect za {WS_RECONNECT_INTERVAL}s...", xbmc.LOGINFO)

    def on_open(self, ws):
        """Zpracování navázání spojení - čekáme na welcome zprávu ze serveru."""
        # DŮLEŽITÉ: Nenastavujeme ws_connected = True zde!
        # Čekáme na welcome zprávu ze serveru jako potvrzení že je spojení skutečně funkční
        xbmc.log("[Dohled WS] TCP spojení navázáno, čekám na welcome zprávu ze serveru...", xbmc.LOGINFO)
        self.connected = True  # Lokální flag pro send_json
        # ws_connected = True se nastaví až po přijetí welcome zprávy

        # Odeslat identifikaci s autorizačním tokenem
        self.send_json({
            "type": "identify",
            "device_id": self.device_id,
            "auth_token": API_KEY
        })

    def send_json(self, data):
        """Odeslání JSON zprávy přes WebSocket."""
        if self.ws and self.connected:
            try:
                self.ws.send(json.dumps(data))
                return True
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba při odesílání: {e}", xbmc.LOGERROR)
                self.connected = False
        return False

    def send_pong(self):
        """Odpověď na ping."""
        self.send_json({"type": "pong"})

    def send_monitoring(self, payload):
        """Odeslání monitoring dat přes WebSocket."""
        return self.send_json({
            "type": "monitoring",
            "payload": payload
        })

    def send_log_upload(self, lines):
        """Odeslani Kodi logu na server pres WebSocket."""
        return self.send_json({
            "type": "log_upload",
            "lines": lines,
            "timestamp": datetime.now().isoformat()
        })

    def connect(self):
        """Navázání WebSocket spojení."""
        global ws_app, ws_connected

        url = f"{WS_URL}{self.device_id}"
        xbmc.log(f"[Dohled WS] Připojuji se k: {url}", xbmc.LOGINFO)

        try:
            # SSL kontext - ověřené certifikáty (stejný jako api_request)
            ctx = get_ssl_context()

            self.ws = websocket.WebSocketApp(
                url,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close,
                on_open=self.on_open
            )
            ws_app = self.ws

            # Spustit WebSocket v blokovacím režimu (v samostatném vlákně)
            self.ws.run_forever(
                sslopt={"context": ctx},
                ping_interval=WS_PING_INTERVAL,
                ping_timeout=10
            )

        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba při připojování: {e}", xbmc.LOGERROR)
            self.connected = False
            ws_connected = False  # Povolit reconnect

    def disconnect(self):
        """Ukončení WebSocket spojení."""
        self.should_reconnect = False
        if self.ws:
            try:
                self.ws.close()
            except:
                pass


def ws_connection_loop(device_id):
    """Smyčka pro udržování WebSocket spojení."""

    if not WEBSOCKET_AVAILABLE:
        xbmc.log("[Dohled WS] WebSocket knihovna není dostupná, použije se HTTP", xbmc.LOGWARNING)
        return

    xbmc.log("[Dohled WS] Spouštím WebSocket connection loop", xbmc.LOGINFO)

    ws_client = WebSocketClient(device_id)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        if not ws_connected:
            try:
                ws_client.connect()
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba v connection loop: {e}", xbmc.LOGERROR)

        # Čekat před dalším pokusem o reconnect - použít waitForAbort místo time.sleep!
        # waitForAbort se okamžitě vrátí pokud Kodi požaduje ukončení
        if monitor.waitForAbort(WS_RECONNECT_INTERVAL):
            break
        if stop_monitoring:
            break

    ws_client.disconnect()
    xbmc.log("[Dohled WS] Connection loop ukončen", xbmc.LOGINFO)


# České NTP servery (seřazené podle priority)
CZ_NTP_SERVERS = [
    "antispam.oresi.cz",  # ORESI interní server
    "tik.cesnet.cz",      # CESNET stratum 1
    "tak.cesnet.cz",      # CESNET stratum 1
    "ntp.nic.cz",         # CZ.NIC stratum 1
    "ntp.cesnet.cz",      # CESNET
    "0.cz.pool.ntp.org",  # Czech NTP pool
    "1.cz.pool.ntp.org",
]

# České HTTP servery pro fallback (bez HTTPS - aby fungoval i při špatném čase)
CZ_HTTP_SERVERS = [
    "http://www.seznam.cz",
    "http://www.novinky.cz",
    "http://www.idnes.cz",
    "http://www.centrum.cz",
    # Náš server jako poslední zdroj: je dosažitelný všude, kde zařízení vůbec funguje
    # (i za firewallem, který pustí jen nás). Čte se jen hlavička Date (bez ověření
    # certifikátu - ten při špatných hodinách ověřit nejde, viz sync_time_http).
    "https://apidohled.noreason.eu/",
]

# Minimální platný rok pro kontrolu času
MIN_VALID_YEAR = 2024
# Spodní hranice platného času ("build floor"): časy PŘED tímto datem jsou zaručeně
# špatné (zaseknutý fake-hwclock / RTC bez baterie). Bez tohoto by is_time_valid()
# přijalo starý "platný" čas (rok >= 2024, např. 2025-06) a addon by nesynchronizoval
# -> špatný čas by pak otrávil plánování restartu (viz schedule_random_reboot).
MIN_VALID_DATE = datetime(2026, 7, 1)

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Maximální doba čekání na síť (v sekundách)
NETWORK_WAIT_TIMEOUT = 30

# ======= SYNCHRONIZACE ČASU =======

def wait_for_network(timeout=NETWORK_WAIT_TIMEOUT):
    """Čeká na dostupnost sítě (WiFi může trvat déle)."""
    xbmc.log("[Dohled] Čekám na dostupnost sítě...", xbmc.LOGINFO)

    waited = 0
    while waited < timeout:
        try:
            # Zkusit připojení na Google DNS (IP bez DNS resolvingu)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            xbmc.log(f"[Dohled] Síť dostupná po {waited}s", xbmc.LOGINFO)
            return True
        except:
            pass

        time.sleep(1)
        waited += 1

        # Informovat každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Dohled] Stále čekám na síť... ({waited}s)", xbmc.LOGINFO)

    xbmc.log(f"[Dohled] Timeout čekání na síť ({timeout}s)", xbmc.LOGWARNING)
    return False



def is_time_valid():
    """Zkontroluje, zda je systémový čas platný.
    Platný = rok >= MIN_VALID_YEAR A ZÁROVEŇ není před build floor (MIN_VALID_DATE).
    Odmítnutí zaseknutého starého času (např. 2025-06 z fake-hwclock) vynutí NTP sync,
    aby se špatný čas nedostal do plánování restartu."""
    now = datetime.now()
    is_valid = now.year >= MIN_VALID_YEAR and now >= MIN_VALID_DATE
    xbmc.log(f"[Dohled] Kontrola času: {now.strftime('%Y-%m-%d %H:%M:%S')}, platný: {is_valid}", xbmc.LOGINFO)
    return is_valid


def sync_time_ntp(timeout=5):
    """Pokusí se synchronizovat čas přes NTP pomocí ntpd."""
    for server in CZ_NTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o NTP sync: {server}", xbmc.LOGINFO)
            # ntpd -n -q = nedaemonizovat, ukončit po sync
            result = subprocess.run(
                ["ntpd", "-n", "-q", "-p", server],
                timeout=timeout,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                xbmc.log(f"[Dohled] NTP synchronizace úspěšná: {server}", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"[Dohled] NTP {server} selhalo: {result.stderr}", xbmc.LOGWARNING)
        except subprocess.TimeoutExpired:
            xbmc.log(f"[Dohled] NTP {server} timeout po {timeout}s", xbmc.LOGWARNING)
        except FileNotFoundError:
            xbmc.log("[Dohled] ntpd není dostupný, přeskakuji NTP", xbmc.LOGWARNING)
            return False
        except Exception as e:
            xbmc.log(f"[Dohled] NTP {server} chyba: {e}", xbmc.LOGERROR)
    return False


def sync_time_http(timeout=5):
    """Fallback: získá čas z HTTP Date hlavičky (když NTP nedosáhne, např. firewall lokality).

    DŮLEŽITÉ opravy oproti dřívějšku:
    - http:// dnes většinou přesměruje na https://. Při ŠPATNÉM systémovém čase by ověření
      certifikátu selhalo (cert 'not yet valid') -> celý fallback padal. Proto použijeme
      SSL kontext BEZ ověření certifikátu (čteme jen Date hlavičku, ne obsah = bezpečné).
    - Date hlavička je v UTC (GMT) a nastavuje se jako UTC (`date -u -s`). Do 3.6.1 se
      převáděla na místní čas podle pásma KODI (astimezone), ale `date` ji četl podle pásma
      SYSTÉMU - když se lišila, hodiny se nastavily o rozdíl pásem špatně.
    """
    import ssl as _ssl
    ctx = _ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = _ssl.CERT_NONE
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))
    for url in CZ_HTTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o HTTP time sync: {url}", xbmc.LOGINFO)
            req = urllib.request.Request(url, method='GET')
            req.add_header('User-Agent', 'Mozilla/5.0')

            # Date nese KAŽDÁ HTTP odpověď, i chybová (kořen našeho serveru vrací 404) -
            # HTTPError je odpověď s hlavičkami, čas z ní platí stejně.
            try:
                with opener.open(req, timeout=timeout) as response:
                    date_header = response.headers.get('Date')
            except urllib.error.HTTPError as e:
                date_header = e.headers.get('Date') if e.headers else None
                e.close()
                xbmc.log(f"[Dohled] {url} odpověděl HTTP {e.code} - čtu Date z odpovědi", xbmc.LOGINFO)
            if date_header:
                # RFC 2822 -> UTC
                server_time = parsedate_to_datetime(date_header)
                time_str = server_time.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

                xbmc.log(f"[Dohled] HTTP čas ze serveru: {time_str} UTC (Date: {date_header})", xbmc.LOGINFO)

                result = subprocess.run(
                    ["date", "-u", "-s", time_str],
                    capture_output=True,
                    text=True
                )

                if result.returncode == 0:
                    xbmc.log(f"[Dohled] Systémový čas nastaven na: {time_str} UTC", xbmc.LOGINFO)
                    return True
                else:
                    xbmc.log(f"[Dohled] Chyba nastavení času: {result.stderr}", xbmc.LOGERROR)
            else:
                xbmc.log(f"[Dohled] {url} nevrátil Date hlavičku", xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log(f"[Dohled] HTTP sync {url} chyba: {e}", xbmc.LOGERROR)

    return False


def _synchronizovat_cas():
    """Jeden pokus o synchronizaci času ze zdroje (NTP, pak HTTP Date). True = čas nastaven.
    Synchronizuje VŽDY - i když čas vypadá platně (is_time_valid kontroluje jen spodní mez)."""
    if sync_time_ntp(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes NTP", xbmc.LOGINFO)
        return True
    xbmc.log("[Dohled] NTP selhalo, zkouším HTTP fallback", xbmc.LOGWARNING)
    if sync_time_http(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes HTTP", xbmc.LOGINFO)
        return True
    return False


def _jadro_ma_synchronizovany_cas():
    """Hlásí jádro synchronizované hodiny (adjtimex != TIME_ERROR)? Nastavuje to systémová
    synchronizace času (connman). Po ručním `date --set` nebo startu bez sítě je stav
    TIME_ERROR (5) = hodiny nesynchronizované."""
    try:
        import ctypes
        buf = ctypes.create_string_buffer(512)   # struct timex; modes = 0 -> jen čtení
        stav = ctypes.CDLL(None).adjtimex(buf)
        return 0 <= stav < 5
    except Exception as e:
        xbmc.log(f"[Dohled] Stav synchronizace hodin z jádra nelze zjistit: {e}", xbmc.LOGWARNING)
        return False


# Čas OVĚŘEN = synchronizace ze zdroje proběhla (náš NTP/HTTP Date) nebo jádro hlásí
# synchronizované hodiny. Do 3.6.0 (HEAD 8e0f226) stačilo is_time_valid() = "není před
# MIN_VALID_DATE": uložený starý, ale "platný" čas (např. před notBefore certifikátu
# apidohled - Let's Encrypt obnovuje ~60 dní) se nikdy nesynchronizoval a ověřené TLS
# pak selhávalo navždy ("certificate is not yet valid").
_cas_overen = threading.Event()
# Požadavek na synchronizaci od TLS (certifikát "not yet valid"/"expired" = špatné hodiny)
_cas_pozadavek = threading.Event()
CAS_SYNC_MIN_INTERVAL = 300   # s - synchronizace na žádost TLS nejvýš jednou za 5 min
_cas_posledni_sync = None     # monotonic posledního pokusu o synchronizaci


def _cas_overen_ted(zdroj):
    """Čas je ověřený. R8: boot_time se spočítá JEDNOU - až z ověřeného času - a dál se
    posílá stejná hodnota (do 3.6.0 se mohl spočítat z obnoveného času před NTP)."""
    global _boot_time_ts
    if _boot_time_ts is None:
        _boot_time_ts = time.time() - (time.monotonic() - ADDON_START_MONOTONIC)
        xbmc.log(f"[Dohled] Čas ověřen ({zdroj}): boot_time = {get_boot_time()} "
                 "(spočítán jednou z ověřeného času)", xbmc.LOGINFO)
    _cas_overen.set()


def je_chyba_casu_certifikatu(chyba):
    """Selhalo ověření certifikátu kvůli hodinám zařízení? (X509_V_ERR_CERT_NOT_YET_VALID = 9,
    X509_V_ERR_CERT_HAS_EXPIRED = 10). Prochází i obal výjimky (URLError.reason, __cause__)."""
    videno = set()
    while chyba is not None and id(chyba) not in videno:
        videno.add(id(chyba))
        if isinstance(chyba, ssl.SSLCertVerificationError):
            if getattr(chyba, "verify_code", None) in (9, 10):
                return True
            zprava = str(getattr(chyba, "verify_message", "") or chyba).lower()
            return "not yet valid" in zprava or "expired" in zprava
        dalsi = getattr(chyba, "reason", None)
        chyba = dalsi if isinstance(dalsi, BaseException) else (chyba.__cause__ or chyba.__context__)
    return False


def pri_chybe_tls(chyba, kde):
    """Volá se při chybě spojení na náš server (HTTP i WS). Chyba certifikátu způsobená
    hodinami -> požádat hlídání času o okamžitou synchronizaci (HTTP Date)."""
    if je_chyba_casu_certifikatu(chyba):
        if not _cas_pozadavek.is_set():
            xbmc.log(f"[Dohled] {kde}: certifikát serveru neplatný vůči hodinám zařízení "
                     f"({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) - žádám o synchronizaci času", xbmc.LOGWARNING)
        _cas_pozadavek.set()


def hlidat_cas():
    """Vlákno po celou dobu běhu: dokud čas není ověřený, každých 30 s zkusí synchronizaci;
    na žádost TLS (pri_chybe_tls) synchronizuje hned - nejvýš jednou za CAS_SYNC_MIN_INTERVAL.

    PROČ: když při startu nebyla síť (30 s), čas se do 3.5.9 už nikdy nesynchronizoval
    (zařízení jelo s rokem 2024) a s naším serverem mluvilo jen díky TLS bez ověření.
    3.6.0 ověřuje certifikát vždy, takže špatný čas se musí opravit u zdroje."""
    global _cas_posledni_sync
    monitor = xbmc.Monitor()
    # pokus právě proběhl při startu (ensure_time_synchronized) -> další za 30 s
    dalsi_pokus = time.monotonic() if _cas_posledni_sync is None else _cas_posledni_sync + 30
    while not monitor.abortRequested() and not stop_monitoring:
        ted = time.monotonic()
        if not _cas_overen.is_set():
            if ted >= dalsi_pokus:
                _cas_pozadavek.clear()
                _cas_posledni_sync = ted
                if _synchronizovat_cas():
                    _cas_overen_ted("synchronizace NTP/HTTP")
                else:
                    xbmc.log("[Dohled] Čas se nepodařilo ověřit - zkusím za 30 s", xbmc.LOGWARNING)
                    dalsi_pokus = time.monotonic() + 30
        elif _cas_pozadavek.is_set():
            _cas_pozadavek.clear()
            if _cas_posledni_sync is None or ted - _cas_posledni_sync >= CAS_SYNC_MIN_INTERVAL:
                _cas_posledni_sync = ted
                if not _synchronizovat_cas():
                    xbmc.log("[Dohled] Synchronizace času na žádost TLS selhala", xbmc.LOGWARNING)
            else:
                xbmc.log("[Dohled] Synchronizace času na žádost TLS: poslední byla před "
                         f"{ted - _cas_posledni_sync:.0f} s - čekám", xbmc.LOGDEBUG)
        if monitor.waitForAbort(1):
            return


def ensure_time_synchronized():
    """Ověření času při startu (před čímkoli jiným). Neplatný čas (před MIN_VALID_DATE) se
    synchronizuje hned (blokuje - bez něj nejde nic); "platný", ale neověřený čas ověří
    vlákno hlidat_cas na pozadí (start obsahu na ověření počká, viz _startup_playback)."""
    global _cas_posledni_sync
    xbmc.log("[Dohled] === Zahajuji kontrolu a synchronizaci času ===", xbmc.LOGINFO)
    sit = wait_for_network()
    if _jadro_ma_synchronizovany_cas():
        _cas_overen_ted("jádro hlásí synchronizované hodiny")
    elif sit and not is_time_valid():
        xbmc.log("[Dohled] Systémový čas je neplatný, spouštím synchronizaci", xbmc.LOGWARNING)
        _cas_posledni_sync = time.monotonic()
        if _synchronizovat_cas():
            _cas_overen_ted("synchronizace NTP/HTTP")
    if not _cas_overen.is_set():
        xbmc.log("[Dohled] Čas zatím není ověřený - synchronizace pokračuje na pozadí", xbmc.LOGWARNING)
    threading.Thread(target=hlidat_cas, daemon=True).start()
    return _cas_overen.is_set()

# ======= ČASOVÉ PÁSMO (3.6.2) =======
# Zařízení musí běžet v českém čase: plánování nočního restartu (okno 21:00-05:00), časy na
# dashboardu (boot_time, next_reboot, změny souborů) i převody času se počítají v místním
# čase zařízení. Pásmo nastavuje instalace zařízení - když se nenastaví, LibreELEC běží
# v UTC (tz-data.service: výchozí TIMEZONE=UTC). 31.10.2026: nové zařízení 08-20 hlásilo
# všechny časy o hodinu posunuté.
# Pásmo se mění nastavením Kodi locale.timezone (JSON-RPC): Kodi pak samo (patch
# LibreELEC kodi-100.08-setup-timezone) zapíše /storage/.cache/timezone, restartuje
# tz-data.service (systémové /var/run/localtime) a přepne TZ vlastního procesu (tzset) -
# tím i časy tohoto doplňku. Ověřeno na TEST-RPI3.
CILOVE_CASOVE_PASMO = "Europe/Prague"
CILOVA_ZEME_PASMA = "Czech Republic"
SOUBOR_PASMA_LIBREELEC = "/storage/.cache/timezone"


def _pasmo_jako_cilove(pasmo):
    """Má pásmo stejná pravidla jako Europe/Prague (SEČ/SELČ, např. Europe/Bratislava)?
    Takové nastavení se nepřepisuje - čas je stejný."""
    if pasmo == CILOVE_CASOVE_PASMO:
        return True
    try:
        from zoneinfo import ZoneInfo
        rok = datetime.now().year
        return all(datetime(rok, mesic, 15, 12, tzinfo=ZoneInfo(pasmo)).utcoffset()
                   == datetime(rok, mesic, 15, 12, tzinfo=ZoneInfo(CILOVE_CASOVE_PASMO)).utcoffset()
                   for mesic in (1, 7))
    except Exception:
        return False


def _nastaveni_kodi(id_nastaveni):
    resp = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
        "params": {"setting": id_nastaveni}})))
    return (resp.get("result") or {}).get("value")


def _nastavit_kodi(id_nastaveni, hodnota):
    resp = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
        "params": {"setting": id_nastaveni, "value": hodnota}})))
    return resp.get("result") is True


def zajistit_casove_pasmo():
    """Při startu: nastavení Kodi locale.timezone v českém čase a systém (LibreELEC) ve
    stejném pásmu. Volá se PŘED synchronizací času a plánováním restartu."""
    try:
        pasmo = _nastaveni_kodi("locale.timezone")
        if not pasmo or not _pasmo_jako_cilove(pasmo):
            zeme = _nastaveni_kodi("locale.timezonecountry")
            if zeme != CILOVA_ZEME_PASMA:
                _nastavit_kodi("locale.timezonecountry", CILOVA_ZEME_PASMA)
            if _nastavit_kodi("locale.timezone", CILOVE_CASOVE_PASMO):
                xbmc.log(f"[Dohled] Časové pásmo {pasmo} ({zeme}) -> {CILOVE_CASOVE_PASMO}: "
                         f"čas teď {time.strftime('%Y-%m-%d %H:%M:%S %Z')}", xbmc.LOGWARNING)
                pasmo = CILOVE_CASOVE_PASMO
            else:
                xbmc.log(f"[Dohled] Časové pásmo {pasmo} se nepodařilo změnit na "
                         f"{CILOVE_CASOVE_PASMO}", xbmc.LOGERROR)
                return
        # Systémové pásmo zapisuje Kodi jen při ZMĚNĚ nastavení. Chybí-li soubor (výchozí
        # UTC) při už správném nastavení Kodi, doplní se stejně, jak to dělá Kodi.
        ocekavano = f"TIMEZONE={pasmo}"
        try:
            with open(SOUBOR_PASMA_LIBREELEC, encoding="utf-8") as f:
                ulozeno = f.read().strip()
        except OSError:
            ulozeno = None
        if ulozeno != ocekavano:
            with open(SOUBOR_PASMA_LIBREELEC, "w", encoding="utf-8") as f:
                f.write(ocekavano + "\n")
            subprocess.run(["systemctl", "restart", "tz-data.service"],
                           capture_output=True, timeout=15)
            xbmc.log(f"[Dohled] Systémové časové pásmo {ulozeno} -> {ocekavano}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[Dohled] Kontrola časového pásma selhala: {e}", xbmc.LOGERROR)


def vypnout_service_smycky():
    """service.smycky (starý doplněk smyček) se při startu VYPNE, pokud je nainstalovaný
    a zapnutý. Na 7 lokalitách běžel v legacy režimu vedle service.dohled = dvě
    přehrávací smyčky na jedné TV. Jinak se o něj doplněk nestará (R10)."""
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails",
            "params": {"addonid": "service.smycky", "properties": ["enabled", "version"]}})))
        det = (resp.get("result") or {}).get("addon")
        if not det:
            return   # není nainstalovaný
        if not det.get("enabled"):
            xbmc.log("[Dohled] service.smycky je nainstalovaný, ale vypnutý", xbmc.LOGINFO)
            return
        xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
            "params": {"addonid": "service.smycky", "enabled": False}}))
        xbmc.log(f"[Dohled] service.smycky {det.get('version')} byl zapnutý (druhá přehrávací "
                 "smyčka na TV) - VYPÍNÁM", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[Dohled] Vypnutí service.smycky selhalo: {e}", xbmc.LOGERROR)


# ======= AKTUALIZACE DOPLŇKU =======
# JEDINÝ mechanismus (3.6.0): nativní auto-update Kodi z repository.noreason.
# Doplněk jen požádá Kodi o kontrolu repozitářů (UpdateAddonRepos) - při startu a pak
# každou hodinu (Kodi sám kontroluje jen 1x za den); stažení a instalaci dělá Kodi.
#
# Ruling 27.10.2026 (důkaz z logů flotily, 187 zařízení): 3.5.9 doručil nativní update
# Kodi (addon se restartoval bez restartu Kodi, žádné "AKTUALIZACE DOKONČENA"). Vlastní
# self-update proběhl v uložených logech JEDNOU (3.5.6->3.5.7, 24.10.) - a to jen proto, že
# po UpdateAddonRepos předběhl instalaci, kterou by Kodi stejně provedlo. "Opravy" databáze
# Kodi nebyly nikdy potřeba (installed/origin 0x, update_rules 0x), "oprava" guisettings
# (default="true" -> "false") se opakovala 1451x, protože Kodi takhle zapisuje VÝCHOZÍ
# hodnotu (0 = instalovat automaticky) a při ukončení ji přepíše zpět. Všechno pryč.

def zkontrolovat_aktualizace():
    """Požádá Kodi o kontrolu repozitářů; novější verzi Kodi nainstaluje samo."""
    xbmc.log("[Dohled] Kontrola aktualizací doplňků (UpdateAddonRepos)", xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateAddonRepos()')


# STAV aktualizací v monitoringu (pole "aktualizace"). Doplněk NIC neopravuje (ruling
# koordinátora 28.10.2026), jen hlásí, co vidí; vyhodnocení ("v pořádku" / problém) dělá
# server. Kontrakt (pevný, API ho čte stejně):
#   {"auto_update": int general.addonupdates (0 = instalovat automaticky, 1 = jen upozornit,
#                   2 = nikdy) | None,
#    "enabled": bool service.dohled povolen (tabulka installed v Addons*.db) | None,
#    "origin":  str origin service.dohled z tabulky installed | None,
#    "pinned":  bool existuje záznam service.dohled v update_rules (připnutá verze) | None,
#    "repo_enabled": bool repozitář repository.noreason povolený (installed.enabled; v čitelné
#                   databázi chybí = nenainstalovaný = False) | None}
#   None celé, když nejde zjistit nic.
# Zjišťuje se jednou za start a pak jednou za hodinu (cache), ne v každém hlášení.
AKTUALIZACE_INTERVAL = 3600
_aktualizace_cache = {"cas": None, "hodnota": None}


def _addons_db():
    """Aktuální databáze doplňků Kodi = Addons<N>.db s nejvyšším N (číslo mění verze Kodi)."""
    nejlepsi, nejvyssi = None, -1
    for p in glob.glob("/storage/.kodi/userdata/Database/Addons*.db"):
        m = re.search(r"Addons(\d+)\.db$", p)
        if m and int(m.group(1)) > nejvyssi:
            nejlepsi, nejvyssi = p, int(m.group(1))
    return nejlepsi


def _zjistit_stav_aktualizaci():
    auto_update = enabled = origin = pinned = repo_enabled = None
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
            "params": {"setting": "general.addonupdates"}})))
        hodnota = (resp.get("result") or {}).get("value")
        if isinstance(hodnota, int) and not isinstance(hodnota, bool):
            auto_update = hodnota
    except Exception as e:
        xbmc.log(f"[Dohled] Stav aktualizací: general.addonupdates nelze přečíst: {e}", xbmc.LOGWARNING)
    db = _addons_db()
    if db:
        try:
            # jen ČTENÍ (mode=ro) - databázi vlastní Kodi
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            try:
                row = con.execute("SELECT enabled, origin FROM installed WHERE addonID = ?",
                                  ("service.dohled",)).fetchone()
                if row:
                    enabled = bool(row[0]) if row[0] is not None else None
                    origin = row[1] if isinstance(row[1], str) else None
                # repozitář, ze kterého aktualizace chodí (FIX-KODI-ADDON-UPDATE.md, případ C)
                row = con.execute("SELECT enabled FROM installed WHERE addonID = ?",
                                  ("repository.noreason",)).fetchone()
                if row is None:
                    repo_enabled = False   # repozitář není nainstalovaný
                elif row[0] is not None:
                    repo_enabled = bool(row[0])
                try:
                    pinned = con.execute("SELECT 1 FROM update_rules WHERE addonID = ?",
                                         ("service.dohled",)).fetchone() is not None
                except sqlite3.OperationalError:
                    pinned = None   # verze Kodi bez tabulky update_rules
            finally:
                con.close()
        except Exception as e:
            xbmc.log(f"[Dohled] Stav aktualizací: {os.path.basename(db)} nelze přečíst: {e}", xbmc.LOGWARNING)
    else:
        xbmc.log("[Dohled] Stav aktualizací: databáze Addons*.db nenalezena", xbmc.LOGWARNING)
    def _enabled_z_kodi(addon_id):
        """Bez databáze aspoň stav z Kodi (JSON-RPC); None = nelze zjistit."""
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails",
                "params": {"addonid": addon_id, "properties": ["enabled"]}})))
            det = (resp.get("result") or {}).get("addon") or {}
            if isinstance(det.get("enabled"), bool):
                return det["enabled"]
        except Exception:
            pass
        return None

    if enabled is None:
        enabled = _enabled_z_kodi("service.dohled")
    if repo_enabled is None:
        repo_enabled = _enabled_z_kodi("repository.noreason")
    if auto_update is None and enabled is None and origin is None and pinned is None and repo_enabled is None:
        return None
    return {"auto_update": auto_update, "enabled": enabled, "origin": origin, "pinned": pinned,
            "repo_enabled": repo_enabled}


def stav_aktualizaci():
    """Stav aktualizací pro monitoring (cache AKTUALIZACE_INTERVAL)."""
    ted = time.monotonic()
    if _aktualizace_cache["cas"] is None or ted - _aktualizace_cache["cas"] >= AKTUALIZACE_INTERVAL:
        hodnota = _zjistit_stav_aktualizaci()
        _aktualizace_cache.update(cas=ted, hodnota=hodnota)
        xbmc.log(f"[Dohled] Stav aktualizací (hlášeno v monitoringu): {hodnota}", xbmc.LOGINFO)
    return _aktualizace_cache["hodnota"]


def addon_update_loop():
    """Kontrola aktualizací: první 60 s po startu, pak každou hodinu."""
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(60):
        return
    while not stop_monitoring and not monitor.abortRequested():
        try:
            zkontrolovat_aktualizace()
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v addon update loop: {e}", xbmc.LOGERROR)
        if monitor.waitForAbort(3600):
            return

# Čas startu addonu (Kodi) - server podle změny pozná restart Kodi.
# R8 (3.6.0): spočítá se JEDNOU, jakmile je čas ověřený (_cas_overen_ted), a dál se posílá
# stejná hodnota. Do 3.5.9 se počítal při každém volání jako "teď - monotonic" s hysterezí
# 2 s proti kolísání sekundy. Před platným časem není co poslat (None).
_boot_time_ts = None


def get_boot_time():
    if _boot_time_ts is None:
        return None
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(_boot_time_ts))


def get_system_boot_time():
    """Skutečný start SYSTÉMU (jádro, /proc/stat btime) - na rozdíl od get_boot_time(),
    který je start addonu/Kodi. Před synchronizací hodin (RPi nemá RTC) vrací None."""
    try:
        with open("/proc/stat", encoding="utf-8") as f:
            for line in f:
                if line.startswith("btime "):
                    bt = int(line.split()[1])
                    if time.localtime(bt).tm_year < 2025:
                        return None
                    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(bt))
    except Exception:
        pass
    return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení reboot_log.txt: {e}", xbmc.LOGERROR)
        return None
        
# Načíst nebo vytvořit DeviceID
def get_device_id():
    if xbmcvfs.exists(DEVICE_ID_FILE):
        with xbmcvfs.File(DEVICE_ID_FILE) as f:
            return f.read().strip()
    else:
        new_id = str(uuid.uuid4())
        with xbmcvfs.File(DEVICE_ID_FILE, 'w') as f:
            f.write(new_id)
        xbmc.log(f"[Dohled] Generuji nové DeviceID: {new_id}", xbmc.LOGINFO)
        return new_id

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        response_data = api_request(url, data=payload, timeout=10)
        xbmc.log(f"[Dohled] Odesláno na API, odpověď: {response_data}", xbmc.LOGINFO)
        return response_data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)
        return None

def check_for_commands(device_id):
    """Zkontroluje a vrátí příkaz z API: (command, params, command_id).

    command_id slouží k potvrzení SKUTEČNÉHO provedení (send_command_ack) - R2: server ho
    posílá vždy, potvrzení se páruje výhradně podle něj.
    """
    try:
        url = f"https://apidohled.noreason.eu/api/commands/{device_id}"
        data = api_request(url, timeout=5)
        return data.get("command"), data.get("params"), data.get("command_id")
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole příkazů: {e}", xbmc.LOGERROR)
        return None, None, None


def send_download_progress(filename, percent, downloaded_mb, total_mb, status="downloading"):
    """Odešle průběh stahování přes WebSocket."""
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "download_progress",
                "payload": {
                    "filename": filename,
                    "percent": percent,
                    "downloaded_mb": round(downloaded_mb, 1),
                    "total_mb": round(total_mb, 1),
                    "status": status  # "starting", "downloading", "completed", "error"
                }
            }))
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při odesílání progress: {e}", xbmc.LOGWARNING)


def download_and_play_file(filename, poradi=None, source=""):
    """Stáhne soubor z FTP a pak ho přehraje (cestou play_file)."""
    from ftplib import FTP
    _zamek = None
    _zamek_drzim = False

    try:
        # Nechat aktualni prehravani bezet behem stahovani (bez vypadku)
        xbmc.log(f"[Dohled] Download: Stahuji na pozadi {filename} (aktualni prehravani pokracuje)", xbmc.LOGINFO)

        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně uložit jen basename
        # remote_path musí zachovat celou cestu (ftp_path + filename včetně podsložky)
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        _zamek = zamek_stahovani(local_filename)
        _zamek.acquire()   # viz zamek_stahovani
        _zamek_drzim = True

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)
        # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
        _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
        if _uz_stazeno:
            xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

        if not _uz_stazeno:
            # Kontrola místa před stahováním
            ensure_space_for_download(int(file_size_mb) + 50)  # +50 MB rezerva

            xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Odeslat počáteční progress
            send_download_progress(filename, 0, 0, file_size_mb, "starting")

            downloaded = 0
            last_percent = 0
            last_progress_time = time.time()

            with open(temp_path, 'wb') as f:
                def callback(data):
                    nonlocal downloaded, last_percent, last_progress_time
                    f.write(data)
                    downloaded += len(data)
                    percent = int(downloaded * 100 / file_size)
                    current_time = time.time()

                    # Odeslat progress každých 500ms nebo při změně o 5%
                    if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                        downloaded_mb = downloaded / (1024 * 1024)
                        send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                        last_progress_time = current_time

                    if percent >= last_percent + 10:
                        last_percent = percent
                        xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

                ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)
                # Data na disk PŘED přesunem do cílové složky (jako ostatní stahovací cesty)
                f.flush()
                os.fsync(f.fileno())

        ftp.quit()

        # 4. Ověřit velikost a přesunout do cílové složky. Staging i cíl jsou na /storage
        # (stejný filesystém) -> os.rename je atomický: Kodi vidí buď nic, nebo celý soubor.
        # 3.6.0: proto pryč os.sync(), UpdateLibrary a čekání "až bude obrázek čitelný".
        if not _uz_stazeno:
            actual_size = os.path.getsize(temp_path)
            if actual_size != file_size:
                raise ValueError(f"velikost {actual_size} != {file_size} na FTP")
            xbmc.log(f"[Dohled] Download: Přesouvám do {target_dir}", xbmc.LOGINFO)
            os.rename(temp_path, local_path)
        _zamek.release()
        _zamek_drzim = False

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení
        send_download_progress(filename, 100, file_size_mb, file_size_mb, "completed")

        if not _stale_nejnovejsi(poradi, f"Download {filename}"):
            return
        # 5. Přehrát PŘESNĚ STEJNOU cestou jako příkaz play_file ("stáhnout a přehrát X" =
        # stáhnout + stejný kód jako "přehrát X", CLAUDE.md 3.5.2). Do 3.5.9 tu byla vlastní
        # kopie přechodů obrázek/video.
        prikaz_nasazuje_obsah()   # obsah z příkazu download_and_play nastupuje teď
        execute_command("play_file", {"filename": filename, "source": source}, interni=True)

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        if _zamek_drzim:
            _zamek.release()
            _zamek_drzim = False
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_fname}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def download_only_file(filename):
    """Stáhne soubor z FTP bez přehrání."""
    from ftplib import FTP
    _zamek = None
    _zamek_drzim = False

    try:
        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # Rozdělit na remote path a lokální filename (pro soubory ze složek)
        # filename může být "subfolder/video.mp4" - lokálně uložit jen basename
        # remote_path musí zachovat celou cestu (ftp_path + filename včetně podsložky)
        local_filename = os.path.basename(filename)  # Pro lokální uložení (bez složky)
        # KRITICKÉ: Obrázky do /storage/pictures/, videa do /storage/videos/
        target_dir = IMAGE_DIR if is_image_file(local_filename) else VIDEO_DIR
        local_path = f"{target_dir}{local_filename}"
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        _zamek = zamek_stahovani(local_filename)
        _zamek.acquire()   # viz zamek_stahovani
        _zamek_drzim = True

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)
        # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
        _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
        if _uz_stazeno:
            xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

        if not _uz_stazeno:
            # Kontrola místa před stahováním
            ensure_space_for_download(int(file_size_mb) + 50)

            xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

            # Odeslat počáteční progress
            send_download_progress(filename, 0, 0, file_size_mb, "starting")

            downloaded = 0
            last_percent = 0
            last_progress_time = time.time()

            with open(temp_path, 'wb') as f:
                def callback(data):
                    nonlocal downloaded, last_percent, last_progress_time
                    f.write(data)
                    downloaded += len(data)
                    percent = int(downloaded * 100 / file_size)
                    current_time = time.time()

                    # Odeslat progress každých 500ms nebo při změně o 5%
                    if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                        downloaded_mb = downloaded / (1024 * 1024)
                        send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                        last_progress_time = current_time

                    if percent >= last_percent + 10:
                        last_percent = percent
                        xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

                ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

                # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
                f.flush()
                os.fsync(f.fileno())
                xbmc.log("[Dohled] Download: File flush + fsync dokončen", xbmc.LOGINFO)

        ftp.quit()

        # 4. Ověřit velikost a přesunout do cílové složky (atomický rename na /storage).
        if not _uz_stazeno:
            actual_size = os.path.getsize(temp_path)
            if actual_size != file_size:
                raise ValueError(f"velikost {actual_size} != {file_size} na FTP")
            xbmc.log(f"[Dohled] Download: Přesouvám do {target_dir}", xbmc.LOGINFO)
            os.rename(temp_path, local_path)
        _zamek.release()
        _zamek_drzim = False


        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)

        # Odeslat dokončení - POUZE po úspěšné verifikaci
        send_download_progress(local_filename, 100, file_size_mb, file_size_mb, "completed")

        # Nepřehrávat - pouze staženo

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        if _zamek_drzim:
            _zamek.release()
            _zamek_drzim = False
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor - použít basename pro případ souborů ze složek
        local_fname = os.path.basename(filename)
        temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_fname}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def strip_playlist_duration(item):
    """'Oresi/foto.jpg:15' -> 'Oresi/foto.jpg'. Bez dvojtecky vrati vstup beze zmeny.

    Doba zobrazeni se pripojuje za dvojtecku az v playlistu; pro praci se souborem
    (FTP cesta, lokalni jmeno) se musi odriznout.
    """
    try:
        if ':' in item:
            base, last = item.rsplit(':', 1)
            if last.isdigit():
                return base
    except Exception:
        pass
    return item


def download_files_from_cloud(filenames, ftp_config):
    """Stáhne více souborů z FTP. Vrací seznam úspěšně stažených lokálních souborů."""
    from ftplib import FTP

    ftp_host = ftp_config.get("ftp_host")
    ftp_user = ftp_config.get("ftp_user")
    ftp_pass = ftp_config.get("ftp_pass")
    ftp_path = ftp_config.get("ftp_path")

    downloaded_files = []

    try:
        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        for idx, filename in enumerate(filenames):
            _zamek = None
            _zamek_drzim = False
            try:
                # ODSTRANIT DOBU ZOBRAZENÍ z položky playlistu ("Oresi/foto.jpg:15" -> "Oresi/foto.jpg").
                # Administrace posílá do download_only_playlist položky VČETNĚ ":sekundy"
                # (LocalityPlaylistView to dělá záměrně, kvůli dobám zobrazení). Bez tohohle
                # oříznutí se skládala neexistující cesta "/smycky/Oresi/foto.jpg:15", FTP RETR
                # selhal, chyba se spolkla v per-file try/except a obrázek se PŘED restartem
                # nikdy nestáhl (zařízení ho pak dotáhlo až při startu).
                filename = strip_playlist_duration(filename)
                # FTP cesta = ftp_path + PLNÝ název se složkou ('/smycky/' + 'Oresi/x.jpg', R6);
                # lokálně se soubor ukládá jen pod basename
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                temp_path = f"{DOWNLOAD_STAGING_DIR}.downloading_{local_filename}"  # skrytý soubor v /storage/ mimo videos/ - Kodi ho nevidí
                _zamek = zamek_stahovani(local_filename)
                _zamek.acquire()   # viz zamek_stahovani
                _zamek_drzim = True

                remote_path = ftp_path + filename
                file_size = ftp.size(remote_path)
                file_size_mb = file_size / (1024 * 1024)
                # Jiné vlákno už soubor stáhlo (držel zámek před námi)? Pak nestahovat znovu.
                _uz_stazeno = os.path.exists(local_path) and os.path.getsize(local_path) == file_size
                if _uz_stazeno:
                    xbmc.log(f"[Dohled] Download: {local_filename} už je stažený ({file_size} B) - stahování přeskakuji", xbmc.LOGINFO)

                if not _uz_stazeno:
                    # Kontrola místa
                    ensure_space_for_download(int(file_size_mb) + 50)

                    xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)

                    # Odeslat progress (filename je aktuální soubor)
                    send_download_progress(f"playlist:{idx+1}/{len(filenames)}", 0, 0, file_size_mb, "downloading")

                    downloaded = 0
                    with open(temp_path, 'wb') as f:
                        def callback(data):
                            nonlocal downloaded
                            f.write(data)
                            downloaded += len(data)
                        ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

                        # KRITICKÉ: Vynutit zápis na disk PŘED zavřením souboru
                        f.flush()
                        os.fsync(f.fileno())

                # Ověřit velikost a přesunout do cílové složky (atomický rename na /storage).
                # Nedostažený soubor se do cílové složky NIKDY nedostane.
                actual_size = os.path.getsize(temp_path if not _uz_stazeno else local_path)
                if actual_size != file_size:
                    raise ValueError(f"velikost {actual_size} != {file_size} na FTP")
                if not _uz_stazeno:
                    os.rename(temp_path, local_path)
                _zamek.release()
                _zamek_drzim = False

                downloaded_files.append(local_filename)
                xbmc.log(f"[Dohled] Playlist download: [{idx+1}/{len(filenames)}] Hotovo: {local_filename} (ověřeno {actual_size} bytes)", xbmc.LOGINFO)

            except Exception as e:
                xbmc.log(f"[Dohled] Playlist download: Chyba při stahování {filename}: {e}", xbmc.LOGERROR)
                if _zamek_drzim:
                    _zamek.release()
                    _zamek_drzim = False
                # Uklidit nedokončený staging soubor (na /storage nezmizí sám jako kdysi v /tmp)
                try:
                    os.remove(f"{DOWNLOAD_STAGING_DIR}.downloading_{os.path.basename(filename)}")
                except OSError:
                    pass
                # Pokračovat s dalšími soubory
                continue

        ftp.quit()

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba FTP připojení: {e}", xbmc.LOGERROR)

    return downloaded_files


def download_and_play_playlist(filenames, source="", akce_id=None, poradi=None):
    """Stáhne více souborů z FTP a přehraje je jako playlist."""
    try:
        # 0. Položky "soubor" nebo "soubor:sekundy" - stahují se skutečné názvy bez doby
        parsed_files = parse_playlist_items(filenames)
        filenames_to_download = [pf['filename'] for pf in parsed_files]

        xbmc.log(f"[Dohled] Playlist download: Parsováno {len(parsed_files)} souborů", xbmc.LOGINFO)

        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory (pouze skutečné názvy bez :duration)
        xbmc.log(f"[Dohled] Playlist download: Stahuji {len(filenames_to_download)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames_to_download)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames_to_download, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download: Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # 5. Přehrát PŘESNĚ STEJNOU cestou jako příkaz play_playlist (jedna smyčka pro
        # "přehrát playlist" i "stáhnout a přehrát playlist").
        # Dřív tu byla vlastní, TŘETÍ přehrávací smyčka, která čekala na konec videa
        # dotazem player.isPlaying() jednou za sekundu. Dvě chyby (nalezeno 11.9.2026):
        #  1) po dohrání videa spadlo Kodi až na 1 s na HOME menu, než smyčka zobrazila
        #     další obrázek (monitoring hlásil "Obsah překrytý (home_menu)", test V19);
        #  2) když bylo v Kodi zapnuté opakování (RepeatOne nastavuje startovní smyčka
        #     lokality u KAŽDÉHO videa), video nikdy "neskončilo" - smyčka čekala věčně
        #     a obrázky z playlistu se už nikdy nezobrazily (změřeno: 75 s jen video).
        # Smyčka play_playlist přepíná podle POZICE 2 s před koncem videa, ověřuje
        # soubory, umí pauzu i zakrytí mezery. Předávají se PŮVODNÍ položky (s :dobou):
        # neexistující play_playlist přeskočí a user_initiated_file zůstane shodné
        # s tím, co už nastavil samotný příkaz download_and_play_playlist.
        xbmc.log(f"[Dohled] Playlist download: Hotovo ({len(downloaded_files)} souborů), "
                 f"přehrávám cestou play_playlist", xbmc.LOGINFO)
        if not _stale_nejnovejsi(poradi, "Playlist download"):
            return
        _pp = {"files": list(filenames), "source": source}
        if akce_id is not None:
            _pp["akce_id"] = akce_id
        prikaz_nasazuje_obsah()   # obsah z příkazu download_and_play_playlist nastupuje teď
        execute_command("play_playlist", _pp, interni=True)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def _akce_pripravit(akce_id):
    """Nový playlist: připravit stav akce, aby akce_append během stahování prvního souboru
    neskončil v prázdnu (review C1). akce_id None = běžný playlist (akce neběží)."""
    with _akce_lock:
        if akce_id is None:
            current_akce.update({"id": None, "files": None, "playlist_id": None, "pending": []})
        elif current_akce.get("id") != akce_id:
            current_akce.update({"id": akce_id, "files": None, "playlist_id": None, "pending": []})
        else:   # znovu odeslaná tatáž akce (smazání/pořadí): čekající položky zachovat
            current_akce.update({"files": None, "playlist_id": None})


def akce_append(akce_id, files):
    """Stáhne položky akce a připojí je na konec běžící smyčky téže akce (bez restartu)."""
    global user_initiated_file
    try:
        parsed = parse_playlist_items(files)
        nastavit_nazvy_obsahu(files, pridat=True)
        config = load_config()
        locality = config.get("locality")
        ftp_config = api_request(f"https://apidohled.noreason.eu/api/locality_config?locality={locality}", timeout=10)
        download_files_from_cloud([pf['filename'] for pf in parsed], ftp_config)
        nove = [pf for pf in parsed if is_supported_file(pf['filename'])
                and os.path.exists(get_local_media_path(pf['filename']))]
        with _akce_lock:
            if (current_akce.get("id") == akce_id and current_akce.get("files") is not None
                    and current_akce.get("playlist_id") == current_playlist_id):
                _jsou = {v['filename'] for v in current_akce["files"]}
                nove = [pf for pf in nove if pf['filename'] not in _jsou]
                current_akce["files"].extend(nove)
                stav = "pridano"
            elif current_akce.get("id") == akce_id and current_akce.get("files") is None:
                current_akce.setdefault("pending", []).extend(nove)   # smyčka akce ještě nestartovala
                stav = "ceka"
            else:
                stav = "nebezi"
        if stav == "pridano":
            current_mixed_playlist.extend(pf['filename'] for pf in nove)
            if user_initiated_file and user_initiated_file.startswith("playlist:"):
                user_initiated_file += "".join(
                    "," + (f"{pf['filename']}:{pf['duration']}" if pf.get('duration') else pf['filename']) for pf in nove)
            xbmc.log(f"[Dohled] Akce {akce_id}: přidáno {len(nove)} položek na konec kolečka "
                     f"(celkem {len(current_akce['files'])})", xbmc.LOGINFO)
        elif stav == "ceka":
            xbmc.log(f"[Dohled] Akce {akce_id}: {len(nove)} položek čeká na start smyčky akce", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Dohled] Akce {akce_id}: na zařízení neběží - {len(nove)} položek jen staženo",
                     xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Akce {akce_id}: přidání selhalo - {e}", xbmc.LOGERROR)


def download_only_playlist(filenames):
    """Stáhne více souborů z FTP BEZ přehrání - pouze stažení."""
    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Playlist download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}"
        ftp_config = api_request(api_url, timeout=10)

        if not all([ftp_config.get("ftp_host"), ftp_config.get("ftp_user"), ftp_config.get("ftp_pass"), ftp_config.get("ftp_path")]):
            xbmc.log("[Dohled] Playlist download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 3. Stáhnout všechny soubory
        xbmc.log(f"[Dohled] Playlist download (only): Stahuji {len(filenames)} souborů...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {len(filenames)} souborů...", xbmcgui.NOTIFICATION_INFO, 3000)

        downloaded_files = download_files_from_cloud(filenames, ftp_config)

        if not downloaded_files:
            xbmc.log("[Dohled] Playlist download (only): Žádné soubory nebyly staženy", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Žádné soubory staženy", xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # 4. Vyčistit staré soubory
        cleanup_old_videos()

        # Odeslat dokončení stahování
        send_download_progress(f"playlist:{len(downloaded_files)}", 100, 0, 0, "completed")

        # BEZ přehrávání - pouze staženo
        xbmc.log(f"[Dohled] Playlist download (only): Hotovo, staženo {len(downloaded_files)} souborů", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Staženo {len(downloaded_files)} souborů", xbmcgui.NOTIFICATION_INFO, 3000)

    except Exception as e:
        xbmc.log(f"[Dohled] Playlist download (only): Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)


def stav_prehravani():
    """JEDINÝ výpočet hlášeného stavu přehrávání (monitoring, state_update, okamžitý update).

    Pravda z VLASTNÍHO stavu přehrávání (kdo obsah nasadil, ten nastavil proměnné),
    ne z přechodných stavů Kodi: během přechodu obrázek->video nebo video->video by Kodi
    na zlomek sekundy hlásilo "nic nehraje". 3.6.0: do 3.5.9 se stav počítal třikrát
    (monitor_loop, state_update_loop, okamžitý update), pokaždé jinak, s 5s tolerancí
    "playing=False" (maskovala i skutečné zastavení) a s "posledním známým souborem",
    když nic nehrálo.

    R7: current_filename = basename zobrazené položky (nebo URL streamu), NIKDY celý
    playlist řetězec; playlist = seznam basename položek, když hraje playlist, jinak None.
    """
    player = xbmc.Player()
    is_video = player.isPlayingVideo()
    stav = {"playing": False, "paused": False, "current_filename": None, "playing_file": None,
            "media_type": None, "playlist": None, "playlist_position": None}
    if user_stopped:
        return stav

    pl = list(current_mixed_playlist)
    pos = current_mixed_playlist_position
    if pl and 0 <= pos < len(pl):
        name = os.path.basename(pl[pos])
        video = is_video_file(name)
        # Položka-video hraje, jen když ji Kodi opravdu přehrává (načtené médium - viz jedno
        # video níže). 3.6.0 (HEAD 8e0f226) hlásil u playlistu vždy playing=True - i video
        # jediné položky, které se nerozjelo (černá obrazovka).
        hraje = (is_video or bool(xbmc.getCondVisibility("Player.HasMedia"))) if video else True
        stav.update(playlist=[os.path.basename(x) for x in pl], playlist_position=pos,
                    current_filename=name, media_type="video" if video else "image",
                    playing_file=get_local_media_path(name), playing=hraje)
    elif aktivni_stream:
        stav.update(current_filename=aktivni_stream, playing_file=aktivni_stream,
                    media_type="video", playing=is_video)
    elif current_displayed_image:
        stav.update(current_filename=current_displayed_image, media_type="image",
                    playing_file=get_local_media_path(current_displayed_image), playing=True)
    elif current_video:
        # Jedno video v opakování (RepeatOne): Kodi při přetočení na začátek soubor znovu
        # otevírá - "přehrává" = má načtené médium (Player.HasMedia), ne jen isPlayingVideo.
        stav.update(current_filename=current_video, media_type="video",
                    playing_file=get_local_media_path(current_video),
                    playing=is_video or bool(xbmc.getCondVisibility("Player.HasMedia")))
    elif is_video:
        # Video, které nespustil náš kód (nemělo by nastat) - hlásit, co Kodi opravdu hraje
        pf = safe_playing_file(player)
        if pf:
            stav.update(current_filename=nazev_pro_hlaseni(pf), playing_file=pf,
                        media_type="video", playing=True)
    if stav["playing"]:
        stav["paused"] = bool(playlist_paused or (is_video and xbmc.getCondVisibility("Player.Paused")))
    return stav


def set_kodi_mute(muted):
    """Nastaví mute stav Kodi (Application.SetMute) - jen když se aktuální stav liší.
    Tím se vyhne zbytečnému OSD popupu při opakovaném vynucování v monitoring loopu.
    """
    desired = bool(muted)
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Application.GetProperties",
            "params": {"properties": ["muted"]}
        }))
        current = json.loads(resp).get("result", {}).get("muted")
        if current == desired:
            return
        xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Application.SetMute",
            "params": {"mute": desired}
        }))
        xbmc.log(f"[Dohled] Mute nastaven na: {desired}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při nastavení mute: {e}", xbmc.LOGERROR)


# ======= PŘEHRÁVÁNÍ PLAYLISTU - JEDINÁ SMYČKA =======
# 3.6.0: do 3.5.9 existovaly TŘI cesty: smyčka příkazu play_playlist, nativní Kodi playlist
# s RepeatAll pro playlist jen z videí a samostatná smyčka při startu zařízení
# (start_mixed_playlist_startup). Nativní varianta nechávala current_mixed_playlist prázdný,
# takže monitoring potřeboval záplatu proti auto-play a hlášení nesedělo. Teď jde každý
# playlist (příkaz, stažení, resume, start zařízení, akce) touto jednou smyčkou.
# CLAUDE.md: "NIKDY nepřidávat další přehrávací smyčku".

def ukoncit_playlist(duvod):
    """Ukončí běžící playlistovou smyčku (obsah přebírá někdo jiný) a vrátí nové ID.
    Obrazovku NEMĚNÍ - co na ní zůstalo, říkají current_displayed_image / current_video,
    a nový vlastník obsahu z toho vyjde (přechod obrázek->video, krytí...)."""
    global current_playlist_id, current_mixed_playlist, current_mixed_playlist_position, current_playlist_items
    # Pod zámkem: běžící smyčka buď právě dokončuje zápis (počkáme na něj), nebo už uvidí
    # nové ID a nic dalšího nezapíše. Na doběhnutí vlákna se nečeká.
    with _obrazovka_lock:
        current_playlist_id += 1
        current_mixed_playlist = []
        current_mixed_playlist_position = -1
        current_playlist_items = None
        nove_id = current_playlist_id
    xbmc.log(f"[Dohled] {duvod}: ukončuji playlist (nové ID: {nove_id})", xbmc.LOGINFO)
    return nove_id


def spustit_playlist(parsed_files, akce_id=None):
    """Spustí JEDINOU přehrávací smyčku playlistu ve vlákně (předchozí ukončí)."""
    global mixed_playlist_thread
    my_playlist_id = ukoncit_playlist("nový playlist")

    def _smycka():
        try:
            _playlist_smycka(parsed_files, akce_id, my_playlist_id)
        except Exception as e:
            xbmc.log(f"[Dohled] Playlist {my_playlist_id}: neočekávaná chyba: {e}", xbmc.LOGERROR)
            try:
                with _obrazovka_lock:
                    if current_playlist_id == my_playlist_id and not is_content_on_screen():
                        show_black_filler("chyba playlist smyčky")
            except Exception:
                pass

    mixed_playlist_thread = threading.Thread(target=_smycka, daemon=True)
    mixed_playlist_thread.start()


def _playlist_smycka(all_files, akce_id, my_playlist_id):
    global current_displayed_image, current_video, current_mixed_playlist, current_mixed_playlist_position
    global user_initiated_file, current_playlist_items

    def is_my_playlist_active():
        return current_playlist_id == my_playlist_id

    def nastavit_pozici(i):
        # pozici pro hlášení zapisuje jen vlastník (jinak by přepsal pozici nového playlistu)
        global current_mixed_playlist_position
        with _obrazovka_lock:
            if is_my_playlist_active():
                current_mixed_playlist_position = i

    player = xbmc.Player()
    current_index = 0

    # Chybějící soubory DOTÁHNOUT, ne je potichu zahodit z playlistu.
    # ensure_media_playable má vlastní strop pokusů i cooldown (MEDIA_REPAIR_*).
    valid_files = []
    for pf in all_files:
        if not is_supported_file(pf['filename']):
            continue
        local_path = get_local_media_path(pf['filename'])
        if not os.path.exists(local_path):
            xbmc.log(f"[Dohled] Playlist: {pf['filename']} chybí - zkouším dotáhnout z FTP", xbmc.LOGWARNING)
            ensure_media_playable(pf['filename'])
        if os.path.exists(local_path):
            valid_files.append(pf)

    if not valid_files:
        xbmc.log("[Dohled] Playlist: žádné platné soubory", xbmc.LOGERROR)
        with _obrazovka_lock:
            if is_my_playlist_active() and not is_content_on_screen():
                show_black_filler("playlist bez platných souborů")
        return

    # Stav pro hlášení: playlist (seznam položek) + pozice. Položky hlásí stav_prehravani.
    with _obrazovka_lock:
        if not is_my_playlist_active():
            return
        current_playlist_items = valid_files
        current_mixed_playlist = [pf['filename'] for pf in valid_files]
        current_mixed_playlist_position = 0
        current_video = None   # obrazovku teď vlastní playlist
        xbmc.log(f"[Dohled] Playlist {my_playlist_id}: {len(valid_files)} položek {current_mixed_playlist}", xbmc.LOGINFO)
        if akce_id:
            # položky přidané během stahování (akce_append před startem smyčky) - review C1
            with _akce_lock:
                prevzato = []
                if current_akce.get("id") == int(akce_id):
                    _jsou = {v['filename'] for v in valid_files}
                    for pf in current_akce.get("pending") or []:
                        if pf['filename'] not in _jsou and os.path.exists(get_local_media_path(pf['filename'])):
                            valid_files.append(pf)
                            _jsou.add(pf['filename'])
                            prevzato.append(pf)
                current_akce.update({"id": int(akce_id), "files": valid_files,
                                     "playlist_id": my_playlist_id, "pending": []})
            if prevzato:
                current_mixed_playlist = [pf['filename'] for pf in valid_files]
                if user_initiated_file and user_initiated_file.startswith("playlist:"):
                    user_initiated_file += "".join(
                        "," + (f"{pf['filename']}:{pf['duration']}" if pf.get('duration') else pf['filename'])
                        for pf in prevzato)
                xbmc.log(f"[Dohled] Akce {akce_id}: převzato {len(prevzato)} čekajících položek", xbmc.LOGINFO)
            xbmc.log(f"[Dohled] Akce {akce_id}: smyčka běží ({len(valid_files)} položek)", xbmc.LOGINFO)

    predstartovano = None   # video už spuštěné pre-transition (video→video)
    uz_zobrazeno = None     # obrázek jediné položky už svítí - po přidání položky neukazovat znovu

    # Jedna položka (mimo akci, kam se může přidávat) = zobrazit/přehrávat trvale
    if len(valid_files) == 1 and not akce_id:
        filename = valid_files[0]['filename']
        local_path = get_local_media_path(filename)
        if is_image_file(filename):
            xbmc.log(f"[Dohled] Playlist: jediný obrázek {filename} (trvale)", xbmc.LOGINFO)
            with _obrazovka_lock:
                if not is_my_playlist_active():
                    return
                # Video→obrázek přes transition (obrázek překryje video).
                # POZOR: nikdy nevolat player.stop() nad zobrazeným obrázkem -
                # zavřelo by slideshow a odhalilo Kodi MENU.
                if player.isPlayingVideo():
                    transition_to_image_from_video(player, local_path)
                    ok = wait_slideshow_shows(local_path, 1.0)
                else:
                    ok = show_picture_safe(local_path)
                if ok:
                    current_displayed_image = os.path.basename(filename)
                else:
                    show_black_filler("selhalo zobrazení obrázku")
                    current_displayed_image = None
        else:
            xbmc.log(f"[Dohled] Playlist: jediné video {filename} (v opakování)", xbmc.LOGINFO)
            # STEJNÁ cesta jako jeden soubor: RepeatVideo nastaví current_video, takže po
            # samoopravě opravené video znovu pustí request_video_repair.
            RepeatVideo(local_path, je_vlastnik=is_my_playlist_active)
        # Čekat, dokud playlist nenahradí jiný obsah, nebo dokud add_to_playlist nepřidá
        # položku (do 3.6.0 se přidaná položka nikdy nepřehrála). Menu hlídá menu_guard_loop.
        while not xbmc.Monitor().abortRequested() and is_my_playlist_active() and len(valid_files) == 1:
            time.sleep(0.5)
        if not is_my_playlist_active() or xbmc.Monitor().abortRequested():
            xbmc.log(f"[Dohled] Playlist {my_playlist_id}: jediná položka {filename} ukončena", xbmc.LOGINFO)
            return
        # Přidaná položka: pokračovat smyčkou playlistu. Běžící položka se nespouští znovu -
        # video dohraje (RepeatOff níže) a přejde se na další, obrázek dosvítí svou dobu.
        xbmc.log(f"[Dohled] Playlist {my_playlist_id}: k jediné položce {filename} přibyla další "
                 f"- pokračuji jako playlist ({len(valid_files)} položek)", xbmc.LOGINFO)
        with _obrazovka_lock:
            if not is_my_playlist_active():
                return
            if is_video_file(filename):
                predstartovano = filename
            else:
                uz_zobrazeno = os.path.basename(filename)
            current_video = None   # už to není jedno video v opakování (samooprava ho nepouští)

    while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
        pf = valid_files[current_index]
        filename = pf['filename']
        local_path = get_local_media_path(filename)
        # Pozice pro hlášení = položka, která JE na obrazovce. Obrázek se hlásí hned (svítí
        # okamžitě, i nad dohrávajícím videem), video až po spuštění - viz větev videa.
        # Do 3.6.0 se pozice posouvala před výměnou obsahu a stav_prehravani v té mezeře
        # hlásil video položku, kterou Kodi ještě/už nehraje: playing=False a dashboard
        # "Přehrávání je vypnuto" při běžícím playlistu (regrese T4 29.10.2026).
        if not is_video_file(filename):
            nastavit_pozici(current_index)

        # Proaktivní kontrola integrity (poškozený obrázek Kodi "zobrazí" jako smetí,
        # takže reaktivní kontrola nestačí)
        if os.path.exists(local_path):
            _v, _w = validate_media_file(local_path)
            if not _v:
                xbmc.log(f"[Dohled] Playlist: {filename} je VADNÝ ({_w}) - opravuji", xbmc.LOGWARNING)
                repair_media_file(filename, _w)
        else:
            # Soubor z karty zmizel - stáhnout na pozadí a položku zatím přeskočit
            if request_missing_download(filename):
                xbmc.log(f"[Dohled] Playlist: {filename} na kartě chybí - stahuji, zatím přeskakuji", xbmc.LOGWARNING)
            current_index = (current_index + 1) % len(valid_files)
            time.sleep(2 if len(valid_files) > 1 else 5)
            continue

        if is_video_file(filename):
            # Video - přehrát celé (bez opakování), přepnout 2 s před koncem
            xbmc.log(f"[Dohled] Playlist: přehrávám video {filename}", xbmc.LOGINFO)
            with _obrazovka_lock:
                if not is_my_playlist_active():
                    break
                if current_displayed_image is not None:
                    # Obrazek → Video: plynuly prechod
                    transition_to_video_from_image(player, local_path)
                elif predstartovano == filename and player.isPlayingVideo():
                    # Video → Video: už běží z pre-transition - znovu NEspouštět
                    # (dřív se restartovalo ~1 s po začátku - review I11)
                    pass
                else:
                    # Video → Video nebo START (nad vším může být krycí černá)
                    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
                    xbmc.executebuiltin("PlayerControl(RepeatOff)")
                    play_video_uncovered(player, local_path, builtin=True)
                current_displayed_image = None
                nastavit_pozici(current_index)   # video už běží (nebo se nerozjelo = hlásí False)
            predstartovano = None
            time.sleep(1)
            with _obrazovka_lock:
                if not is_my_playlist_active():
                    break
                xbmc.executebuiltin("PlayerControl(RepeatOff)")

            # Cekat na video - spustit prechod na dalsi polozku
            # 2s PRED koncem (kdy video jeste bezi = plynuly prechod)
            next_idx = (current_index + 1) % len(valid_files)
            next_is_image = is_image_file(valid_files[next_idx]['filename'])
            video_started = False
            transition_started = False
            wait_count = 0
            while not xbmc.Monitor().abortRequested() and is_my_playlist_active():
                if player.isPlayingVideo():
                    video_started = True
                    if not transition_started:
                        try:
                            total = player.getTotalTime()
                            current_pos = player.getTime()
                            remaining = total - current_pos
                            if remaining < 2.0 and total > 3.0:
                                xbmc.log(f"[Dohled] Playlist: video konci za {remaining:.1f}s, startuji pre-transition", xbmc.LOGINFO)
                                # další položku určit AŽ TEĎ - mezitím mohla přibýt (akce_append)
                                next_idx = (current_index + 1) % len(valid_files)
                                next_name = valid_files[next_idx]['filename']
                                next_is_image = is_image_file(next_name)
                                next_path = get_local_media_path(next_name)
                                with _obrazovka_lock:
                                    if not is_my_playlist_active():
                                        break
                                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                                    if next_is_image:
                                        nastavit_pozici(next_idx)
                                        transition_to_image_from_video(player, next_path)
                                        current_displayed_image = os.path.basename(next_name)
                                    else:
                                        # Video → Video: primo nahradit (video jeste bezi = plynule)
                                        player.play(next_path)
                                        predstartovano = next_name
                                transition_started = True
                                break
                        except Exception:
                            pass
                    time.sleep(0.3)
                elif video_started:
                    break
                else:
                    wait_count += 1
                    if wait_count > 20:
                        xbmc.log(f"[Dohled] Playlist: video {filename} se nespustilo", xbmc.LOGWARNING)
                        break
                    time.sleep(0.5)

            if transition_started:
                xbmc.log(f"[Dohled] Playlist: video {filename} dokonceno (pre-transition)", xbmc.LOGINFO)
                current_index = next_idx
                nastavit_pozici(current_index)
                if next_is_image:
                    # Obrazek - pockat dobu zobrazeni
                    img_duration = valid_files[next_idx].get('duration') or DEFAULT_IMAGE_DISPLAY_TIME
                    elapsed = 0
                    while elapsed < img_duration and is_my_playlist_active():
                        time.sleep(0.5)
                        if playlist_paused:
                            continue   # PAUZA: cas nebezi
                        elapsed += 0.5
                    current_index = (current_index + 1) % len(valid_files)
                # (video už běží z pre-transition - vyřeší další iterace)
                continue
            else:
                time.sleep(0.3)
                xbmc.log(f"[Dohled] Playlist: video {filename} dokončeno", xbmc.LOGINFO)
                # Po dohrání videa se Kodi vrací na HOME - okamžitě zakrýt
                with _obrazovka_lock:
                    if is_my_playlist_active() and not is_content_on_screen():
                        show_black_filler("video dohrálo - zakrytí mezery")

        elif is_image_file(filename):
            # Obrázek - zobrazit na specifikovanou dobu
            duration = pf['duration'] or DEFAULT_IMAGE_DISPLAY_TIME
            xbmc.log(f"[Dohled] Playlist: zobrazuji obrázek {filename} ({duration}s)", xbmc.LOGINFO)
            base = os.path.basename(filename)
            selhalo = False
            with _obrazovka_lock:
                if not is_my_playlist_active():
                    break
                if ((uz_zobrazeno == base or (akce_id and len(valid_files) == 1))
                        and current_displayed_image == base and not player.isPlayingVideo()):
                    pass  # obrázek už svítí (jediná položka akce / jediná položka před přidáním) - bez bliknutí
                elif player.isPlayingVideo():
                    transition_to_image_from_video(player, local_path)
                    current_displayed_image = base
                elif show_picture_safe(local_path):
                    # Obrázek→obrázek: ShowPicture nahradí atomicky, nic nezavírat
                    current_displayed_image = base
                else:
                    # Zobrazení selhalo -> soubor je pravděpodobně poškozený: krýt, opravit, zkusit znovu
                    show_black_filler("selhalo zobrazení obrázku")
                    current_displayed_image = None
                    selhalo = True
            uz_zobrazeno = None
            # oprava (stahování) mimo zámek - nový vlastník obsahu na ni nesmí čekat
            if selhalo and ensure_media_playable(filename):
                with _obrazovka_lock:
                    if is_my_playlist_active() and show_picture_safe(local_path):
                        current_displayed_image = base
                        xbmc.log(f"[Dohled] Obrázek {filename} opraven a zobrazen", xbmc.LOGINFO)
            # Čekat po menších intervalech pro rychlejší reakci na stop
            elapsed = 0
            while elapsed < duration and is_my_playlist_active():
                time.sleep(0.5)
                if playlist_paused:
                    continue   # PAUZA: cas nebezi
                elapsed += 0.5

        if not is_my_playlist_active():
            break

        # Přejít na další soubor
        next_index = (current_index + 1) % len(valid_files)
        if next_index == 0:
            xbmc.log(f"[Dohled] Playlist: opakuji od začátku (položka 1/{len(valid_files)})", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Dohled] Playlist: další položka {next_index + 1}/{len(valid_files)}", xbmc.LOGINFO)
        current_index = next_index

    # Konec: playlist nahradil jiný obsah. Stav (co je na obrazovce, playlist pro hlášení)
    # už patří novému vlastníkovi - smyčka ho NEMAŽE (do 3.5.9 mazala current_displayed_image
    # i current_mixed_playlist a mohla tím přepsat stav nového playlistu).
    if current_akce.get("playlist_id") == my_playlist_id:
        current_akce.update({"id": None, "files": None, "playlist_id": None})
    xbmc.log(f"[Dohled] Playlist {my_playlist_id}: smyčka ukončena", xbmc.LOGINFO)


def send_command_ack(command, command_id, ok=True, error="", result=None):
    """Potvrdi serveru, ze prikaz byl OPRAVDU proveden (ne jen dorucen).

    Server do te doby vi jen to, ze prikaz PREDAL - Executed=1 se nastavuje uz pri
    vyzvednuti z fronty. Bez tohohle hlasi administrace "Odeslano" i u prikazu,
    ktery se na zarizeni nikdy nevykonal.

    R2: potvrzení se páruje VÝHRADNĚ podle command_id - bez něj se nic neposílá (párování
    podle názvu příkazu by mohlo potvrdit cizí, ještě neprovedený příkaz).

    Posila se pres WebSocket; kdyz neni, pres HTTP. Selhani se ignoruje - potvrzeni
    je doplnkova informace a nesmi shodit vykonavani prikazu.
    """
    if command_id is None:
        return False
    zprava = {"type": "command_ack", "command": command, "command_id": command_id,
              "ok": bool(ok), "error": str(error)[:180]}
    if result:
        zprava["result"] = result
    xbmc.log(f"[Dohled] Potvrzení příkazu {command} ({command_id}): "
             f"{'OK' if ok else 'CHYBA ' + zprava['error']}", xbmc.LOGINFO)
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps(zprava))
            return True
        except Exception:
            pass   # spadne se na HTTP nize
    try:
        payload = dict(zprava)
        payload["device_id"] = get_device_id()
        api_request("https://apidohled.noreason.eu/api/commands/ack", data=payload,
                    method="POST", timeout=5)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] Potvrzení příkazu se nepodařilo odeslat: {e}", xbmc.LOGDEBUG)
    return False


def execute_command(command, params=None, command_id=None, interni=False):
    """Vykoná přijatý příkaz a potvrdí serveru jeho SKUTEČNÉ provedení.

    interni=True = volání zevnitř addonu (resume po stopu, přehrání po stažení playlistu,
    start po zapnutí): NEposílá potvrzení - není co potvrzovat.
    Příkaz ze serveru bez command_id je CHYBA SERVERU (R2: server ho posílá vždy) - provede
    se, zaloguje se jako chyba a potvrzení se nepošle (párování podle názvu neexistuje).
    """
    global current_video, user_initiated_file, aktivni_stream, user_stopped, last_stopped_content, playlist_paused, stream_watchdog_od
    xbmc.log(f"[Dohled] Vykonávám příkaz: {command}, params: {params}", xbmc.LOGINFO)
    if command_id is None and not interni:
        xbmc.log(f"[Dohled] CHYBA SERVERU: příkaz {command} přišel bez command_id - provádím, "
                 "ale nelze ho potvrdit", xbmc.LOGERROR)
    if not interni and command in PRIKAZY_OBSAHU:
        prikaz_nasazuje_obsah()

    # Jakykoli prikaz, ktery NASAZUJE NOVY OBSAH, rusi pauzu playlistu.
    # Jinak by novy obsah nabehl rovnou pozastaveny (pauza je globalni priznak, ktery
    # playlistove smycky respektuji) a vypadalo by to jako zamrznute zarizeni.
    if command in ("play_file", "play_playlist", "play_stream", "download_and_play",
                   "download_and_play_playlist"):
        playlist_paused = False

    # Prikazy, ktere zarizeni RESTARTUJI, musi potvrdit HNED - po os.system("reboot")
    # se uz funkce nevrati, takze potvrzeni na konci by nikdy neodeslo a restart
    # (nejcastejsi prikaz vubec) by vypadal jako nikdy neprovedeny.
    if command in ("restart", "refresh_config") and not interni:
        # "accepted" = prikaz prijat a zarizeni se restartuje; "ok" by tvrdilo,
        # ze prikaz dobehl, coz u restartu nedava smysl.
        send_command_ack(command, command_id, ok=True, result="accepted")

    try:
        if command == "restart":
            xbmc.log("[Dohled] Příkaz: RESTART zařízení", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Přijat příkaz k restartu...", xbmcgui.NOTIFICATION_WARNING, 3000)
            time.sleep(2)
            mark_reboot("manual")
            os.system("reboot")

        elif command == "play":
            xbmc.log("[Dohled] Příkaz: Spustit přehrávání", xbmc.LOGINFO)
            user_stopped = False  # Reset stop flagu
            playlist_paused = False  # Play vzdy rusi pauzu playlistu
            player = xbmc.Player()
            if player.isPlaying():
                # Pokud je pausnuto, spustit
                if xbmc.getCondVisibility("Player.Paused"):
                    player.pause()  # Toggle pause off
                    xbmc.log("[Dohled] Přehrávání obnoveno z pauzy", xbmc.LOGINFO)
            elif last_stopped_content:
                # RESUME: Obnovit naposledy stopnutý obsah - jediný případ, kdy play nasazuje obsah
                if not interni:
                    prikaz_nasazuje_obsah()
                xbmc.log(f"[Dohled] Obnovuji naposledy zastavený obsah: {last_stopped_content}", xbmc.LOGINFO)
                # Zdroj obsahu se zachová: obsah provozovny zůstane obsahem provozovny
                # (do 3.6.0 se při resume hlásil jako "Jen teď").
                zdroj = last_stopped_content.get('source', '')
                if last_stopped_content.get('type') == 'playlist':
                    files = last_stopped_content.get('files', [])
                    if files:
                        xbmc.log(f"[Dohled] Resume: spouštím playlist s {len(files)} soubory (zdroj: {zdroj or 'Jen teď'})", xbmc.LOGINFO)
                        execute_command("play_playlist", {"files": files, "source": zdroj}, interni=True)
                    else:
                        xbmc.log("[Dohled] Resume: playlist je prázdný", xbmc.LOGWARNING)
                elif last_stopped_content.get('type') == 'single':
                    filename = last_stopped_content.get('file')
                    if filename and '://' in filename:
                        xbmc.log(f"[Dohled] Resume: spouštím stream {filename} (zdroj: {zdroj or 'Jen teď'})", xbmc.LOGINFO)
                        execute_command("play_stream", {"url": filename, "source": zdroj}, interni=True)
                    elif filename:
                        xbmc.log(f"[Dohled] Resume: spouštím soubor {filename} (zdroj: {zdroj or 'Jen teď'})", xbmc.LOGINFO)
                        execute_command("play_file", {"filename": filename, "source": zdroj}, interni=True)
                    else:
                        xbmc.log("[Dohled] Resume: filename chybí", xbmc.LOGWARNING)
            else:
                # Není nic přehráváno a nemáme co obnovit - zkusit Kodi builtin
                xbmc.executebuiltin("PlayerControl(Play)")
                xbmc.log("[Dohled] Pokus o spuštění přehrávání (Kodi builtin)", xbmc.LOGINFO)

        elif command == "stop":
            playlist_paused = False  # Stop rusi pauzu, at nezustane viset pri dalsim obsahu
            xbmc.log("[Dohled] Příkaz: Zastavit přehrávání", xbmc.LOGINFO)

            # ULOŽIT AKTUÁLNÍ OBSAH PŘED ZASTAVENÍM (pro možnost obnovení přehrávání).
            # Playlist se ukládá s PLNÝMI položkami (vč. doby zobrazení) a se ZDROJEM obsahu
            # (user_initiated_file = None -> obsah provozovny), aby ho resume nehlásil jako "Jen teď".
            zdroj = "" if user_initiated_file else "locality"
            if current_playlist_items:
                last_stopped_content = {
                    'type': 'playlist',
                    'files': [f"{pf['filename']}:{pf['duration']}" if pf.get('duration') else pf['filename']
                              for pf in current_playlist_items],
                    'source': zdroj,
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: playlist s {len(current_playlist_items)} soubory "
                         f"(zdroj: {zdroj or 'Jen teď'})", xbmc.LOGINFO)
            elif aktivni_stream or current_video or current_displayed_image:
                last_stopped_content = {
                    'type': 'single',
                    'file': aktivni_stream or vzdaleny_nazev(current_video or current_displayed_image),
                    'source': zdroj,
                }
                xbmc.log(f"[Dohled] Uložen obsah pro resume: {last_stopped_content['file']} "
                         f"(zdroj: {zdroj or 'Jen teď'})", xbmc.LOGINFO)

            ukoncit_playlist("stop")

            # Nastavit flag že uživatel zastavil - monitoring nebude auto-startovat
            user_stopped = True
            xbmc.log("[Dohled] User stopped flag nastaven - auto-play deaktivován", xbmc.LOGINFO)

            user_initiated_file = None
            aktivni_stream = None
            current_video = None

            # Zavřít zobrazený obrázek (krytí černou)
            if current_displayed_image is not None:
                close_image_viewer()

            # Zastavit video
            player = xbmc.Player()
            if player.isPlaying():
                # Pravidlo projektu: NIKDY nezastavovat přehrávání bez krytí - černá PŘED stopem
                if not xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
                    show_black_filler("zastaveni videa")
                player.stop()
                wait_for_player_stop(timeout=2.0)
            xbmc.log("[Dohled] Přehrávání zastaveno", xbmc.LOGINFO)
            send_immediate_state_update()

        elif command == "pause":
            xbmc.log("[Dohled] Příkaz: Pozastavit/pokračovat přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            # Pauza je PREPINAC a musi fungovat i nad OBRAZKEM: ten se zobrazuje pres
            # ShowPicture, takze player.isPlaying() je False. Driv se v takovem pripade
            # jen zalogovalo "nic se neprehrava" a playlist bezel dal - tlacitko bylo mrtve.
            playlist_paused = not playlist_paused
            if player.isPlaying():
                # Video: pauznout i samotny prehravac, at zamrzne obraz
                if xbmc.getCondVisibility("Player.Paused") != playlist_paused:
                    player.pause()  # Toggle
            status = "pozastaveno" if playlist_paused else "pokračuje"
            xbmc.log(f"[Dohled] Přehrávání {status} (playlist_paused={playlist_paused})", xbmc.LOGINFO)
            send_immediate_state_update()

        elif command == "play_file":
            # Přehrát konkrétní lokální soubor (video v opakování nebo obrázek trvale).
            # Stejnou cestou jde i download_and_play po stažení a auto-play monitoringu.
            user_stopped = False  # Reset stop flagu
            if params and params.get("filename"):
                filename = params.get("filename")
                # Lokálně je soubor uložený pod basename (bez podsložky)
                local_filename = os.path.basename(filename)
                local_path = get_local_media_path(local_filename)
                if os.path.exists(local_path):
                    xbmc.log(f"[Dohled] Příkaz: Přehrát soubor {local_path}", xbmc.LOGINFO)

                    # Při obsahu provozovny (source=locality) NENASTAVOVAT "Jen teď"
                    source = params.get("source", "")
                    # Hlásí se PŘESNĚ název z příkazu ('Oresi/x.mp4', z karty holý název)
                    user_initiated_file = None if source == "locality" else filename
                    aktivni_stream = None
                    xbmc.log(f"[Dohled] play_file: {local_filename} (zdroj: {source or 'docasne'})", xbmc.LOGINFO)
                    nastavit_nazvy_obsahu([filename])

                    # Zastavit běžící playlist. Co je na obrazovce, říkají current_displayed_image
                    # / current_video: smyčka je při ukončení NEMAŽE (3.6.0 - do 3.5.9 je mazala,
                    # obrázek přitom zůstal na obrazovce a play_file to musel dohledávat).
                    ukoncit_playlist("play_file")

                    if is_image_file(local_filename):
                        ShowImage(local_path)
                    else:
                        # Video (i neznámý typ) - vždy JEDNA cesta: 1položkový playlist + RepeatOne
                        RepeatVideo(local_path)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {local_filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz play_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "play_stream":
            # Přehrát stream URL přímo (IPTV, HTTP, HLS/m3u8, RTMP atd.)
            user_stopped = False
            url = params.get('url', '') if params else ''
            if url:
                xbmc.log(f"[Dohled] Příkaz: Přehrát stream {url}", xbmc.LOGINFO)
                # Oznacit, ze nabiha obsah - pojistka nesmi mezitim spustit fallback
                # (viz ensure_content_visible, bod 2a-0: zpusobilo to pad Kodi)
                _transition_begin(20.0)

                # Zastavit běžící playlist
                ukoncit_playlist("play_stream")

                # Zavřít případný obrázek
                if current_displayed_image is not None:
                    close_image_viewer()
                current_video = None

                # Zastavit aktuální přehrávání - ale NEJDŘÍV krytí: player.stop() u videa
                # bez slideshow okna ukáže HOME MENU, dokud stream nenaběhne (u internetového
                # HLS klidně sekundy; změřeno 2.9.2026 v E4: menu 170 ms). Černá se odkryje
                # až když stream hraje (smyčka níže + uncover_if_covered).
                player = xbmc.Player()
                if player.isPlaying():
                    if not xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive"):
                        show_black_filler("příprava streamu")
                    player.stop()
                    wait_for_player_stop(timeout=3.0)

                # Připravit ListItem pro stream
                url_lower = url.lower()

                # Mrtvou URL Kodi NEPŘEDÁVAT (viz stream_dostupny) - krycí černá zůstane,
                # user_initiated_file se nastaví a watchdog zkouší znovu (bez přehrávání).
                _dostupny = stream_dostupny(url)
                if not _dostupny:
                    xbmc.log(f"[Dohled] play_stream: stream nedostupný, nepouštím: {url}", xbmc.LOGWARNING)
                elif url_lower.startswith(('rtsp://', 'rtp://', 'udp://', 'rtmp://')):
                    # Pro RTSP/RTP/UDP/RTMP - přehrát čistě bez ListItem properties
                    player.play(item=url)
                else:
                    play_item = xbmcgui.ListItem(path=url)
                    play_item.setProperty('IsPlayable', 'true')

                    # Zjistit zda jsou dostupné inputstream addony
                    has_adaptive = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')

                    # Pro HLS/m3u8 streamy: NECHAT NA KODI (nativni ffmpeg cesta).
                    # Driv se tu vynucoval inputstream.adaptive vcetne zastarale vlastnosti
                    # manifest_type (Kodi na ni hlasi deprecation warning). Na RPi3 to
                    # spolehlive shazovalo Kodi ~15 s po startu streamu (SIGSEGV, 2 pady
                    # za sebou 1.9.2026). Tataz URL prehravana PRIMO pres Kodi JSON-RPC,
                    # tedy bez techto vlastnosti, bezela 60 s bez problemu - rozdil je
                    # prave ve vynuceni adaptivniho vstupu.
                    if '.m3u8' in url_lower or 'hls' in url_lower:
                        play_item.setContentLookup(False)
                    # Pro DASH streamy
                    elif '.mpd' in url_lower:
                        if has_adaptive:
                            play_item.setMimeType('application/dash+xml')
                            play_item.setContentLookup(False)
                            play_item.setProperty('inputstream', 'inputstream.adaptive')
                            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')

                    player.play(item=url, listitem=play_item)
                xbmc.sleep(500)
                xbmc.executebuiltin('PlayerControl(RepeatOne)')

                # Stream hlídá watchdog a chrání před auto-play podle aktivni_stream (vždy);
                # "Jen teď" (user_initiated_file) jen když nejde o obsah provozovny.
                aktivni_stream = url
                stream_watchdog_od = time.time()
                user_initiated_file = None if (params or {}).get("source", "") == "locality" else url
                # Internetovy HLS/RTSP na RPi3 nabiha klidne 5-15 s. uncover_if_covered ceka
                # jen 3 s: kdyby odkryl driv, ukaze se menu, pojistka ho zakryje cernou a ta
                # pak nad uz hrajicim streamem visi az do dalsiho monitoring cyklu (~35 s).
                # Proto se na start streamu ceka az 20 s (znacka prechodu po tu dobu bezi).
                _t0 = time.time()
                while _dostupny and time.time() - _t0 < 20.0 and not player.isPlayingVideo():
                    xbmc.executebuiltin('Dialog.Close(busydialog)')
                    xbmc.sleep(250)
                if _dostupny:
                    uncover_if_covered(player, "stream")
                _transition_end()

                if not _dostupny:
                    # Stav je nastaven (aktivni_stream), obnovu resi stream watchdog;
                    # technik dostane potvrzeni s chybou misto "ok".
                    raise RuntimeError(f"stream nedostupný: {url}")
                xbmc.log(f"[Dohled] Přehrávám stream: {url}", xbmc.LOGINFO)
                send_immediate_state_update()
            else:
                xbmc.log("[Dohled] Příkaz play_stream bez parametru url", xbmc.LOGWARNING)

        elif command == "download_and_play":
            # Stáhnout soubor z FTP a pak přehrát
            # DULEZITE: Nezastavovat aktualni prehravani - nechame bezet co bezi
            # az po stazeni se prepne na novy soubor (bez vypadku)
            user_stopped = False
            if params and params.get("filename"):
                filename = params.get("filename")
                local_filename = os.path.basename(filename)
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát {filename} (bez zastaveni)", xbmc.LOGINFO)
                source = params.get("source", "")
                # "Jen teď" platí od přijetí příkazu (server ho tak eviduje); obrazovku
                # i hlášení přepne až play_file po stažení.
                user_initiated_file = None if source == "locality" else filename
                xbmc.log(f"[Dohled] download_and_play {local_filename}: "
                         f"{'obsah provozovny' if source == 'locality' else 'Jen teď'}", xbmc.LOGINFO)
                nastavit_nazvy_obsahu([filename], pridat=True)
                threading.Thread(target=download_and_play_file, args=(filename, _novy_stahovany_prikaz(), source),
                                 daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_only":
            # Pouze stáhnout soubor z FTP bez přehrání
            if params and params.get("filename"):
                filename = params.get("filename")
                xbmc.log(f"[Dohled] Příkaz: Pouze stáhnout {filename}", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně (bez přehrání)
                threading.Thread(target=download_only_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_and_play_playlist":
            # Stáhnout více souborů z FTP a přehrát jako playlist
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát playlist ({len(files)} souborů)", xbmc.LOGINFO)
                _akce_pripravit(int(params["akce_id"]) if params.get("akce_id") is not None else None)
                nastavit_nazvy_obsahu(files, pridat=True)
                # "Jen teď" platí od přijetí příkazu (server ho tak eviduje)
                user_initiated_file = None if params.get("source", "") == "locality" else "playlist:" + ",".join(files)
                # Stahování a pak STEJNÁ cesta jako play_playlist (ukončí předchozí obsah
                # a pustí smyčku). Do 3.5.9 se tady předchozí smyčka ukončovala hned - po celou
                # dobu stahování zůstala obrazovka na poslední položce bez smyčky (video
                # dohrálo -> HOME, zakryla až pojistka).
                threading.Thread(target=download_and_play_playlist,
                                 args=(files, params.get("source", ""), params.get("akce_id"), _novy_stahovany_prikaz()),
                                 daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "download_only_playlist":
            # Stáhnout více souborů z FTP BEZ přehrání
            if params and params.get("files"):
                files = params.get("files")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout {len(files)} souborů (bez přehrání)", xbmc.LOGINFO)
                # Spustit stahování v samostatném vlákně
                threading.Thread(target=download_only_playlist, args=(files,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "delete_file":
            # Smazat lokální soubor. Výsledek VŽDY potvrdí ack (chyba = výjimka -> ack s chybou);
            # do 3.6.0 "return" u přehrávaného souboru ack přeskočil a chyba mazání se
            # potvrdila jako úspěch.
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)

                # Kontrola že soubor není právě přehráván (lokálně je uložený pod basename,
                # příkaz může nést název se složkou 'Oresi/x.mp4')
                player = xbmc.Player()
                if player.isPlayingVideo():
                    playing_file = safe_playing_file(player)
                    if playing_file and os.path.basename(playing_file) == os.path.basename(filename):
                        xbmc.log(f"[Dohled] Nelze smazat přehrávaný soubor: {filename}", xbmc.LOGWARNING)
                        xbmcgui.Dialog().notification("Dohled", "Nelze smazat - soubor se přehrává", xbmcgui.NOTIFICATION_ERROR, 3000)
                        raise RuntimeError(f"soubor se přehrává: {os.path.basename(filename)}")

                if not os.path.exists(local_path):
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Dohled", "Soubor neexistuje", xbmcgui.NOTIFICATION_WARNING, 2000)
                    raise FileNotFoundError(f"soubor není na kartě: {os.path.basename(filename)}")
                try:
                    os.remove(local_path)
                except Exception as e:
                    xbmcgui.Dialog().notification("Dohled", f"Chyba mazání: {str(e)[:20]}", xbmcgui.NOTIFICATION_ERROR, 3000)
                    raise
                xbmc.log(f"[Dohled] Soubor smazán: {local_path}", xbmc.LOGINFO)
            else:
                xbmc.log("[Dohled] Příkaz delete_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "notification":
            title = params.get("title", "Dohled") if params else "Dohled"
            message = params.get("message", "") if params else ""
            duration = params.get("duration", 5000) if params else 5000
            xbmc.log(f"[Dohled] Příkaz: Notifikace - {title}: {message}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, duration)

        elif command == "set_mute":
            # Trvalé ztlumení/odtlumení zařízení
            if params is not None and "muted" in params:
                xbmc.log(f"[Dohled] Příkaz: set_mute ({params.get('muted')})", xbmc.LOGINFO)
                set_kodi_mute(params.get("muted"))
            else:
                xbmc.log("[Dohled] Příkaz set_mute bez parametru muted", xbmc.LOGWARNING)

        elif command == "update_addons":
            xbmc.log("[Dohled] Příkaz: Aktualizace doplňků", xbmc.LOGINFO)
            zkontrolovat_aktualizace()

        elif command == "refresh_config":
            xbmc.log("[Dohled] Příkaz: Obnovení konfigurace", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Obnovuji konfiguraci - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            mark_reboot("refresh_config")
            os.system("reboot")

        elif command == "reschedule_restart":
            # Feature B: přeplánovat noční restart podle nové konfigurace lokality (BEZ rebootu).
            # Posílá Django admin po změně restart nastavení lokality.
            xbmc.log("[Dohled] Příkaz: Přeplánování restartu (nová konfigurace lokality)", xbmc.LOGINFO)
            try:
                schedule_random_reboot(load_config().get("locality"))
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při přeplánování restartu: {e}", xbmc.LOGERROR)

        elif command == "play_playlist":
            # Přehrát playlist (videa i obrázky) - JEDINÁ přehrávací smyčka (spustit_playlist).
            # Stejnou cestou jde download_and_play_playlist po stažení, resume i start zařízení.
            user_stopped = False  # Reset stop flagu
            if params and params.get("files"):
                files = params.get("files")  # Seznam názvů souborů (může obsahovat filename:duration)
                xbmc.log(f"[Dohled] Příkaz: Přehrát playlist s {len(files)} soubory", xbmc.LOGINFO)
                source = params.get("source", "")
                akce_id = params.get("akce_id")  # Akce z mobilu (lze přidávat akce_append)
                parsed_files = parse_playlist_items(files)

                # Aspoň jeden soubor musí být na kartě - jinak nechat běžet dosavadní obsah
                if not any(is_supported_file(pf['filename']) and os.path.exists(get_local_media_path(pf['filename']))
                           for pf in parsed_files):
                    xbmc.log("[Dohled] Playlist: žádný soubor není na kartě - nepřehrávám", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Dohled", "Žádné soubory nenalezeny", xbmcgui.NOTIFICATION_ERROR, 3000)
                else:
                    # "Jen teď" (user_initiated_file) - kromě obsahu provozovny (source=locality)
                    if source == "locality":
                        user_initiated_file = None
                        xbmc.log(f"[Dohled] Obsah provozovny (play_playlist): {len(files)} souborů", xbmc.LOGINFO)
                    else:
                        user_initiated_file = "playlist:" + ",".join(files)
                        xbmc.log(f"[Dohled] user_initiated_file nastaven: {user_initiated_file}", xbmc.LOGINFO)
                    aktivni_stream = None
                    nastavit_nazvy_obsahu(files)
                    spustit_playlist(parsed_files, akce_id)
            else:
                xbmc.log("[Dohled] Příkaz play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "akce_append":
            # Akce z mobilu: stáhnout nové položky a přidat je na KONEC běžící smyčky akce
            # (bez restartu). Když akce na zařízení neběží (restart = konec akce), jen stáhne.
            if params and params.get("files") and params.get("akce_id") is not None:
                threading.Thread(target=akce_append,
                                 args=(int(params["akce_id"]), list(params["files"])), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz akce_append bez akce_id nebo files", xbmc.LOGWARNING)

        elif command == "add_to_playlist":
            # Přidat LOKÁLNÍ soubor ZA běžící obsah. Výsledek se liší od nastaveného obsahu
            # provozovny, je to tedy dočasný obsah "Jen teď" (user_initiated_file = výsledný
            # playlist ve formátu "playlist:a:6,b,..." jako u ostatních Jen teď playlistů).
            # Do 3.6.0 (review 28.10.) se výsledek hlásil jako obsah provozovny -> server čekal
            # obsah lokality a hlásil UpdateNeeded trvale. Výjimka: smyčka AKCE - ta zůstává
            # akcí (stav beze změny, přidaná položka se jen připojí).
            # - běžící playlist (i jednopoložkový): na konec - smyčka čte délku v každém kroku
            #   a jediná položka po přidání pokračuje jako playlist (do 3.6.0 se přidaná položka
            #   u jednopoložkového playlistu nikdy nepřehrála, i když se hlásila v playlistu);
            # - jeden soubor: z něj a přidaného se stane playlist [běžící, přidaná] (do 3.6.0
            #   se obsah nahradil playlistem jen z přidaného souboru);
            # - nic neběží: playlist z přidaného souboru.
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = get_local_media_path(filename)
                if not os.path.exists(local_path):
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
                    raise FileNotFoundError(f"soubor není na kartě: {os.path.basename(filename)}")
                polozka = parse_playlist_item(filename)
                with _obrazovka_lock:
                    polozky = current_playlist_items
                    if polozky is not None:
                        polozky.append(polozka)
                        current_mixed_playlist.append(polozka['filename'])
                        nastavit_nazvy_obsahu([filename], pridat=True)
                        with _akce_lock:
                            je_akce = (current_akce.get("id") is not None
                                       and current_akce.get("playlist_id") == current_playlist_id)
                        if user_initiated_file and user_initiated_file.startswith("playlist:"):
                            user_initiated_file += "," + filename
                        elif not je_akce:
                            # obsah provozovny + přidaná položka = Jen teď (celý výsledný playlist)
                            user_initiated_file = "playlist:" + ",".join(
                                f"{pf['filename']}:{pf['duration']}" if pf.get('duration') else pf['filename']
                                for pf in polozky)
                if polozky is not None:
                    xbmc.log(f"[Dohled] Přidáno na konec playlistu: {filename} ({len(polozky)} položek, "
                             f"user_initiated_file={user_initiated_file})", xbmc.LOGINFO)
                elif aktivni_stream:
                    raise ValueError("k streamu nelze přidat položku playlistu")
                elif current_video or current_displayed_image:
                    bezici = current_video or current_displayed_image
                    if user_initiated_file and not user_initiated_file.startswith("playlist:"):
                        bezici_nazev = user_initiated_file          # "Jen teď" - název z příkazu
                    else:
                        bezici_nazev = vzdaleny_nazev(bezici)       # obsah provozovny
                    xbmc.log(f"[Dohled] add_to_playlist: {bezici} + {filename} -> playlist (Jen teď)",
                             xbmc.LOGINFO)
                    execute_command("play_playlist", {"files": [bezici_nazev, filename], "source": ""},
                                    interni=True)
                else:
                    execute_command("play_playlist", {"files": [filename]}, interni=True)
            else:
                xbmc.log("[Dohled] Příkaz add_to_playlist bez parametru filename", xbmc.LOGWARNING)

        else:
            xbmc.log(f"[Dohled] Neznámý příkaz: {command}", xbmc.LOGWARNING)
            # clear_playlist (nativní Kodi playlist) i update_video 3.6.0 už nezná - viz changelog
            raise ValueError(f"neznámý příkaz: {command}")

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vykonávání příkazu {command}: {e}", xbmc.LOGERROR)
        if not interni:
            send_command_ack(command, command_id, ok=False, error=str(e))
    else:
        # Probehlo bez vyjimky. Restartovaci prikazy uz potvrdily vyse (do te doby,
        # nez se stihne dojit sem, uz zarizeni rebootuje).
        if not interni and command not in ("restart", "refresh_config"):
            send_command_ack(command, command_id, ok=True)


# Příkazy serveru (WebSocket, HTTP polling i piggyback v odpovědi na monitoring) se vykonávají
# v JEDNOM vlákně v pořadí přijetí (FIFO). Do 3.6.0 (review 28.10.) běžely přímo ve vlákně, které
# je přijalo: příkaz, který čeká na _obrazovka_lock, dokud playlistová smyčka dokončí přechod
# obrazovky (až ~9-14 s), blokoval WS vlákno (ping/ack), a po výpadku WS mohl příkaz z HTTP
# pollingu předběhnout dřívější příkaz z WS. Zámek se nezkracuje: chrání atomické "jsem pořád
# vlastník + zápis obrazovky" (bod 11).
_prikazy = queue.Queue()
_prikazy_vlakno = None
_prikazy_lock = threading.Lock()


def _prikazy_smycka():
    monitor = xbmc.Monitor()
    while not stop_monitoring and not monitor.abortRequested():
        try:
            command, params, command_id = _prikazy.get(timeout=1)
        except queue.Empty:
            continue
        try:
            execute_command(command, params, command_id)
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba vykonání příkazu {command}: {e}", xbmc.LOGERROR)


def zaradit_prikaz(command, params, command_id):
    global _prikazy_vlakno
    with _prikazy_lock:
        if _prikazy_vlakno is None or not _prikazy_vlakno.is_alive():
            _prikazy_vlakno = threading.Thread(target=_prikazy_smycka, daemon=True)
            _prikazy_vlakno.start()
    _prikazy.put((command, params, command_id))


# Interval pro HTTP polling příkazů (fallback když není WebSocket)
# Zvýšeno zpět na 5s protože je to jen fallback
COMMAND_POLL_INTERVAL = 5


def command_polling_loop(device_id):
    """HTTP fallback pro příkazy - běží pouze když není WebSocket."""

    xbmc.log("[Dohled] Spuštěn HTTP fallback polling příkazů", xbmc.LOGINFO)
    monitor = xbmc.Monitor()

    while not stop_monitoring and not monitor.abortRequested():
        # Pouze pollovat pokud není WebSocket připojen
        if not ws_connected:
            try:
                command, params, cmd_id = check_for_commands(device_id)
                if command:
                    # Parsovat params pokud je to JSON string
                    if params and isinstance(params, str):
                        try:
                            params = json.loads(params)
                        except:
                            pass
                    zaradit_prikaz(command, params, cmd_id)

            except Exception as e:
                xbmc.log(f"[Dohled] Chyba v HTTP polling: {e}", xbmc.LOGERROR)

        # Čekat COMMAND_POLL_INTERVAL sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(COMMAND_POLL_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break

    xbmc.log("[Dohled] HTTP polling příkazů ukončen", xbmc.LOGINFO)

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        return api_request(url, timeout=5)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        return api_request(url, timeout=5)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def get_local_video_files():
    """Vrátí seznam lokálních mediálních souborů (videa z VIDEO_DIR, obrázky z IMAGE_DIR)."""
    try:
        files = []

        # Skenovat VIDEO_DIR (videa)
        if os.path.exists(VIDEO_DIR):
            for filename in os.listdir(VIDEO_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(VIDEO_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Skenovat IMAGE_DIR (obrázky)
        if os.path.exists(IMAGE_DIR):
            for filename in os.listdir(IMAGE_DIR):
                if filename.lower().endswith(SUPPORTED_EXTENSIONS) and not filename.startswith('.'):
                    filepath = os.path.join(IMAGE_DIR, filename)
                    if os.path.isfile(filepath):
                        try:
                            stat = os.stat(filepath)
                            media_type = get_media_type(filename)
                            files.append({
                                "name": filename,
                                "size": stat.st_size,
                                "size_mb": round(stat.st_size / 1024 / 1024, 2),
                                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                                "type": media_type
                            })
                        except:
                            files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None, "type": get_media_type(filename)})

        # Seřadit podle jména
        files.sort(key=lambda x: x["name"].lower())
        video_count = sum(1 for f in files if f.get("type") == "video")
        image_count = sum(1 for f in files if f.get("type") == "image")
        xbmc.log(f"[Dohled] Nalezeno {len(files)} lokálních souborů ({video_count} videí, {image_count} obrázků)", xbmc.LOGINFO)
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání lokálních souborů: {e}", xbmc.LOGERROR)
        return []


def get_storage_info():
    """Vrátí informace o úložišti (volné místo, celková kapacita)."""
    try:
        stat = os.statvfs(VIDEO_DIR)
        free_bytes = stat.f_bavail * stat.f_frsize
        total_bytes = stat.f_blocks * stat.f_frsize
        used_bytes = total_bytes - free_bytes

        return {
            "free_mb": round(free_bytes / 1024 / 1024, 2),
            "total_mb": round(total_bytes / 1024 / 1024, 2),
            "used_mb": round(used_bytes / 1024 / 1024, 2),
            "free_percent": round((free_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 0
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa: {e}", xbmc.LOGERROR)
        return {"free_mb": 0, "total_mb": 0, "used_mb": 0, "free_percent": 0}


def get_video_files_sorted_by_age():
    """Vrátí seznam video souborů seřazený od nejstaršího."""
    try:
        if not os.path.exists(VIDEO_DIR):
            return []

        files = []
        for filename in os.listdir(VIDEO_DIR):
            if filename.lower().endswith(VIDEO_EXTENSIONS) and not filename.startswith('.'):
                filepath = os.path.join(VIDEO_DIR, filename)
                if os.path.isfile(filepath):
                    try:
                        mtime = os.path.getmtime(filepath)
                        size = os.path.getsize(filepath)
                        files.append({
                            "name": filename,
                            "path": filepath,
                            "mtime": mtime,
                            "size": size,
                            "size_mb": round(size / 1024 / 1024, 2)
                        })
                    except:
                        pass

        # Seřadit od nejstaršího
        files.sort(key=lambda x: x["mtime"])
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání seznamu souborů: {e}", xbmc.LOGERROR)
        return []


def cleanup_old_videos(needed_space_mb=0, keep_current=True):
    """
    Vyčistí staré video soubory pouze pokud je nedostatek volného místa.
    Neomezuje počet souborů - uživatel může mít libovolně mnoho souborů v playlistu.

    Args:
        needed_space_mb: Kolik MB potřebujeme uvolnit (0 = jen kontrola MIN_FREE_SPACE_MB)
        keep_current: Ponechat aktuálně přehrávaný soubor

    Returns:
        Počet smazaných souborů
    """
    try:
        storage = get_storage_info()
        total_needed = needed_space_mb + MIN_FREE_SPACE_MB

        # Kontrola zda je potřeba uvolnit místo
        if storage["free_mb"] >= total_needed:
            xbmc.log(f"[Dohled] Storage: Dostatek místa ({storage['free_mb']} MB volných), čištění není potřeba", xbmc.LOGINFO)
            return 0

        files = get_video_files_sorted_by_age()
        if not files:
            return 0

        # Zjistit aktuálně přehrávaný soubor
        current_file = None
        if keep_current:
            player = xbmc.Player()
            if player.isPlayingVideo():
                playing_path = safe_playing_file(player)
                current_file = os.path.basename(playing_path) if playing_path else None

        deleted_count = 0
        freed_space_mb = 0
        space_to_free = total_needed - storage["free_mb"]

        xbmc.log(f"[Dohled] Storage: Málo místa ({storage['free_mb']} MB volných), potřeba uvolnit {space_to_free} MB", xbmc.LOGWARNING)

        for f in files:
            if freed_space_mb >= space_to_free:
                break
            if f["name"] == current_file:
                xbmc.log(f"[Dohled] Storage: Přeskakuji aktuálně přehrávaný soubor: {f['name']}", xbmc.LOGINFO)
                continue
            try:
                os.remove(f["path"])
                deleted_count += 1
                freed_space_mb += f["size_mb"]
                xbmc.log(f"[Dohled] Storage: Smazán pro uvolnění místa: {f['name']} ({f['size_mb']} MB)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Dohled] Storage: Nelze smazat {f['name']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            xbmc.log(f"[Dohled] Storage: Celkem smazáno {deleted_count} souborů, uvolněno {freed_space_mb} MB", xbmc.LOGINFO)

        return deleted_count

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění souborů: {e}", xbmc.LOGERROR)
        return 0


def ensure_space_for_download(needed_mb):
    """Zajistí dostatek místa pro stažení nového souboru."""
    storage = get_storage_info()
    if storage["free_mb"] < needed_mb + MIN_FREE_SPACE_MB:
        xbmc.log(f"[Dohled] Storage: Před stahováním potřeba uvolnit místo pro {needed_mb} MB", xbmc.LOGINFO)
        cleanup_old_videos(needed_space_mb=needed_mb)
        return True
    return False


def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    # Zapisovat heartbeat aby watchdog nerestartoval Kodi behem setup
    write_heartbeat()

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    write_heartbeat()
    names = fetch_device_setup_name()
    if names:
        # API vrací seznam stringů, ne slovníků
        name_options = sorted(names, key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    write_heartbeat()
    localities = fetch_localities()
    if localities:
        locality_pairs = sorted(
            [(loc['name'], loc['code']) for loc in localities],
            key=lambda x: x[0].lower()
        )
        locality_options = [f"{name} ({code})" for name, code in locality_pairs]
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = locality_pairs[selected_locality][1]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    # Hostname je jen kosmetika (LibreELEC ho zobrazi v siti). Konfigurace je uz ulozena,
    # takze chyba tady NESMI shodit nastaveni zarizeni. 18.9.2026: na cerstvem LibreELEC
    # 12.2.1 ma embedded Python v Kodi vychozi kodovani ASCII -> open() bez encoding
    # spadlo na "Prodejce - zázemí" (UnicodeEncodeError) a zarizeni nešlo nastavit.
    try:
        with open("/storage/.cache/hostname", "w", encoding="utf-8") as f:
            f.write(name + "\n")
    except Exception as e:
        xbmc.log(f"[Dohled] Hostname se nepodařilo zapsat (pokračuji): {e}", xbmc.LOGWARNING)

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    mark_reboot("setup")
    os.system("reboot")

# ======= FEATURE A: DETEKCE PŘEKRYTÍ OBSAHU (menu/dialog/OSD/screensaver přes obsah) =======
content_obscured = False  # poslední zjištěný stav - reportuje se do monitoringu (dashboard varování)

# Nemodální překryvy (OSD, seekbar, hlasitost, kontextové menu, nastavení) dle jmen oken.
_OVERLAY_WINDOWS = (
    "Window.IsVisible(videoosd) | Window.IsVisible(seekbar) | Window.IsVisible(volumebar) | "
    "Window.IsVisible(contextmenu) | Window.IsVisible(osdvideosettings) | Window.IsVisible(osdaudiosettings) | "
    "Window.IsVisible(fullscreeninfo) | Window.IsVisible(playercontrols)"
)


def check_content_obscured():
    """Zjistí, zda je přes přehrávaný obsah GUI okno/dialog/OSD/screensaver nebo MENU.

    POZOR (oprava regrese z 3.5.0): slideshow okno 12007, kterým zobrazujeme OBRÁZKY,
    je v Kodi implementované jako MODÁLNÍ DIALOG. Původní kontrola ho proto vyhodnotila
    jako "překryv" a clear_content_overlays() ho zavřela -> obrazovka bez obsahu -> MENU.
    Náš vlastní slideshow (a přechodový busydialog) se proto NESMÍ počítat jako překryv.
    """
    try:
        if xbmc.getCondVisibility("System.ScreenSaverActive | System.DPMSActive"):
            return True, "screensaver/dpms"
        # Menu v popředí = obsah není vidět (nejhorší stav pro digital signage)
        if is_menu_visible():
            return True, "home_menu"
        # KRYCÍ ČERNÁ NAD HRAJÍCÍM VIDEEM: zařízení hlásí playing=True se správným
        # souborem, ale divák vidí ČERNOU OBRAZOVKU. Dashboard to jinak nemá jak poznat
        # (v testech výměny obsahu hlásil OK, přesto že 243 s svítila černá).
        # Během přechodu je to normální stav, proto se to hlásí jen mimo přechod.
        if (xbmc.getCondVisibility("Player.HasVideo") and not _transition_running()
                and xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive")):
            try:
                if os.path.basename(xbmc.getInfoLabel('Slideshow.Filename') or '') == \
                        os.path.basename(BLACK_IMAGE_PATH):
                    return True, "cerna_pres_video"
            except Exception:
                pass
        # Nemodální překryvy (OSD, seekbar, kontextové menu...) - ty zavřít lze
        if xbmc.getCondVisibility(_OVERLAY_WINDOWS):
            return True, "overlay_osd"
        if xbmc.getCondVisibility("System.HasVisibleModalDialog | System.HasActiveModalDialog"):
            # Náš obsah/přechod - NENÍ to překryv
            if xbmc.getCondVisibility("Window.IsVisible(slideshow) | Window.IsVisible(busydialog) | Window.IsVisible(busydialognocancel)"):
                return False, ""
            return True, "modal_dialog"
        return False, ""
    except Exception:
        return False, ""


# Dialogy, které patří NÁM a nesmí se zavírat: slideshow s obrázkem + přechodový busydialog.
# 9999 = "žádný aktivní dialog" (návratová hodnota xbmcgui.getCurrentWindowDialogId()).
_OUR_DIALOG_IDS = {12007, 10138, 10160, 9999}


def close_foreign_dialogs():
    """Zavře JAKÝKOLIV cizí dialog nad obsahem - podle jeho ID, ne podle jména.

    DŮVOD: jmenný seznam překryvů nikdy nepokryje všechno (změřeno: 'Nabídka vypnutí'
    (10111) zůstala nad videem, protože v seznamu nebyla, a 30s monitor loop ji nestihl).
    Tímto se pokryjí i dialogy nastavení, chybová okna, kontextová menu atd.
    Náš slideshow (12007) a přechodový busydialog se NIKDY nezavírají - je to obsah.
    """
    try:
        did = xbmcgui.getCurrentWindowDialogId()
        if did and did not in _OUR_DIALOG_IDS:
            xbmc.log(f"[Dohled] Pojistka: cizí dialog ID={did} nad obsahem - zavírám", xbmc.LOGWARNING)
            # Kodi se po zavření modálního dialogu na okamžik vrací na HOME, než znovu
            # aktivuje slideshow. Když nehraje video (to zůstane ve fullscreenu samo),
            # nejdřív znovu nasadit zobrazený obrázek nebo černou a teprve pak zavřít.
            if not xbmc.Player().isPlayingVideo():
                _img = get_local_media_path(current_displayed_image) if current_displayed_image else None
                if _img and os.path.exists(_img):
                    xbmc.executebuiltin(f'ShowPicture("{_img}")')
                else:
                    show_black_filler("zavření cizího dialogu")
            xbmc.executebuiltin(f"Dialog.Close({did},true)")
            return True
    except Exception:
        pass
    return False


# Jak dlouho smí nad hrajícím videem zůstat krycí okno, než to pojistka vyhodnotí
# jako zaseknuté krytí (přechody trvají do ~0,5 s, takže 3 s je bezpečná mez).
STUCK_COVER_SECONDS = 3.0
_video_under_slideshow_since = 0.0
_video_windowed_streak = 0


def uncover_stuck_cover():
    """POJISTKA proti zaseknuté krycí černé nad hrajícím videem (STUCK_COVER_SECONDS).

    Volá se KAŽDÝCH 0,5 s z menu_guard_loop. Dřív ležela jen uvnitř clear_content_overlays(),
    kterou rychlá smyčka volala jen při viditelném OSD - reálně tedy běžela až z monitor_loop
    (~35 s). Nalezeno 2.9.2026 nezávislou kontrolou kódu (changelog tvrdil 3 s).
    """
    try:
        # Obnovit fullscreen videa, pokud video hraje mimo fullscreen.
        #
        # POZOR - když je vidět náš slideshow, NESMÍ se použít Action(FullScreen):
        # uprostřed přechodu obrázek→video hraje video ZÁMĚRNĚ pod slideshow oknem a
        # Action(FullScreen) nad otevřeným slideshow video NEODKRYJE, jen zavře obrázek
        # a ukáže HOME (změřeno harnessem: HOME ~1,9 s, 3/3 pokusů).
        has_video = xbmc.getCondVisibility("Player.HasVideo")
        slideshow_up = xbmc.getCondVisibility("Window.IsVisible(slideshow) | Slideshow.IsActive")
        # POZOR: VideoPlayer.IsFullscreen se na zaseknuté krytí SPOLEHNOUT NELZE - Kodi
        # považuje video pod otevřeným slideshow oknem pořád za "fullscreen" (změřeno:
        # krycí černá visela nad hrajícím videem 40+ s a podmínka na IsFullscreen mlčela).
        # Rozhoduje proto, CO je ve slideshow okně: black.png je vždycky jen KRYTÍ,
        # nikdy ne cílový obsah - takže nad hrajícím videem tam nemá co dělat.
        cover_up = False
        if slideshow_up:
            try:
                cover_up = os.path.basename(
                    xbmc.getInfoLabel('Slideshow.Filename') or '') == os.path.basename(BLACK_IMAGE_PATH)
            except Exception:
                cover_up = False
        global _video_under_slideshow_since, _video_windowed_streak
        if has_video and not slideshow_up and not xbmc.getCondVisibility("VideoPlayer.IsFullscreen"):
            # Video hraje mimo fullscreen a nad nim neni nas slideshow (typicky HOME menu
            # nad videem). Ted se kontroluje 2x/s, proto: NIKDY behem oznaceneho prechodu
            # (video->obrazek ma ~0,3 s okno, kdy video jeste "hraje" a fullscreen uz neni)
            # a teprve kdyz stav drzi 2 kontroly po sobe (~1 s) - jednoframove stavy se neresi.
            _video_windowed_streak += 1
            if not _transition_running() and _video_windowed_streak >= 2:
                xbmc.log("[Dohled] POJISTKA: video hraje mimo fullscreen bez krytí - obnovuji fullscreen", xbmc.LOGWARNING)
                ensure_fullscreen_video()
                _video_windowed_streak = 0
            _video_under_slideshow_since = 0.0
        elif has_video and cover_up and not _transition_running():
            _video_windowed_streak = 0
            # ZASEKNUTÁ KRYCÍ ČERNÁ nad hrajícím videem -> divák vidí ČERNOU OBRAZOVKU.
            # Během přechodu je tenhle stav normální (a je označený značkou), takže sem
            # se dostane jen stav, který přechod není. Chvíli se ještě počká, aby se
            # nezasahovalo do neoznačeného krátkého přepnutí.
            if not _video_under_slideshow_since:
                _video_under_slideshow_since = time.monotonic()
            elif time.monotonic() - _video_under_slideshow_since > STUCK_COVER_SECONDS:
                xbmc.log("[Dohled] POJISTKA: nad hrajícím videem zůstalo krycí okno "
                         f"({round(time.monotonic() - _video_under_slideshow_since, 1)}s) "
                         "- odkrývám video", xbmc.LOGWARNING)
                # Odkrytí ATOMICKY přímo tady (ne přes uncover_video_from_image):
                # ta funkce nastavuje značku přechodu, a protože pojistka běží v jiném
                # vlákně než playlist, mohla by tím shodit ochranu právě běžícího přechodu.
                xbmc.executebuiltin('Dialog.Close(busydialog)')
                xbmc.executebuiltin('Dialog.Close(12007,true)')  # true = BEZ zaviraci animace (na RPi3 pri ni prosvitalo HOME)
                ensure_fullscreen_video()   # idempotentni - Action(FullScreen) je prepinac
                _video_under_slideshow_since = 0.0
        else:
            _video_under_slideshow_since = 0.0
            _video_windowed_streak = 0
    except Exception:
        pass


def clear_content_overlays():
    """Zavře překryvy tak, aby se NIKDY neodhalilo menu ani prázdná obrazovka.

    KRITICKÉ: NEPOUŽÍVAT Dialog.Close(all,true) - zavřelo by i náš slideshow (12007),
    kterým zobrazujeme obrázky, a obrazovka by spadla na HOME (přesně ten bug).
    Zavíráme proto jen KONKRÉTNÍ překryvná okna a obsah necháváme být.
    """
    try:
        for win in ("videoosd", "seekbar", "volumebar", "contextmenu", "osdvideosettings",
                    "osdaudiosettings", "fullscreeninfo", "playercontrols", "notification"):
            if xbmc.getCondVisibility(f"Window.IsVisible({win})"):
                xbmc.log(f"[Dohled] Pojistka: zavírám překryv {win} nad obsahem", xbmc.LOGWARNING)
                xbmc.executebuiltin(f"Dialog.Close({win},true)")
        # Kodi chybové dialogy ("Přehrávání selhalo", potvrzovací okna) na reklamní
        # obrazovce nemají co dělat - zavřít cíleně (NIKDY Dialog.Close(all), to by
        # zavřelo i náš slideshow s obsahem).
        for win in ("okdialog", "yesnodialog", "progressdialog", "extendedprogressdialog"):
            if xbmc.getCondVisibility(f"Window.IsVisible({win})"):
                xbmc.log(f"[Dohled] Pojistka: zavírám chybový/potvrzovací dialog {win}", xbmc.LOGWARNING)
                xbmc.executebuiltin(f"Dialog.Close({win},true)")
        uncover_stuck_cover()
    except Exception:
        pass


# ======= POJISTKA: MENU SE NIKDY NESMÍ UKÁZAT =======
_last_menu_recovery = 0.0
MENU_RECOVERY_COOLDOWN = 3.0  # s - aby oprava nejela v nekonečné smyčce


_menu_seen_streak = 0  # kolik kontrol po sobě vidělo menu (debounce proti jednoframovým blikům)


def ensure_content_visible():
    """Když v popředí ZŮSTÁVÁ Kodi MENU, přebije ho obsahem.

    DEBOUNCE: reaguje teprve když je menu vidět 2x po sobě (~0,5 s). Při přechodech
    (zavření slideshow / start videa) totiž prosvitne jediný frame - a "oprava" takového
    bliknutí byla ŠKODLIVÁ: pojistka jednou spustila fallback obrázek přes rozjíždějící
    se video, rozbila playlist a způsobila 3 s narušení (změřeno). Jednoframové bliky
    se proto ignorují; řeší se v příčině (pořadí operací v transition funkcích).

    Když běží playlist, pojistka NIKDY nespouští fallback - playlist si obsah nasadí sám
    do zlomku sekundy, stačí zakrýt černou.
    """
    global _last_menu_recovery, _menu_seen_streak

    try:
        if not is_menu_visible():
            _menu_seen_streak = 0
            return False
        # Nezasahovat, pokud uživatel zastavil přehrávání záměrně (stop příkaz)
        if user_stopped:
            _menu_seen_streak = 0
            return False

        _menu_seen_streak += 1
        if _menu_seen_streak < 2:
            return False   # jednoframový blik při přechodu - neřešit

        now = time.monotonic()
        if now - _last_menu_recovery < MENU_RECOVERY_COOLDOWN:
            return False
        _last_menu_recovery = now

        xbmc.log("[Dohled] POJISTKA: v popředí ZŮSTÁVÁ MENU - obnovuji obsah "
                 f"(obrázek={current_displayed_image}, video={current_video}, "
                 f"playlist={len(current_mixed_playlist)}, přechod={_transition_running()})", xbmc.LOGWARNING)

        # 1) Okamžité krytí - menu zmizí i když obnova obsahu chvíli trvá
        show_black_filler("pojistka proti menu")

        player = xbmc.Player()

        # 2a-0) PRÁVĚ SE ROZJÍŽDÍ OBSAH Z PŘÍKAZU (stream, soubor, playlist)? Jen krýt.
        #       Fallback by spustil DRUHÉ přehrávání proti tomu, které startuje - a dvě
        #       OpenFile na jednom přehrávači z různých vláken shodila Kodi na RPi3
        #       (změřeno 28.8.2026: příkaz play_stream v 12:55:31.953 a fallback pojistky
        #       ve 12:55:31.974 -> pád v 12:55:39). Značka sama vyprší, viz _transition_*.
        if _transition_running():
            xbmc.log("[Dohled] POJISTKA: právě nabíhá obsah z příkazu - jen krytí", xbmc.LOGWARNING)
            return True

        # 2b) Zmizel zobrazený obrázek (i položka playlistu) -> zobrazit ho znovu.
        #     3.6.0: dřív to kromě pojistky dělaly ještě obě playlistové smyčky samy.
        if current_displayed_image:
            path = get_local_media_path(current_displayed_image)
            if path and os.path.exists(path):
                xbmc.executebuiltin(f'ShowPicture("{path}")')
                xbmc.log(f"[Dohled] POJISTKA: obnoven obrázek {current_displayed_image}", xbmc.LOGWARNING)
                return True

        # 2c) Hraje video - jen vrátit do fullscreenu (idempotentně: Action(FullScreen)
        #     je PŘEPÍNAČ a naslepo by video vyhodil zpět na HOME - CLAUDE.md)
        if player.isPlayingVideo():
            xbmc.log("[Dohled] POJISTKA: video hraje pod menu - vracím fullscreen", xbmc.LOGWARNING)
            ensure_fullscreen_video()
            return True

        # 2a) Běží playlist? Nechat ho být - sám zobrazí další položku. Žádný fallback,
        #     jinak bychom mu přehráli cizí soubor a rozbili smyčku.
        if current_mixed_playlist:
            xbmc.log("[Dohled] POJISTKA: běží playlist - jen krytí, obsah nasadí playlist sám", xbmc.LOGWARNING)
            return True

        # 2d) Krátce po startu / během startu ještě nic nespouštět - startup_playback obsah
        #     nasadí. Jinak by se na ~1 s ukázal starý nesouvisející soubor.
        if startup_bezi or (time.monotonic() - ADDON_START_MONOTONIC) < 25:
            xbmc.log("[Dohled] POJISTKA: start obsahu - jen krytí, obsah nasadí startup", xbmc.LOGWARNING)
            return True

        # 2e) Nic neběží ani není playlist - teprve teď fallback soubor
        fallback = find_best_fallback_file()
        if fallback and os.path.exists(fallback):
            xbmc.log(f"[Dohled] POJISTKA: nic neběží - spouštím fallback {os.path.basename(fallback)}", xbmc.LOGWARNING)
            play_media_file(fallback)
            return True
        xbmc.log("[Dohled] POJISTKA: nic neběží a není co pustit - zůstává černá", xbmc.LOGWARNING)
        return True
    except Exception as e:
        xbmc.log(f"[Dohled] POJISTKA: chyba při obnově obsahu: {e}", xbmc.LOGERROR)
        return False


def menu_guard_loop():
    """Samostatné vlákno: každé 2s hlídá, že v popředí není Kodi menu.

    Vlastní vlákno (ne součást state_update_loop) proto, že state_update_loop se spouští
    jen když je dostupná WebSocket knihovna - pojistka proti menu musí fungovat VŽDY.
    """
    monitor = xbmc.Monitor()
    xbmc.log("[Dohled] Pojistka proti menu spuštěna (kontrola 2x/s)", xbmc.LOGINFO)
    while not stop_monitoring and not monitor.abortRequested():
        try:
            ensure_content_visible()
            uncover_stuck_cover()   # zaseknuta cerna nad videem - kontrola 2x/s, ne az z monitoringu
            # Uklidit i překryvy PŘES obsah (videoosd, seekbar, hlasitost, kontextové menu).
            # Na reklamní obrazovce nemá svítit lišta přehrávače - a 30s monitor_loop
            # by ji nechal viset až půl minuty.
            if xbmc.getCondVisibility(_OVERLAY_WINDOWS):
                xbmc.log("[Dohled] Pojistka: překryv přes obsah (OSD/lišta) - zavírám", xbmc.LOGWARNING)
                clear_content_overlays()
            # Cokoli cizího nad obsahem (nabídka vypnutí, nastavení, chybové okno...) zavřít podle ID
            close_foreign_dialogs()
        except Exception:
            pass
        if monitor.waitForAbort(0.5):
            break


def monitor_loop():
    global ws_connected
    config = load_config()
    device_id = get_device_id()
    monitor = xbmc.Monitor()

    # Počkat na navázání WebSocket spojení (max 15 sekund)
    # Tím se vyhneme zbytečnému HTTP fallbacku při startu
    ws_wait_timeout = 15
    waited = 0
    while not ws_connected and waited < ws_wait_timeout and not stop_monitoring and not monitor.abortRequested():
        # Použít waitForAbort místo time.sleep - okamžitě se vrátí při abort
        if monitor.waitForAbort(1):
            return  # Kodi požaduje ukončení
        waited += 1
        # Logovat průběh čekání každých 5 sekund
        if waited % 5 == 0 and not ws_connected:
            xbmc.log(f"[Dohled] Čekám na WebSocket... {waited}s/{ws_wait_timeout}s", xbmc.LOGINFO)

    # Dát WebSocketu ještě chvíli na dokončení připojení
    if not ws_connected:
        if monitor.waitForAbort(1):
            return

    if ws_connected:
        xbmc.log(f"[Dohled] WebSocket připojen po {waited}s, spouštím monitoring", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] WebSocket timeout ({ws_wait_timeout}s), spouštím monitoring s HTTP fallback", xbmc.LOGWARNING)

    # Log upload tracking
    _log_upload_position = 0
    _last_log_upload_time = 0
    if os.path.exists(KODI_LOG_PATH):
        try:
            # od startu doplňku (LOG_UPLOAD_ZACATEK); bez něj od současného konce jako dřív
            _log_upload_position = (LOG_UPLOAD_ZACATEK if LOG_UPLOAD_ZACATEK is not None
                                    else os.path.getsize(KODI_LOG_PATH))
            xbmc.log(f"[Dohled] Log upload: startovni pozice {_log_upload_position}", xbmc.LOGINFO)
        except:
            pass

    while not stop_monitoring and not monitor.abortRequested():
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            # Feature A: detekce a zavření překrytí obsahu (menu/dialog/OSD/screensaver)
            global content_obscured
            _obscured, _obscured_reason = check_content_obscured()
            if _obscured:
                xbmc.log(f"[Dohled] Obsah je překryt ({_obscured_reason}) - zavírám překryvy", xbmc.LOGWARNING)
                clear_content_overlays()
                _obscured, _obscured_reason = check_content_obscured()  # znovu ověřit po pokusu o zavření
            content_obscured = _obscured

            # Očekávaný obsah z API (override, kampaň, dočasné přehrávání, lokalita).
            # Při chybě se nic nemění - hraje dál, co hraje, a zkusí se to v dalším cyklu.
            # Volá se kvůli vedlejším efektům (ztlumení, plné názvy pro samoopravu, boot_time).
            fetch_expected_file(device_id)

            # Vynutit trvalé ztlumení zařízení (příznak Muted z API)
            set_kodi_mute(device_muted)

            # 3.6.0: ŽÁDNÝ auto-play očekávaného obsahu. Obsah nasazuje server příkazem (R4:
            # operace s obsahem patří API - kampaně, override, vrácení k obsahu). Auto-play
            # v 3.5.9 reálně spouštěl jen jeden soubor lokality (u ostatních ho blokovalo
            # porovnání velikosti s locality_config) a souběžně se serverem by závodil
            # (ověřeno testem O1/O2: auto-play předběhl start kampaně a server pak konec
            # kampaně neposlal). Start zařízení nasazuje obsah sám (startup_playback).

            stav = stav_prehravani()
            # Velikost a datum ZOBRAZENÉHO lokálního souboru (server je porovná s FTP)
            last_modified = file_size = None
            _pf = stav["playing_file"]
            if _pf and '://' not in _pf and os.path.exists(_pf):
                _st = os.stat(_pf)
                file_size = _st.st_size
                last_modified = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(_st.st_mtime))

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] Stav: playing={stav['playing']}, paused={stav['paused']}, "
                     f"soubor={stav['current_filename']}, typ={stav['media_type']}, "
                     f"playlist={stav['playlist_position']}/{len(stav['playlist'] or [])}, WS={ws_connected}",
                     xbmc.LOGINFO)

            payload = {
                "device_id": device_id,
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": get_boot_time(),
                "system_boot_time": get_system_boot_time(),
                "next_reboot": get_next_reboot(),
                "last_reboot": get_last_reboot_date(),
                "locality": locality,
                "playing": stav["playing"],
                "playing_file": stav["playing_file"],
                "paused": stav["paused"],
                "addon_version": ADDON_VERSION,
                "current_filename": stav["current_filename"],
                "content_obscured": content_obscured,
                "sd_health": sd_health_report(),
                "local_files": get_local_video_files(),
                "ws_connected": ws_connected,
                "playlist": stav["playlist"],
                "playlist_position": stav["playlist_position"],
                "storage": get_storage_info(),
                "media_type": stav["media_type"],  # "video", "image" nebo None
                # "Jen teď": VŽDY přítomné - název přesně z příkazu / URL / "playlist:..."; None = obsah provozovny
                "user_initiated_file": user_initiated_file,
                # Stav aktualizací doplňku (jen hlášení, nic se neopravuje) - viz stav_aktualizaci
                "aktualizace": stav_aktualizaci(),
            }

            # Detekce stale WS - pokud zadny ACK za 90s, spojeni je mrtve
            if ws_connected and last_ws_ack_time > 0 and (time.time() - last_ws_ack_time) > WS_STALE_TIMEOUT:
                xbmc.log(f"[Dohled] WS stale: zadny ACK za {time.time() - last_ws_ack_time:.0f}s, vynucuji reconnect", xbmc.LOGWARNING)
                ws_connected = False
                try:
                    if ws_app:
                        ws_app.close()
                except:
                    pass

            # Zkusit odeslat přes WebSocket, jinak HTTP fallback
            sent_via_ws = False
            if ws_connected and ws_app:
                try:
                    ws_app.send(json.dumps({
                        "type": "monitoring",
                        "payload": payload
                    }))
                    sent_via_ws = True
                    xbmc.log("[Dohled] Monitoring data odeslána přes WebSocket", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání přes WS, použiji HTTP: {e}", xbmc.LOGWARNING)
                    ws_connected = False

            if not sent_via_ws:
                # HTTP fallback
                url = "https://apidohled.noreason.eu/api/monitoring"
                response = send_data(payload, url)

                # Zpracovat odpověď serveru
                if response and response.get("status") == "saved":
                    # Piggyback příkazy - server může poslat příkaz v odpovědi na monitoring
                    piggyback_command = response.get("command")
                    if piggyback_command:
                        piggyback_params = response.get("command_params")
                        xbmc.log(f"[Dohled] Piggyback příkaz z monitoring odpovědi: {piggyback_command}", xbmc.LOGINFO)
                        zaradit_prikaz(piggyback_command, piggyback_params,
                                       response.get("command_id"))

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        # === Log upload (kazdych 60s) ===
        try:
            now_ts = time.time()
            if ws_connected and ws_app and (now_ts - _last_log_upload_time) >= LOG_UPLOAD_INTERVAL:
                if os.path.exists(KODI_LOG_PATH):
                    file_size_now = os.path.getsize(KODI_LOG_PATH)
                    # Detekce rotace logu (Kodi restartoval a soubor je mensi)
                    if file_size_now < _log_upload_position:
                        xbmc.log("[Dohled] Log upload: detekce rotace, reset pozice", xbmc.LOGINFO)
                        _log_upload_position = 0
                    if file_size_now > _log_upload_position:
                        with open(KODI_LOG_PATH, 'r', encoding='utf-8', errors='ignore') as f:
                            f.seek(_log_upload_position)
                            new_lines = f.read(LOG_UPLOAD_MAX_SIZE)
                        if new_lines:
                            ws_app.send(json.dumps({
                                "type": "log_upload",
                                "lines": new_lines
                            }))
                            _log_upload_position += len(new_lines.encode('utf-8'))
                            xbmc.log(f"[Dohled] Log upload: odeslan {len(new_lines)} znaku", xbmc.LOGINFO)
                _last_log_upload_time = now_ts
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v log uploadu: {e}", xbmc.LOGWARNING)

        # Monitoring interval: 30 sekund - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_MONITORING_INTERVAL):
            break  # Kodi požaduje ukončení
        if stop_monitoring:
            break


def _odeslat_stav(stav):
    """Odešle lehký state update (stav ze stav_prehravani): WS, jinak HTTP. Vrací True/False."""
    can_resume = bool(last_stopped_content)
    payload = {
        "playing": stav["playing"],
        "paused": stav["paused"],
        "current_filename": stav["current_filename"],
        "can_resume": can_resume,
        "user_initiated_file": user_initiated_file  # Pro API - nastaví UserInitiatedPlayback
    }
    if stav["playlist_position"] is not None:
        payload["playlist_position"] = stav["playlist_position"]

    if user_initiated_file:
        # Pozorovatelné v logu (e2e testy podle něj ověřují "Jen teď")
        xbmc.log(f"[Dohled] Hlášeno user_initiated_file={user_initiated_file}", xbmc.LOGINFO)
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({"type": "state_update", "payload": payload}))
            return True
        except Exception as e:
            xbmc.log(f"[Dohled] State update přes WS selhal, zkouším HTTP: {e}", xbmc.LOGWARNING)

    # HTTP fallback - lehký update (state_update_only). update_needed se NEPOSÍLÁ: je to
    # čistý výpočet serveru (R3) - do 3.5.9 tu bylo natvrdo False.
    try:
        config = load_config()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()
        except Exception:
            ip_address = "unknown"
        http_payload = {
            "device_id": get_device_id(),
            "name": config.get("name", "unknown"),
            "ip_address": ip_address,
            "locality": config.get("locality", ""),
            "playing": stav["playing"],
            "playing_file": stav["playing_file"],
            "paused": stav["paused"],
            "current_filename": stav["current_filename"],
            "can_resume": can_resume,
            "user_initiated_file": user_initiated_file,
            "ws_connected": False,
            "state_update_only": True
        }
        return send_data(http_payload, "https://apidohled.noreason.eu/api/monitoring") is not None
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba HTTP state update: {e}", xbmc.LOGWARNING)
        return False


def send_immediate_state_update():
    """Okamžité odeslání stavu po změně obsahu (rychlá aktualizace dashboardu).
    Stav počítá stav_prehravani() - stejně jako state_update_loop a monitoring."""
    global _posledni_odeslany_stav
    stav = stav_prehravani()
    if _odeslat_stav(stav):
        _posledni_odeslany_stav = (stav["playing"], stav["paused"], stav["current_filename"],
                                   stav["playlist_position"])
        xbmc.log(f"[Dohled] Okamžitý stav: playing={stav['playing']}, soubor={stav['current_filename']}",
                 xbmc.LOGINFO)
        return True
    return False


_posledni_odeslany_stav = None


def state_update_loop():
    """
    Rychlá smyčka pro aktualizaci stavu přehrávání.
    - Kontroluje stav každé WS_STATE_CHECK_INTERVAL sekund (rychlá detekce změn)
    - Odesílá pouze při ZMĚNĚ stavu nebo po WS_STATE_HEARTBEAT_INTERVAL sekundách (heartbeat)
      (přes HTTP při změně nebo max. jednou za HTTP_FALLBACK_INTERVAL)
    - Stream watchdog
    3.6.0: stav počítá stav_prehravani() bez 5s tolerance "playing=False" a bez druhé
    pojistky proti menu (tu dělá menu_guard_loop 2x/s).
    """
    global _posledni_odeslany_stav, user_initiated_file, aktivni_stream, stream_watchdog_od

    HTTP_FALLBACK_INTERVAL = 10  # Sekund mezi HTTP requesty když WS není k dispozici
    last_send_time = 0
    stream_watchdog_fails = 0  # Počítadlo neúspěšných pokusů watchdogu
    stream_stable_since = 0  # Cas kdy stream zacal stabilne hrat
    monitor = xbmc.Monitor()

    xbmc.log(f"[Dohled] State update smyčka: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)

    while not stop_monitoring and not monitor.abortRequested():
        try:
            # Zapsat heartbeat pro externí watchdog (vždy, i bez WS)
            write_heartbeat()

            player = xbmc.Player()
            current_time = time.time()

            # === Stream watchdog ===
            # Běží stream (aktivni_stream, i provozovny) a Kodi ho nepřehrává déle než 8 s
            # (od startu streamu / posledního pokusu / posledního přehrávání) -> restart streamu.
            stream_hraje = bool(aktivni_stream) and player.isPlayingVideo()
            if stream_hraje:
                stream_watchdog_od = current_time
                if stream_stable_since == 0:
                    stream_stable_since = current_time
                # Reset pocitadla az po 30s nepretrziteho prehravani
                if stream_watchdog_fails > 0 and (current_time - stream_stable_since) > 30:
                    stream_watchdog_fails = 0
                    xbmc.log("[Dohled] Stream watchdog: stream stabilni 30s, reset pocitadla", xbmc.LOGINFO)
            elif aktivni_stream and not user_stopped and (current_time - stream_watchdog_od) > 8:
                stream_stable_since = 0
                stream_watchdog_fails += 1
                max_retries = 5
                if stream_watchdog_fails <= max_retries:
                    xbmc.log(f"[Dohled] Stream watchdog: stream vypadl, pokus {stream_watchdog_fails}/{max_retries} - restartuji {aktivni_stream}", xbmc.LOGWARNING)
                    # NEJDŘÍV krytí, PAK zavřít chybové dialogy - a NIKDY Dialog.Close(all):
                    # to zavře i naši krycí černou a do dalšího ShowPicture svítí HOME
                    # (změřeno 2.9.2026 v E4: 170 ms menu při každém pokusu watchdogu).
                    show_black_filler("restart streamu")
                    xbmc.sleep(100)
                    for _w in ("okdialog", "yesnodialog", "busydialog"):
                        xbmc.executebuiltin(f'Dialog.Close({_w},true)')
                    try:
                        url_lower = aktivni_stream.lower()
                        if not stream_dostupny(aktivni_stream):
                            # Nedostupny stream Kodi nepredavat (viz stream_dostupny) - pocita
                            # se jako neuspesny pokus, cerna zustava.
                            xbmc.log(f"[Dohled] Stream watchdog: stream nedostupný (pokus {stream_watchdog_fails})", xbmc.LOGWARNING)
                        else:
                            if url_lower.startswith(('rtsp://', 'rtp://', 'udp://', 'rtmp://')):
                                player.play(item=aktivni_stream)
                            else:
                                play_item = xbmcgui.ListItem(path=aktivni_stream)
                                play_item.setProperty('IsPlayable', 'true')
                                player.play(item=aktivni_stream, listitem=play_item)
                            xbmc.sleep(5000)
                            if player.isPlaying():
                                xbmc.executebuiltin('PlayerControl(RepeatOne)')
                                # Krytí z tohoto bloku musí jít pryč, jinak by stream hrál
                                # pod černou (divák by viděl černou obrazovku)
                                uncover_if_covered(player, "stream")
                                # NERESETOVAT pocitadlo hned - az po 30s stabilniho prehravani
                                xbmc.log(f"[Dohled] Stream watchdog: stream spusten, cekam na stabilitu (pokus {stream_watchdog_fails})", xbmc.LOGINFO)
                            else:
                                xbmc.log(f"[Dohled] Stream watchdog: stream se nespustil (pokus {stream_watchdog_fails})", xbmc.LOGWARNING)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Stream watchdog chyba: {e}", xbmc.LOGERROR)
                    stream_watchdog_od = time.time()
                else:
                    xbmc.log(f"[Dohled] Stream watchdog: {max_retries} neúspěšných pokusů, ukončuji stream", xbmc.LOGWARNING)
                    user_initiated_file = None
                    aktivni_stream = None
                    stream_watchdog_fails = 0
                    # Krytí PŘED zavíráním dialogů (viz výše) - obnova z lokality chvíli trvá
                    show_black_filler("ukončení streamu, obnova lokality")
                    xbmc.sleep(100)
                    for _w in ("okdialog", "yesnodialog", "busydialog"):
                        xbmc.executebuiltin(f'Dialog.Close({_w},true)')
                    xbmc.sleep(100)
                    # Ve VLAKNE - startup_playback dela FTP/HTTP (i desitky sekund) a tahle
                    # smycka posila stav pres WS kazde 2 s; nesmi stat.
                    threading.Thread(target=startup_playback, daemon=True).start()
                    xbmc.log("[Dohled] Stream watchdog: obnova prehravani z lokality spustena", xbmc.LOGINFO)

            # === Stav ===
            stav = stav_prehravani()
            klic = (stav["playing"], stav["paused"], stav["current_filename"], stav["playlist_position"])
            state_changed = klic != _posledni_odeslany_stav
            if ws_connected and ws_app:
                odeslat = state_changed or (current_time - last_send_time) >= WS_STATE_HEARTBEAT_INTERVAL
            else:
                odeslat = state_changed or (current_time - last_send_time) >= HTTP_FALLBACK_INTERVAL
            if odeslat and _odeslat_stav(stav):
                last_send_time = current_time
                _posledni_odeslany_stav = klic
                if state_changed:
                    xbmc.log(f"[Dohled] Změna stavu: playing={stav['playing']}, paused={stav['paused']}, "
                             f"soubor={stav['current_filename']}, pozice={stav['playlist_position']}", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v state update loop: {e}", xbmc.LOGERROR)

        # Čekat na další kontrolu - použít waitForAbort pro rychlé ukončení
        if monitor.waitForAbort(WS_STATE_CHECK_INTERVAL):
            break  # Kodi požaduje ukončení


# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}


# ======= STARTUP SEKVENCE (nahrazuje service.smycky) =======

def startup_playback():
    """
    Spustí přehrávání při startu zařízení (a po vzdání stream watchdogu): stáhne, co chybí
    nebo se na FTP změnilo, a pustí obsah STEJNOU cestou jako příkazy play_playlist / play_file.
    """
    global startup_bezi
    startup_bezi = True
    try:
        _startup_playback()
    finally:
        startup_bezi = False


# Běží start obsahu - auto-play monitoringu do něj nesmí vstoupit druhým přehráváním
startup_bezi = False

STARTUP_OPAKOVANI_OD = 10    # s - první čekání na API / ověřený čas při startu
STARTUP_OPAKOVANI_MAX = 60   # s - strop čekání (backoff 10 -> 20 -> 40 -> 60)


def _startup_prevzato(poradi):
    """Převzal obsah během startu příkaz (play/stop/...)? Pak start nic nenasazuje."""
    if _prikaz_obsahu_poradi != poradi:
        xbmc.log("[Dohled] Startup: obsah mezitím převzal příkaz - start nic nenasazuje", xbmc.LOGINFO)
        return True
    return False


def _startup_ocekavany_obsah(device_id, locality, poradi):
    """Start zařízení: očekávaný obsah z API -> (filename, source), nebo None, když Kodi
    končí nebo obsah mezitím převzal příkaz ze serveru / od uživatele.

    Do 3.6.0 (HEAD 8e0f226) start při nedostupném API přehrál fallback a SKONČIL - a protože
    auto-play je zrušený (R4), hrál fallback až do restartu (typicky po výpadku proudu, kdy
    router naběhne později než zařízení). Teď start rozliší "API nedostupné" od "API
    odpovědělo, žádný obsah": při chybě hraje fallback a zkouší to dál (10 s -> max 60 s);
    jakmile API odpoví, start se dokončí normálně (není to auto-play).

    Ptá se až s OVĚŘENÝM časem (_cas_overen): bez boot_time by server po restartu nezrušil
    "Jen teď" a start by nasadil dočasný obsah jako obsah provozovny."""
    monitor = xbmc.Monitor()

    def _cekat(sekund, i_na_cas):
        """Počká `sekund`; dřív skončí při ověření času (i_na_cas). False = Kodi končí."""
        konec = time.monotonic() + sekund
        while time.monotonic() < konec:
            if i_na_cas and _cas_overen.is_set():
                return True
            if monitor.waitForAbort(0.5) or stop_monitoring:
                return False
        return True

    # Ověření času trvá obvykle do sekundy - chvíli počkat pod krycí černou, ať zbytečně
    # neblikne fallback.
    if not _cas_overen.is_set() and not _cekat(STARTUP_OPAKOVANI_OD, True):
        return None
    cekani = STARTUP_OPAKOVANI_OD
    fallback_hraje = False
    while True:
        if _cas_overen.is_set():
            vysledek = fetch_expected_file(device_id, locality)
            if vysledek is not None:
                if fallback_hraje:
                    xbmc.log("[Dohled] Startup: API odpovědělo - dokončuji start", xbmc.LOGINFO)
                return vysledek
            duvod = "API nedostupné"
        else:
            duvod = "čas zařízení zatím není ověřený"
        if _startup_prevzato(poradi):
            return None
        if not fallback_hraje:
            fallback_hraje = True
            fallback = find_best_fallback_file()
            if fallback:
                xbmc.log(f"[Dohled] Startup: {duvod} - mezitím přehrávám fallback {fallback}", xbmc.LOGWARNING)
                play_media_file(fallback)
            else:
                xbmc.log(f"[Dohled] Startup: {duvod} - fallback není, zůstává černá", xbmc.LOGWARNING)
        xbmc.log(f"[Dohled] Startup: {duvod} - zkusím znovu za {cekani} s", xbmc.LOGWARNING)
        if not _cekat(cekani, not _cas_overen.is_set()):
            return None
        if _startup_prevzato(poradi):
            return None
        cekani = min(cekani * 2, STARTUP_OPAKOVANI_MAX)


def _startup_playback():
    xbmc.log("[Dohled] === Spuštění přehrávání při startu ===", xbmc.LOGINFO)

    # PRVNÍ VĚC: krycí černá obrazovka. Než se stáhne konfigurace z API a připraví obsah
    # (HTTP + případně FTP = klidně desítky sekund), svítilo by na TV Kodi MENU.
    show_black_filler("start - příprava obsahu")
    # Příkaz ze serveru / od uživatele, který během startu (API, FTP - klidně desítky
    # sekund) nasadí nebo zastaví obsah, má přednost: start ho nepřepíše.
    poradi = _prikaz_obsahu_poradi

    try:
        # 1. Načíst konfiguraci
        config = load_config()
        locality = config.get("locality")
        device_id = get_device_id()

        if not locality:
            xbmc.log("[Dohled] Startup: Locality není nastavena, přeskakuji přehrávání", xbmc.LOGWARNING)
            return

        xbmc.log(f"[Dohled] Startup: Locality={locality}, DeviceID={device_id}", xbmc.LOGINFO)

        # 2. Získat očekávaný soubor (device override nebo locality)
        # Předáváme locality jako fallback pro nová zařízení bez záznamu v DB
        vysledek = _startup_ocekavany_obsah(device_id, locality, poradi)
        if vysledek is None:
            return   # Kodi končí, nebo obsah mezitím převzal příkaz
        expected_file, source = vysledek

        if not expected_file:
            # API odpovědělo: žádný obsah
            xbmc.log("[Dohled] Startup: Žádný očekávaný soubor, zkouším fallback", xbmc.LOGWARNING)
            if not current_video and not current_displayed_image:
                fallback = find_best_fallback_file()
                if fallback:
                    xbmc.log(f"[Dohled] Startup: Přehrávám fallback: {fallback}", xbmc.LOGINFO)
                    if _startup_prevzato(poradi):
                        return
                    play_media_file(fallback)
            return

        xbmc.log(f"[Dohled] Startup: Očekávaný soubor '{expected_file}' (zdroj: {source})", xbmc.LOGINFO)

        # 3. Stream / playlist / jeden soubor
        if '://' in expected_file:
            # Stream jako obsah (kampaň, override) - STEJNOU cestou jako příkaz play_stream.
            # Do 3.6.0 se URL zkoušela stáhnout z FTP jako soubor a hrál náhradní soubor.
            xbmc.log(f"[Dohled] Startup: obsah je stream {expected_file}", xbmc.LOGINFO)
            if _startup_prevzato(poradi):
                return
            execute_command("play_stream", {"url": expected_file, "source": "locality"}, interni=True)
        elif expected_file.startswith("playlist:"):
            # Playlist mode
            playlist_content = expected_file[9:]  # Odstranit "playlist:" prefix
            xbmc.log(f"[Dohled] Startup: Detekován playlist: {playlist_content}", xbmc.LOGINFO)

            # Parsovat playlist
            playlist_items = parse_playlist_items(playlist_content.split(','))
            if not playlist_items:
                xbmc.log("[Dohled] Startup: Playlist je prázdný", xbmc.LOGWARNING)
                return

            # Kontrola a stažení souborů z playlistu
            ftp_config = fetch_ftp_config(locality)
            valid_files = []

            _ftp_kontrola = None          # jedno FTP spojeni pro kontrolu velikosti polozek
            _ftp_kontrola_selhala = False
            for item in playlist_items:
                filename = item['filename']
                local_path = get_local_media_path(filename)

                # Zkontrolovat zda soubor existuje lokálně
                if os.path.exists(local_path) and os.path.getsize(local_path) > 0:
                    # Soubor na FTP mohl byt NAHRAZEN (stejny nazev, jina velikost) - v single
                    # rezimu se to kontroluje, u playlistu se to driv nikdy nedotahlo a server
                    # to ted hlasi jako "Aktualizace" (zastarale_polozky_playlistu). Porovnat a
                    # pripadne stahnout znovu; pri chybe FTP nechat lokalni soubor.
                    # JEDNO FTP spojeni pro vsechny polozky (viz _ftp_kontrola nize) - spojeni
                    # na kazdou polozku by pod kryci cernou trvalo N x az 30 s.
                    _znovu = False
                    if _ftp_kontrola is None and ftp_config and not _ftp_kontrola_selhala:
                        try:
                            from ftplib import FTP as _FTP
                            _ftp_kontrola = _FTP()
                            _ftp_kontrola.connect(ftp_config.get('ftp_host'), timeout=10)
                            _ftp_kontrola.login(ftp_config.get('ftp_user'), ftp_config.get('ftp_pass'))
                            _ftp_kontrola.voidcmd("TYPE I")
                        except Exception as _e:
                            xbmc.log(f"[Dohled] Startup: FTP pro kontrolu velikosti nedostupne ({_e}) - kontrola vynechana", xbmc.LOGWARNING)
                            _ftp_kontrola = None
                            _ftp_kontrola_selhala = True
                    if _ftp_kontrola is not None:
                        try:
                            _rs = _ftp_kontrola.size(ftp_config.get('ftp_path') + filename)
                            if _rs and int(_rs) != os.path.getsize(local_path):
                                xbmc.log(f"[Dohled] Startup: {filename} má na FTP jinou velikost "
                                         f"({_rs} vs {os.path.getsize(local_path)}) - stahuji znovu", xbmc.LOGWARNING)
                                _znovu = True
                        except Exception as _e:
                            xbmc.log(f"[Dohled] Startup: kontrola velikosti {filename} selhala: {_e}", xbmc.LOGWARNING)
                    if _znovu and not download_file_ftp(
                            ftp_config.get('ftp_host'), ftp_config.get('ftp_user'),
                            ftp_config.get('ftp_pass'), ftp_config.get('ftp_path'), filename, local_path):
                        xbmc.log(f"[Dohled] Startup: nové stažení {filename} selhalo - hraji lokální verzi", xbmc.LOGWARNING)
                    valid_files.append(item)
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} existuje lokálně", xbmc.LOGINFO)
                elif ftp_config:
                    # Zkusit stáhnout z FTP
                    xbmc.log(f"[Dohled] Startup: Stahuji {filename} z FTP", xbmc.LOGINFO)
                    if download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        filename,
                        local_path
                    ):
                        valid_files.append(item)
                    else:
                        xbmc.log(f"[Dohled] Startup: Nepodařilo se stáhnout {filename}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[Dohled] Startup: Soubor {filename} nenalezen a FTP není dostupné", xbmc.LOGWARNING)

            if not valid_files:
                xbmc.log("[Dohled] Startup: Žádné platné soubory v playlistu", xbmc.LOGERROR)
                fallback = find_best_fallback_file()
                if fallback:
                    if _startup_prevzato(poradi):
                        return
                    play_media_file(fallback)
                return

            if _ftp_kontrola is not None:
                try:
                    _ftp_kontrola.quit()
                except Exception:
                    pass
            # Spustit playlist STEJNOU cestou jako příkaz (jediná přehrávací smyčka).
            # Obsah po startu je vždy základní obsah zařízení (server dočasné přehrávání
            # při restartu maže) -> source=locality, žádné "Jen teď".
            xbmc.log(f"[Dohled] Startup: Spouštím playlist s {len(valid_files)} soubory", xbmc.LOGINFO)
            if _startup_prevzato(poradi):
                return
            execute_command("play_playlist", {
                "files": [f"{it['filename']}:{it['duration']}" if it.get('duration') else it['filename']
                          for it in valid_files],
                "source": "locality"}, interni=True)

        else:
            # Single file mode
            local_path = get_local_media_path(expected_file)

            # 4. Zkontrolovat zda soubor existuje a je aktuální
            needs_download = False

            if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
                needs_download = True
                xbmc.log(f"[Dohled] Startup: Soubor {expected_file} neexistuje lokálně", xbmc.LOGINFO)
            else:
                # Zkontrolovat zda je na FTP novější verze
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    remote_time, remote_size = get_remote_file_info(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file
                    )
                    local_time, local_size = get_local_file_info(local_path)

                    if remote_time and remote_size:
                        if remote_size != local_size or remote_time > local_time + 60:
                            needs_download = True
                            xbmc.log("[Dohled] Startup: Na FTP je novější verze souboru", xbmc.LOGINFO)

            # 5. Stáhnout pokud potřeba
            if needs_download:
                ftp_config = fetch_ftp_config(locality)
                if ftp_config:
                    xbmc.log(f"[Dohled] Startup: Stahuji {expected_file} z FTP", xbmc.LOGINFO)
                    download_file_ftp(
                        ftp_config.get('ftp_host'),
                        ftp_config.get('ftp_user'),
                        ftp_config.get('ftp_pass'),
                        ftp_config.get('ftp_path'),
                        expected_file,
                        local_path
                    )
                else:
                    xbmc.log("[Dohled] Startup: FTP konfigurace není dostupná", xbmc.LOGWARNING)

            # 6. Kontrola integrity PŘED přehráním - poškozený soubor by jinak
            #    způsobil smyčku "pořád se zkouší spustit přehrávání".
            #    (velikost proti FTP ověřuje už download_file_ftp)
            if not validate_media_file(local_path)[0]:
                xbmc.log(f"[Dohled] Startup: soubor {expected_file} je vadný - opravuji", xbmc.LOGWARNING)
                ensure_media_playable(expected_file, None, locality)

            # 7. Přehrát soubor - STEJNOU cestou jako příkaz play_file
            file_to_play = get_best_available_file(local_path)
            if file_to_play == local_path:
                xbmc.log(f"[Dohled] Startup: Přehrávám {file_to_play}", xbmc.LOGINFO)
                if _startup_prevzato(poradi):
                    return
                execute_command("play_file", {"filename": expected_file, "source": "locality"}, interni=True)
            elif file_to_play:
                xbmc.log(f"[Dohled] Startup: očekávaný soubor chybí, přehrávám náhradní {file_to_play}", xbmc.LOGWARNING)
                if _startup_prevzato(poradi):
                    return
                play_media_file(file_to_play)
            else:
                xbmc.log("[Dohled] Startup: Žádný soubor k přehrání!", xbmc.LOGERROR)
                xbmcgui.Dialog().notification("Chyba", "Žádný soubor k přehrání", xbmcgui.NOTIFICATION_ERROR, 5000)

    except Exception as e:
        xbmc.log(f"[Dohled] Startup: Chyba - {e}", xbmc.LOGERROR)
        # Zkusit fallback
        fallback = find_best_fallback_file()
        if fallback:
            xbmc.log(f"[Dohled] Startup: Používám fallback po chybě: {fallback}", xbmc.LOGWARNING)
            if _startup_prevzato(poradi):
                return
            play_media_file(fallback)


def main():
    # stop_monitoring: do 3.5.9 bez global -> lokální proměnná, vlákna se o ukončení nedozvěděla
    global ws_thread, stop_monitoring

    global LOG_UPLOAD_ZACATEK
    try:
        LOG_UPLOAD_ZACATEK = os.path.getsize(KODI_LOG_PATH)
    except OSError:
        LOG_UPLOAD_ZACATEK = None
    xbmc.log("[Dohled] === Spuštění doplňku Dohled ===", xbmc.LOGINFO)
    try:
        import locale as _locale
        xbmc.log(f"[Dohled] Python kódování: soubory={_locale.getpreferredencoding(False)}, "
                 f"fs={sys.getfilesystemencoding()}, utf8_mode={sys.flags.utf8_mode}", xbmc.LOGINFO)
    except Exception:
        pass

    # PRVNÍ KROK: české časové pásmo a synchronizace času (před čímkoli jiným)
    zajistit_casove_pasmo()
    ensure_time_synchronized()

    # Druhá přehrávací smyčka (service.smycky v legacy režimu) nesmí běžet vedle nás
    vypnout_service_smycky()

    # ========================================
    # WATCHDOG DAEMON (automatický restart při pádu)
    # ========================================
    # Spustit watchdog jako oddělený daemon proces
    # Pokud service.dohled přestane zapisovat heartbeat, watchdog restartuje Kodi
    xbmc.log("[Dohled] === Spouštění watchdog daemonu ===", xbmc.LOGINFO)
    spawn_watchdog_daemon()

    # Načtení konfigurace - PRED aktualizaci addonu!
    # Pokud neni nakonfigurovano, nejdrive dokoncit setup, pak teprve updatovat
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
        # prompt_for_config konci rebootem, sem se nedostaneme
        return
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    # Závislosti pro streamy (cache, inputstream addony) - jednou při startu, AŽ PO
    # dokončení konfigurace (instalace inputstreamu restartuje Kodi). Do 3.5.9 se to
    # volalo z hodinové "aktualizace doplňků".
    def _zavislosti():
        ensure_low_latency_cache()
        ensure_inputstream_addons()
    threading.Thread(target=_zavislosti, daemon=True).start()

    # Získat device_id pro komunikaci
    device_id = get_device_id()
    xbmc.log(f"[Dohled] Device ID: {device_id}", xbmc.LOGINFO)

    # Spuštění WebSocket connection loop (prioritní real-time kanál)
    if WEBSOCKET_AVAILABLE:
        ws_thread = threading.Thread(target=ws_connection_loop, args=(device_id,), daemon=True)
        ws_thread.start()
        xbmc.log("[Dohled] WebSocket connection loop spuštěn", xbmc.LOGINFO)

        # Spuštění rychlé state update smyčky (každé 2s, pouze přes WS)
        threading.Thread(target=state_update_loop, daemon=True).start()
        xbmc.log("[Dohled] Rychlá state update smyčka spuštěna (2s interval)", xbmc.LOGINFO)
    else:
        xbmc.log("[Dohled] WebSocket není dostupný, použije se pouze HTTP", xbmc.LOGWARNING)

    # Spuštění monitorovací smyčky (odesílá data každých 30s přes WS nebo HTTP)
    threading.Thread(target=monitor_loop, daemon=True).start()

    # Spuštění HTTP fallback pollingu příkazů (aktivní pouze když není WS)
    threading.Thread(target=command_polling_loop, args=(device_id,), daemon=True).start()

    # Spuštění periodické kontroly aktualizací addonů (každou hodinu, první za 5 minut)
    threading.Thread(target=addon_update_loop, daemon=True).start()
    xbmc.log("[Dohled] Periodická kontrola aktualizací spuštěna", xbmc.LOGINFO)

    # ========================================
    # ZAKÁZÁNÍ SCREENSAVERU (prevence ztlumení obrazovky)
    # ========================================
    xbmc.log("[Dohled] Zakázání screensaveru (InhibitScreensaver)", xbmc.LOGINFO)
    xbmc.executebuiltin('InhibitScreensaver(true)')

    # ========================================
    # STARTUP PŘEHRÁVÁNÍ (nahrazuje service.smycky)
    # ========================================
    xbmc.log("[Dohled] === Spuštění startup přehrávání ===", xbmc.LOGINFO)
    threading.Thread(target=startup_playback, daemon=True).start()

    # ========================================
    # KODI LOG MONITOR (detekce černé obrazovky)
    # ========================================
    global kodi_log_monitor
    xbmc.log("[Dohled] === Spuštění KodiLogMonitor ===", xbmc.LOGINFO)
    kodi_log_monitor = KodiLogMonitor()
    kodi_log_monitor.start()

    # ========================================
    # POJISTKA PROTI KODI MENU
    # ========================================
    # Menu se nikdy nesmí ukázat - hlídá se každé 2s nezávisle na WebSocketu.
    threading.Thread(target=menu_guard_loop, daemon=True).start()

    # ========================================
    # OCHRANA PROTI SMYČCE RESTARTŮ
    # ========================================
    # Vynuluje počítadlo automatických restartů po stabilním uptime (monotonic).
    threading.Thread(target=reset_auto_reboot_counter_when_stable, daemon=True).start()

    # ========================================
    # PLÁNOVÁNÍ RESTARTU
    # ========================================
    xbmc.log("[Dohled] === Plánování denního restartu ===", xbmc.LOGINFO)
    schedule_random_reboot(load_config().get("locality"))

    xbmc.log("[Dohled] === Inicializace dokončena ===", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] WebSocket: {'ANO' if WEBSOCKET_AVAILABLE else 'NE'}", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] State updates: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)
    xbmc.log("[Dohled] Startup přehrávání: ANO (nahrazuje service.smycky)", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] Krytí přechodů: černý obrázek"
             f"{' + krycí video (Amlogic)' if USE_BLACK_TRANSITION_VIDEO else ' (krycí video se nepoužívá)'}",
             xbmc.LOGINFO)

    # ========================================
    # HLAVNÍ SMYČKA - ČEKÁNÍ NA ABORT
    # ========================================
    # KRITICKÉ: Tato smyčka je nutná pro správné ukončení addonu!
    # Bez ní Kodi nemůže gracefully zastavit addon a zabije ho po 5 sekundách.
    monitor = xbmc.Monitor()
    xbmc.log("[Dohled] Spouštím hlavní smyčku (čekám na abort)", xbmc.LOGINFO)

    while not monitor.abortRequested():
        # Čekat 1 sekundu, ale okamžitě se probudit při abort requestu
        if monitor.waitForAbort(1):
            break

    # ========================================
    # GRACEFUL SHUTDOWN
    # ========================================
    xbmc.log("[Dohled] === Ukončování addonu ===", xbmc.LOGINFO)

    # Nastavit stop_monitoring flag pro všechny vlákna
    stop_monitoring = True

    # Zavřít WebSocket spojení (toto probudí blokující run_forever)
    if ws_app:
        try:
            xbmc.log("[Dohled] Zavírám WebSocket spojení...", xbmc.LOGINFO)
            ws_app.close()
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při zavírání WS: {e}", xbmc.LOGWARNING)

    # Zastavit KodiLogMonitor
    if kodi_log_monitor:
        try:
            kodi_log_monitor.stop()
        except:
            pass

    xbmc.log("[Dohled] === Addon ukončen ===", xbmc.LOGINFO)


if __name__ == "__main__":
    main()