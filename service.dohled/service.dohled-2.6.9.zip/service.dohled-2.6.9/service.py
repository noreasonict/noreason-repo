import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import sys
import json
import socket
import threading
import time
import urllib.request
import urllib.parse
import uuid
import subprocess
import ssl
from email.utils import parsedate_to_datetime
from datetime import datetime

# Přidat cestu k bundlované websocket knihovně
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
sys.path.insert(0, ADDON_PATH)

# Import websocket knihovny (bundlovaná s addonem)
try:
    import websocket
    WEBSOCKET_AVAILABLE = True
    xbmc.log("[Dohled] WebSocket knihovna načtena", xbmc.LOGINFO)
except ImportError:
    WEBSOCKET_AVAILABLE = False
    xbmc.log("[Dohled] WebSocket knihovna není dostupná, použije se HTTP fallback", xbmc.LOGWARNING)

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')
DEVICE_ID_FILE = os.path.join(PROFILE_DIR, 'device_id.txt')
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
TIME_SYNC_FILE = "/storage/.kodi/userdata/time_synced.flag"
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# WebSocket konfigurace
WS_URL = "wss://apidohled.noreason.eu/ws/"
WS_RECONNECT_INTERVAL = 5  # Sekund mezi pokusy o reconnect
WS_PING_INTERVAL = 30  # Sekund mezi ping zprávami
WS_MONITORING_INTERVAL = 30  # Sekund mezi plnými monitoring zprávami přes WebSocket
WS_STATE_CHECK_INTERVAL = 2  # Sekund mezi kontrolami stavu (rychlá detekce změn)
WS_STATE_HEARTBEAT_INTERVAL = 10  # Sekund - max interval pro heartbeat i bez změny stavu

# Správa úložiště
VIDEO_DIR = "/storage/videos/"
MIN_FREE_SPACE_MB = 500  # Minimální volné místo v MB před mazáním starých souborů
MAX_VIDEO_FILES = 10  # Maximální počet video souborů (0 = neomezeno)

# Globální stav WebSocket spojení
ws_connected = False
ws_app = None
ws_thread = None

# Globální stav pro detekci změn (rychlé aktualizace)
last_playing_state = None
last_playing_true_time = None  # Čas kdy bylo naposledy playing=True (pro debouncing)
last_paused_state = None
last_filename = None


class WebSocketClient:
    """WebSocket klient pro real-time komunikaci s API serverem."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.ws = None
        self.connected = False
        self.should_reconnect = True
        self.last_monitoring_time = 0

    def on_message(self, ws, message):
        """Zpracování příchozí zprávy ze serveru."""
        try:
            data = json.loads(message)
            msg_type = data.get("type")

            xbmc.log(f"[Dohled WS] Přijata zpráva typu: {msg_type}", xbmc.LOGINFO)

            if msg_type == "command":
                # Okamžité zpracování příkazu!
                command = data.get("command")
                params = data.get("params", {})
                if command:
                    xbmc.log(f"[Dohled WS] Příkaz: {command}, params: {params}", xbmc.LOGINFO)
                    execute_command(command, params)

            elif msg_type == "ping":
                # Odpovědět na ping
                self.send_pong()

            elif msg_type == "welcome":
                xbmc.log(f"[Dohled WS] Spojení navázáno: {data.get('message')}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification(
                    "Dohled",
                    "Real-time spojení aktivní",
                    xbmcgui.NOTIFICATION_INFO,
                    2000
                )

            elif msg_type == "ack":
                xbmc.log(f"[Dohled WS] Server potvrdil monitoring data", xbmc.LOGINFO)

        except json.JSONDecodeError:
            xbmc.log(f"[Dohled WS] Neplatná JSON zpráva: {message[:100]}", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba zpracování zprávy: {e}", xbmc.LOGERROR)

    def on_error(self, ws, error):
        """Zpracování chyby WebSocket."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Chyba: {error}", xbmc.LOGERROR)
        self.connected = False
        ws_connected = False  # Povolit HTTP fallback

    def on_close(self, ws, close_status_code, close_msg):
        """Zpracování uzavření spojení."""
        global ws_connected
        xbmc.log(f"[Dohled WS] Spojení uzavřeno: {close_status_code} - {close_msg}", xbmc.LOGWARNING)
        self.connected = False
        ws_connected = False

        if self.should_reconnect:
            xbmc.log(f"[Dohled WS] Pokus o reconnect za {WS_RECONNECT_INTERVAL}s...", xbmc.LOGINFO)

    def on_open(self, ws):
        """Zpracování navázání spojení."""
        global ws_connected
        xbmc.log("[Dohled WS] Spojení navázáno!", xbmc.LOGINFO)
        self.connected = True
        ws_connected = True

        # Odeslat identifikaci
        self.send_json({
            "type": "identify",
            "device_id": self.device_id
        })

    def send_json(self, data):
        """Odeslání JSON zprávy přes WebSocket."""
        if self.ws and self.connected:
            try:
                self.ws.send(json.dumps(data))
                return True
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba při odesílání: {e}", xbmc.LOGERROR)
                self.connected = False
        return False

    def send_pong(self):
        """Odpověď na ping."""
        self.send_json({"type": "pong"})

    def send_monitoring(self, payload):
        """Odeslání monitoring dat přes WebSocket."""
        return self.send_json({
            "type": "monitoring",
            "payload": payload
        })

    def connect(self):
        """Navázání WebSocket spojení."""
        global ws_app

        url = f"{WS_URL}{self.device_id}"
        xbmc.log(f"[Dohled WS] Připojuji se k: {url}", xbmc.LOGINFO)

        try:
            # Nastavení SSL kontextu (pro self-signed certifikáty)
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

            self.ws = websocket.WebSocketApp(
                url,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close,
                on_open=self.on_open
            )
            ws_app = self.ws

            # Spustit WebSocket v blokovacím režimu (v samostatném vlákně)
            self.ws.run_forever(
                sslopt={"cert_reqs": ssl.CERT_NONE, "check_hostname": False},
                ping_interval=WS_PING_INTERVAL,
                ping_timeout=10
            )

        except Exception as e:
            xbmc.log(f"[Dohled WS] Chyba při připojování: {e}", xbmc.LOGERROR)
            self.connected = False

    def disconnect(self):
        """Ukončení WebSocket spojení."""
        self.should_reconnect = False
        if self.ws:
            try:
                self.ws.close()
            except:
                pass


def ws_connection_loop(device_id):
    """Smyčka pro udržování WebSocket spojení."""
    global stop_monitoring, ws_connected

    if not WEBSOCKET_AVAILABLE:
        xbmc.log("[Dohled WS] WebSocket knihovna není dostupná, použije se HTTP", xbmc.LOGWARNING)
        return

    xbmc.log("[Dohled WS] Spouštím WebSocket connection loop", xbmc.LOGINFO)

    ws_client = WebSocketClient(device_id)

    while not stop_monitoring:
        if not ws_connected:
            try:
                ws_client.connect()
            except Exception as e:
                xbmc.log(f"[Dohled WS] Chyba v connection loop: {e}", xbmc.LOGERROR)

        # Čekat před dalším pokusem o reconnect
        for _ in range(WS_RECONNECT_INTERVAL):
            if stop_monitoring:
                break
            time.sleep(1)

    ws_client.disconnect()
    xbmc.log("[Dohled WS] Connection loop ukončen", xbmc.LOGINFO)


# České NTP servery (seřazené podle priority)
CZ_NTP_SERVERS = [
    "antispam.oresi.cz",  # ORESI interní server
    "tik.cesnet.cz",      # CESNET stratum 1
    "tak.cesnet.cz",      # CESNET stratum 1
    "ntp.nic.cz",         # CZ.NIC stratum 1
    "ntp.cesnet.cz",      # CESNET
    "0.cz.pool.ntp.org",  # Czech NTP pool
    "1.cz.pool.ntp.org",
]

# České HTTP servery pro fallback (bez HTTPS - aby fungoval i při špatném čase)
CZ_HTTP_SERVERS = [
    "http://www.seznam.cz",
    "http://www.novinky.cz",
    "http://www.idnes.cz",
    "http://www.centrum.cz",
]

# Minimální platný rok pro kontrolu času
MIN_VALID_YEAR = 2024

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Maximální doba čekání na síť (v sekundách)
NETWORK_WAIT_TIMEOUT = 30

# KRITICKÉ: Okamžitě smazat starý sync flag při načtení modulu
# Toto musí proběhnout PŘED spuštěním doplňku Smycky
try:
    if os.path.exists(TIME_SYNC_FILE):
        os.remove(TIME_SYNC_FILE)
        xbmc.log("[Dohled] Okamžitě odstraněn starý sync flag při startu", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)

# ======= SYNCHRONIZACE ČASU =======

def wait_for_network(timeout=NETWORK_WAIT_TIMEOUT):
    """Čeká na dostupnost sítě (WiFi může trvat déle)."""
    xbmc.log("[Dohled] Čekám na dostupnost sítě...", xbmc.LOGINFO)

    waited = 0
    while waited < timeout:
        try:
            # Zkusit připojení na Google DNS (IP bez DNS resolvingu)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            xbmc.log(f"[Dohled] Síť dostupná po {waited}s", xbmc.LOGINFO)
            return True
        except:
            pass

        time.sleep(1)
        waited += 1

        # Informovat každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Dohled] Stále čekám na síť... ({waited}s)", xbmc.LOGINFO)

    xbmc.log(f"[Dohled] Timeout čekání na síť ({timeout}s)", xbmc.LOGWARNING)
    return False



def is_time_valid():
    """Zkontroluje, zda je systémový čas platný (rok >= MIN_VALID_YEAR)."""
    current_year = datetime.now().year
    is_valid = current_year >= MIN_VALID_YEAR
    xbmc.log(f"[Dohled] Kontrola času: rok {current_year}, platný: {is_valid}", xbmc.LOGINFO)
    return is_valid


def sync_time_ntp(timeout=5):
    """Pokusí se synchronizovat čas přes NTP pomocí ntpd."""
    for server in CZ_NTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o NTP sync: {server}", xbmc.LOGINFO)
            # ntpd -n -q = nedaemonizovat, ukončit po sync
            result = subprocess.run(
                ["ntpd", "-n", "-q", "-p", server],
                timeout=timeout,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                xbmc.log(f"[Dohled] NTP synchronizace úspěšná: {server}", xbmc.LOGINFO)
                return True
            else:
                xbmc.log(f"[Dohled] NTP {server} selhalo: {result.stderr}", xbmc.LOGWARNING)
        except subprocess.TimeoutExpired:
            xbmc.log(f"[Dohled] NTP {server} timeout po {timeout}s", xbmc.LOGWARNING)
        except FileNotFoundError:
            xbmc.log("[Dohled] ntpd není dostupný, přeskakuji NTP", xbmc.LOGWARNING)
            return False
        except Exception as e:
            xbmc.log(f"[Dohled] NTP {server} chyba: {e}", xbmc.LOGERROR)
    return False


def sync_time_http(timeout=5):
    """Fallback: získá čas z HTTP Date hlavičky českých serverů."""
    for url in CZ_HTTP_SERVERS:
        try:
            xbmc.log(f"[Dohled] Pokus o HTTP time sync: {url}", xbmc.LOGINFO)

            # HTTP požadavek (bez SSL - funguje i při špatném systémovém čase)
            req = urllib.request.Request(url, method='HEAD')
            req.add_header('User-Agent', 'Mozilla/5.0')

            with urllib.request.urlopen(req, timeout=timeout) as response:
                date_header = response.headers.get('Date')
                if date_header:
                    # Parsování RFC 2822 data z hlavičky
                    server_time = parsedate_to_datetime(date_header)
                    # Formát pro Linux date příkaz
                    time_str = server_time.strftime("%Y-%m-%d %H:%M:%S")

                    xbmc.log(f"[Dohled] HTTP čas ze serveru: {time_str}", xbmc.LOGINFO)

                    # Nastavení systémového času
                    result = subprocess.run(
                        ["date", "--set", time_str],
                        capture_output=True,
                        text=True
                    )

                    if result.returncode == 0:
                        xbmc.log(f"[Dohled] Systémový čas nastaven na: {time_str}", xbmc.LOGINFO)
                        return True
                    else:
                        xbmc.log(f"[Dohled] Chyba nastavení času: {result.stderr}", xbmc.LOGERROR)
                else:
                    xbmc.log(f"[Dohled] {url} nevrátil Date hlavičku", xbmc.LOGWARNING)

        except Exception as e:
            xbmc.log(f"[Dohled] HTTP sync {url} chyba: {e}", xbmc.LOGERROR)

    return False


def create_time_sync_flag():
    """Vytvoří signalizační soubor o úspěšné synchronizaci času."""
    try:
        sync_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(TIME_SYNC_FILE, "w") as f:
            f.write(sync_time_str)
        xbmc.log(f"[Dohled] Vytvořen sync flag: {TIME_SYNC_FILE}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vytváření sync flagu: {e}", xbmc.LOGERROR)


def remove_time_sync_flag():
    """Odstraní signalizační soubor (volá se při startu)."""
    try:
        if os.path.exists(TIME_SYNC_FILE):
            os.remove(TIME_SYNC_FILE)
            xbmc.log(f"[Dohled] Odstraněn starý sync flag", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)


def ensure_time_synchronized():
    """Zajistí synchronizaci času - hlavní funkce volaná při startu."""
    xbmc.log("[Dohled] === Zahajuji kontrolu a synchronizaci času ===", xbmc.LOGINFO)

    # Vždy odstranit starý flag při startu
    remove_time_sync_flag()

    # PRVNÍ: Počkat na síť (WiFi může trvat déle)
    if not wait_for_network():
        xbmc.log("[Dohled] Síť nedostupná, pokračuji bez synchronizace", xbmc.LOGWARNING)
        create_time_sync_flag()
        return False

    # Kontrola, zda je čas již platný
    if is_time_valid():
        xbmc.log("[Dohled] Systémový čas je již platný, sync není potřeba", xbmc.LOGINFO)
        create_time_sync_flag()
        return True

    xbmc.log("[Dohled] Systémový čas je neplatný, spouštím synchronizaci", xbmc.LOGWARNING)
    xbmcgui.Dialog().notification(
        "Synchronizace času",
        "Probíhá synchronizace systémového času...",
        xbmcgui.NOTIFICATION_INFO,
        3000
    )

    # Pokus 1: NTP (nejpřesnější)
    if sync_time_ntp(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes NTP", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            "Čas synchronizován",
            "Synchronizace přes NTP úspěšná",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        create_time_sync_flag()
        return True

    # Pokus 2: HTTP fallback
    xbmc.log("[Dohled] NTP selhalo, zkouším HTTP fallback", xbmc.LOGWARNING)
    if sync_time_http(timeout=5):
        xbmc.log("[Dohled] Čas synchronizován přes HTTP", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            "Čas synchronizován",
            "Synchronizace přes HTTP úspěšná",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
        create_time_sync_flag()
        return True

    # Synchronizace selhala
    xbmc.log("[Dohled] KRITICKÉ: Synchronizace času selhala!", xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        "Chyba synchronizace",
        "Nepodařilo se synchronizovat čas!",
        xbmcgui.NOTIFICATION_ERROR,
        5000
    )

    # I při selhání vytvoříme flag, aby smyčky mohly pokračovat (s rizikem)
    # Lepší než aby se smyčky vůbec nespustily
    create_time_sync_flag()
    return False

# Vynucení kontroly aktualizací doplňků
def force_update_addons():
    try:
        xbmc.executebuiltin('UpdateAddonRepos()')  # Aktualizuje repozitáře
        xbmc.executebuiltin('UpdateLocalAddons()') # Aktualizuje nainstalované doplňky
        xbmc.log("[Dohled] Vynucená kontrola aktualizací addonů", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při aktualizaci addonů: {e}", xbmc.LOGERROR)

# Získá čas posledního restartu ze systémového uptime
def get_boot_time():
    try:
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            boot_timestamp = time.time() - uptime_seconds
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(boot_timestamp))
    except:
        return None

# Načtení verze doplňku pro aktualizaci         
def get_smycky_version():
    try:
        with open("/storage/.kodi/userdata/smycky_version.txt", "r") as f:
            return f.read().strip()
    except:
        return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení reboot_log.txt: {e}", xbmc.LOGERROR)
        return None
        
# Načíst nebo vytvořit DeviceID
def get_device_id():
    if xbmcvfs.exists(DEVICE_ID_FILE):
        with xbmcvfs.File(DEVICE_ID_FILE) as f:
            return f.read().strip()
    else:
        new_id = str(uuid.uuid4())
        with xbmcvfs.File(DEVICE_ID_FILE, 'w') as f:
            f.write(new_id)
        xbmc.log(f"[Dohled] Generuji nové DeviceID: {new_id}", xbmc.LOGINFO)
        return new_id

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'}, method="POST")
        with urllib.request.urlopen(req) as response:
            response_data = json.loads(response.read().decode())
            xbmc.log(f"[Dohled] Odesláno na API, status: {response.status}, odpověď: {response_data}", xbmc.LOGINFO)
            return response_data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)
        return None

def check_for_commands(device_id):
    """Zkontroluje a vrátí příkaz z API."""
    try:
        url = f"https://apidohled.noreason.eu/api/commands/{device_id}"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data.get("command"), data.get("params")
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole příkazů: {e}", xbmc.LOGERROR)
        return None, None


def send_download_progress(filename, percent, downloaded_mb, total_mb, status="downloading"):
    """Odešle průběh stahování přes WebSocket."""
    global ws_connected, ws_app
    if ws_connected and ws_app:
        try:
            ws_app.send(json.dumps({
                "type": "download_progress",
                "payload": {
                    "filename": filename,
                    "percent": percent,
                    "downloaded_mb": round(downloaded_mb, 1),
                    "total_mb": round(total_mb, 1),
                    "status": status  # "starting", "downloading", "completed", "error"
                }
            }))
        except Exception as e:
            xbmc.log(f"[Dohled] Chyba při odesílání progress: {e}", xbmc.LOGWARNING)


def download_and_play_file(filename):
    """Stáhne soubor z FTP a pak ho přehraje."""
    from ftplib import FTP

    try:
        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        local_path = f"/storage/videos/{filename}"
        temp_path = f"/storage/videos/.downloading_{filename}"

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Připojuji k FTP...", xbmcgui.NOTIFICATION_INFO, 2000)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)

        # Kontrola místa před stahováním
        ensure_space_for_download(int(file_size_mb) + 50)  # +50 MB rezerva

        xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {file_size_mb:.0f} MB...", xbmcgui.NOTIFICATION_INFO, 5000)

        # Odeslat počáteční progress
        send_download_progress(filename, 0, 0, file_size_mb, "starting")

        downloaded = 0
        last_percent = 0
        last_progress_time = time.time()

        with open(temp_path, 'wb') as f:
            def callback(data):
                nonlocal downloaded, last_percent, last_progress_time
                f.write(data)
                downloaded += len(data)
                percent = int(downloaded * 100 / file_size)
                current_time = time.time()

                # Odeslat progress každých 500ms nebo při změně o 5%
                if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                    downloaded_mb = downloaded / (1024 * 1024)
                    send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                    last_progress_time = current_time

                if percent >= last_percent + 10:
                    last_percent = percent
                    xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

            ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

        ftp.quit()

        # 4. Přesunout dokončený soubor (starý soubor se nemaže - zůstane na disku)
        if os.path.exists(local_path):
            # Soubor už existuje - přepsat
            os.remove(local_path)
        os.rename(temp_path, local_path)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Staženo: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)

        # Odeslat dokončení
        send_download_progress(filename, 100, file_size_mb, file_size_mb, "completed")

        # 5. Přehrát soubor
        time.sleep(1)
        player = xbmc.Player()
        player.play(local_path)
        time.sleep(1)
        xbmc.executebuiltin("PlayerControl(RepeatOne)")
        xbmc.log(f"[Dohled] Download: Přehrávám {filename}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor
        temp_path = f"/storage/videos/.downloading_{filename}"
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def download_only_file(filename):
    """Stáhne soubor z FTP bez přehrání."""
    from ftplib import FTP

    try:
        # 1. Načíst konfiguraci pro získání locality
        config = load_config()
        locality = config.get("locality")

        if not locality:
            xbmc.log("[Dohled] Download: Locality nenalezena v konfiguraci", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Locality nenalezena", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        # 2. Získat FTP konfiguraci z API
        api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
        with urllib.request.urlopen(api_url, timeout=10) as response:
            ftp_config = json.loads(response.read().decode())

        ftp_host = ftp_config.get("ftp_host")
        ftp_user = ftp_config.get("ftp_user")
        ftp_pass = ftp_config.get("ftp_pass")
        ftp_path = ftp_config.get("ftp_path")

        if not all([ftp_host, ftp_user, ftp_pass, ftp_path]):
            xbmc.log("[Dohled] Download: Neúplná FTP konfigurace", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Dohled", "Chyba: Neúplná FTP konfigurace", xbmcgui.NOTIFICATION_ERROR, 3000)
            send_download_progress(filename, 0, 0, 0, "error")
            return

        local_path = f"/storage/videos/{filename}"
        temp_path = f"/storage/videos/.downloading_{filename}"

        # 3. Připojit k FTP a stáhnout
        xbmc.log(f"[Dohled] Download: Připojuji k FTP {ftp_host}...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Připojuji k FTP...", xbmcgui.NOTIFICATION_INFO, 2000)

        ftp = FTP()
        ftp.connect(ftp_host, timeout=30)
        ftp.login(ftp_user, ftp_pass)
        ftp.voidcmd("TYPE I")

        remote_path = ftp_path + filename
        file_size = ftp.size(remote_path)
        file_size_mb = file_size / (1024 * 1024)

        # Kontrola místa před stahováním
        ensure_space_for_download(int(file_size_mb) + 50)

        xbmc.log(f"[Dohled] Download: Stahuji {filename} ({file_size_mb:.1f} MB)", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Stahuji {file_size_mb:.0f} MB...", xbmcgui.NOTIFICATION_INFO, 5000)

        # Odeslat počáteční progress
        send_download_progress(filename, 0, 0, file_size_mb, "starting")

        downloaded = 0
        last_percent = 0
        last_progress_time = time.time()

        with open(temp_path, 'wb') as f:
            def callback(data):
                nonlocal downloaded, last_percent, last_progress_time
                f.write(data)
                downloaded += len(data)
                percent = int(downloaded * 100 / file_size)
                current_time = time.time()

                # Odeslat progress každých 500ms nebo při změně o 5%
                if current_time - last_progress_time >= 0.5 or percent >= last_percent + 5:
                    downloaded_mb = downloaded / (1024 * 1024)
                    send_download_progress(filename, percent, downloaded_mb, file_size_mb, "downloading")
                    last_progress_time = current_time

                if percent >= last_percent + 10:
                    last_percent = percent
                    xbmc.log(f"[Dohled] Download: {percent}% ({downloaded / (1024*1024):.1f} MB)", xbmc.LOGINFO)

            ftp.retrbinary(f"RETR {remote_path}", callback, blocksize=262144)

        ftp.quit()

        # 4. Přesunout dokončený soubor
        if os.path.exists(local_path):
            os.remove(local_path)
        os.rename(temp_path, local_path)

        # Vyčistit staré soubory pokud je jich moc
        cleanup_old_videos()

        xbmc.log(f"[Dohled] Download: Soubor úspěšně stažen: {local_path}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Dohled", f"Staženo: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)

        # Odeslat dokončení
        send_download_progress(filename, 100, file_size_mb, file_size_mb, "completed")

        # Nepřehrávat - pouze staženo

    except Exception as e:
        xbmc.log(f"[Dohled] Download: Chyba - {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Dohled", f"Chyba stahování: {str(e)[:30]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        send_download_progress(filename, 0, 0, 0, "error")
        # Vyčistit temp soubor
        temp_path = f"/storage/videos/.downloading_{filename}"
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def get_current_playlist():
    """Získá seznam souborů v aktuálním playlistu."""
    try:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        items = []
        for i in range(playlist.size()):
            item = playlist[i]
            path = item.getPath() if hasattr(item, 'getPath') else str(item)
            filename = path.split('/')[-1] if path else f"Item {i}"
            items.append(filename)
        return items
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení playlistu: {e}", xbmc.LOGERROR)
        return []


def get_playlist_position():
    """Vrátí aktuální pozici v playlistu."""
    try:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        return playlist.getposition()
    except:
        return -1


def execute_command(command, params=None):
    """Vykoná přijatý příkaz."""
    xbmc.log(f"[Dohled] Vykonávám příkaz: {command}, params: {params}", xbmc.LOGINFO)

    try:
        if command == "restart":
            xbmc.log("[Dohled] Příkaz: RESTART zařízení", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Přijat příkaz k restartu...", xbmcgui.NOTIFICATION_WARNING, 3000)
            time.sleep(2)
            os.system("reboot")

        elif command == "update_video":
            xbmc.log("[Dohled] Příkaz: Vynucená aktualizace videa", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Vynucená aktualizace videa - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            os.system("reboot")  # Restart způsobí stažení nového videa

        elif command == "play":
            xbmc.log("[Dohled] Příkaz: Spustit přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            if player.isPlaying():
                # Pokud je pausnuto, spustit
                if xbmc.getCondVisibility("Player.Paused"):
                    player.pause()  # Toggle pause off
                    xbmc.log("[Dohled] Přehrávání obnoveno z pauzy", xbmc.LOGINFO)
            else:
                # Není nic přehráváno - zkusit poslední soubor
                xbmc.executebuiltin("PlayerControl(Play)")
                xbmc.log("[Dohled] Pokus o spuštění přehrávání", xbmc.LOGINFO)

        elif command == "stop":
            xbmc.log("[Dohled] Příkaz: Zastavit přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            if player.isPlaying():
                player.stop()
                xbmc.log("[Dohled] Přehrávání zastaveno", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Přehrávání zastaveno", xbmcgui.NOTIFICATION_INFO, 2000)

        elif command == "pause":
            xbmc.log("[Dohled] Příkaz: Pozastavit/pokračovat přehrávání", xbmc.LOGINFO)
            player = xbmc.Player()
            if player.isPlaying():
                player.pause()  # Toggle pause
                is_paused = xbmc.getCondVisibility("Player.Paused")
                status = "pozastaveno" if is_paused else "pokračuje"
                xbmc.log(f"[Dohled] Přehrávání {status}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("Dohled", f"Přehrávání {status}", xbmcgui.NOTIFICATION_INFO, 2000)
            else:
                xbmc.log("[Dohled] Nic se nepřehrává, nelze pozastavit", xbmc.LOGWARNING)

        elif command == "play_file":
            # Přehrát konkrétní lokální soubor
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = f"/storage/videos/{filename}"
                if os.path.exists(local_path):
                    xbmc.log(f"[Dohled] Příkaz: Přehrát soubor {local_path}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification("Dohled", f"Přehrávám: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)
                    player = xbmc.Player()
                    player.play(local_path)
                    time.sleep(1)
                    xbmc.executebuiltin("PlayerControl(RepeatOne)")
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz play_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_and_play":
            # Stáhnout soubor z FTP a pak přehrát
            if params and params.get("filename"):
                filename = params.get("filename")
                xbmc.log(f"[Dohled] Příkaz: Stáhnout a přehrát {filename}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("Dohled", f"Stahuji: {filename}...", xbmcgui.NOTIFICATION_INFO, 5000)
                # Spustit stahování v samostatném vlákně
                threading.Thread(target=download_and_play_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_and_play bez parametru filename", xbmc.LOGWARNING)

        elif command == "download_only":
            # Pouze stáhnout soubor z FTP bez přehrání
            if params and params.get("filename"):
                filename = params.get("filename")
                xbmc.log(f"[Dohled] Příkaz: Pouze stáhnout {filename}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("Dohled", f"Stahuji: {filename}...", xbmcgui.NOTIFICATION_INFO, 5000)
                # Spustit stahování v samostatném vlákně (bez přehrání)
                threading.Thread(target=download_only_file, args=(filename,), daemon=True).start()
            else:
                xbmc.log("[Dohled] Příkaz download_only bez parametru filename", xbmc.LOGWARNING)

        elif command == "delete_file":
            # Smazat lokální soubor
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = f"/storage/videos/{filename}"

                # Kontrola že soubor není právě přehráván
                player = xbmc.Player()
                if player.isPlayingVideo():
                    playing_file = player.getPlayingFile()
                    if playing_file and playing_file.endswith(filename):
                        xbmc.log(f"[Dohled] Nelze smazat přehrávaný soubor: {filename}", xbmc.LOGWARNING)
                        xbmcgui.Dialog().notification("Dohled", f"Nelze smazat - soubor se přehrává", xbmcgui.NOTIFICATION_ERROR, 3000)
                        return

                if os.path.exists(local_path):
                    try:
                        os.remove(local_path)
                        xbmc.log(f"[Dohled] Soubor smazán: {local_path}", xbmc.LOGINFO)
                        xbmcgui.Dialog().notification("Dohled", f"Smazáno: {filename}", xbmcgui.NOTIFICATION_INFO, 2000)
                    except Exception as e:
                        xbmc.log(f"[Dohled] Chyba při mazání souboru: {e}", xbmc.LOGERROR)
                        xbmcgui.Dialog().notification("Dohled", f"Chyba mazání: {str(e)[:20]}", xbmcgui.NOTIFICATION_ERROR, 3000)
                else:
                    xbmc.log(f"[Dohled] Soubor neexistuje: {local_path}", xbmc.LOGWARNING)
                    xbmcgui.Dialog().notification("Dohled", f"Soubor neexistuje", xbmcgui.NOTIFICATION_WARNING, 2000)
            else:
                xbmc.log("[Dohled] Příkaz delete_file bez parametru filename", xbmc.LOGWARNING)

        elif command == "notification":
            title = params.get("title", "Dohled") if params else "Dohled"
            message = params.get("message", "") if params else ""
            duration = params.get("duration", 5000) if params else 5000
            xbmc.log(f"[Dohled] Příkaz: Notifikace - {title}: {message}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, duration)

        elif command == "update_addons":
            xbmc.log("[Dohled] Příkaz: Aktualizace doplňků", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Aktualizuji doplňky...", xbmcgui.NOTIFICATION_INFO, 3000)
            force_update_addons()

        elif command == "refresh_config":
            xbmc.log("[Dohled] Příkaz: Obnovení konfigurace", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", "Obnovuji konfiguraci - restart...", xbmcgui.NOTIFICATION_INFO, 3000)
            time.sleep(2)
            os.system("reboot")

        elif command == "shell":
            if params and params.get("cmd"):
                cmd = params.get("cmd")
                xbmc.log(f"[Dohled] Příkaz: Shell - {cmd}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("Dohled", f"Spouštím: {cmd[:30]}...", xbmcgui.NOTIFICATION_INFO, 2000)
                result = os.system(cmd)
                xbmc.log(f"[Dohled] Shell příkaz dokončen s kódem: {result}", xbmc.LOGINFO)
            else:
                xbmc.log("[Dohled] Shell příkaz bez parametru cmd", xbmc.LOGWARNING)

        elif command == "play_playlist":
            # Přehrát více souborů za sebou (playlist)
            if params and params.get("files"):
                files = params.get("files")  # Seznam názvů souborů
                xbmc.log(f"[Dohled] Příkaz: Přehrát playlist s {len(files)} soubory", xbmc.LOGINFO)

                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()

                added = 0
                for filename in files:
                    local_path = f"/storage/videos/{filename}"
                    if os.path.exists(local_path):
                        playlist.add(local_path)
                        added += 1
                    else:
                        xbmc.log(f"[Dohled] Playlist: Soubor neexistuje: {local_path}", xbmc.LOGWARNING)

                if added > 0:
                    player = xbmc.Player()
                    player.play(playlist)
                    time.sleep(1)
                    xbmc.executebuiltin("PlayerControl(RepeatAll)")
                    xbmcgui.Dialog().notification("Dohled", f"Playlist: {added} souborů", xbmcgui.NOTIFICATION_INFO, 3000)
                else:
                    xbmcgui.Dialog().notification("Dohled", "Žádné soubory nenalezeny", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz play_playlist bez parametru files", xbmc.LOGWARNING)

        elif command == "add_to_playlist":
            # Přidat soubor do aktuálního playlistu
            if params and params.get("filename"):
                filename = params.get("filename")
                local_path = f"/storage/videos/{filename}"
                if os.path.exists(local_path):
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    playlist.add(local_path)
                    xbmc.log(f"[Dohled] Přidáno do playlistu: {filename}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification("Dohled", f"Přidáno: {filename}", xbmcgui.NOTIFICATION_INFO, 2000)
                    # Pokud nic nehraje, spustit
                    player = xbmc.Player()
                    if not player.isPlaying():
                        player.play(playlist)
                        time.sleep(1)
                        xbmc.executebuiltin("PlayerControl(RepeatAll)")
                else:
                    xbmcgui.Dialog().notification("Dohled", f"Soubor nenalezen: {filename}", xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                xbmc.log("[Dohled] Příkaz add_to_playlist bez parametru filename", xbmc.LOGWARNING)

        elif command == "clear_playlist":
            # Vyčistit playlist
            xbmc.log("[Dohled] Příkaz: Vyčistit playlist", xbmc.LOGINFO)
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            xbmcgui.Dialog().notification("Dohled", "Playlist vyčištěn", xbmcgui.NOTIFICATION_INFO, 2000)

        else:
            xbmc.log(f"[Dohled] Neznámý příkaz: {command}", xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při vykonávání příkazu {command}: {e}", xbmc.LOGERROR)


# Interval pro HTTP polling příkazů (fallback když není WebSocket)
# Zvýšeno zpět na 5s protože je to jen fallback
COMMAND_POLL_INTERVAL = 5


def command_polling_loop(device_id):
    """HTTP fallback pro příkazy - běží pouze když není WebSocket."""
    global stop_monitoring, ws_connected

    xbmc.log(f"[Dohled] Spuštěn HTTP fallback polling příkazů", xbmc.LOGINFO)

    while not stop_monitoring:
        # Pouze pollovat pokud není WebSocket připojen
        if not ws_connected:
            try:
                command, params = check_for_commands(device_id)
                if command:
                    # Parsovat params pokud je to JSON string
                    if params and isinstance(params, str):
                        try:
                            params = json.loads(params)
                        except:
                            pass
                    execute_command(command, params)

            except Exception as e:
                xbmc.log(f"[Dohled] Chyba v HTTP polling: {e}", xbmc.LOGERROR)

        # Čekat COMMAND_POLL_INTERVAL sekund (s možností přerušení)
        for _ in range(COMMAND_POLL_INTERVAL):
            if stop_monitoring:
                break
            time.sleep(1)

    xbmc.log("[Dohled] HTTP polling příkazů ukončen", xbmc.LOGINFO)

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None

# NOVÉ FUNKCE PRO LEPŠÍ DETEKCI VIDEO SOUBORŮ

# Video přípony pro filtrování
VIDEO_EXTENSIONS = ('.mp4', '.avi', '.mkv', '.mov', '.wmv', '.webm', '.m4v')

def get_local_video_files():
    """Vrátí seznam lokálních video souborů v /storage/videos/."""
    try:
        video_dir = "/storage/videos/"
        if not os.path.exists(video_dir):
            return []

        files = []
        for filename in os.listdir(video_dir):
            if filename.lower().endswith(VIDEO_EXTENSIONS):
                filepath = os.path.join(video_dir, filename)
                if os.path.isfile(filepath):
                    try:
                        stat = os.stat(filepath)
                        files.append({
                            "name": filename,
                            "size": stat.st_size,
                            "size_mb": round(stat.st_size / 1024 / 1024, 2),
                            "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime))
                        })
                    except:
                        files.append({"name": filename, "size": 0, "size_mb": 0, "modified": None})

        # Seřadit podle jména
        files.sort(key=lambda x: x["name"].lower())
        xbmc.log(f"[Dohled] Nalezeno {len(files)} lokálních video souborů", xbmc.LOGINFO)
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání lokálních souborů: {e}", xbmc.LOGERROR)
        return []


def get_storage_info():
    """Vrátí informace o úložišti (volné místo, celková kapacita)."""
    try:
        stat = os.statvfs(VIDEO_DIR)
        free_bytes = stat.f_bavail * stat.f_frsize
        total_bytes = stat.f_blocks * stat.f_frsize
        used_bytes = total_bytes - free_bytes

        return {
            "free_mb": round(free_bytes / 1024 / 1024, 2),
            "total_mb": round(total_bytes / 1024 / 1024, 2),
            "used_mb": round(used_bytes / 1024 / 1024, 2),
            "free_percent": round((free_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 0
        }
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při zjišťování místa: {e}", xbmc.LOGERROR)
        return {"free_mb": 0, "total_mb": 0, "used_mb": 0, "free_percent": 0}


def get_video_files_sorted_by_age():
    """Vrátí seznam video souborů seřazený od nejstaršího."""
    try:
        if not os.path.exists(VIDEO_DIR):
            return []

        files = []
        for filename in os.listdir(VIDEO_DIR):
            if filename.lower().endswith(VIDEO_EXTENSIONS) and not filename.startswith('.'):
                filepath = os.path.join(VIDEO_DIR, filename)
                if os.path.isfile(filepath):
                    try:
                        mtime = os.path.getmtime(filepath)
                        size = os.path.getsize(filepath)
                        files.append({
                            "name": filename,
                            "path": filepath,
                            "mtime": mtime,
                            "size": size,
                            "size_mb": round(size / 1024 / 1024, 2)
                        })
                    except:
                        pass

        # Seřadit od nejstaršího
        files.sort(key=lambda x: x["mtime"])
        return files

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání seznamu souborů: {e}", xbmc.LOGERROR)
        return []


def cleanup_old_videos(needed_space_mb=0, keep_current=True):
    """
    Vyčistí staré video soubory pokud je málo místa nebo je jich moc.

    Args:
        needed_space_mb: Kolik MB potřebujeme uvolnit (0 = jen kontrola limitu)
        keep_current: Ponechat aktuálně přehrávaný soubor

    Returns:
        Počet smazaných souborů
    """
    try:
        files = get_video_files_sorted_by_age()
        if not files:
            return 0

        # Zjistit aktuálně přehrávaný soubor
        current_file = None
        if keep_current:
            player = xbmc.Player()
            if player.isPlayingVideo():
                playing_path = player.getPlayingFile()
                current_file = os.path.basename(playing_path) if playing_path else None

        storage = get_storage_info()
        deleted_count = 0
        freed_space_mb = 0

        # 1. Kontrola počtu souborů
        if MAX_VIDEO_FILES > 0 and len(files) > MAX_VIDEO_FILES:
            files_to_delete = len(files) - MAX_VIDEO_FILES
            xbmc.log(f"[Dohled] Storage: Překročen limit souborů ({len(files)}/{MAX_VIDEO_FILES}), mažu {files_to_delete} nejstarších", xbmc.LOGINFO)

            for f in files[:files_to_delete]:
                if f["name"] == current_file:
                    xbmc.log(f"[Dohled] Storage: Přeskakuji aktuálně přehrávaný soubor: {f['name']}", xbmc.LOGINFO)
                    continue
                try:
                    os.remove(f["path"])
                    deleted_count += 1
                    freed_space_mb += f["size_mb"]
                    xbmc.log(f"[Dohled] Storage: Smazán starý soubor: {f['name']} ({f['size_mb']} MB)", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Storage: Nelze smazat {f['name']}: {e}", xbmc.LOGERROR)

            # Obnovit seznam po smazání
            files = get_video_files_sorted_by_age()

        # 2. Kontrola volného místa
        total_needed = needed_space_mb + MIN_FREE_SPACE_MB
        if storage["free_mb"] < total_needed:
            space_to_free = total_needed - storage["free_mb"]
            xbmc.log(f"[Dohled] Storage: Málo místa ({storage['free_mb']} MB volných), potřeba uvolnit {space_to_free} MB", xbmc.LOGWARNING)

            for f in files:
                if freed_space_mb >= space_to_free:
                    break
                if f["name"] == current_file:
                    xbmc.log(f"[Dohled] Storage: Přeskakuji aktuálně přehrávaný soubor: {f['name']}", xbmc.LOGINFO)
                    continue
                try:
                    os.remove(f["path"])
                    deleted_count += 1
                    freed_space_mb += f["size_mb"]
                    xbmc.log(f"[Dohled] Storage: Smazán pro uvolnění místa: {f['name']} ({f['size_mb']} MB)", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Storage: Nelze smazat {f['name']}: {e}", xbmc.LOGERROR)

        if deleted_count > 0:
            xbmc.log(f"[Dohled] Storage: Celkem smazáno {deleted_count} souborů, uvolněno {freed_space_mb} MB", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Dohled", f"Vyčištěno {deleted_count} starých souborů", xbmcgui.NOTIFICATION_INFO, 3000)

        return deleted_count

    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čištění souborů: {e}", xbmc.LOGERROR)
        return 0


def ensure_space_for_download(needed_mb):
    """Zajistí dostatek místa pro stažení nového souboru."""
    storage = get_storage_info()
    if storage["free_mb"] < needed_mb + MIN_FREE_SPACE_MB:
        xbmc.log(f"[Dohled] Storage: Před stahováním potřeba uvolnit místo pro {needed_mb} MB", xbmc.LOGINFO)
        cleanup_old_videos(needed_space_mb=needed_mb)
        return True
    return False


def find_current_video_file():
    """Najde aktuálně přehrávaný nebo nejnovější video soubor."""
    try:
        # 1. Zkusit najít aktuálně přehrávaný soubor
        player = xbmc.Player()
        if player.isPlayingVideo():
            playing_file = player.getPlayingFile()
            if playing_file and playing_file.startswith("/storage/videos/") and playing_file.endswith(".mp4"):
                xbmc.log(f"[Dohled] Nalezen přehrávaný soubor: {playing_file}", xbmc.LOGINFO)
                return playing_file
        
        # 2. Zkusit načíst z last_filename.txt (pokud existuje)
        if os.path.exists(LAST_FILENAME_FILE):
            try:
                with open(LAST_FILENAME_FILE, 'r', encoding='utf-8') as f:
                    last_filename = f.read().strip()
                    if last_filename:
                        potential_path = f"/storage/videos/{last_filename}"
                        if os.path.exists(potential_path):
                            xbmc.log(f"[Dohled] Nalezen soubor z last_filename: {potential_path}", xbmc.LOGINFO)
                            return potential_path
            except Exception as e:
                xbmc.log(f"[Dohled] Chyba při čtení last_filename.txt: {e}", xbmc.LOGERROR)
        
        # 3. Najít nejnovější MP4 soubor v /storage/videos/
        video_dir = "/storage/videos/"
        if os.path.exists(video_dir):
            video_files = []
            for filename in os.listdir(video_dir):
                if filename.endswith('.mp4'):
                    filepath = os.path.join(video_dir, filename)
                    if os.path.exists(filepath):
                        mtime = os.path.getmtime(filepath)
                        video_files.append((filepath, mtime))
            
            if video_files:
                # Seřadit podle času úpravy (nejnovější první)
                video_files.sort(key=lambda x: x[1], reverse=True)
                xbmc.log(f"[Dohled] Nalezen nejnovější soubor: {video_files[0][0]}", xbmc.LOGINFO)
                return video_files[0][0]
        
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return None
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při hledání aktuálního video souboru: {e}", xbmc.LOGERROR)
        return None

def get_video_file_info(expected_filename, expected_file_size=None):
    """Získá informace o video souboru a vyhodnotí potřebu aktualizace."""
    try:
        # 1. Zkusit nejdříve očekávaný soubor z API
        if expected_filename:
            expected_path = f"/storage/videos/{expected_filename}"
            if os.path.exists(expected_path):
                stat = os.stat(expected_path)
                file_size = stat.st_size
                
                # Vyhodnotit, zda je soubor aktuální
                size_matches = (expected_file_size is None or file_size == expected_file_size)
                
                xbmc.log(f"[Dohled] Očekávaný soubor existuje: {expected_filename}, velikost OK: {size_matches}", xbmc.LOGINFO)
                
                return {
                    'path': expected_path,
                    'filename': expected_filename,
                    'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                    'file_size': file_size,
                    'is_expected': True,
                    'update_needed': not size_matches  # Aktualizace potřeba, pokud se velikost neshoduje
                }
        
        # 2. Pokud očekávaný soubor neexistuje, najít aktuální
        current_video = find_current_video_file()
        if current_video and os.path.exists(current_video):
            stat = os.stat(current_video)
            filename = os.path.basename(current_video)
            
            xbmc.log(f"[Dohled] Očekávaný soubor ({expected_filename}) neexistuje, používám aktuální: {filename}", xbmc.LOGWARNING)
            
            return {
                'path': current_video,
                'filename': filename,
                'last_modified': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                'file_size': stat.st_size,
                'is_expected': False,
                'update_needed': True  # Pokud nemáme očekávaný soubor, aktualizace je potřeba
            }
        
        # 3. Žádný soubor nenalezen
        xbmc.log("[Dohled] Žádný video soubor nenalezen", xbmc.LOGWARNING)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True  # Pokud nemáme žádný soubor, aktualizace je potřeba
        }
        
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při získávání info o video souboru: {e}", xbmc.LOGERROR)
        return {
            'path': None,
            'filename': None,
            'last_modified': None,
            'file_size': None,
            'is_expected': False,
            'update_needed': True
        }

def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    names = fetch_device_setup_name()
    if names:
        name_options = sorted([n["name"] for n in names], key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    localities = fetch_localities()
    if localities:
        locality_pairs = sorted(
            [(loc['name'], loc['code']) for loc in localities],
            key=lambda x: x[0].lower()
        )
        locality_options = [f"{name} ({code})" for name, code in locality_pairs]
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = locality_pairs[selected_locality][1]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    with open("/storage/.cache/hostname", "w") as f:
        f.write(name + "\n")

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    os.system("reboot")

def monitor_loop():
    global ws_connected, ws_app
    config = load_config()
    device_id = get_device_id()

    # Počkat na navázání WebSocket spojení (max 10 sekund)
    # Tím se vyhneme zbytečnému HTTP fallbacku při startu
    ws_wait_timeout = 15
    waited = 0
    while not ws_connected and waited < ws_wait_timeout and not stop_monitoring:
        time.sleep(1)
        waited += 1
        # Logovat průběh čekání každých 5 sekund
        if waited % 5 == 0 and not ws_connected:
            xbmc.log(f"[Dohled] Čekám na WebSocket... {waited}s/{ws_wait_timeout}s", xbmc.LOGINFO)

    # Dát WebSocketu ještě chvíli na dokončení připojení
    if not ws_connected:
        time.sleep(1)

    if ws_connected:
        xbmc.log(f"[Dohled] WebSocket připojen po {waited}s, spouštím monitoring", xbmc.LOGINFO)
    else:
        xbmc.log(f"[Dohled] WebSocket timeout ({ws_wait_timeout}s), spouštím monitoring s HTTP fallback", xbmc.LOGWARNING)

    while not stop_monitoring:
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            boot_time = get_boot_time()

            # Načíst očekávaný název souboru a velikost z API
            ftp_config = fetch_ftp_config(locality)
            expected_filename = ftp_config.get("file_name") if ftp_config else None
            expected_file_size = ftp_config.get("expected_file_size") if ftp_config else None

            # NOVÁ LOGIKA: Získat info o video souboru včetně update_needed
            video_info = get_video_file_info(expected_filename, expected_file_size)

            last_modified = video_info['last_modified']
            file_size = video_info['file_size']
            current_filename = video_info['filename']
            update_needed = video_info['update_needed']

            # Logování pro debug
            if update_needed:
                if video_info['is_expected']:
                    reason = "velikost se neshoduje"
                elif current_filename:
                    reason = f"název se liší (aktuální: {current_filename}, očekávaný: {expected_filename})"
                else:
                    reason = "žádný soubor nenalezen"
                xbmc.log(f"[Dohled] Aktualizace potřeba - důvod: {reason}", xbmc.LOGWARNING)
            else:
                xbmc.log(f"[Dohled] Soubor je aktuální: {current_filename}", xbmc.LOGINFO)

            next_reboot = get_next_reboot()

            player = xbmc.Player()
            is_playing_actual = player.isPlayingVideo()
            playing_file = player.getPlayingFile() if is_playing_actual else None

            is_paused = xbmc.getCondVisibility("Player.Paused")

            # Debouncing pro playing=false (stejná logika jako v state_update_loop)
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            global last_playing_true_time
            current_time = time.time()
            PLAYING_FALSE_TOLERANCE = 5

            if is_playing_actual:
                last_playing_true_time = current_time
                is_playing = True
            else:
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    is_playing = True  # Stále v toleranci
                else:
                    is_playing = False

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] isPlaying: {is_playing}, Paused: {is_paused}, File: {playing_file}, WS: {ws_connected}", xbmc.LOGINFO)

            # Získat seznam lokálních video souborů
            local_files = get_local_video_files()

            # Získat info o playlistu
            playlist_items = get_current_playlist()
            playlist_position = get_playlist_position()

            # Získat info o úložišti
            storage_info = get_storage_info()

            payload = {
                "device_id": device_id,
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": boot_time,
                "next_reboot": next_reboot,
                "locality": locality,
                "playing": is_playing,
                "playing_file": playing_file,
                "paused": is_paused,
                "addon_version": ADDON_VERSION,
                "smycky_version": get_smycky_version(),
                "current_filename": current_filename,
                "expected_filename": expected_filename,
                "update_needed": update_needed,
                "local_files": local_files,
                "ws_connected": ws_connected,
                "playlist": playlist_items,
                "playlist_position": playlist_position,
                "storage": storage_info
            }

            # Zkusit odeslat přes WebSocket, jinak HTTP fallback
            sent_via_ws = False
            if ws_connected and ws_app:
                try:
                    ws_app.send(json.dumps({
                        "type": "monitoring",
                        "payload": payload
                    }))
                    sent_via_ws = True
                    xbmc.log("[Dohled] Monitoring data odeslána přes WebSocket", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání přes WS, použiji HTTP: {e}", xbmc.LOGWARNING)

            if not sent_via_ws:
                # HTTP fallback
                url = "https://apidohled.noreason.eu/api/monitoring"
                response = send_data(payload, url)

                # Zpracovat odpověď serveru
                if response and response.get("status") == "saved":
                    server_update_needed = response.get("update_needed")
                    if server_update_needed != update_needed:
                        xbmc.log(f"[Dohled] Server přepsal update_needed: {update_needed} -> {server_update_needed}", xbmc.LOGINFO)

                    # Piggyback příkazy - server může poslat příkaz v odpovědi na monitoring
                    piggyback_command = response.get("command")
                    if piggyback_command:
                        piggyback_params = response.get("command_params")
                        xbmc.log(f"[Dohled] Piggyback příkaz z monitoring odpovědi: {piggyback_command}", xbmc.LOGINFO)
                        execute_command(piggyback_command, piggyback_params)

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        # Monitoring interval: 30 sekund
        for _ in range(WS_MONITORING_INTERVAL):
            if stop_monitoring:
                break
            time.sleep(1)


def state_update_loop():
    """
    Rychlá smyčka pro aktualizaci stavu přehrávání.
    - Kontroluje stav každé WS_STATE_CHECK_INTERVAL sekund (rychlá detekce změn)
    - Odesílá pouze při ZMĚNĚ stavu nebo po WS_STATE_HEARTBEAT_INTERVAL sekundách (heartbeat)
    - Používá debouncing pro playing=false (5 sekund tolerance pro přechody smyčky)
    """
    global last_playing_state, last_paused_state, last_filename, ws_connected, ws_app, last_playing_true_time

    # Tolerance pro přechod mezi videi ve smyčce (sekundy)
    PLAYING_FALSE_TOLERANCE = 5

    # Čas posledního odeslání (pro heartbeat)
    last_send_time = 0

    # Inicializace last_filename z disku pokud je None (při startu addonu)
    if last_filename is None:
        try:
            video_path = find_current_video_file()
            if video_path:
                last_filename = os.path.basename(video_path)
                xbmc.log(f"[Dohled] Inicializace last_filename z disku: {last_filename}", xbmc.LOGINFO)
        except:
            pass

    xbmc.log(f"[Dohled] State update smyčka: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)

    while not stop_monitoring:
        try:
            # Pouze když je WS připojen
            if not ws_connected or not ws_app:
                time.sleep(WS_STATE_CHECK_INTERVAL)
                continue

            # Zjistit aktuální stav
            player = xbmc.Player()
            is_playing_actual = player.isPlayingVideo()
            is_paused = xbmc.getCondVisibility("Player.Paused") if is_playing_actual else False
            # Při pauze/stopu zachovat poslední známý soubor (zabraňuje problikávání na dashboardu)
            current_file = player.getPlayingFile().split('/')[-1] if is_playing_actual else last_filename

            # Debouncing pro playing=false
            # Při přechodu mezi videi ve smyčce je krátce playing=false
            # Reportujeme playing=false až po PLAYING_FALSE_TOLERANCE sekundách
            current_time = time.time()

            if is_playing_actual:
                # Aktualizovat čas posledního playing=true
                last_playing_true_time = current_time
                is_playing = True
            else:
                # playing je false - zkontrolovat toleranci
                if last_playing_true_time and (current_time - last_playing_true_time) < PLAYING_FALSE_TOLERANCE:
                    # Stále v toleranci - reportovat jako playing=true (pravděpodobně jen přechod smyčky)
                    is_playing = True
                else:
                    # Mimo toleranci - skutečně není playing
                    is_playing = False

            # Detekce změny stavu
            state_changed = (
                is_playing != last_playing_state or
                is_paused != last_paused_state or
                current_file != last_filename
            )

            # Heartbeat - odeslat i bez změny po určitém čase
            time_since_last_send = current_time - last_send_time
            heartbeat_needed = time_since_last_send >= WS_STATE_HEARTBEAT_INTERVAL

            # Odeslat pouze při změně NEBO heartbeat
            if ws_connected and ws_app and (state_changed or heartbeat_needed):
                try:
                    ws_app.send(json.dumps({
                        "type": "state_update",
                        "payload": {
                            "playing": is_playing,
                            "paused": is_paused,
                            "current_filename": current_file
                        }
                    }))
                    last_send_time = current_time

                    if state_changed:
                        xbmc.log(f"[Dohled] Změna stavu: playing={is_playing}, paused={is_paused}, file={current_file}", xbmc.LOGINFO)

                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při odesílání state update: {e}", xbmc.LOGWARNING)

            # Uložit poslední stav
            last_playing_state = is_playing
            last_paused_state = is_paused
            last_filename = current_file

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v state update loop: {e}", xbmc.LOGERROR)

        # Čekat na další kontrolu
        time.sleep(WS_STATE_CHECK_INTERVAL)


# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}

def main():
    global ws_thread

    xbmc.log("[Dohled] === Spuštění doplňku Dohled ===", xbmc.LOGINFO)

    # PRVNÍ KROK: Synchronizace času (před čímkoli jiným)
    ensure_time_synchronized()

    # Aktualizace doplňků
    force_update_addons()

    # Načtení konfigurace
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    # Získat device_id pro komunikaci
    device_id = get_device_id()
    xbmc.log(f"[Dohled] Device ID: {device_id}", xbmc.LOGINFO)

    # Spuštění WebSocket connection loop (prioritní real-time kanál)
    if WEBSOCKET_AVAILABLE:
        ws_thread = threading.Thread(target=ws_connection_loop, args=(device_id,), daemon=True)
        ws_thread.start()
        xbmc.log("[Dohled] WebSocket connection loop spuštěn", xbmc.LOGINFO)

        # Spuštění rychlé state update smyčky (každé 2s, pouze přes WS)
        threading.Thread(target=state_update_loop, daemon=True).start()
        xbmc.log("[Dohled] Rychlá state update smyčka spuštěna (2s interval)", xbmc.LOGINFO)
    else:
        xbmc.log("[Dohled] WebSocket není dostupný, použije se pouze HTTP", xbmc.LOGWARNING)

    # Spuštění monitorovací smyčky (odesílá data každých 30s přes WS nebo HTTP)
    threading.Thread(target=monitor_loop, daemon=True).start()

    # Spuštění HTTP fallback pollingu příkazů (aktivní pouze když není WS)
    threading.Thread(target=command_polling_loop, args=(device_id,), daemon=True).start()

    xbmc.log("[Dohled] === Inicializace dokončena ===", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] WebSocket: {'ANO' if WEBSOCKET_AVAILABLE else 'NE'}", xbmc.LOGINFO)
    xbmc.log(f"[Dohled] State updates: check={WS_STATE_CHECK_INTERVAL}s, heartbeat={WS_STATE_HEARTBEAT_INTERVAL}s", xbmc.LOGINFO)

if __name__ == "__main__":
    main()