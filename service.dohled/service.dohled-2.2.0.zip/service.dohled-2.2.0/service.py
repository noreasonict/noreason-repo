import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import json
import socket
import threading
import time
import urllib.request
import urllib.parse
import uuid

# Cesta ke konfiguračnímu souboru doplňku
PROFILE_DIR = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
CONFIG_FILE = os.path.join(PROFILE_DIR, 'config.json')
DEVICE_ID_FILE = os.path.join(PROFILE_DIR, 'device_id.txt')
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# Globální příznak pro zastavení smyčky monitoringu
stop_monitoring = False

# Vynucení kontroly aktualizací doplňků
def force_update_addons():
    try:
        xbmc.executebuiltin('UpdateAddonRepos()')  # Aktualizuje repozitáře
        xbmc.executebuiltin('UpdateLocalAddons()') # Aktualizuje nainstalované doplňky
        xbmc.log("[Dohled] Vynucená kontrola aktualizací addonů", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při aktualizaci addonů: {e}", xbmc.LOGERROR)

# Získá čas posledního restartu ze systémového uptime
def get_boot_time():
    try:
        with open("/proc/uptime", "r") as f:
            uptime_seconds = float(f.readline().split()[0])
            boot_timestamp = time.time() - uptime_seconds
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(boot_timestamp))
    except:
        return None

# Načtení verze doplňku pro aktualizaci         
def get_smycky_version():
    try:
        with open("/storage/.kodi/userdata/smycky_version.txt", "r") as f:
            return f.read().strip()
    except:
        return None

# Načtení plánovaného restartu ze souboru
def get_next_reboot():
    reboot_log_path = "/storage/.kodi/userdata/reboot_log.txt"
    if not os.path.exists(reboot_log_path):
        return None
    try:
        with open(reboot_log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for line in lines:
                if line.lower().startswith("naplánovaný restart"):
                    return line.split(":", 1)[-1].strip()
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při čtení reboot_log.txt: {e}", xbmc.LOGERROR)
        return None
        
# Načíst nebo vytvořit DeviceID
def get_device_id():
    if xbmcvfs.exists(DEVICE_ID_FILE):
        with xbmcvfs.File(DEVICE_ID_FILE) as f:
            return f.read().strip()
    else:
        new_id = str(uuid.uuid4())
        with xbmcvfs.File(DEVICE_ID_FILE, 'w') as f:
            f.write(new_id)
        xbmc.log(f"[Dohled] Generuji nové DeviceID: {new_id}", xbmc.LOGINFO)
        return new_id

# Odeslání dat na API ve formátu JSON
def send_data(payload, url):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'}, method="POST")
        with urllib.request.urlopen(req) as response:
            xbmc.log(f"[Dohled] Odesláno na API, status: {response.status}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při odesílání dat: {e}", xbmc.LOGERROR)

def check_for_commands(name, ip_address):
    try:
        encoded_name = urllib.parse.quote(name)
        encoded_ip = urllib.parse.quote(ip_address)
        url = f"https://apidohled.noreason.eu/api/commands/{encoded_name}/{encoded_ip}"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data.get("command")
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při kontrole příkazů: {e}", xbmc.LOGERROR)
        return None

def fetch_device_setup_name():
    try:
        url = "https://apidohled.noreason.eu/api/device-setup-name"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání názvů zařízení: {e}", xbmc.LOGERROR)
        return []

def fetch_localities():
    try:
        url = "https://apidohled.noreason.eu/api/localities"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read())
            return data
    except Exception as e:
        xbmc.log(f"[Dohled] Chyba při načítání lokalit: {e}", xbmc.LOGERROR)
        return []

def prompt_for_config():
    global stop_monitoring
    stop_monitoring = True
    time.sleep(1)

    xbmcvfs.mkdirs(os.path.dirname(CONFIG_FILE))

    names = fetch_device_setup_name()
    if names:
        name_options = sorted([n["name"] for n in names], key=lambda x: x.lower())
        selected_name = xbmcgui.Dialog().select("Vyberte název zařízení", name_options)
        if selected_name != -1:
            name = name_options[selected_name]
        else:
            name = xbmcgui.Dialog().input("Zadejte název zařízení ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání názvu ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        name = xbmcgui.Dialog().input("Zadejte název zařízení", type=xbmcgui.INPUT_ALPHANUM)

    localities = fetch_localities()
    if localities:
        locality_pairs = sorted(
            [(loc['name'], loc['code']) for loc in localities],
            key=lambda x: x[0].lower()
        )
        locality_options = [f"{name} ({code})" for name, code in locality_pairs]
        selected_locality = xbmcgui.Dialog().select("Vyberte lokalitu zařízení", locality_options)
        if selected_locality != -1:
            locality = locality_pairs[selected_locality][1]
        else:
            locality = xbmcgui.Dialog().input("Zadejte lokalitu ručně", type=xbmcgui.INPUT_ALPHANUM)
    else:
        xbmcgui.Dialog().notification("Dohled", "API nedostupné, zadání lokality ručně.", xbmcgui.NOTIFICATION_WARNING, 4000)
        locality = xbmcgui.Dialog().input("Zadejte lokalitu", type=xbmcgui.INPUT_ALPHANUM)

    config = {
        "configured": True,
        "name": name,
        "locality": locality
    }

    with xbmcvfs.File(CONFIG_FILE, 'w') as f:
        f.write(json.dumps(config, indent=4))

    with open("/storage/.cache/hostname", "w") as f:
        f.write(name + "\n")

    xbmcgui.Dialog().notification("Dohled", "Nastavení dokončeno. Restart...", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.sleep(5000)
    os.system("reboot")

def monitor_loop():
    config = load_config()
    device_id = get_device_id()
    while not stop_monitoring:
        try:
            name = config.get("name")
            locality = config.get("locality")

            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip_address = s.getsockname()[0]
            s.close()

            boot_time = get_boot_time()

            # ==== NOVINKA: Načíst file_name z API ====
            def fetch_ftp_config(locality):
                api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
                try:
                    with urllib.request.urlopen(api_url) as response:
                        return json.loads(response.read().decode())
                except Exception as e:
                    xbmc.log(f"[Dohled] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
                    return None

            ftp_config = fetch_ftp_config(locality)
            if ftp_config:
                file_name = ftp_config.get("file_name")
                video_path = f"/storage/videos/{file_name}" if file_name else None
            else:
                file_name = None
                video_path = None

            if video_path and os.path.exists(video_path):
                stat = os.stat(video_path)
                last_modified = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime))
                file_size = stat.st_size
            else:
                last_modified = None
                file_size = None

            # ==== Konec nové části ====

            next_reboot = get_next_reboot()

            player = xbmc.Player()
            is_playing = player.isPlayingVideo()
            playing_file = player.getPlayingFile() if is_playing else None

            is_paused = xbmc.getCondVisibility("Player.Paused")

            ADDON_VERSION = xbmcaddon.Addon().getAddonInfo('version')

            xbmc.log(f"[Dohled] isPlaying: {is_playing}, Paused: {is_paused}, File: {playing_file}", xbmc.LOGINFO)

            payload = {
                "device_id": device_id,
                "name": name,
                "ip_address": ip_address,
                "last_modified": last_modified,
                "file_size": file_size,
                "boot_time": boot_time,
                "next_reboot": next_reboot,
                "locality": locality,
                "playing": is_playing,
                "playing_file": playing_file,
                "paused": is_paused,
                "addon_version": ADDON_VERSION,
                "smycky_version": get_smycky_version()
            }

            url = "https://apidohled.noreason.eu/api/monitoring"
            send_data(payload, url)

            # Kontrola příkazů po odeslání
            cmd = check_for_commands(name, ip_address)
            if cmd == "restart":
                xbmc.log("[Dohled] Přijat příkaz k restartu zařízení.", xbmc.LOGINFO)
                os.system("reboot")

        except Exception as e:
            xbmc.log(f"[Dohled] Chyba v monitoringu: {e}", xbmc.LOGERROR)

        for _ in range(60):
            if stop_monitoring:
                break
            time.sleep(1)

# Načtení konfigurace ze souboru
def load_config():
    try:
        with xbmcvfs.File(CONFIG_FILE) as f:
            return json.loads(f.read())
    except:
        return {"configured": False}

def main():
    force_update_addons()
    config = load_config()
    if not config.get("configured", False):
        prompt_for_config()
    else:
        xbmc.log(f"[Dohled] Zařízení: {config.get('name')}", xbmc.LOGINFO)

    threading.Thread(target=monitor_loop, daemon=True).start()

if __name__ == "__main__":
    main()
