import os
import xbmc
import xbmcgui
import urllib.request
import time
import random
import threading
import shutil
import xbmcaddon
import json
from ftplib import FTP
from datetime import datetime, timedelta

# ======= KONSTANTY =======
REBOOT_TRACK_FILE = "/storage/.kodi/userdata/reboot_log.txt"
CONFIG_FILE = "/storage/.kodi/userdata/addon_data/service.dohled/config.json"
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
TIME_SYNC_FILE = "/storage/.kodi/userdata/time_synced.flag"
VIDEO_DIR = "/storage/videos/"
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# Maximální doba čekání na synchronizaci času (v sekundách)
TIME_SYNC_WAIT_TIMEOUT = 30

# Konfigurace správy disku - optimalizováno pro měnící se názvy souborů
MAX_OLD_FILES = 1           # Kolik starých souborů ponechat jako zálohu (doporučeno 1 pro časté změny)
MIN_FREE_SPACE_MB = 1000    # Minimální volné místo v MB (zvýšeno pro bezpečnost)

# ======= ZÁKLADNÍ FUNKCE =======

def show_notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    """Zobrazí informační okénko v Kodi s výchozí ikonou."""
    xbmcgui.Dialog().notification(title, message, icon, duration)


def wait_for_time_sync():
    """Čeká na synchronizaci času od doplňku Dohled."""
    xbmc.log("[Smycky] Čekám na synchronizaci času od doplňku Dohled...", xbmc.LOGINFO)

    waited = 0
    while waited < TIME_SYNC_WAIT_TIMEOUT:
        if os.path.exists(TIME_SYNC_FILE):
            try:
                with open(TIME_SYNC_FILE, "r") as f:
                    sync_time = f.read().strip()
                xbmc.log(f"[Smycky] Synchronizace času dokončena: {sync_time}", xbmc.LOGINFO)
                return True
            except Exception as e:
                xbmc.log(f"[Smycky] Chyba při čtení sync flagu: {e}", xbmc.LOGERROR)

        time.sleep(1)
        waited += 1

        # Informovat uživatele každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Smycky] Stále čekám na synchronizaci času... ({waited}s)", xbmc.LOGINFO)

    # Timeout - pokračovat i bez synchronizace
    xbmc.log(f"[Smycky] VAROVÁNÍ: Timeout čekání na synchronizaci času ({TIME_SYNC_WAIT_TIMEOUT}s)", xbmc.LOGWARNING)
    show_notification(
        "Varování",
        "Synchronizace času trvá příliš dlouho, pokračuji...",
        xbmcgui.NOTIFICATION_WARNING
    )
    return False


def is_internet_available():
    """Zkontroluje dostupnost internetu pomocí jednoduchého HTTP požadavku."""
    try:
        urllib.request.urlopen("http://google.com", timeout=5)
        return True
    except:
        return False

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None

# ======= VYLEPŠENÉ FUNKCE PRO SPRÁVU DISKU =======

def get_disk_space_mb(path):
    """Vrátí volné místo na disku v MB."""
    try:
        statvfs = os.statvfs(path)
        free_bytes = statvfs.f_frsize * statvfs.f_bavail
        return free_bytes / (1024 * 1024)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při zjišťování místa na disku: {e}", xbmc.LOGERROR)
        return 0

def get_file_size_mb(filepath):
    """Vrátí velikost souboru v MB."""
    try:
        if os.path.exists(filepath):
            return os.path.getsize(filepath) / (1024 * 1024)
        return 0
    except:
        return 0

def cleanup_old_videos_improved(current_filename, keep_count=MAX_OLD_FILES):
    """Vyčistí staré video soubory, ponechá jen zadaný počet nejnovějších.
    Optimalizováno pro měnící se názvy souborů - řadí podle času úpravy."""
    try:
        video_files = []
        current_file_path = os.path.join(VIDEO_DIR, current_filename)
        
        # Najít všechny MP4 soubory
        for filename in os.listdir(VIDEO_DIR):
            if filename.endswith('.mp4'):
                filepath = os.path.join(VIDEO_DIR, filename)
                mtime = os.path.getmtime(filepath)
                size_mb = get_file_size_mb(filepath)
                video_files.append({
                    'filename': filename,
                    'filepath': filepath,
                    'mtime': mtime,
                    'size_mb': size_mb
                })
        
        # Seřadit podle data úpravy (nejnovější první)
        video_files.sort(key=lambda x: x['mtime'], reverse=True)
        
        xbmc.log(f"[Smycky] Nalezeno {len(video_files)} MP4 souborů pro analýzu čištění", xbmc.LOGINFO)
        
        # Logika: ponechat nejnovější soubory + zajistit, že aktuální soubor se nepomaže
        files_to_keep = []
        files_to_delete = []
        current_file_protected = False
        
        for i, file_info in enumerate(video_files):
            # Vždy chránit aktuální soubor (podle názvu)
            if file_info['filename'] == current_filename:
                files_to_keep.append(file_info)
                current_file_protected = True
                xbmc.log(f"[Smycky] Chráním aktuální soubor: {file_info['filename']}", xbmc.LOGINFO)
            # Ponechat keep_count nejnovějších souborů (podle času úpravy)
            elif len([f for f in files_to_keep if f['filename'] != current_filename]) < keep_count:
                files_to_keep.append(file_info)
                xbmc.log(f"[Smycky] Ponechávám jako zálohu: {file_info['filename']} (změněn: {datetime.fromtimestamp(file_info['mtime']).strftime('%Y-%m-%d %H:%M')})", xbmc.LOGINFO)
            else:
                files_to_delete.append(file_info)
        
        # Smazat nadbytečné soubory
        deleted_count = 0
        freed_space_mb = 0
        
        for file_info in files_to_delete:
            try:
                os.remove(file_info['filepath'])
                deleted_count += 1
                freed_space_mb += file_info['size_mb']
                xbmc.log(f"[Smycky] Smazán starý soubor: {file_info['filename']} ({file_info['size_mb']:.1f} MB, ze dne {datetime.fromtimestamp(file_info['mtime']).strftime('%Y-%m-%d')})", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Smycky] Chyba při mazání {file_info['filename']}: {e}", xbmc.LOGERROR)
        
        # Informativní zprávy
        if deleted_count > 0:
            show_notification("Čištění disku", f"Smazáno {deleted_count} starých souborů ({freed_space_mb:.1f} MB)")
            xbmc.log(f"[Smycky] Cleanup dokončen: smazáno {deleted_count} souborů, uvolněno {freed_space_mb:.1f} MB", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Smycky] Cleanup: žádné soubory ke smazání (celkem {len(video_files)} souborů, max {keep_count} záloh)", xbmc.LOGINFO)
        
        # Finální statistiky
        remaining_count = len(video_files) - deleted_count
        xbmc.log(f"[Smycky] Po čištění: {remaining_count} souborů zůstává na disku", xbmc.LOGINFO)
        
        return deleted_count, freed_space_mb
        
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při čištění starých videí: {e}", xbmc.LOGERROR)
        return 0, 0

def analyze_disk_usage():
    """Analyzuje využití disku a vrátí statistiky."""
    try:
        video_files = []
        total_size_mb = 0
        
        for filename in os.listdir(VIDEO_DIR):
            if filename.endswith('.mp4'):
                filepath = os.path.join(VIDEO_DIR, filename)
                size_mb = get_file_size_mb(filepath)
                mtime = os.path.getmtime(filepath)
                video_files.append({
                    'filename': filename,
                    'size_mb': size_mb,
                    'mtime': mtime
                })
                total_size_mb += size_mb
        
        # Seřadit podle velikosti (největší první)
        video_files.sort(key=lambda x: x['size_mb'], reverse=True)
        
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        
        return {
            'video_count': len(video_files),
            'total_size_mb': total_size_mb,
            'free_space_mb': free_space_mb,
            'largest_files': video_files[:3]  # 3 největší soubory
        }
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při analýze disku: {e}", xbmc.LOGERROR)
        return None

def check_disk_space_before_download_improved(remote_size_bytes, local_file):
    """Vylepšená kontrola místa s prediktivní analýzou a multiple cleanup attempts."""
    try:
        # Analýza současného stavu
        stats = analyze_disk_usage()
        if not stats:
            return True  # V případě chyby pokračovat
        
        free_space_mb = stats['free_space_mb']
        needed_space_mb = (remote_size_bytes or 0) / (1024 * 1024)
        total_required_mb = needed_space_mb + MIN_FREE_SPACE_MB
        
        xbmc.log(f"[Smycky] Analýza před stahováním:", xbmc.LOGINFO)
        xbmc.log(f"  Volné místo: {free_space_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Potřeba stáhnout: {needed_space_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Celkem potřeba: {total_required_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Aktuálně {stats['video_count']} video souborů ({stats['total_size_mb']:.1f} MB)", xbmc.LOGINFO)
        
        # Pokud je dostatek místa, pokračovat
        if free_space_mb >= total_required_mb:
            xbmc.log(f"[Smycky] Dostatek místa pro stahování", xbmc.LOGINFO)
            return True
        
        # Potřebujeme uvolnit místo
        deficit_mb = total_required_mb - free_space_mb
        xbmc.log(f"[Smycky] Nedostatek {deficit_mb:.1f} MB, spouštím postupné čištění", xbmc.LOGWARNING)
        
        current_filename = os.path.basename(local_file)
        
        # Postupné čištění - více pokusů s různou agresivitou
        cleanup_attempts = [
            (MAX_OLD_FILES, "standardní čištění"),
            (max(0, MAX_OLD_FILES - 1), "agresivnější čištění"), 
            (0, "extrémní čištění - jen aktuální soubor")
        ]
        
        for keep_count, description in cleanup_attempts:
            xbmc.log(f"[Smycky] Pokus: {description} (ponechat {keep_count} záloh)", xbmc.LOGINFO)
            
            deleted_count, freed_mb = cleanup_old_videos_improved(current_filename, keep_count)
            
            if freed_mb > 0:
                free_space_mb = get_disk_space_mb(VIDEO_DIR)
                xbmc.log(f"[Smycky] Po čištění: volné místo {free_space_mb:.1f} MB", xbmc.LOGINFO)
                
                if free_space_mb >= total_required_mb:
                    show_notification("Místo uvolněno", f"Vyčištěno {freed_mb:.1f} MB, pokračuji ve stahování")
                    return True
            
            # Pokud bylo co mazat ale stále není dost místa, pokračovat dalším pokusem
            if deleted_count == 0:
                break  # Už není co mazat
        
        # Finální kontrola
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        if free_space_mb >= total_required_mb:
            return True
        
        # Stále není dost místa
        show_notification(
            "Nedostatek místa", 
            f"Nelze uvolnit dostatek místa. Volné: {free_space_mb:.1f}MB, potřeba: {total_required_mb:.1f}MB", 
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmc.log(f"[Smycky] KRITICKÉ: Nedostatek místa i po všech pokusech o čištění", xbmc.LOGERROR)
        return False
        
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při kontrole místa na disku: {e}", xbmc.LOGERROR)
        return True  # V případě chyby pokračovat

def smart_cleanup_after_download_improved(new_filename):
    """Vylepšené čištění po stažení s pokročilou analýzou."""
    try:
        xbmc.log(f"[Smycky] Spouštím post-download cleanup pro {new_filename}", xbmc.LOGINFO)
        
        # Analýza před čištěním
        stats_before = analyze_disk_usage()
        
        # Standardní čištění s vylepšenou logikou
        deleted_count, freed_mb = cleanup_old_videos_improved(new_filename, MAX_OLD_FILES)
        
        # Aktualizovat last_filename.txt
        with open(LAST_FILENAME_FILE, "w", encoding="utf-8") as f:
            f.write(new_filename)
        xbmc.log(f"[Smycky] Aktualizován last_filename.txt: {new_filename}", xbmc.LOGINFO)
            
        # Analýza po čištění
        stats_after = analyze_disk_usage()
        if stats_after:
            free_space_mb = stats_after['free_space_mb']
            
            # Pokud je stále málo místa, logovat varování
            if free_space_mb < MIN_FREE_SPACE_MB * 1.5:  # 1.5x safety margin
                xbmc.log(f"[Smycky] VAROVÁNÍ: Nízké volné místo ({free_space_mb:.1f}MB)", xbmc.LOGWARNING)
                show_notification("Varování místa", f"Pouze {free_space_mb:.1f}MB volných", xbmcgui.NOTIFICATION_WARNING)
            
            # Detailní statistiky pro monitorování
            xbmc.log(f"[Smycky] Post-cleanup statistiky:", xbmc.LOGINFO)
            xbmc.log(f"  Video souborů: {stats_after['video_count']}", xbmc.LOGINFO)
            xbmc.log(f"  Celková velikost videí: {stats_after['total_size_mb']:.1f} MB", xbmc.LOGINFO)
            xbmc.log(f"  Volné místo: {free_space_mb:.1f} MB", xbmc.LOGINFO)
            
            # Zobrazit největší soubory pro debug
            if stats_after['largest_files']:
                xbmc.log(f"[Smycky] Největší soubory na disku:", xbmc.LOGINFO)
                for i, file_info in enumerate(stats_after['largest_files'], 1):
                    xbmc.log(f"  {i}. {file_info['filename']}: {file_info['size_mb']:.1f} MB", xbmc.LOGINFO)
            
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při smart cleanup: {e}", xbmc.LOGERROR)

# ======= FTP FUNKCE =======

def get_remote_file_info(host, user, password, path, filename):
    """Získá datum poslední úpravy a velikost souboru na FTP serveru s detailním error handling."""
    try:
        xbmc.log(f"[Smycky] Připojuji se k FTP serveru {host}...", xbmc.LOGINFO)
        
        ftp = FTP(host)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        
        # Pokusit se získat velikost souboru
        try:
            size = ftp.size(path + filename)
        except Exception as e:
            xbmc.log(f"[Smycky] Chyba při získávání velikosti souboru {filename}: {str(e)}", xbmc.LOGERROR)
            ftp.quit()
            return None, None
        
        # Pokusit se získat datum úpravy
        try:
            modified_time = ftp.sendcmd("MDTM " + path + filename)[4:].strip()
            remote_timestamp = time.mktime(datetime.strptime(modified_time, "%Y%m%d%H%M%S").timetuple())
        except Exception as e:
            xbmc.log(f"[Smycky] Chyba při získávání data úpravy souboru {filename}: {str(e)}", xbmc.LOGERROR)
            ftp.quit()
            return None, None
        
        ftp.quit()
        
        xbmc.log(f"[Smycky] FTP info úspěšně získáno - velikost: {size/1024/1024:.1f}MB, datum: {datetime.fromtimestamp(remote_timestamp).strftime('%Y-%m-%d %H:%M')}", xbmc.LOGINFO)
        return remote_timestamp, size
        
    except Exception as e:
        # Rozlišit typy chyb pro lepší diagnostiku
        error_msg = str(e).lower()
        
        if "authentication" in error_msg or "login" in error_msg or "530" in error_msg:
            xbmc.log(f"[Smycky] CHYBA AUTENTIFIKACE FTP: Špatné uživatelské jméno nebo heslo pro {host}", xbmc.LOGERROR)
            show_notification("Chyba FTP", "Špatné přihlašovací údaje k FTP serveru", xbmcgui.NOTIFICATION_ERROR)
        elif "timeout" in error_msg or "timed out" in error_msg:
            xbmc.log(f"[Smycky] CHYBA TIMEOUT FTP: Server {host} neodpovídá", xbmc.LOGERROR)
            show_notification("Chyba FTP", "FTP server neodpovídá (timeout)", xbmcgui.NOTIFICATION_ERROR)
        elif "refused" in error_msg or "connection" in error_msg:
            xbmc.log(f"[Smycky] CHYBA PŘIPOJENÍ FTP: Nelze se připojit k {host}", xbmc.LOGERROR)
            show_notification("Chyba FTP", "Nelze se připojit k FTP serveru", xbmcgui.NOTIFICATION_ERROR)
        elif "not found" in error_msg or "550" in error_msg:
            xbmc.log(f"[Smycky] CHYBA SOUBOR FTP: Soubor {filename} nebyl nalezen na serveru", xbmc.LOGERROR)
            show_notification("Chyba FTP", f"Soubor {filename} nenalezen na serveru", xbmcgui.NOTIFICATION_ERROR)
        else:
            xbmc.log(f"[Smycky] OBECNÁ CHYBA FTP při připojení k {host}: {str(e)}", xbmc.LOGERROR)
            show_notification("Chyba FTP", f"Obecná chyba FTP: {str(e)[:50]}", xbmcgui.NOTIFICATION_ERROR)
        
        return None, None

def get_local_file_info(path):
    """Získá datum poslední úpravy a velikost lokálního souboru."""
    if os.path.exists(path):
        return os.path.getmtime(path), os.path.getsize(path)
    return 0, 0

def download_file(host, user, password, path, filename, local_path):
    """Bezpečně stáhne soubor z FTP po blocích s vylepšenou kontrolou místa na disku."""
    
    # 1. Nejdříve získat velikost souboru pro kontrolu místa
    try:
        ftp = FTP(host)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        remote_size = ftp.size(path + filename)
        ftp.quit()
        xbmc.log(f"[Smycky] Vzdálený soubor {filename}: {remote_size / (1024*1024):.1f} MB", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Nelze získat velikost souboru pro kontrolu místa: {e}", xbmc.LOGERROR)
        remote_size = None
    
    # 2. Vylepšená kontrola místa před stahováním
    if not check_disk_space_before_download_improved(remote_size, local_path):
        return False
    
    temp_path = local_path + "_tmp"
    block_size = 1024 * 1024  # 1 MB bloky pro detekci výpadku internetu

    try:
        show_notification("Stahování", "Probíhá stahování souboru (FTP)...", xbmcgui.NOTIFICATION_INFO)
        xbmc.log(f"[Smycky] Stahuji soubor z FTP {host}:{path}{filename} do {temp_path}", xbmc.LOGINFO)

        with open(temp_path, "wb") as out_file:
            # Nastavíme timeout připojení
            ftp = FTP()
            ftp.connect(host, timeout=30)  # Timeout 30 sekund
            ftp.login(user, password)

            # Získat velikost souboru pro notifikace
            ftp.voidcmd("TYPE I")
            file_size = ftp.size(path + filename)
            downloaded = 0
            last_shown_mb = 0

            def write_block(block):
                nonlocal downloaded, last_shown_mb
                try:
                    out_file.write(block)
                    downloaded += len(block)

                    downloaded_mb = downloaded / (1024 * 1024)
                    total_mb = file_size / (1024 * 1024) if file_size > 0 else 0

                    # Aktualizace notifikace pouze každých 40 MB + info o volném místě
                    if downloaded_mb - last_shown_mb >= 40:
                        free_mb = get_disk_space_mb(VIDEO_DIR)
                        show_notification("Stahování", f"Staženo: {downloaded_mb:.1f}/{total_mb:.1f} MB (volné: {free_mb:.0f} MB)", xbmcgui.NOTIFICATION_INFO)
                        last_shown_mb = downloaded_mb

                except Exception as e:
                    xbmc.log(f"[Smycky] Chyba zápisu bloku během stahování: {str(e)}", xbmc.LOGERROR)
                    raise e  # Vyvolá výjimku pro ukončení retrbinary

            # Spustíme stahování s blokovým zápisem
            ftp.retrbinary("RETR " + path + filename, write_block)
            ftp.quit()

        # Ověření, že soubor existuje a není prázdný
        if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
            # Přepsání původního souboru novým
            shutil.move(temp_path, local_path)
            
            actual_size_mb = get_file_size_mb(local_path)
            show_notification("Stahování dokončeno", f"Soubor úspěšně aktualizován ({actual_size_mb:.1f} MB)", xbmcgui.NOTIFICATION_INFO)
            xbmc.log(f"[Smycky] Soubor {local_path} byl úspěšně aktualizován ({actual_size_mb:.1f} MB)", xbmc.LOGINFO)
            
            # 3. Po úspěšném stažení provést vylepšené čištění
            smart_cleanup_after_download_improved(filename)
            
            return True
        else:
            raise ValueError("Stažený soubor je prázdný!")

    except Exception as e:
        # Pokud dojde k chybě (např. výpadek internetu), dočasný soubor odstraníme
        if os.path.exists(temp_path):
            os.remove(temp_path)

        error_message = f"Nepodařilo se stáhnout soubor: {str(e)}"
        show_notification("Chyba", error_message, xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Smycky] Chyba při stahování z FTP: {str(e)}", xbmc.LOGERROR)
        return False

# ======= PŘEHRÁVÁNÍ A RESTART FUNKCE =======

def RepeatVideo(local_file):
    """Spustí přehrávání videa ve smyčce."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(local_file)
    xbmc.Player().play(playlist)
    xbmc.executebuiltin("PlayerControl(RepeatOne)")
    show_notification("Přehrávání", f"Smyčka: {os.path.basename(local_file)}")

def was_reboot_today():
    """Zjistí, zda už dnes proběhl restart."""
    if os.path.exists(REBOOT_TRACK_FILE):
        with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() == datetime.now().strftime('%Y-%m-%d')
    return False

def mark_reboot_done():
    """Uloží aktuální datum jako poslední provedený restart."""
    with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
        f.write(datetime.now().strftime('%Y-%m-%d'))

def schedule_random_reboot():
    """Naplánuje náhodný restart mezi 21:00 a 5:00 v samostatném vlákně, každý den znovu."""

    def reboot_task():
        """Funkce běžící v samostatném vlákně, která plánuje restart."""
        now = datetime.now()

        # Načteme poslední restart a naplánovaný restart ze souboru
        last_reboot_date = "Žádný"
        planned_reboot_date = "Žádný"

        if os.path.exists(REBOOT_TRACK_FILE):
            with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if len(lines) >= 2:
                    last_reboot_date = lines[0].strip().replace("Poslední restart: ", "")
                    planned_reboot_date = lines[1].strip().replace("Naplánovaný restart: ", "")

        # Pokud byl plánovaný restart v minulosti, znamená to, že výpadek elektřiny restart přerušil
        if planned_reboot_date != "Žádný":
            planned_time = datetime.strptime(planned_reboot_date, "%Y-%m-%d %H:%M:%S")
            if planned_time < now:
                xbmc.log(f"[Smycky] Detekován neprovedený restart ({planned_reboot_date}), plánování nového restartu.", xbmc.LOGWARNING)
                last_reboot_date = "Neprovedeno"  # Ověříme, že starý restart nebyl proveden

        # Nastavení časového okna mezi 21:00 a 05:00
        start_time = now.replace(hour=21, minute=0, second=0)
        end_time = now.replace(hour=4, minute=59, second=0) + timedelta(days=1)

        # Pokud už je po 05:00, naplánujeme restart na další noc
        if now >= end_time or last_reboot_date == datetime.now().strftime('%Y-%m-%d'):
            start_time += timedelta(days=1)
            end_time += timedelta(days=1)

        # Generování náhodného času mezi 21:00 a 05:00
        while True:
            random_reboot_time = start_time + timedelta(minutes=random.randint(0, int((end_time - start_time).total_seconds() / 60)))
            if random_reboot_time > now:  # Ověříme, že restart není naplánován na aktuální čas
                break

        restart_date_time = random_reboot_time.strftime('%Y-%m-%d %H:%M:%S')

        # Zápis informací do souboru reboot_log.txt
        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {last_reboot_date}\nNaplánovaný restart: {restart_date_time}")

        log_message = f"Poslední restart: {last_reboot_date} | Naplánovaný restart: {restart_date_time}"
        xbmc.log(f"[Smycky] {log_message}", xbmc.LOGINFO)
        show_notification("Naplánovaný restart", log_message)

        # Čekání na restart
        time.sleep((random_reboot_time - now).total_seconds())
        perform_reboot(restart_date_time)

    threading.Thread(target=reboot_task, daemon=True).start()

def perform_reboot(restart_date_time):
    """Provede restart zařízení a zaznamená ho do souboru."""
    mark_reboot_done()
    xbmc.log("[Smycky] Provádím restart zařízení...", xbmc.LOGINFO)
    show_notification("Restart", f"Zařízení se nyní restartuje ({restart_date_time}).", xbmcgui.NOTIFICATION_WARNING)
    xbmc.executebuiltin("Reboot")

# ======= HLAVNÍ FUNKCE =======
def main():
    """Hlavní funkce s vylepšenou fallback logikou."""
    xbmc.log("[Smycky] === Spuštění doplňku Smycky ===", xbmc.LOGINFO)

    # PRVNÍ KROK: Počkat na synchronizaci času od doplňku Dohled
    wait_for_time_sync()

    # Zápis verze doplňku (zachovat)
    try:
        version = xbmcaddon.Addon().getAddonInfo('version')
        with open("/storage/.kodi/userdata/smycky_version.txt", "w", encoding="utf-8") as f:
            f.write(version)
        xbmc.log(f"[Smycky] Spuštěna verze {version}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při zápisu verze: {e}", xbmc.LOGERROR)

    # Zobrazit počáteční analýzu disku (zachovat)
    try:
        stats = analyze_disk_usage()
        if stats:
            free_space_mb = stats['free_space_mb']
            xbmc.log(f"[Smycky] Počáteční stav disku: {stats['video_count']} videí, {stats['total_size_mb']:.1f}MB obsazeno, {free_space_mb:.1f}MB volných", xbmc.LOGINFO)
            
            if free_space_mb < MIN_FREE_SPACE_MB:
                show_notification("Varování místa", f"Málo místa na disku: {free_space_mb:.1f} MB", xbmcgui.NOTIFICATION_WARNING)
            else:
                show_notification("Info disku", f"Volné místo: {free_space_mb:.0f} MB")
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při počáteční analýze disku: {e}", xbmc.LOGERROR)

    # 1️⃣ Načíst locality z konfigurace
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            config = json.load(f)
            locality = config.get("locality")
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba načítání config.json: {e}", xbmc.LOGERROR)
        show_notification("Chyba", "Nelze načíst konfiguraci.")
        # I při chybě konfigurace zkusit fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            RepeatVideo(fallback_file)
            schedule_random_reboot()
        return

    if not locality:
        show_notification("Chyba", "Locality nenalezena v konfiguraci.")
        xbmc.log("[Smycky] Locality nenalezena v konfiguraci.", xbmc.LOGERROR)
        # I při chybě locality zkusit fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            RepeatVideo(fallback_file)
            schedule_random_reboot()
        return

    xbmc.log(f"[Smycky] Načtena locality: {locality}", xbmc.LOGINFO)

    # 2️⃣ Kontrola internetu a načtení FTP konfigurace
    if not is_internet_available():
        xbmc.log("[Smycky] Internet není dostupný.", xbmc.LOGWARNING)
        show_notification("Offline režim", "Internet není dostupný, používám lokální soubor.", xbmcgui.NOTIFICATION_WARNING)
        # Bez internetu rovnou fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            RepeatVideo(fallback_file)
            schedule_random_reboot()
            return
        else:
            show_notification("Chyba", "Bez internetu a žádný lokální soubor není dostupný.")
            xbmc.log("[Smycky] KRITICKÉ: Bez internetu a žádný lokální soubor.", xbmc.LOGERROR)
            return

    # Pokus o načtení FTP konfigurace
    ftp_config = fetch_ftp_config(locality)
    if not ftp_config:
        xbmc.log("[Smycky] Nelze načíst FTP konfiguraci (SSL nebo jiná chyba).", xbmc.LOGWARNING)
        show_notification("Chyba FTP konfigurace", "Používám lokální soubor.")
        # Chyba FTP konfigurace (např. SSL) -> fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            RepeatVideo(fallback_file)
            schedule_random_reboot()
            return
        else:
            show_notification("Chyba", "Chyba FTP konfigurace a žádný lokální soubor.")
            xbmc.log("[Smycky] KRITICKÉ: Chyba FTP konfigurace a žádný lokální soubor.", xbmc.LOGERROR)
            return

    # FTP konfigurace načtena úspěšně
    ftp_host = ftp_config["ftp_host"]
    ftp_user = ftp_config["ftp_user"]
    ftp_pass = ftp_config["ftp_pass"]
    ftp_path = ftp_config["ftp_path"]
    file_name = ftp_config["file_name"]

    xbmc.log(f"[Smycky] FTP konfigurace načtena - host: {ftp_host}, soubor: {file_name}", xbmc.LOGINFO)

    local_file = f"/storage/videos/{file_name}"

    # 3️⃣ Kontrola aktualizace souboru přes FTP
    show_notification("Aktualizace", "Kontroluji aktualizace souboru...")
    remote_timestamp, remote_size = get_remote_file_info(ftp_host, ftp_user, ftp_pass, ftp_path, file_name)
    local_timestamp, local_size = get_local_file_info(local_file)

    # Pokud je chyba FTP (SSL nebo jiná)
    if remote_timestamp is None or remote_size is None:
        xbmc.log("[Smycky] Chyba při připojení k FTP serveru.", xbmc.LOGWARNING)
        show_notification("Chyba FTP", "Nelze se připojit k serveru. Používám lokální soubor.", xbmcgui.NOTIFICATION_WARNING)
        # FTP chyba -> použít lokální soubor nebo fallback
        target_file = get_best_available_file(local_file)
        if target_file:
            RepeatVideo(target_file)
            schedule_random_reboot()
            return
        else:
            show_notification("Kritická chyba", "Chyba FTP a není dostupný žádný soubor.", xbmcgui.NOTIFICATION_ERROR)
            xbmc.log("[Smycky] KRITICKÉ: Chyba FTP a žádný dostupný soubor.", xbmc.LOGERROR)
            return

    # FTP připojení OK - kontrola aktualizace
    update_needed = False
    if remote_timestamp > local_timestamp or remote_size != local_size:
        update_needed = True
        
        if remote_timestamp > local_timestamp:
            time_diff = remote_timestamp - local_timestamp
            xbmc.log(f"[Smycky] Vzdálený soubor je novější o {time_diff/3600:.1f} hodin", xbmc.LOGINFO)
        if remote_size != local_size:
            size_diff_mb = (remote_size - local_size) / (1024 * 1024)
            xbmc.log(f"[Smycky] Rozdíl velikosti: {size_diff_mb:+.1f} MB", xbmc.LOGINFO)

    if update_needed:
        xbmc.log("[Smycky] Novější soubor nalezen, pokusím se stáhnout.", xbmc.LOGINFO)
        
        size_mb = remote_size / (1024 * 1024)
        free_mb = get_disk_space_mb(VIDEO_DIR)
        show_notification("Připravuji stahování", f"Nový soubor: {size_mb:.1f} MB, Volné místo: {free_mb:.1f} MB")
        xbmc.log(f"[Smycky] Připravuji stažení: {size_mb:.1f} MB (volné místo: {free_mb:.1f} MB)", xbmc.LOGINFO)
        
        if download_file(ftp_host, ftp_user, ftp_pass, ftp_path, file_name, local_file):
            xbmc.log("[Smycky] Soubor úspěšně aktualizován.", xbmc.LOGINFO)
        else:
            xbmc.log("[Smycky] Stahování selhalo, použiji nejlepší dostupný soubor.", xbmc.LOGWARNING)
    else:
        show_notification("Aktualizace", "Soubor je aktuální.")
        xbmc.log("[Smycky] Soubor je aktuální, provádím údržbu disku.", xbmc.LOGINFO)
        cleanup_old_videos_improved(file_name, MAX_OLD_FILES)

    # 4️⃣ ROBUSTNÍ VÝBĚR SOUBORU PRO PŘEHRÁNÍ
    target_file = get_best_available_file(local_file)
    
    if target_file:
        actual_size_mb = get_file_size_mb(target_file)
        xbmc.log(f"[Smycky] Spouštím přehrávání: {target_file} ({actual_size_mb:.1f} MB)", xbmc.LOGINFO)
        RepeatVideo(target_file)
    else:
        show_notification("Kritická chyba", "Žádný dostupný soubor ke spuštění.")
        xbmc.log("[Smycky] KRITICKÉ: Nelze najít žádný přehratelný soubor.", xbmc.LOGERROR)
        return

    # 5️⃣ Naplánovat restart
    schedule_random_reboot()

    # 6️⃣ Finální statistiky
    try:
        final_stats = analyze_disk_usage()
        if final_stats:
            xbmc.log(f"[Smycky] Finální stav: {final_stats['video_count']} souborů, {final_stats['free_space_mb']:.1f}MB volných", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při finálních statistikách: {e}", xbmc.LOGERROR)

def find_best_fallback_file():
    """Najde nejlepší fallback soubor podle priority: last_filename -> nejnovější -> libovolný."""
    fallback_file = None
    
    try:
        # 1. Priorita: last_filename.txt
        if os.path.exists(LAST_FILENAME_FILE):
            with open(LAST_FILENAME_FILE, encoding="utf-8") as f:
                last_file = f.read().strip()
                possible = f"/storage/videos/{last_file}"
                if os.path.exists(possible):
                    fallback_file = possible
                    xbmc.log(f"[Smycky] Fallback z last_filename: {fallback_file}", xbmc.LOGINFO)
                    return fallback_file

        # 2. Priorita: najít nejnovější MP4 soubor
        video_files = []
        for filename in os.listdir("/storage/videos/"):
            if filename.endswith(".mp4"):
                filepath = os.path.join("/storage/videos/", filename)
                mtime = os.path.getmtime(filepath)
                video_files.append((filepath, mtime))
        
        if video_files:
            # Seřadit podle času úpravy (nejnovější první)
            video_files.sort(key=lambda x: x[1], reverse=True)
            fallback_file = video_files[0][0]
            xbmc.log(f"[Smycky] Fallback nejnovější soubor: {fallback_file}", xbmc.LOGINFO)
        
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při hledání fallback souboru: {e}", xbmc.LOGERROR)
    
    return fallback_file
    
def get_best_available_file(preferred_file):
    """Najde nejlepší dostupný soubor pro přehrání s robustní fallback logikou."""
    
    # 1. Priorita: preferovaný soubor (většinou local_file)
    if preferred_file and os.path.exists(preferred_file) and os.path.getsize(preferred_file) > 0:
        xbmc.log(f"[Smycky] Používám preferovaný soubor: {preferred_file}", xbmc.LOGINFO)
        return preferred_file
    
    # 2. Priorita: fallback podle last_filename
    fallback_file = find_best_fallback_file()
    if fallback_file and os.path.exists(fallback_file) and os.path.getsize(fallback_file) > 0:
        xbmc.log(f"[Smycky] Používám fallback soubor: {fallback_file}", xbmc.LOGINFO)
        return fallback_file
    
    # 3. Priorita: jakýkoli MP4 soubor ve složce (nouzové řešení)
    try:
        if os.path.exists("/storage/videos/"):
            for filename in os.listdir("/storage/videos/"):
                if filename.endswith(".mp4"):
                    filepath = os.path.join("/storage/videos/", filename)
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        xbmc.log(f"[Smycky] Používám nouzový soubor: {filepath}", xbmc.LOGWARNING)
                        return filepath
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při hledání nouzového souboru: {e}", xbmc.LOGERROR)
    
    # 4. Žádný soubor nenalezen
    xbmc.log("[Smycky] Žádný přehratelný soubor nenalezen", xbmc.LOGERROR)
    return None

# Spustí hlavní funkci
if __name__ == "__main__":
    main()