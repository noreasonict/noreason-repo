import os
import xbmc
import xbmcgui
import urllib.request
import time
import random
import threading
import shutil
import xbmcaddon
import json
from ftplib import FTP
from datetime import datetime, timedelta

# ======= KONSTANTY =======
REBOOT_TRACK_FILE = "/storage/.kodi/userdata/reboot_log.txt"
CONFIG_FILE = "/storage/.kodi/userdata/addon_data/service.dohled/config.json"
DEVICE_ID_FILE = "/storage/.kodi/userdata/addon_data/service.dohled/device_id.txt"
LAST_FILENAME_FILE = "/storage/.kodi/userdata/last_filename.txt"
TIME_SYNC_FILE = "/storage/.kodi/userdata/time_synced.flag"
STOP_SMYCKY_FLAG = "/storage/.kodi/userdata/stop_smycky_playlist.flag"  # Signal od service.dohled pro zastavení playlistu
CURRENT_PLAYING_FILE = "/storage/.kodi/userdata/current_playing.txt"  # Sdílení aktuálně přehrávaného souboru s service.dohled

# KRITICKÉ: Okamžitě smazat starý sync flag při načtení modulu
# Toto zajistí, že starý flag z předchozího bootu nebude přečten
# Bez ohledu na to, zda se Smycky načte před nebo po Dohledu
try:
    if os.path.exists(TIME_SYNC_FILE):
        os.remove(TIME_SYNC_FILE)
        xbmc.log("[Smycky] Okamžitě odstraněn starý sync flag při startu", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Smycky] Chyba při odstraňování sync flagu: {e}", xbmc.LOGERROR)

# Také smazat stop flag - při restartu začínáme nanovo
try:
    if os.path.exists(STOP_SMYCKY_FLAG):
        os.remove(STOP_SMYCKY_FLAG)
        xbmc.log("[Smycky] Odstraněn starý stop flag při startu", xbmc.LOGINFO)
except Exception as e:
    xbmc.log(f"[Smycky] Chyba při odstraňování stop flagu: {e}", xbmc.LOGERROR)

VIDEO_DIR = "/storage/videos/"
API_KEY = "cw4LilUj_B2ByrtGkK2024"

# Maximální doba čekání na synchronizaci času (v sekundách)
TIME_SYNC_WAIT_TIMEOUT = 30

# Konfigurace správy disku - upraveno pro podporu playlistů s více soubory
MAX_OLD_FILES = 20          # Kolik starých souborů ponechat (zvýšeno pro playlisty)
MIN_FREE_SPACE_MB = 1000    # Minimální volné místo v MB - cleanup se spustí jen při nedostatku místa

# ======= PODPOROVANÉ FORMÁTY SOUBORŮ =======
VIDEO_EXTENSIONS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv')
IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp')
SUPPORTED_EXTENSIONS = VIDEO_EXTENSIONS + IMAGE_EXTENSIONS

# Výchozí doba zobrazení obrázku (v sekundách)
DEFAULT_IMAGE_DISPLAY_TIME = 10


def parse_playlist_item(item, default_duration=10):
    """Parsuje položku playlistu ve formátu 'soubor' nebo 'soubor:sekundy'.

    Args:
        item: Položka playlistu (např. 'video.mp4' nebo 'obrazek.jpg:15')
        default_duration: Výchozí doba zobrazení pro obrázky

    Returns:
        dict: {'filename': str, 'duration': int nebo None}
              duration je None pro videa (přehrají se celá)
    """
    item = item.strip()
    if not item:
        return None

    # Zkontrolovat formát soubor:sekundy
    # Pozor: soubor může obsahovat dvojtečku v cestě (např. C:\...) - ale to se netýká Linuxu
    # Hledáme dvojtečku následovanou číslem na konci
    if ':' in item:
        parts = item.rsplit(':', 1)  # Rozdělit od konce, max 1x
        if len(parts) == 2 and parts[1].isdigit():
            filename = parts[0]
            duration = int(parts[1])
            return {'filename': filename, 'duration': duration}

    # Bez specifikované doby - použít default pro obrázky, None pro videa
    return {'filename': item, 'duration': None}


def parse_playlist_string(playlist_str, default_duration=10):
    """Parsuje celý playlist string.

    Args:
        playlist_str: String s playlistem (bez prefixu 'playlist:')
        default_duration: Výchozí doba zobrazení pro obrázky

    Returns:
        list: Seznam dict s 'filename' a 'duration'
    """
    items = []
    for item in playlist_str.split(','):
        parsed = parse_playlist_item(item, default_duration)
        if parsed:
            items.append(parsed)
    return items


# ======= ZÁKLADNÍ FUNKCE =======

def show_notification(title, message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    """Zobrazí informační okénko v Kodi s výchozí ikonou."""
    xbmcgui.Dialog().notification(title, message, icon, duration)


def is_video_file(filename):
    """Zjistí, zda je soubor video podle přípony."""
    return filename.lower().endswith(VIDEO_EXTENSIONS)


def is_image_file(filename):
    """Zjistí, zda je soubor obrázek podle přípony."""
    return filename.lower().endswith(IMAGE_EXTENSIONS)


def is_supported_file(filename):
    """Zjistí, zda je soubor podporovaný (video nebo obrázek)."""
    return filename.lower().endswith(SUPPORTED_EXTENSIONS)


def get_media_type(filename):
    """Vrátí typ média: 'video', 'image' nebo None."""
    lower_name = filename.lower()
    if lower_name.endswith(VIDEO_EXTENSIONS):
        return 'video'
    elif lower_name.endswith(IMAGE_EXTENSIONS):
        return 'image'
    return None


def wait_for_time_sync():
    """Čeká na synchronizaci času od doplňku Dohled."""
    xbmc.log("[Smycky] Čekám na synchronizaci času od doplňku Dohled...", xbmc.LOGINFO)

    waited = 0
    while waited < TIME_SYNC_WAIT_TIMEOUT:
        if os.path.exists(TIME_SYNC_FILE):
            try:
                with open(TIME_SYNC_FILE, "r") as f:
                    sync_time = f.read().strip()
                xbmc.log(f"[Smycky] Synchronizace času dokončena: {sync_time}", xbmc.LOGINFO)
                return True
            except Exception as e:
                xbmc.log(f"[Smycky] Chyba při čtení sync flagu: {e}", xbmc.LOGERROR)

        time.sleep(1)
        waited += 1

        # Informovat uživatele každých 5 sekund
        if waited % 5 == 0:
            xbmc.log(f"[Smycky] Stále čekám na synchronizaci času... ({waited}s)", xbmc.LOGINFO)

    # Timeout - pokračovat i bez synchronizace
    xbmc.log(f"[Smycky] VAROVÁNÍ: Timeout čekání na synchronizaci času ({TIME_SYNC_WAIT_TIMEOUT}s)", xbmc.LOGWARNING)
    show_notification(
        "Varování",
        "Synchronizace času trvá příliš dlouho, pokračuji...",
        xbmcgui.NOTIFICATION_WARNING
    )
    return False


def is_internet_available():
    """Zkontroluje dostupnost internetu pomocí jednoduchého HTTP požadavku."""
    try:
        urllib.request.urlopen("http://google.com", timeout=5)
        return True
    except:
        return False

def fetch_ftp_config(locality):
    """Načte FTP konfiguraci z API podle locality."""
    api_url = f"https://apidohled.noreason.eu/api/locality_config?locality={locality}&apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url) as response:
            return json.loads(response.read().decode())
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při načítání FTP konfigurace: {e}", xbmc.LOGERROR)
        return None


def get_device_id():
    """Načte device_id ze souboru vytvořeného doplňkem Dohled."""
    try:
        if os.path.exists(DEVICE_ID_FILE):
            with open(DEVICE_ID_FILE, "r", encoding="utf-8") as f:
                device_id = f.read().strip()
                if device_id:
                    return device_id
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při čtení device_id: {e}", xbmc.LOGERROR)
    return None


def fetch_expected_file(device_id):
    """Získá očekávaný soubor z API - nejprve zkontroluje device override, pak locality."""
    if not device_id:
        return None, None

    api_url = f"https://apidohled.noreason.eu/api/devices/{device_id}/expected-file?apikey={API_KEY}"
    try:
        with urllib.request.urlopen(api_url, timeout=10) as response:
            data = json.loads(response.read().decode())
            filename = data.get("filename")
            source = data.get("source")  # "device" nebo "locality"

            if filename:
                xbmc.log(f"[Smycky] Očekávaný soubor z API: {filename} (zdroj: {source})", xbmc.LOGINFO)
                return filename, source
            return None, None
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při získávání očekávaného souboru: {e}", xbmc.LOGWARNING)
        return None, None

# ======= VYLEPŠENÉ FUNKCE PRO SPRÁVU DISKU =======

def get_disk_space_mb(path):
    """Vrátí volné místo na disku v MB."""
    try:
        statvfs = os.statvfs(path)
        free_bytes = statvfs.f_frsize * statvfs.f_bavail
        return free_bytes / (1024 * 1024)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při zjišťování místa na disku: {e}", xbmc.LOGERROR)
        return 0

def get_file_size_mb(filepath):
    """Vrátí velikost souboru v MB."""
    try:
        if os.path.exists(filepath):
            return os.path.getsize(filepath) / (1024 * 1024)
        return 0
    except:
        return 0

def cleanup_old_media(current_filename, keep_count=MAX_OLD_FILES):
    """Vyčistí staré mediální soubory (videa i obrázky), ponechá jen zadaný počet nejnovějších.
    Optimalizováno pro měnící se názvy souborů - řadí podle času úpravy."""
    try:
        media_files = []
        current_file_path = os.path.join(VIDEO_DIR, current_filename)

        # Najít všechny podporované soubory (videa i obrázky)
        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                mtime = os.path.getmtime(filepath)
                size_mb = get_file_size_mb(filepath)
                media_files.append({
                    'filename': filename,
                    'filepath': filepath,
                    'mtime': mtime,
                    'size_mb': size_mb
                })
        
        # Seřadit podle data úpravy (nejnovější první)
        media_files.sort(key=lambda x: x['mtime'], reverse=True)

        xbmc.log(f"[Smycky] Nalezeno {len(media_files)} mediálních souborů pro analýzu čištění", xbmc.LOGINFO)

        # Logika: ponechat nejnovější soubory + zajistit, že aktuální soubor se nepomaže
        files_to_keep = []
        files_to_delete = []
        current_file_protected = False

        for i, file_info in enumerate(media_files):
            # Vždy chránit aktuální soubor (podle názvu)
            if file_info['filename'] == current_filename:
                files_to_keep.append(file_info)
                current_file_protected = True
                xbmc.log(f"[Smycky] Chráním aktuální soubor: {file_info['filename']}", xbmc.LOGINFO)
            # Ponechat keep_count nejnovějších souborů (podle času úpravy)
            elif len([f for f in files_to_keep if f['filename'] != current_filename]) < keep_count:
                files_to_keep.append(file_info)
                xbmc.log(f"[Smycky] Ponechávám jako zálohu: {file_info['filename']} (změněn: {datetime.fromtimestamp(file_info['mtime']).strftime('%Y-%m-%d %H:%M')})", xbmc.LOGINFO)
            else:
                files_to_delete.append(file_info)

        # Smazat nadbytečné soubory
        deleted_count = 0
        freed_space_mb = 0

        for file_info in files_to_delete:
            try:
                os.remove(file_info['filepath'])
                deleted_count += 1
                freed_space_mb += file_info['size_mb']
                xbmc.log(f"[Smycky] Smazán starý soubor: {file_info['filename']} ({file_info['size_mb']:.1f} MB, ze dne {datetime.fromtimestamp(file_info['mtime']).strftime('%Y-%m-%d')})", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Smycky] Chyba při mazání {file_info['filename']}: {e}", xbmc.LOGERROR)

        # Informativní zprávy
        if deleted_count > 0:
            show_notification("Čištění disku", f"Smazáno {deleted_count} starých souborů ({freed_space_mb:.1f} MB)")
            xbmc.log(f"[Smycky] Cleanup dokončen: smazáno {deleted_count} souborů, uvolněno {freed_space_mb:.1f} MB", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Smycky] Cleanup: žádné soubory ke smazání (celkem {len(media_files)} souborů, max {keep_count} záloh)", xbmc.LOGINFO)

        # Finální statistiky
        remaining_count = len(media_files) - deleted_count
        xbmc.log(f"[Smycky] Po čištění: {remaining_count} souborů zůstává na disku", xbmc.LOGINFO)
        
        return deleted_count, freed_space_mb
        
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při čištění starých videí: {e}", xbmc.LOGERROR)
        return 0, 0

def analyze_disk_usage():
    """Analyzuje využití disku a vrátí statistiky."""
    try:
        media_files = []
        total_size_mb = 0

        for filename in os.listdir(VIDEO_DIR):
            if is_supported_file(filename):
                filepath = os.path.join(VIDEO_DIR, filename)
                size_mb = get_file_size_mb(filepath)
                mtime = os.path.getmtime(filepath)
                media_files.append({
                    'filename': filename,
                    'size_mb': size_mb,
                    'mtime': mtime,
                    'type': get_media_type(filename)
                })
                total_size_mb += size_mb

        # Seřadit podle velikosti (největší první)
        media_files.sort(key=lambda x: x['size_mb'], reverse=True)

        free_space_mb = get_disk_space_mb(VIDEO_DIR)

        # Počet videí a obrázků
        video_count = sum(1 for f in media_files if f['type'] == 'video')
        image_count = sum(1 for f in media_files if f['type'] == 'image')

        return {
            'media_count': len(media_files),
            'video_count': video_count,
            'image_count': image_count,
            'total_size_mb': total_size_mb,
            'free_space_mb': free_space_mb,
            'largest_files': media_files[:3]  # 3 největší soubory
        }
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při analýze disku: {e}", xbmc.LOGERROR)
        return None

def check_disk_space_before_download_improved(remote_size_bytes, local_file):
    """Vylepšená kontrola místa s prediktivní analýzou a multiple cleanup attempts."""
    try:
        # Analýza současného stavu
        stats = analyze_disk_usage()
        if not stats:
            return True  # V případě chyby pokračovat
        
        free_space_mb = stats['free_space_mb']
        needed_space_mb = (remote_size_bytes or 0) / (1024 * 1024)
        total_required_mb = needed_space_mb + MIN_FREE_SPACE_MB
        
        xbmc.log(f"[Smycky] Analýza před stahováním:", xbmc.LOGINFO)
        xbmc.log(f"  Volné místo: {free_space_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Potřeba stáhnout: {needed_space_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Celkem potřeba: {total_required_mb:.1f} MB", xbmc.LOGINFO)
        xbmc.log(f"  Aktuálně {stats['video_count']} video souborů ({stats['total_size_mb']:.1f} MB)", xbmc.LOGINFO)
        
        # Pokud je dostatek místa, pokračovat
        if free_space_mb >= total_required_mb:
            xbmc.log(f"[Smycky] Dostatek místa pro stahování", xbmc.LOGINFO)
            return True
        
        # Potřebujeme uvolnit místo
        deficit_mb = total_required_mb - free_space_mb
        xbmc.log(f"[Smycky] Nedostatek {deficit_mb:.1f} MB, spouštím postupné čištění", xbmc.LOGWARNING)
        
        current_filename = os.path.basename(local_file)
        
        # Postupné čištění - více pokusů s různou agresivitou
        cleanup_attempts = [
            (MAX_OLD_FILES, "standardní čištění"),
            (max(0, MAX_OLD_FILES - 1), "agresivnější čištění"), 
            (0, "extrémní čištění - jen aktuální soubor")
        ]
        
        for keep_count, description in cleanup_attempts:
            xbmc.log(f"[Smycky] Pokus: {description} (ponechat {keep_count} záloh)", xbmc.LOGINFO)
            
            deleted_count, freed_mb = cleanup_old_media(current_filename, keep_count)
            
            if freed_mb > 0:
                free_space_mb = get_disk_space_mb(VIDEO_DIR)
                xbmc.log(f"[Smycky] Po čištění: volné místo {free_space_mb:.1f} MB", xbmc.LOGINFO)
                
                if free_space_mb >= total_required_mb:
                    show_notification("Místo uvolněno", f"Vyčištěno {freed_mb:.1f} MB, pokračuji ve stahování")
                    return True
            
            # Pokud bylo co mazat ale stále není dost místa, pokračovat dalším pokusem
            if deleted_count == 0:
                break  # Už není co mazat
        
        # Finální kontrola
        free_space_mb = get_disk_space_mb(VIDEO_DIR)
        if free_space_mb >= total_required_mb:
            return True
        
        # Stále není dost místa
        show_notification(
            "Nedostatek místa", 
            f"Nelze uvolnit dostatek místa. Volné: {free_space_mb:.1f}MB, potřeba: {total_required_mb:.1f}MB", 
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmc.log(f"[Smycky] KRITICKÉ: Nedostatek místa i po všech pokusech o čištění", xbmc.LOGERROR)
        return False
        
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při kontrole místa na disku: {e}", xbmc.LOGERROR)
        return True  # V případě chyby pokračovat

def smart_cleanup_after_download_improved(new_filename):
    """Vylepšené čištění po stažení - POUZE při nedostatku místa."""
    try:
        xbmc.log(f"[Smycky] Post-download analýza pro {new_filename}", xbmc.LOGINFO)

        # Aktualizovat last_filename.txt
        with open(LAST_FILENAME_FILE, "w", encoding="utf-8") as f:
            f.write(new_filename)
        xbmc.log(f"[Smycky] Aktualizován last_filename.txt: {new_filename}", xbmc.LOGINFO)

        # Analýza disku
        stats = analyze_disk_usage()
        if stats:
            free_space_mb = stats['free_space_mb']
            xbmc.log(f"[Smycky] Stav disku: {stats['media_count']} souborů, {free_space_mb:.1f} MB volných", xbmc.LOGINFO)

            # Cleanup POUZE při nedostatku místa
            if free_space_mb < MIN_FREE_SPACE_MB:
                xbmc.log(f"[Smycky] Nedostatek místa ({free_space_mb:.1f} MB < {MIN_FREE_SPACE_MB} MB), spouštím cleanup", xbmc.LOGWARNING)
                deleted_count, freed_mb = cleanup_old_media(new_filename, MAX_OLD_FILES)

                # Znovu zkontrolovat
                new_stats = analyze_disk_usage()
                if new_stats and new_stats['free_space_mb'] < MIN_FREE_SPACE_MB:
                    xbmc.log(f"[Smycky] VAROVÁNÍ: Stále málo místa ({new_stats['free_space_mb']:.1f}MB)", xbmc.LOGWARNING)
                    show_notification("Varování místa", f"Pouze {new_stats['free_space_mb']:.1f}MB volných", xbmcgui.NOTIFICATION_WARNING)
            else:
                xbmc.log(f"[Smycky] Dostatek místa, soubory zachovány pro playlisty", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při post-download analýze: {e}", xbmc.LOGERROR)

# ======= FTP FUNKCE =======

def get_remote_file_info(host, user, password, path, filename):
    """Získá datum poslední úpravy a velikost souboru na FTP serveru s detailním error handling."""
    try:
        xbmc.log(f"[Smycky] Připojuji se k FTP serveru {host}...", xbmc.LOGINFO)
        
        ftp = FTP(host)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        
        # Pokusit se získat velikost souboru
        try:
            size = ftp.size(path + filename)
        except Exception as e:
            xbmc.log(f"[Smycky] Chyba při získávání velikosti souboru {filename}: {str(e)}", xbmc.LOGERROR)
            ftp.quit()
            return None, None
        
        # Pokusit se získat datum úpravy
        try:
            modified_time = ftp.sendcmd("MDTM " + path + filename)[4:].strip()
            remote_timestamp = time.mktime(datetime.strptime(modified_time, "%Y%m%d%H%M%S").timetuple())
        except Exception as e:
            xbmc.log(f"[Smycky] Chyba při získávání data úpravy souboru {filename}: {str(e)}", xbmc.LOGERROR)
            ftp.quit()
            return None, None
        
        ftp.quit()
        
        xbmc.log(f"[Smycky] FTP info úspěšně získáno - velikost: {size/1024/1024:.1f}MB, datum: {datetime.fromtimestamp(remote_timestamp).strftime('%Y-%m-%d %H:%M')}", xbmc.LOGINFO)
        return remote_timestamp, size
        
    except Exception as e:
        # Rozlišit typy chyb pro lepší diagnostiku
        error_msg = str(e).lower()
        
        if "authentication" in error_msg or "login" in error_msg or "530" in error_msg:
            xbmc.log(f"[Smycky] CHYBA AUTENTIFIKACE FTP: Špatné uživatelské jméno nebo heslo pro {host}", xbmc.LOGERROR)
            show_notification("Chyba FTP", "Špatné přihlašovací údaje k FTP serveru", xbmcgui.NOTIFICATION_ERROR)
        elif "timeout" in error_msg or "timed out" in error_msg:
            xbmc.log(f"[Smycky] CHYBA TIMEOUT FTP: Server {host} neodpovídá", xbmc.LOGERROR)
            show_notification("Chyba FTP", "FTP server neodpovídá (timeout)", xbmcgui.NOTIFICATION_ERROR)
        elif "refused" in error_msg or "connection" in error_msg:
            xbmc.log(f"[Smycky] CHYBA PŘIPOJENÍ FTP: Nelze se připojit k {host}", xbmc.LOGERROR)
            show_notification("Chyba FTP", "Nelze se připojit k FTP serveru", xbmcgui.NOTIFICATION_ERROR)
        elif "not found" in error_msg or "550" in error_msg:
            xbmc.log(f"[Smycky] CHYBA SOUBOR FTP: Soubor {filename} nebyl nalezen na serveru", xbmc.LOGERROR)
            show_notification("Chyba FTP", f"Soubor {filename} nenalezen na serveru", xbmcgui.NOTIFICATION_ERROR)
        else:
            xbmc.log(f"[Smycky] OBECNÁ CHYBA FTP při připojení k {host}: {str(e)}", xbmc.LOGERROR)
            show_notification("Chyba FTP", f"Obecná chyba FTP: {str(e)[:50]}", xbmcgui.NOTIFICATION_ERROR)
        
        return None, None

def get_local_file_info(path):
    """Získá datum poslední úpravy a velikost lokálního souboru."""
    if os.path.exists(path):
        return os.path.getmtime(path), os.path.getsize(path)
    return 0, 0

def download_file(host, user, password, path, filename, local_path):
    """Bezpečně stáhne soubor z FTP po blocích s vylepšenou kontrolou místa na disku."""
    
    # 1. Nejdříve získat velikost souboru pro kontrolu místa
    try:
        ftp = FTP(host)
        ftp.login(user, password)
        ftp.voidcmd("TYPE I")
        remote_size = ftp.size(path + filename)
        ftp.quit()
        xbmc.log(f"[Smycky] Vzdálený soubor {filename}: {remote_size / (1024*1024):.1f} MB", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Nelze získat velikost souboru pro kontrolu místa: {e}", xbmc.LOGERROR)
        remote_size = None
    
    # 2. Vylepšená kontrola místa před stahováním
    if not check_disk_space_before_download_improved(remote_size, local_path):
        return False
    
    temp_path = local_path + "_tmp"
    block_size = 1024 * 1024  # 1 MB bloky pro detekci výpadku internetu

    try:
        show_notification("Stahování", "Probíhá stahování souboru (FTP)...", xbmcgui.NOTIFICATION_INFO)
        xbmc.log(f"[Smycky] Stahuji soubor z FTP {host}:{path}{filename} do {temp_path}", xbmc.LOGINFO)

        with open(temp_path, "wb") as out_file:
            # Nastavíme timeout připojení
            ftp = FTP()
            ftp.connect(host, timeout=30)  # Timeout 30 sekund
            ftp.login(user, password)

            # Získat velikost souboru pro notifikace
            ftp.voidcmd("TYPE I")
            file_size = ftp.size(path + filename)
            downloaded = 0
            last_shown_mb = 0

            def write_block(block):
                nonlocal downloaded, last_shown_mb
                try:
                    out_file.write(block)
                    downloaded += len(block)

                    downloaded_mb = downloaded / (1024 * 1024)
                    total_mb = file_size / (1024 * 1024) if file_size > 0 else 0

                    # Aktualizace notifikace pouze každých 40 MB + info o volném místě
                    if downloaded_mb - last_shown_mb >= 40:
                        free_mb = get_disk_space_mb(VIDEO_DIR)
                        show_notification("Stahování", f"Staženo: {downloaded_mb:.1f}/{total_mb:.1f} MB (volné: {free_mb:.0f} MB)", xbmcgui.NOTIFICATION_INFO)
                        last_shown_mb = downloaded_mb

                except Exception as e:
                    xbmc.log(f"[Smycky] Chyba zápisu bloku během stahování: {str(e)}", xbmc.LOGERROR)
                    raise e  # Vyvolá výjimku pro ukončení retrbinary

            # Spustíme stahování s blokovým zápisem
            ftp.retrbinary("RETR " + path + filename, write_block)
            ftp.quit()

        # Ověření, že soubor existuje a není prázdný
        if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
            # Přepsání původního souboru novým
            shutil.move(temp_path, local_path)
            
            actual_size_mb = get_file_size_mb(local_path)
            show_notification("Stahování dokončeno", f"Soubor úspěšně aktualizován ({actual_size_mb:.1f} MB)", xbmcgui.NOTIFICATION_INFO)
            xbmc.log(f"[Smycky] Soubor {local_path} byl úspěšně aktualizován ({actual_size_mb:.1f} MB)", xbmc.LOGINFO)
            
            # 3. Po úspěšném stažení provést vylepšené čištění
            smart_cleanup_after_download_improved(filename)
            
            return True
        else:
            raise ValueError("Stažený soubor je prázdný!")

    except Exception as e:
        # Pokud dojde k chybě (např. výpadek internetu), dočasný soubor odstraníme
        if os.path.exists(temp_path):
            os.remove(temp_path)

        error_message = f"Nepodařilo se stáhnout soubor: {str(e)}"
        show_notification("Chyba", error_message, xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[Smycky] Chyba při stahování z FTP: {str(e)}", xbmc.LOGERROR)
        return False

# ======= PŘEHRÁVÁNÍ A RESTART FUNKCE =======

def set_current_playing(filename):
    """Zapíše aktuálně přehrávaný/zobrazovaný soubor pro sdílení s service.dohled."""
    try:
        with open(CURRENT_PLAYING_FILE, 'w') as f:
            f.write(filename)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při zápisu current_playing: {e}", xbmc.LOGERROR)

def clear_current_playing():
    """Smaže info o aktuálně přehrávaném souboru."""
    try:
        if os.path.exists(CURRENT_PLAYING_FILE):
            os.remove(CURRENT_PLAYING_FILE)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při mazání current_playing: {e}", xbmc.LOGERROR)

# ======= FUNKCE PRO PŘEHRÁVÁNÍ MÉDIÍ =======

def ShowImage(image_path, display_time=None):
    """Zobrazí jeden obrázek. Pokud display_time=None, zobrazí nekonečně."""
    if not os.path.exists(image_path):
        xbmc.log(f"[Smycky] Obrázek nenalezen: {image_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(image_path)
    xbmc.log(f"[Smycky] Zobrazuji obrázek: {filename}", xbmc.LOGINFO)

    # OPRAVA: Použít ShowPicture přímo pro konkrétní soubor
    # SlideShow s folderem zobrazoval první soubor abecedně, ne požadovaný
    xbmc.executebuiltin(f'ShowPicture({image_path})')
    set_current_playing(filename)  # Sdílet s service.dohled pro monitoring
    show_notification("Obrázek", f"Zobrazen: {filename}")

    return True


def ShowSlideshow(image_list, display_time=10):
    """Spustí slideshow s více obrázky.

    Args:
        image_list: Seznam názvů souborů obrázků
        display_time: Doba zobrazení každého obrázku v sekundách
    """
    if not image_list:
        xbmc.log("[Smycky] Prázdný seznam obrázků pro slideshow", xbmc.LOGERROR)
        return False

    # Nastavit dobu zobrazení v Kodi
    try:
        xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {"setting": "slideshow.staytime", "value": display_time},
            "id": 1
        }))
        xbmc.log(f"[Smycky] Nastavena doba slideshow: {display_time}s", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při nastavování doby slideshow: {e}", xbmc.LOGWARNING)

    # Ověřit existenci souborů
    valid_images = []
    for filename in image_list:
        filepath = os.path.join(VIDEO_DIR, filename)
        if os.path.exists(filepath) and is_image_file(filename):
            valid_images.append(filepath)
            xbmc.log(f"[Smycky] Slideshow: přidán {filename}", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Smycky] Slideshow: soubor nenalezen nebo není obrázek: {filename}", xbmc.LOGWARNING)

    if not valid_images:
        xbmc.log("[Smycky] Žádné platné obrázky pro slideshow", xbmc.LOGERROR)
        return False

    # Spustit slideshow
    xbmc.executebuiltin(f'SlideShow({VIDEO_DIR},notrandom,recursive)')
    show_notification("Slideshow", f"Spuštěno {len(valid_images)} obrázků")
    xbmc.log(f"[Smycky] Slideshow spuštěna s {len(valid_images)} obrázky", xbmc.LOGINFO)
    return True


def RepeatMixedPlaylist(playlist_items, default_image_time=10):
    """Přehraje mix videí a obrázků ve smyčce.

    Tato funkce spravuje vlastní smyčku pro střídání videí a obrázků:
    - Video: přehraje se celé
    - Obrázek: zobrazí se po dobu specifikovanou v položce nebo default_image_time

    Args:
        playlist_items: Seznam dict s 'filename' a 'duration' (z parse_playlist_string)
                        nebo seznam stringů (zpětná kompatibilita)
        default_image_time: Výchozí doba zobrazení obrázků v sekundách
    """
    if not playlist_items:
        xbmc.log("[Smycky] Prázdný seznam pro mixed playlist", xbmc.LOGERROR)
        return False

    # Rozdělit na videa a obrázky a ověřit existenci
    valid_files = []
    for item in playlist_items:
        # Podpora starého formátu (string) i nového (dict)
        if isinstance(item, str):
            filename = item
            custom_duration = None
        else:
            filename = item.get('filename', '')
            custom_duration = item.get('duration')

        filepath = os.path.join(VIDEO_DIR, filename)
        if os.path.exists(filepath):
            media_type = get_media_type(filename)
            if media_type:
                # Pro obrázky použít custom duration, jinak default
                if media_type == 'image':
                    duration = custom_duration if custom_duration is not None else default_image_time
                else:
                    duration = None  # Videa se přehrají celá

                valid_files.append({
                    'filename': filename,
                    'path': filepath,
                    'type': media_type,
                    'duration': duration
                })
                duration_info = f", {duration}s" if duration else ""
                xbmc.log(f"[Smycky] Mixed playlist: přidán {filename} ({media_type}{duration_info})", xbmc.LOGINFO)
            else:
                xbmc.log(f"[Smycky] Mixed playlist: nepodporovaný formát {filename}", xbmc.LOGWARNING)
        else:
            xbmc.log(f"[Smycky] Mixed playlist: soubor nenalezen {filename}", xbmc.LOGWARNING)

    if not valid_files:
        xbmc.log("[Smycky] Žádné platné soubory pro mixed playlist", xbmc.LOGERROR)
        return False

    video_count = sum(1 for f in valid_files if f['type'] == 'video')
    image_count = sum(1 for f in valid_files if f['type'] == 'image')

    show_notification("Mix playlist", f"Spuštěno: {video_count} videí, {image_count} obrázků")
    xbmc.log(f"[Smycky] Mixed playlist: {video_count} videí, {image_count} obrázků", xbmc.LOGINFO)

    # Spustit smyčku přehrávání v samostatném vlákně
    def playback_loop():
        player = xbmc.Player()
        current_index = 0

        # Proměnná pro sledování zda máme ukončit playlist
        stop_requested = False

        def check_stop_flag():
            """Kontroluje zda service.dohled signalizuje zastavení playlistu."""
            nonlocal stop_requested
            if os.path.exists(STOP_SMYCKY_FLAG):
                xbmc.log("[Smycky] Detekován STOP flag od service.dohled, ukončuji playlist", xbmc.LOGINFO)
                try:
                    os.remove(STOP_SMYCKY_FLAG)
                except:
                    pass
                stop_requested = True
                return True
            return False

        while not xbmc.Monitor().abortRequested() and not stop_requested:
            # Kontrola stop flagu na začátku každé iterace
            if check_stop_flag():
                xbmc.log("[Smycky] Playlist ukončen na základě STOP flagu", xbmc.LOGINFO)
                break

            file_info = valid_files[current_index]
            filename = file_info['filename']
            filepath = file_info['path']
            media_type = file_info['type']
            duration = file_info['duration']

            duration_info = f", {duration}s" if duration else ""
            xbmc.log(f"[Smycky] Mixed playlist: přehrávám {filename} ({media_type}{duration_info})", xbmc.LOGINFO)

            if media_type == 'video':
                # Přehrát video
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                playlist.add(filepath)
                player.play(playlist)

                # Čekat na dokončení videa s kontrolou stop flagu
                time.sleep(2)  # Počkat na start
                while player.isPlaying() and not xbmc.Monitor().abortRequested() and not stop_requested:
                    if check_stop_flag():
                        player.stop()
                        break
                    time.sleep(1)

            elif media_type == 'image':
                # Zobrazit obrázek na určenou dobu (custom nebo default)
                xbmc.executebuiltin(f'ShowPicture({filepath})')
                # Čekat s kontrolou stop flagu každou sekundu
                for _ in range(duration):
                    if check_stop_flag() or xbmc.Monitor().abortRequested():
                        xbmc.executebuiltin('Action(Back)')
                        break
                    time.sleep(1)
                else:
                    # Zavřít obrázek pouze pokud jsme neopustili smyčku předčasně
                    if not stop_requested:
                        xbmc.executebuiltin('Action(Back)')

            # Pokud byl stop požadován během přehrávání, ukončit
            if stop_requested:
                xbmc.log("[Smycky] Playlist ukončen (stop během přehrávání)", xbmc.LOGINFO)
                break

            # Další soubor
            current_index = (current_index + 1) % len(valid_files)

    # Spustit ve vlákně
    playback_thread = threading.Thread(target=playback_loop, daemon=True)
    playback_thread.start()
    return True


def RepeatVideo(local_file):
    """Spustí přehrávání videa ve smyčce."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    playlist.add(local_file)
    xbmc.Player().play(playlist)
    xbmc.executebuiltin("PlayerControl(RepeatOne)")
    filename = os.path.basename(local_file)
    set_current_playing(filename)  # Sdílet s service.dohled pro monitoring
    show_notification("Přehrávání", f"Smyčka: {filename}")


def play_media_file(file_path, image_display_time=DEFAULT_IMAGE_DISPLAY_TIME):
    """Přehraje soubor podle jeho typu - video nebo obrázek.

    Args:
        file_path: Cesta k souboru
        image_display_time: Doba zobrazení pro obrázky (None = nekonečně)

    Returns:
        True pokud se podařilo spustit přehrávání
    """
    if not os.path.exists(file_path):
        xbmc.log(f"[Smycky] Soubor neexistuje: {file_path}", xbmc.LOGERROR)
        return False

    filename = os.path.basename(file_path)
    media_type = get_media_type(filename)

    if media_type == 'video':
        RepeatVideo(file_path)
        return True
    elif media_type == 'image':
        # Pro samostatný obrázek zobrazit nekonečně
        return ShowImage(file_path, display_time=None)
    else:
        xbmc.log(f"[Smycky] Nepodporovaný typ souboru: {filename}", xbmc.LOGERROR)
        return False


def RepeatPlaylist(file_list):
    """Spustí přehrávání playlistu ve smyčce."""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    valid_count = 0
    for filename in file_list:
        local_path = os.path.join(VIDEO_DIR, filename)
        if os.path.exists(local_path):
            playlist.add(local_path)
            valid_count += 1
            xbmc.log(f"[Smycky] Playlist: přidán {filename}", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Smycky] Playlist: soubor {filename} nenalezen", xbmc.LOGWARNING)

    if valid_count > 0:
        xbmc.Player().play(playlist)
        xbmc.executebuiltin("PlayerControl(RepeatAll)")
        show_notification("Playlist", f"Spuštěno {valid_count} souborů")
        xbmc.log(f"[Smycky] Playlist spuštěn s {valid_count} soubory", xbmc.LOGINFO)
        return True
    else:
        xbmc.log("[Smycky] Playlist: žádné platné soubory", xbmc.LOGERROR)
        return False

def was_reboot_today():
    """Zjistí, zda už dnes proběhl restart."""
    if os.path.exists(REBOOT_TRACK_FILE):
        with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() == datetime.now().strftime('%Y-%m-%d')
    return False

def mark_reboot_done():
    """Uloží aktuální datum jako poslední provedený restart."""
    with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
        f.write(datetime.now().strftime('%Y-%m-%d'))

def schedule_random_reboot():
    """Naplánuje náhodný restart mezi 21:00 a 5:00 v samostatném vlákně, každý den znovu."""

    def reboot_task():
        """Funkce běžící v samostatném vlákně, která plánuje restart."""
        now = datetime.now()

        # Načteme poslední restart a naplánovaný restart ze souboru
        last_reboot_date = "Žádný"
        planned_reboot_date = "Žádný"

        if os.path.exists(REBOOT_TRACK_FILE):
            with open(REBOOT_TRACK_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if len(lines) >= 2:
                    last_reboot_date = lines[0].strip().replace("Poslední restart: ", "")
                    planned_reboot_date = lines[1].strip().replace("Naplánovaný restart: ", "")

        # Pokud byl plánovaný restart v minulosti, znamená to, že výpadek elektřiny restart přerušil
        if planned_reboot_date != "Žádný":
            planned_time = datetime.strptime(planned_reboot_date, "%Y-%m-%d %H:%M:%S")
            if planned_time < now:
                xbmc.log(f"[Smycky] Detekován neprovedený restart ({planned_reboot_date}), plánování nového restartu.", xbmc.LOGWARNING)
                last_reboot_date = "Neprovedeno"  # Ověříme, že starý restart nebyl proveden

        # Nastavení časového okna mezi 21:00 a 05:00
        start_time = now.replace(hour=21, minute=0, second=0)
        end_time = now.replace(hour=4, minute=59, second=0) + timedelta(days=1)

        # Pokud už je po 05:00, naplánujeme restart na další noc
        if now >= end_time or last_reboot_date == datetime.now().strftime('%Y-%m-%d'):
            start_time += timedelta(days=1)
            end_time += timedelta(days=1)

        # Generování náhodného času mezi 21:00 a 05:00
        while True:
            random_reboot_time = start_time + timedelta(minutes=random.randint(0, int((end_time - start_time).total_seconds() / 60)))
            if random_reboot_time > now:  # Ověříme, že restart není naplánován na aktuální čas
                break

        restart_date_time = random_reboot_time.strftime('%Y-%m-%d %H:%M:%S')

        # Zápis informací do souboru reboot_log.txt
        with open(REBOOT_TRACK_FILE, "w", encoding="utf-8") as f:
            f.write(f"Poslední restart: {last_reboot_date}\nNaplánovaný restart: {restart_date_time}")

        log_message = f"Poslední restart: {last_reboot_date} | Naplánovaný restart: {restart_date_time}"
        xbmc.log(f"[Smycky] {log_message}", xbmc.LOGINFO)
        show_notification("Naplánovaný restart", log_message)

        # Čekání na restart
        time.sleep((random_reboot_time - now).total_seconds())
        perform_reboot(restart_date_time)

    threading.Thread(target=reboot_task, daemon=True).start()

def perform_reboot(restart_date_time):
    """Provede restart zařízení a zaznamená ho do souboru."""
    mark_reboot_done()
    xbmc.log("[Smycky] Provádím restart zařízení...", xbmc.LOGINFO)
    show_notification("Restart", f"Zařízení se nyní restartuje ({restart_date_time}).", xbmcgui.NOTIFICATION_WARNING)
    xbmc.executebuiltin("Reboot")

# ======= HLAVNÍ FUNKCE =======
def main():
    """Hlavní funkce s vylepšenou fallback logikou."""
    xbmc.log("[Smycky] === Spuštění doplňku Smycky ===", xbmc.LOGINFO)

    # PRVNÍ KROK: Počkat na synchronizaci času od doplňku Dohled
    wait_for_time_sync()

    # Zápis verze doplňku (zachovat)
    try:
        version = xbmcaddon.Addon().getAddonInfo('version')
        with open("/storage/.kodi/userdata/smycky_version.txt", "w", encoding="utf-8") as f:
            f.write(version)
        xbmc.log(f"[Smycky] Spuštěna verze {version}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při zápisu verze: {e}", xbmc.LOGERROR)

    # Zobrazit počáteční analýzu disku (zachovat)
    try:
        stats = analyze_disk_usage()
        if stats:
            free_space_mb = stats['free_space_mb']
            xbmc.log(f"[Smycky] Počáteční stav disku: {stats['media_count']} souborů ({stats['video_count']} videí, {stats['image_count']} obrázků), {stats['total_size_mb']:.1f}MB obsazeno, {free_space_mb:.1f}MB volných", xbmc.LOGINFO)

            if free_space_mb < MIN_FREE_SPACE_MB:
                show_notification("Varování místa", f"Málo místa na disku: {free_space_mb:.1f} MB", xbmcgui.NOTIFICATION_WARNING)
            else:
                show_notification("Info disku", f"Volné místo: {free_space_mb:.0f} MB")
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při počáteční analýze disku: {e}", xbmc.LOGERROR)

    # 1️⃣ Načíst locality z konfigurace
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            config = json.load(f)
            locality = config.get("locality")
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba načítání config.json: {e}", xbmc.LOGERROR)
        show_notification("Chyba", "Nelze načíst konfiguraci.")
        # I při chybě konfigurace zkusit fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            play_media_file(fallback_file)
            schedule_random_reboot()
        return

    if not locality:
        show_notification("Chyba", "Locality nenalezena v konfiguraci.")
        xbmc.log("[Smycky] Locality nenalezena v konfiguraci.", xbmc.LOGERROR)
        # I při chybě locality zkusit fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            play_media_file(fallback_file)
            schedule_random_reboot()
        return

    xbmc.log(f"[Smycky] Načtena locality: {locality}", xbmc.LOGINFO)

    # 2️⃣ Kontrola internetu a načtení FTP konfigurace
    if not is_internet_available():
        xbmc.log("[Smycky] Internet není dostupný.", xbmc.LOGWARNING)
        show_notification("Offline režim", "Internet není dostupný, používám lokální soubor.", xbmcgui.NOTIFICATION_WARNING)
        # Bez internetu rovnou fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            play_media_file(fallback_file)
            schedule_random_reboot()
            return
        else:
            show_notification("Chyba", "Bez internetu a žádný lokální soubor není dostupný.")
            xbmc.log("[Smycky] KRITICKÉ: Bez internetu a žádný lokální soubor.", xbmc.LOGERROR)
            return

    # Pokus o načtení FTP konfigurace (potřebujeme FTP credentials)
    ftp_config = fetch_ftp_config(locality)
    if not ftp_config:
        xbmc.log("[Smycky] Nelze načíst FTP konfiguraci (SSL nebo jiná chyba).", xbmc.LOGWARNING)
        show_notification("Chyba FTP konfigurace", "Používám lokální soubor.")
        # Chyba FTP konfigurace (např. SSL) -> fallback
        fallback_file = find_best_fallback_file()
        if fallback_file:
            play_media_file(fallback_file)
            schedule_random_reboot()
            return
        else:
            show_notification("Chyba", "Chyba FTP konfigurace a žádný lokální soubor.")
            xbmc.log("[Smycky] KRITICKÉ: Chyba FTP konfigurace a žádný lokální soubor.", xbmc.LOGERROR)
            return

    # FTP konfigurace načtena úspěšně
    ftp_host = ftp_config["ftp_host"]
    ftp_user = ftp_config["ftp_user"]
    ftp_pass = ftp_config["ftp_pass"]
    ftp_path = ftp_config["ftp_path"]
    file_name = ftp_config["file_name"]  # Výchozí z locality
    file_source = "locality"
    # Načtení doby zobrazení obrázků z API (nebo výchozí hodnota)
    image_display_time = ftp_config.get("image_display_time", DEFAULT_IMAGE_DISPLAY_TIME)
    xbmc.log(f"[Smycky] Doba zobrazení obrázků: {image_display_time}s", xbmc.LOGINFO)

    # 2.5️⃣ Kontrola device-specific override
    device_id = get_device_id()
    is_playlist = False
    playlist_files = []

    if device_id:
        xbmc.log(f"[Smycky] Device ID: {device_id}", xbmc.LOGINFO)
        expected_file, source = fetch_expected_file(device_id)
        if expected_file and source == "device":
            # Device override má přednost
            file_name = expected_file
            file_source = "device"
            xbmc.log(f"[Smycky] Použit device override: {file_name}", xbmc.LOGINFO)
        elif expected_file:
            # Použít filename z API (může být jiný než v FTP konfiguraci)
            file_name = expected_file
            xbmc.log(f"[Smycky] Soubor z API (locality): {file_name}", xbmc.LOGINFO)

    # 2.6️⃣ Kontrola, zda je to playlist (formát: "playlist:file1.mp4,file2.jpg:15,file3.png:5")
    # Funguje pro device override I pro nastavení lokality
    # Nový formát podporuje individuální dobu zobrazení pro obrázky (soubor:sekundy)
    playlist_items = []  # Seznam dict s 'filename' a 'duration'

    if file_name and file_name.startswith("playlist:"):
        is_playlist = True
        playlist_str = file_name[9:]  # Odstranit "playlist:" prefix
        playlist_items = parse_playlist_string(playlist_str, image_display_time)
        # Pro zpětnou kompatibilitu a analýzu - seznam názvů souborů
        playlist_files = [item['filename'] for item in playlist_items]
        xbmc.log(f"[Smycky] Detekován playlist s {len(playlist_items)} položkami (zdroj: {file_source})", xbmc.LOGINFO)
        show_notification(f"Playlist ({file_source})", f"{len(playlist_items)} souborů")

    # Pokud je to playlist, přehrát ho přímo (lokální soubory)
    if is_playlist and playlist_items:
        xbmc.log(f"[Smycky] Spouštím playlist: {[item['filename'] for item in playlist_items]}", xbmc.LOGINFO)

        # Analyzovat obsah playlistu
        video_files_in_playlist = [item for item in playlist_items if is_video_file(item['filename'])]
        image_files_in_playlist = [item for item in playlist_items if is_image_file(item['filename'])]

        has_videos = len(video_files_in_playlist) > 0
        has_images = len(image_files_in_playlist) > 0

        playlist_success = False

        if has_videos and has_images:
            # Mix videí a obrázků - předat položky s individuálními časy
            xbmc.log(f"[Smycky] Mix playlist: {len(video_files_in_playlist)} videí, {len(image_files_in_playlist)} obrázků", xbmc.LOGINFO)
            playlist_success = RepeatMixedPlaylist(playlist_items, image_display_time)
        elif has_images and not has_videos:
            # Pouze obrázky - slideshow (zatím bez individuálních časů)
            xbmc.log(f"[Smycky] Slideshow: {len(image_files_in_playlist)} obrázků", xbmc.LOGINFO)
            playlist_success = ShowSlideshow([item['filename'] for item in image_files_in_playlist], image_display_time)
        elif has_videos and not has_images:
            # Pouze videa - klasický video playlist
            xbmc.log(f"[Smycky] Video playlist: {len(video_files_in_playlist)} videí", xbmc.LOGINFO)
            playlist_success = RepeatPlaylist([item['filename'] for item in video_files_in_playlist])

        if playlist_success:
            schedule_random_reboot()
            return
        else:
            # Fallback pokud playlist selže
            xbmc.log("[Smycky] Playlist selhal, zkouším fallback", xbmc.LOGWARNING)
            fallback_file = find_best_fallback_file()
            if fallback_file:
                play_media_file(fallback_file, image_display_time)
                schedule_random_reboot()
            return

    xbmc.log(f"[Smycky] FTP konfigurace načtena - host: {ftp_host}, soubor: {file_name} (zdroj: {file_source})", xbmc.LOGINFO)

    local_file = f"/storage/videos/{file_name}"

    # 3️⃣ Kontrola aktualizace souboru přes FTP
    show_notification("Aktualizace", "Kontroluji aktualizace souboru...")
    remote_timestamp, remote_size = get_remote_file_info(ftp_host, ftp_user, ftp_pass, ftp_path, file_name)
    local_timestamp, local_size = get_local_file_info(local_file)

    # Pokud je chyba FTP (SSL nebo jiná)
    if remote_timestamp is None or remote_size is None:
        xbmc.log("[Smycky] Chyba při připojení k FTP serveru.", xbmc.LOGWARNING)
        show_notification("Chyba FTP", "Nelze se připojit k serveru. Používám lokální soubor.", xbmcgui.NOTIFICATION_WARNING)
        # FTP chyba -> použít lokální soubor nebo fallback
        target_file = get_best_available_file(local_file)
        if target_file:
            play_media_file(target_file, image_display_time)
            schedule_random_reboot()
            return
        else:
            show_notification("Kritická chyba", "Chyba FTP a není dostupný žádný soubor.", xbmcgui.NOTIFICATION_ERROR)
            xbmc.log("[Smycky] KRITICKÉ: Chyba FTP a žádný dostupný soubor.", xbmc.LOGERROR)
            return

    # FTP připojení OK - kontrola aktualizace
    update_needed = False
    if remote_timestamp > local_timestamp or remote_size != local_size:
        update_needed = True
        
        if remote_timestamp > local_timestamp:
            time_diff = remote_timestamp - local_timestamp
            xbmc.log(f"[Smycky] Vzdálený soubor je novější o {time_diff/3600:.1f} hodin", xbmc.LOGINFO)
        if remote_size != local_size:
            size_diff_mb = (remote_size - local_size) / (1024 * 1024)
            xbmc.log(f"[Smycky] Rozdíl velikosti: {size_diff_mb:+.1f} MB", xbmc.LOGINFO)

    if update_needed:
        xbmc.log("[Smycky] Novější soubor nalezen, pokusím se stáhnout.", xbmc.LOGINFO)
        
        size_mb = remote_size / (1024 * 1024)
        free_mb = get_disk_space_mb(VIDEO_DIR)
        show_notification("Připravuji stahování", f"Nový soubor: {size_mb:.1f} MB, Volné místo: {free_mb:.1f} MB")
        xbmc.log(f"[Smycky] Připravuji stažení: {size_mb:.1f} MB (volné místo: {free_mb:.1f} MB)", xbmc.LOGINFO)
        
        if download_file(ftp_host, ftp_user, ftp_pass, ftp_path, file_name, local_file):
            xbmc.log("[Smycky] Soubor úspěšně aktualizován.", xbmc.LOGINFO)
        else:
            xbmc.log("[Smycky] Stahování selhalo, použiji nejlepší dostupný soubor.", xbmc.LOGWARNING)
    else:
        show_notification("Aktualizace", "Soubor je aktuální.")
        xbmc.log("[Smycky] Soubor je aktuální.", xbmc.LOGINFO)
        # Cleanup POUZE když je málo místa na disku
        free_space = get_disk_space_mb(VIDEO_DIR)
        if free_space < MIN_FREE_SPACE_MB:
            xbmc.log(f"[Smycky] Málo místa ({free_space:.1f} MB < {MIN_FREE_SPACE_MB} MB), spouštím cleanup", xbmc.LOGWARNING)
            cleanup_old_media(file_name, MAX_OLD_FILES)
        else:
            xbmc.log(f"[Smycky] Dostatek místa ({free_space:.1f} MB), soubory zachovány pro playlisty", xbmc.LOGINFO)

    # 4️⃣ ROBUSTNÍ VÝBĚR SOUBORU PRO PŘEHRÁNÍ
    target_file = get_best_available_file(local_file)

    if target_file:
        actual_size_mb = get_file_size_mb(target_file)
        media_type = get_media_type(os.path.basename(target_file))
        xbmc.log(f"[Smycky] Spouštím přehrávání: {target_file} ({actual_size_mb:.1f} MB, typ: {media_type})", xbmc.LOGINFO)
        play_media_file(target_file, image_display_time)
    else:
        show_notification("Kritická chyba", "Žádný dostupný soubor ke spuštění.")
        xbmc.log("[Smycky] KRITICKÉ: Nelze najít žádný přehratelný soubor.", xbmc.LOGERROR)
        return

    # 5️⃣ Naplánovat restart
    schedule_random_reboot()

    # 6️⃣ Finální statistiky
    try:
        final_stats = analyze_disk_usage()
        if final_stats:
            xbmc.log(f"[Smycky] Finální stav: {final_stats['media_count']} souborů ({final_stats['video_count']} videí, {final_stats['image_count']} obrázků), {final_stats['free_space_mb']:.1f}MB volných", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při finálních statistikách: {e}", xbmc.LOGERROR)

def find_best_fallback_file():
    """Najde nejlepší fallback soubor podle priority: last_filename -> nejnovější -> libovolný."""
    fallback_file = None

    try:
        # 1. Priorita: last_filename.txt
        if os.path.exists(LAST_FILENAME_FILE):
            with open(LAST_FILENAME_FILE, encoding="utf-8") as f:
                last_file = f.read().strip()
                possible = f"/storage/videos/{last_file}"
                if os.path.exists(possible):
                    fallback_file = possible
                    xbmc.log(f"[Smycky] Fallback z last_filename: {fallback_file}", xbmc.LOGINFO)
                    return fallback_file

        # 2. Priorita: najít nejnovější podporovaný soubor (video nebo obrázek)
        media_files = []
        for filename in os.listdir("/storage/videos/"):
            if is_supported_file(filename):
                filepath = os.path.join("/storage/videos/", filename)
                mtime = os.path.getmtime(filepath)
                media_files.append((filepath, mtime, get_media_type(filename)))

        if media_files:
            # Seřadit podle času úpravy (nejnovější první), preferovat videa
            media_files.sort(key=lambda x: (x[2] != 'video', -x[1]))  # videa první, pak podle času
            fallback_file = media_files[0][0]
            xbmc.log(f"[Smycky] Fallback nejnovější soubor: {fallback_file}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při hledání fallback souboru: {e}", xbmc.LOGERROR)

    return fallback_file
    
def get_best_available_file(preferred_file):
    """Najde nejlepší dostupný soubor pro přehrání s robustní fallback logikou."""

    # 1. Priorita: preferovaný soubor (většinou local_file)
    if preferred_file and os.path.exists(preferred_file) and os.path.getsize(preferred_file) > 0:
        xbmc.log(f"[Smycky] Používám preferovaný soubor: {preferred_file}", xbmc.LOGINFO)
        return preferred_file

    # 2. Priorita: fallback podle last_filename
    fallback_file = find_best_fallback_file()
    if fallback_file and os.path.exists(fallback_file) and os.path.getsize(fallback_file) > 0:
        xbmc.log(f"[Smycky] Používám fallback soubor: {fallback_file}", xbmc.LOGINFO)
        return fallback_file

    # 3. Priorita: jakýkoli podporovaný soubor ve složce (nouzové řešení)
    try:
        if os.path.exists("/storage/videos/"):
            for filename in os.listdir("/storage/videos/"):
                if is_supported_file(filename):
                    filepath = os.path.join("/storage/videos/", filename)
                    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
                        xbmc.log(f"[Smycky] Používám nouzový soubor: {filepath}", xbmc.LOGWARNING)
                        return filepath
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba při hledání nouzového souboru: {e}", xbmc.LOGERROR)

    # 4. Žádný soubor nenalezen
    xbmc.log("[Smycky] Žádný přehratelný soubor nenalezen", xbmc.LOGERROR)
    return None

# Spustí hlavní funkci
if __name__ == "__main__":
    main()