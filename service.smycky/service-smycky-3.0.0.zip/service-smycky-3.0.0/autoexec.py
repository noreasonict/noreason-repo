"""
service.smycky 2.6.0 - Proxy Mode

Tato verze detekuje service.dohled 2.7.0+ a pokud je nainstalován,
přejde do "proxy mode" - nedělá nic, protože veškerou funkcionalitu
přebírá service.dohled.

Pokud je nainstalován starší service.dohled (< 2.7.0), spustí se
původní logika ze smycky_legacy.py pro zpětnou kompatibilitu.
"""

import xbmc
import xbmcaddon
import time

# Minimální verze service.dohled která obsahuje startup přehrávání
DOHLED_MIN_VERSION = "2.7.0"


def version_compare(v1, v2):
    """
    Porovná verze. Vrací True pokud v1 >= v2.
    Např: "2.7.0" >= "2.7.0" = True
          "2.6.19" >= "2.7.0" = False
          "2.8.0" >= "2.7.0" = True
    """
    def normalize(v):
        return [int(x) for x in v.split(".")]

    try:
        v1_parts = normalize(v1)
        v2_parts = normalize(v2)

        # Doplnit nulami na stejnou délku
        while len(v1_parts) < len(v2_parts):
            v1_parts.append(0)
        while len(v2_parts) < len(v1_parts):
            v2_parts.append(0)

        return v1_parts >= v2_parts
    except:
        return False


def main():
    """Hlavní funkce - detekce verze service.dohled a rozhodnutí o režimu."""

    xbmc.log("[Smycky] === Spuštění service.smycky 2.6.0 ===", xbmc.LOGINFO)
    xbmc.log("[Smycky] Kontroluji verzi service.dohled...", xbmc.LOGINFO)

    # Počkat na načtení addonů (Kodi potřebuje chvíli při startu)
    time.sleep(5)

    try:
        # Zkusit načíst service.dohled
        dohled_addon = xbmcaddon.Addon('service.dohled')
        dohled_version = dohled_addon.getAddonInfo('version')

        xbmc.log(f"[Smycky] Nalezen service.dohled verze {dohled_version}", xbmc.LOGINFO)

        if version_compare(dohled_version, DOHLED_MIN_VERSION):
            # Nový service.dohled - přejít do proxy mode
            xbmc.log(f"[Smycky] service.dohled {dohled_version} >= {DOHLED_MIN_VERSION}", xbmc.LOGINFO)
            xbmc.log("[Smycky] === PROXY MODE AKTIVOVÁN ===", xbmc.LOGINFO)
            xbmc.log("[Smycky] Přehrávání řídí service.dohled - smycky v proxy mode", xbmc.LOGINFO)

            # Pouze čekat - nic nedělat
            # Service.dohled přebírá veškerou funkcionalitu
            monitor = xbmc.Monitor()
            while not monitor.abortRequested():
                # Periodicky logovat že jsme stále v proxy mode (pro debugging)
                if monitor.waitForAbort(300):  # 5 minut
                    break
                xbmc.log("[Smycky] Proxy mode - aktivní, čekám...", xbmc.LOGINFO)

            xbmc.log("[Smycky] Proxy mode ukončen (Kodi shutdown)", xbmc.LOGINFO)
            return
        else:
            xbmc.log(f"[Smycky] service.dohled {dohled_version} < {DOHLED_MIN_VERSION}", xbmc.LOGWARNING)
            xbmc.log("[Smycky] Starší verze service.dohled - spouštím legacy režim", xbmc.LOGWARNING)

    except Exception as e:
        xbmc.log(f"[Smycky] service.dohled nenalezen nebo chyba: {e}", xbmc.LOGWARNING)
        xbmc.log("[Smycky] Spouštím legacy režim (standardní přehrávání)", xbmc.LOGINFO)

    # Fallback - spustit starou logiku
    xbmc.log("[Smycky] === LEGACY MODE ===", xbmc.LOGINFO)
    try:
        from smycky_legacy import main as legacy_main
        legacy_main()
    except ImportError as e:
        xbmc.log(f"[Smycky] Chyba při importu legacy modulu: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"[Smycky] Chyba v legacy režimu: {e}", xbmc.LOGERROR)


if __name__ == "__main__":
    main()
